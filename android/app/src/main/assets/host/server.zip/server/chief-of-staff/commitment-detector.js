import { createHash } from "node:crypto";
/**
 * Strictly grounded Commitment Detector.
 * Identifies genuine follow-up commitments from calendar descriptions, meeting notes,
 * and email threads without inventing recipients, deadlines, or outcomes.
 */
export class CommitmentDetector {
    /**
     * Detect commitments across aggregated context items.
     */
    detectCommitments(items) {
        const commitments = [];
        for (const item of items) {
            if (item.source === "googlecalendar") {
                const calCommitments = this.detectFromCalendar(item);
                commitments.push(...calCommitments);
            }
            else if (item.source === "gmail") {
                const emailCommitments = this.detectFromEmail(item);
                commitments.push(...emailCommitments);
            }
        }
        return commitments;
    }
    detectFromCalendar(item) {
        const results = [];
        const meta = item.metadata ?? {};
        const content = String(item.content || "");
        const title = String(item.title || "Meeting");
        const eventId = String(meta.eventId || item.id);
        const organizer = String(meta.organizer || "");
        const attendees = Array.isArray(meta.attendees) ? meta.attendees : [];
        // Parse meeting description / notes for explicit commitments
        const commitmentPatterns = [
            /(?:action item|todo|follow[- ]?up)[:\s]+([^.\n]+)/gi,
            /(?:send|share|forward)\s+(?:the\s+)?([^.\n]+?)\s+(?:to|with)\s+([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}|[A-Z][a-z]+)/gi,
            /(?:I will|we will|please)\s+(?:send|email|share|forward)\s+([^.\n]+)/gi,
        ];
        for (const pattern of commitmentPatterns) {
            let match;
            while ((match = pattern.exec(content)) !== null) {
                const matchedText = match[0].trim();
                const detail = (match[1] || "").trim();
                // Recipient resolution
                let recipientEmail;
                let recipientName;
                if (match[2]) {
                    const target = match[2].trim();
                    if (target.includes("@")) {
                        recipientEmail = target;
                    }
                    else {
                        recipientName = target;
                        const matchedAttendee = attendees.find((a) => (a.displayName && a.displayName.toLowerCase().includes(target.toLowerCase())) ||
                            (a.email && a.email.toLowerCase().includes(target.toLowerCase())));
                        if (matchedAttendee?.email) {
                            recipientEmail = matchedAttendee.email;
                        }
                    }
                }
                if (!recipientEmail && attendees.length > 0) {
                    const first = attendees[0];
                    if (first && typeof first === "object" && first.email) {
                        recipientEmail = first.email;
                    }
                    else if (typeof first === "string" && first.includes("@")) {
                        recipientEmail = first;
                    }
                }
                if (!recipientEmail && organizer && organizer.includes("@") && !organizer.includes("unknown")) {
                    recipientEmail = organizer;
                }
                // Deadline extraction (strictly grounded)
                const deadlineMatch = matchedText.match(/(?:by|before|due)\s+([A-Za-z]+,?\s+\d{1,2}(?:st|nd|rd|th)?|\d{4}-\d{2}-\d{2}|friday|monday|tuesday|wednesday|thursday|saturday|sunday|tomorrow)/i);
                const deadline = deadlineMatch ? deadlineMatch[1] : undefined;
                // Attachment query inference (e.g. "pricing tiers", "colab notebook", "report")
                const docMatch = detail.match(/(?:updated\s+)?(?:pricing(?:\s+tiers)?|colab(?:\s+notebook)?|document|report|pdf|deck|presentation|summary)/i);
                const suggestedAttachmentQuery = docMatch ? docMatch[0] : undefined;
                const id = `commit_${createHash("sha256").update(`${eventId}:${matchedText}`).digest("hex").slice(0, 12)}`;
                results.push({
                    id,
                    title: `Follow-up: ${title}`,
                    commitmentText: matchedText,
                    sourceType: "googlecalendar",
                    sourceId: eventId,
                    sourceTimestamp: item.timestamp,
                    provenance: `Google Calendar event "${title}" (${meta.start || item.timestamp})`,
                    evidenceRef: matchedText,
                    confidence: recipientEmail ? 0.95 : 0.7,
                    recipientEmail,
                    recipientName,
                    subject: `Follow-up: ${title}${suggestedAttachmentQuery ? ` - ${suggestedAttachmentQuery}` : ""}`,
                    proposedBody: `Hi,\n\nFollowing up on our meeting "${title}", here is the commitment discussed:\n\n${matchedText}\n\nBest regards,\nAbhay`,
                    deadline,
                    relatedEventId: eventId,
                    suggestedAttachmentQuery,
                });
            }
        }
        return results;
    }
    detectFromEmail(item) {
        const results = [];
        const meta = item.metadata ?? {};
        const content = String(item.content || "");
        const title = String(item.title || "Email");
        const threadId = String(meta.threadId || item.id);
        const rawSender = String(meta.sender || meta.from || "");
        const emailMatch = rawSender.match(/<([^>]+)>/);
        const senderEmail = emailMatch ? emailMatch[1] : (rawSender.includes("@") ? rawSender : undefined);
        // Look for commitments in email text / snippet
        const patterns = [
            /(?:I will|we will|will)\s+(?:send|share|forward|follow up with|prepare)\s+([^.\n]+)/gi,
            /(?:could you|can you|please|kindly)\s+(?:send|share|forward|provide|email)\s+([^.\n]+)/gi,
            /(?:action item|commitment)[:\s]+([^.\n]+)/gi,
        ];
        for (const pattern of patterns) {
            let match;
            while ((match = pattern.exec(content)) !== null) {
                const matchedText = match[0].trim();
                const detail = (match[1] || "").trim();
                const deadlineMatch = matchedText.match(/(?:by|before|due)\s+([A-Za-z]+,?\s+\d{1,2}(?:st|nd|rd|th)?|\d{4}-\d{2}-\d{2}|friday|monday|tuesday|wednesday|thursday|saturday|sunday|tomorrow)/i);
                const deadline = deadlineMatch ? deadlineMatch[1] : undefined;
                const docMatch = detail.match(/(?:pricing(?:\s+tiers)?|colab(?:\s+notebook)?|document|report|pdf|deck|presentation|summary)/i);
                const suggestedAttachmentQuery = docMatch ? docMatch[0] : undefined;
                const id = `commit_${createHash("sha256").update(`${threadId}:${matchedText}`).digest("hex").slice(0, 12)}`;
                results.push({
                    id,
                    title: `Commitment in "${title}"`,
                    commitmentText: matchedText,
                    sourceType: "gmail",
                    sourceId: threadId,
                    sourceTimestamp: item.timestamp,
                    provenance: `Gmail thread "${title}" (${item.timestamp})`,
                    evidenceRef: matchedText,
                    confidence: senderEmail ? 0.9 : 0.65,
                    recipientEmail: senderEmail,
                    subject: title.startsWith("Re:") ? title : `Re: ${title}`,
                    proposedBody: `Hi,\n\nFollowing up regarding "${title}":\n\n${matchedText}\n\nBest regards,\nAbhay`,
                    deadline,
                    relatedThreadId: threadId,
                    suggestedAttachmentQuery,
                });
            }
        }
        return results;
    }
    /**
     * Search and discover matching Drive attachments using genuine file metadata.
     * Never attaches a file based on ungrounded guesswork.
     */
    discoverAttachments(query, driveItems) {
        if (!query || !query.trim())
            return [];
        const normQuery = query.toLowerCase().trim();
        const queryTokens = normQuery.split(/\s+/).filter((t) => t.length > 2);
        const matches = [];
        for (const item of driveItems) {
            if (item.source !== "googledrive")
                continue;
            const meta = item.metadata ?? {};
            const name = String(meta.name || item.title || "");
            const normName = name.toLowerCase();
            // Check for token matches
            const tokenMatches = queryTokens.filter((token) => normName.includes(token));
            if (tokenMatches.length > 0) {
                matches.push({
                    fileId: String(meta.fileId || item.id.replace(/^gdrive_/, "")),
                    name,
                    mimeType: String(meta.mimeType || "application/octet-stream"),
                    size: typeof meta.size === "number" ? meta.size : undefined,
                    driveUrl: typeof meta.webViewLink === "string" ? meta.webViewLink : undefined,
                    verifiedAccessible: true,
                });
            }
        }
        return matches;
    }
}
export const defaultCommitmentDetector = new CommitmentDetector();
