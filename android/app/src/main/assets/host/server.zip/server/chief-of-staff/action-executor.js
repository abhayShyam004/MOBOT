import { defaultChiefStore } from "./chief-store.js";
import { ComposioTransportClient, } from "./context-aggregator.js";
import { loadConfig } from "../config.js";
import { defaultActionAuthorizationManager, } from "../capabilities/safety-policy.js";
export class ActionExecutor {
    store;
    transport;
    cfg;
    authManager;
    constructor(opts) {
        this.store = opts?.store ?? defaultChiefStore;
        this.transport = opts?.transport;
        this.cfg = opts?.config;
        this.authManager = opts?.authManager ?? defaultActionAuthorizationManager;
    }
    resolveTransport() {
        if (this.transport)
            return this.transport;
        const cfg = this.cfg ?? loadConfig();
        const apiKey = cfg.composio?.apiKey;
        if (apiKey && apiKey.startsWith("ck_")) {
            this.transport = new ComposioTransportClient(apiKey, cfg.composio?.mcpUrl);
            return this.transport;
        }
        return undefined;
    }
    async execute(taskId, opts) {
        const task = this.store.getTask(taskId);
        if (!task) {
            return {
                ok: false,
                error: `Task ${taskId} not found`,
                userFacingMessage: `Error: Task with ID ${taskId} does not exist in the Chief of Staff registry.`,
            };
        }
        const action = task.action;
        if (!action) {
            return {
                ok: false,
                error: `No action attached to task ${taskId}`,
                userFacingMessage: `Error: Task "${task.title}" has no automated action configured.`,
            };
        }
        // 1. Prevent duplicate execution
        if (task.status === "completed" || action.status === "completed") {
            return {
                ok: false,
                error: `Task ${taskId} has already been completed`,
                userFacingMessage: `Error: Task "${task.title}" was already successfully executed and completed. Duplicate execution rejected.`,
            };
        }
        // 2. Validate action arguments strictly before execution
        const payload = (action.payload ?? {});
        switch (action.type) {
            case "create_email_draft":
            case "reply_email_draft":
            case "update_email_draft":
            case "send_email": {
                const recipient = String(payload.recipient_email || "").trim();
                const subject = String(payload.subject || "").trim();
                const body = String(payload.body || "").trim();
                const threadId = payload.thread_id ? String(payload.thread_id).trim() : undefined;
                const draftId = payload.draft_id ? String(payload.draft_id).trim() : undefined;
                if (action.type === "update_email_draft" && !draftId) {
                    return {
                        ok: false,
                        error: "Draft ID required to update existing draft",
                        userFacingMessage: "Error: Cannot update draft without a valid draft ID.",
                    };
                }
                if (!recipient && !threadId && !draftId) {
                    return {
                        ok: false,
                        error: "Recipient or thread_id required for email action",
                        userFacingMessage: "Error: Cannot prepare email without a recipient or existing thread ID.",
                    };
                }
                if (recipient && !recipient.includes("@")) {
                    return {
                        ok: false,
                        error: `Invalid recipient email address: "${recipient}"`,
                        userFacingMessage: `Error: Invalid recipient email address: "${recipient}".`,
                    };
                }
                if (!subject && action.type !== "send_email") {
                    return {
                        ok: false,
                        error: "Email subject cannot be empty",
                        userFacingMessage: "Error: Email subject is required.",
                    };
                }
                if (!body && action.type !== "send_email") {
                    return {
                        ok: false,
                        error: "Email body cannot be empty",
                        userFacingMessage: "Error: Email body is required.",
                    };
                }
                break;
            }
            default:
                break;
        }
        // 3. Authoritative server-side approval verification via ActionAuthorizationManager
        if (action.requiresApproval) {
            const targetGrantId = opts?.grantId || action.approvalGrantId;
            const authCheck = this.authManager.validateAndConsumeGrant({
                grantId: targetGrantId,
                grant: opts?.grant,
                capabilityId: `chief_of_staff:${action.id}`,
                operation: action.type,
                parameters: payload,
                threadId: opts?.threadId,
                botId: opts?.botId,
            });
            if (!authCheck.valid) {
                return {
                    ok: false,
                    error: authCheck.reason || "Action approval verification failed",
                    userFacingMessage: `Authorization required: Action "${action.title}" cannot be executed. ${authCheck.reason || "Explicit human approval required."}`,
                };
            }
        }
        const transport = this.resolveTransport();
        if (!transport) {
            return {
                ok: false,
                error: "No execution transport available",
                userFacingMessage: "Error: No connected apps transport is available to execute this action.",
            };
        }
        this.store.updateTaskStatus(taskId, "executing");
        const executedAt = new Date().toISOString();
        // Route by action type
        switch (action.type) {
            case "create_email_draft":
            case "reply_email_draft": {
                const recipient = String(payload.recipient_email || "").trim();
                const subject = String(payload.subject || "No Subject").trim();
                const body = String(payload.body || "").trim();
                const threadId = payload.thread_id ? String(payload.thread_id).trim() : undefined;
                const args = {
                    recipient_email: recipient,
                    subject,
                    body,
                    is_html: false,
                };
                if (threadId) {
                    args.thread_id = threadId;
                }
                const res = await transport.callTool("GMAIL_CREATE_EMAIL_DRAFT", args);
                if (!res.ok) {
                    const receipt = {
                        actionId: action.id,
                        transport: "composio_mcp",
                        toolName: "GMAIL_CREATE_EMAIL_DRAFT",
                        executedAt,
                        success: false,
                        error: res.error,
                    };
                    this.store.recordExecutionReceipt(taskId, receipt);
                    return {
                        ok: false,
                        error: res.error,
                        receipt,
                        userFacingMessage: `Failed to create Gmail draft: ${res.error}. If Gmail is not connected, authenticate via the connection card.`,
                    };
                }
                const draftData = res.data ?? {};
                const draftId = String(draftData.id || draftData.draftId || draftData.draft_id || "").trim();
                if (!draftId) {
                    const receipt = {
                        actionId: action.id,
                        transport: "composio_mcp",
                        toolName: "GMAIL_CREATE_EMAIL_DRAFT",
                        executedAt,
                        success: false,
                        error: "Transport did not return a valid draft ID",
                    };
                    this.store.recordExecutionReceipt(taskId, receipt);
                    return {
                        ok: false,
                        error: "No external draft ID returned by Gmail transport",
                        receipt,
                        userFacingMessage: "Failed to confirm draft creation: Gmail did not return an external draft identifier.",
                    };
                }
                const receipt = {
                    actionId: action.id,
                    transport: "composio_mcp",
                    toolName: "GMAIL_CREATE_EMAIL_DRAFT",
                    executedAt,
                    success: true,
                    externalId: draftId,
                    responseData: draftData,
                };
                const updatedTask = this.store.recordExecutionReceipt(taskId, receipt);
                return {
                    ok: true,
                    task: updatedTask,
                    receipt,
                    userFacingMessage: `✅ Successfully created Gmail draft (ID: ${draftId}) to ${recipient} with subject "${subject}". The draft is ready in your Gmail account for review before sending.`,
                };
            }
            case "update_email_draft": {
                const draftId = String(payload.draft_id || "").trim();
                const recipient = String(payload.recipient_email || "").trim();
                const subject = String(payload.subject || "").trim();
                const body = String(payload.body || "").trim();
                const res = await transport.callTool("GMAIL_UPDATE_DRAFT", {
                    draft_id: draftId,
                    recipient_email: recipient || undefined,
                    subject: subject || undefined,
                    body: body || undefined,
                });
                if (!res.ok) {
                    const receipt = {
                        actionId: action.id,
                        transport: "composio_mcp",
                        toolName: "GMAIL_UPDATE_DRAFT",
                        executedAt,
                        success: false,
                        error: res.error,
                    };
                    this.store.recordExecutionReceipt(taskId, receipt);
                    return {
                        ok: false,
                        error: res.error,
                        receipt,
                        userFacingMessage: `Failed to update draft: ${res.error}`,
                    };
                }
                const receipt = {
                    actionId: action.id,
                    transport: "composio_mcp",
                    toolName: "GMAIL_UPDATE_DRAFT",
                    executedAt,
                    success: true,
                    externalId: draftId,
                    responseData: res.data,
                };
                const updatedTask = this.store.recordExecutionReceipt(taskId, receipt);
                return {
                    ok: true,
                    task: updatedTask,
                    receipt,
                    userFacingMessage: `✅ Successfully updated Gmail draft (ID: ${draftId}).`,
                };
            }
            case "send_email": {
                const draftId = String(payload.draft_id || "").trim();
                const recipient = String(payload.recipient_email || "").trim();
                const subject = String(payload.subject || "").trim();
                const body = String(payload.body || "").trim();
                let targetDraftId = draftId;
                if (!targetDraftId) {
                    // Create draft first
                    const createRes = await transport.callTool("GMAIL_CREATE_EMAIL_DRAFT", {
                        recipient_email: recipient,
                        subject,
                        body,
                    });
                    if (!createRes.ok || !createRes.data?.id) {
                        return {
                            ok: false,
                            error: `Failed to prepare draft before sending: ${createRes.error}`,
                            userFacingMessage: `Failed to prepare draft for sending: ${createRes.error}`,
                        };
                    }
                    targetDraftId = String(createRes.data.id);
                }
                const sendRes = await transport.callTool("GMAIL_SEND_DRAFT", {
                    draft_id: targetDraftId,
                });
                if (!sendRes.ok) {
                    const receipt = {
                        actionId: action.id,
                        transport: "composio_mcp",
                        toolName: "GMAIL_SEND_DRAFT",
                        executedAt,
                        success: false,
                        error: sendRes.error,
                    };
                    this.store.recordExecutionReceipt(taskId, receipt);
                    return {
                        ok: false,
                        error: sendRes.error,
                        receipt,
                        userFacingMessage: `Failed to send email: ${sendRes.error}`,
                    };
                }
                const messageId = String(sendRes.data?.id || sendRes.data?.message_id || targetDraftId).trim();
                const receipt = {
                    actionId: action.id,
                    transport: "composio_mcp",
                    toolName: "GMAIL_SEND_DRAFT",
                    executedAt,
                    success: true,
                    externalId: messageId,
                    responseData: sendRes.data,
                };
                const updatedTask = this.store.recordExecutionReceipt(taskId, receipt);
                return {
                    ok: true,
                    task: updatedTask,
                    receipt,
                    userFacingMessage: `🚀 Successfully sent email to ${recipient}! Message ID: ${messageId}.`,
                };
            }
            default: {
                return {
                    ok: false,
                    error: `Unsupported action type: ${action.type}`,
                    userFacingMessage: `Error: Automated execution for action type "${action.type}" is not yet supported.`,
                };
            }
        }
    }
}
