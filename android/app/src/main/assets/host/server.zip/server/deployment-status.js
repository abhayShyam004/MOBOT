/**
 * How far a project actually got.
 *
 * "It ran on my machine" is not a deployment. This module keeps the five
 * distinct states apart and refuses to call anything deployed without a real
 * public URL *and* an independent remote check that answered successfully.
 */
function isPublicHttpUrl(value) {
    if (!value)
        return false;
    try {
        const parsed = new URL(value);
        if (parsed.protocol !== "http:" && parsed.protocol !== "https:")
            return false;
        // A loopback or private host is a local preview, not a public deployment.
        const host = parsed.hostname.toLowerCase();
        if (host === "localhost" || host.endsWith(".localhost") || host === "127.0.0.1" || host === "0.0.0.0")
            return false;
        if (host === "::1" || host === "[::1]")
            return false;
        if (/^10\./.test(host) || /^192\.168\./.test(host) || /^172\.(?:1[6-9]|2\d|3[01])\./.test(host))
            return false;
        if (!host.includes("."))
            return false;
        return true;
    }
    catch {
        return false;
    }
}
/**
 * Derives the strongest state the evidence supports. Later states are never
 * inferred from earlier ones: a build does not imply a test, an attempt does
 * not imply a deployment, and a URL does not imply it is reachable.
 */
export function deriveDeploymentVerdict(evidence) {
    const urlIsPublic = isPublicHttpUrl(evidence.url);
    const remoteOk = Boolean(evidence.remoteCheck?.ok);
    const hasError = Boolean(evidence.error);
    const remaining = [];
    if (!evidence.built)
        remaining.push("build the project");
    if (!evidence.tested)
        remaining.push("run the tests locally");
    if (!evidence.attempted)
        remaining.push("deploy it to a host");
    if (!urlIsPublic)
        remaining.push("obtain a public deployment URL");
    if (urlIsPublic && !remoteOk)
        remaining.push("verify the public URL independently");
    let state;
    if (evidence.attempted && hasError && !urlIsPublic)
        state = "failed";
    else if (urlIsPublic && remoteOk && evidence.remoteCheck?.statusCode !== undefined)
        state = "remotely_verified";
    else if (urlIsPublic && remoteOk)
        state = "deployed";
    else if (evidence.attempted || urlIsPublic)
        state = "deployment_attempted";
    else if (evidence.tested)
        state = "tested_locally";
    else if (evidence.built)
        state = "built_locally";
    else
        state = "not_started";
    const deployed = state === "deployed" || state === "remotely_verified";
    return { state, deployed, remaining, summary: summarise(state, evidence, remaining) };
}
function summarise(state, evidence, remaining) {
    switch (state) {
        case "remotely_verified":
            return `Deployed and independently verified at ${evidence.url}.`;
        case "deployed":
            return `Deployed at ${evidence.url}; the public URL answered.`;
        case "deployment_attempted":
            return evidence.url
                ? `Deployment was attempted at ${evidence.url}, but that URL has not been independently verified, so I cannot call it deployed.`
                : `Deployment was attempted but no public URL was returned, so it is not deployed.`;
        case "tested_locally":
            return "Built and tested locally. Nothing has been deployed, so there is no public URL yet.";
        case "built_locally":
            return "Built locally but not tested and not deployed.";
        case "failed":
            return `Deployment failed${evidence.error ? `: ${evidence.error}` : ""}. ${remaining.length ? `Still to do: ${remaining.join(", ")}.` : ""}`;
        default:
            return "Nothing has been built or deployed yet.";
    }
}
/** A claim is only allowed when the verdict is a verified deployment. */
export function mayClaimDeployed(verdict) {
    return verdict.deployed;
}
