// Project lifecycle: binds a software project to a durable, resumable task.
//
// A project request is only genuinely durable when the requirements, the
// acceptance criteria, the ordered steps, and every completed step with its
// evidence live somewhere that survives a turn or a server restart. The
// ProjectManager owns the workspace, the DurableTaskEngine owns the task
// ledger; this module is the one place that keeps the two in agreement. It
// adds no new store and no parallel queue: the spec is a file inside the
// project it describes, and the task is the engine's own record.
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
export const PROJECT_SPEC_PATH = ".mobot/project-spec.json";
function nowIso() {
    return new Date().toISOString();
}
function requireText(value, field) {
    const text = typeof value === "string" ? value.trim() : "";
    if (!text)
        throw new Error(`${field} is required.`);
    return text;
}
function slugify(name) {
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 64);
    if (!slug)
        throw new Error("Project name must contain at least one letter or digit.");
    return slug;
}
export class ProjectLifecycle {
    // Written out rather than as constructor parameter properties: the repo's
    // type-stripped runtime (Node's strip-only mode) rejects that syntax.
    manager;
    tasks;
    constructor(manager, tasks) {
        this.manager = manager;
        this.tasks = tasks;
    }
    specPath(projectDir) {
        return join(projectDir, PROJECT_SPEC_PATH);
    }
    /** The persisted spec, or null when this project never went through start(). */
    getSpec(projectId) {
        const projectDir = this.manager.getProjectDir(projectId);
        const path = this.specPath(projectDir);
        if (!existsSync(path))
            return null;
        try {
            const spec = JSON.parse(readFileSync(path, "utf8"));
            return spec && spec.projectId === projectId ? spec : null;
        }
        catch {
            return null;
        }
    }
    saveSpec(spec) {
        spec.updatedAt = nowIso();
        const projectDir = this.manager.getProjectDir(spec.projectId);
        this.manager.writeFile(spec.projectId, PROJECT_SPEC_PATH, JSON.stringify(spec, null, 2));
        // Read the spec back: a lifecycle record that was not actually persisted
        // must not be reported as durable.
        const reread = readFileSync(this.specPath(projectDir), "utf8");
        if (reread !== JSON.stringify(spec, null, 2)) {
            throw new Error(`Project spec for ${spec.projectId} was not persisted.`);
        }
    }
    /**
     * Create or adopt the project, persist its specification, and open the
     * durable task that tracks it. Repeating the same request returns the
     * existing lifecycle instead of a second project and a second task.
     */
    start(input) {
        const name = requireText(input.name, "name");
        const goal = requireText(input.goal, "goal");
        const projectId = (input.id ? requireText(input.id, "id") : slugify(name)).toLowerCase();
        const requirements = (input.requirements || []).map((item) => String(item).trim()).filter(Boolean);
        const criteriaText = (input.acceptanceCriteria || []).map((item) => String(item).trim()).filter(Boolean);
        const steps = (input.steps || []).map((step, index) => ({
            id: String(step?.id || `step_${index + 1}`).trim(),
            title: requireText(step?.title, `steps[${index}].title`),
            description: requireText(step?.description, `steps[${index}].description`),
            expectedOutcome: requireText(step?.expectedOutcome, `steps[${index}].expectedOutcome`),
        }));
        if (requirements.length === 0)
            throw new Error("At least one requirement is required.");
        if (criteriaText.length === 0)
            throw new Error("At least one acceptance criterion is required.");
        if (steps.length === 0)
            throw new Error("At least one execution step is required.");
        const duplicateStep = steps.find((step, index) => steps.findIndex((other) => other.id === step.id) !== index);
        if (duplicateStep)
            throw new Error(`Duplicate step id: ${duplicateStep.id}`);
        const existingProject = this.manager.getProject(projectId);
        const existingSpec = existingProject ? this.getSpec(projectId) : null;
        if (existingSpec) {
            const task = this.tasks.getTask(existingSpec.taskId, this.manager.getProjectDir(projectId));
            if (!task) {
                // The spec outlived its task record: recreate the task rather than
                // silently reporting a lifecycle whose ledger is gone.
                const recreated = this.createTask(projectId, goal, steps, input, existingSpec);
                existingSpec.taskId = recreated.id;
                this.saveSpec(existingSpec);
                return {
                    ok: true,
                    created: false,
                    projectId,
                    projectDir: this.manager.getProjectDir(projectId),
                    taskId: recreated.id,
                    specPath: PROJECT_SPEC_PATH,
                    resumed: true,
                };
            }
            return {
                ok: true,
                created: false,
                projectId,
                projectDir: this.manager.getProjectDir(projectId),
                taskId: task.id,
                specPath: PROJECT_SPEC_PATH,
                resumed: true,
            };
        }
        if (!existingProject) {
            this.manager.createProject({
                name,
                id: projectId,
                description: input.description ? String(input.description) : goal,
                framework: input.framework || "fullstack",
                template: input.framework || "fullstack",
                initGit: input.initGit !== false,
            });
        }
        const spec = {
            version: 1,
            projectId,
            goal,
            requirements,
            steps: steps.map((step) => ({ ...step, status: "pending" })),
            acceptanceCriteria: criteriaText.map((description, index) => ({
                id: `criterion_${index + 1}`,
                description,
                verified: false,
            })),
            botId: input.botId || "default_bot",
            threadId: input.threadId || "default_thread",
            taskId: "",
            createdAt: nowIso(),
            updatedAt: nowIso(),
        };
        const task = this.createTask(projectId, goal, steps, input, spec);
        spec.taskId = task.id;
        this.saveSpec(spec);
        return {
            ok: true,
            created: !existingProject,
            projectId,
            projectDir: this.manager.getProjectDir(projectId),
            taskId: task.id,
            specPath: PROJECT_SPEC_PATH,
            resumed: false,
        };
    }
    createTask(projectId, goal, steps, input, spec) {
        const projectDir = this.manager.getProjectDir(projectId);
        const task = this.tasks.createTask({
            goal,
            workspacePath: projectDir,
            botId: input.botId || spec.botId,
            threadId: input.threadId || spec.threadId,
            initialMilestones: steps.map((step) => step.title),
        });
        this.tasks.startPlanning(task.id, projectId);
        return this.tasks.getTask(task.id, projectDir) || task;
    }
    requireSpec(projectId) {
        const projectIdText = requireText(projectId, "projectId");
        // getProjectDir validates the id and that the project exists on disk.
        const projectDir = this.manager.getProjectDir(projectIdText);
        const spec = this.getSpec(projectIdText);
        if (!spec)
            throw new Error(`Project "${projectIdText}" has no lifecycle specification; call project_start first.`);
        return { spec, projectDir };
    }
    requireTask(spec, projectDir) {
        const task = this.tasks.getTask(spec.taskId, projectDir);
        if (!task)
            throw new Error(`Durable task ${spec.taskId} for project "${spec.projectId}" could not be loaded.`);
        return task;
    }
    /** Mark one ordered step complete with the observation that proved it. */
    completeStep(projectId, stepId, observation, evidence) {
        const { spec, projectDir } = this.requireSpec(projectId);
        const step = spec.steps.find((item) => item.id === requireText(stepId, "stepId"));
        if (!step)
            throw new Error(`Step "${stepId}" is not part of the ${projectId} plan.`);
        const observationText = requireText(observation, "observation");
        const evidenceText = evidence ? String(evidence).trim() : undefined;
        const task = this.requireTask(spec, projectDir);
        if (step.status === "completed") {
            return { ok: true, alreadyCompleted: true, spec, task, nextStep: spec.steps.find((item) => item.status !== "completed") };
        }
        step.status = "completed";
        step.observation = observationText;
        step.evidence = evidenceText;
        step.updatedAt = nowIso();
        this.saveSpec(spec);
        const next = spec.steps.find((item) => item.status === "pending");
        if (next)
            next.status = "in_progress";
        this.saveSpec(spec);
        const completedCount = spec.steps.filter((item) => item.status === "completed").length;
        const updated = this.tasks.updateProgress(spec.taskId, {
            progressPercent: Math.min(95, Math.round((completedCount / spec.steps.length) * 100)),
            progressMessage: `Completed step "${step.title}".`,
            currentStepId: next ? next.id : step.id,
            observation: evidenceText ? `${observationText} (evidence: ${evidenceText})` : observationText,
            milestoneCompleted: {
                id: step.id,
                title: step.title,
                description: step.description,
                evidence: evidenceText || observationText,
            },
        });
        if (updated.status === "PLANNING" || updated.status === "CREATED" || updated.status === "PAUSED") {
            this.tasks.startRunning(spec.taskId, next ? next.id : step.id);
        }
        return {
            ok: true,
            alreadyCompleted: false,
            spec,
            task: this.tasks.getTask(spec.taskId, projectDir) || updated,
            nextStep: next,
        };
    }
    /**
     * Record verified evidence for acceptance criteria. A criterion is never
     * marked satisfied without evidence naming what was observed.
     */
    verifyCriterion(projectId, criterionId, verified, evidence) {
        const { spec } = this.requireSpec(projectId);
        const criterion = spec.acceptanceCriteria.find((item) => item.id === requireText(criterionId, "criterionId"));
        if (!criterion)
            throw new Error(`Criterion "${criterionId}" is not part of the ${projectId} specification.`);
        const evidenceText = evidence ? String(evidence).trim() : "";
        if (verified && !evidenceText) {
            throw new Error("Cannot mark a criterion verified without evidence describing the observed result.");
        }
        criterion.verified = verified;
        criterion.evidence = evidenceText || undefined;
        criterion.verifiedAt = verified ? nowIso() : undefined;
        this.saveSpec(spec);
        return spec;
    }
    /**
     * Close the lifecycle only when every step is complete and every acceptance
     * criterion carries evidence. Anything else is reported as the real reason
     * completion was refused.
     */
    finish(projectId, summary, deliveredArtifacts) {
        const { spec, projectDir } = this.requireSpec(projectId);
        const summaryText = requireText(summary, "summary");
        const incompleteSteps = spec.steps.filter((step) => step.status !== "completed");
        if (incompleteSteps.length > 0) {
            return {
                ok: false,
                spec,
                error: `Cannot complete: ${incompleteSteps.length} step(s) are not complete (${incompleteSteps.map((step) => step.id).join(", ")}).`,
            };
        }
        const unverified = spec.acceptanceCriteria.filter((criterion) => !criterion.verified);
        const verificationItems = spec.acceptanceCriteria.map((criterion) => ({
            id: criterion.id,
            description: criterion.description,
            verified: criterion.verified,
            evidence: criterion.evidence,
        }));
        if (unverified.length > 0) {
            return {
                ok: false,
                spec,
                error: `Cannot complete: ${unverified.length} acceptance criterion(s) lack verified evidence (${unverified.map((item) => item.id).join(", ")}).`,
            };
        }
        const result = this.tasks.completeTask(spec.taskId, verificationItems, summaryText, deliveredArtifacts);
        if (!result.ok)
            return { ok: false, error: result.error, spec, task: result.task };
        return { ok: true, spec, task: this.tasks.getTask(spec.taskId, projectDir) || result.task };
    }
    /** Join the durable ledger with the project's own state for one honest view. */
    status(projectId) {
        const { spec, projectDir } = this.requireSpec(projectId);
        const task = this.requireTask(spec, projectDir);
        const nextStep = spec.steps.find((step) => step.status !== "completed");
        return {
            ok: true,
            projectId: spec.projectId,
            projectDir,
            goal: spec.goal,
            taskId: task.id,
            taskStatus: task.status,
            progressPercent: task.progressPercent,
            progressMessage: task.progressMessage,
            currentStepId: task.currentStepId,
            steps: spec.steps.map((step) => ({
                id: step.id,
                title: step.title,
                status: step.status,
                evidence: step.evidence,
            })),
            acceptanceCriteria: spec.acceptanceCriteria.map((criterion) => ({
                id: criterion.id,
                description: criterion.description,
                verified: criterion.verified,
            })),
            completed: task.status === "COMPLETED",
            nextStep: nextStep
                ? { id: nextStep.id, title: nextStep.title, expectedOutcome: nextStep.expectedOutcome }
                : undefined,
            task,
        };
    }
}
