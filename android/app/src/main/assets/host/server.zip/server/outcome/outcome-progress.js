import { existsSync, mkdirSync, openSync, readFileSync, writeSync, fsyncSync, closeSync } from "node:fs";
import { join } from "node:path";
import { DATA_DIR } from "../config.js";
export class OutcomeProgressManager {
    baseDir;
    listeners = new Map();
    lastSeqByJob = new Map();
    constructor(baseDir) {
        this.baseDir = baseDir ?? join(DATA_DIR, "progress");
    }
    getProgressFilePath(jobId) {
        const sanitized = jobId.replace(/[^a-zA-Z0-9_-]/g, "_");
        return join(this.baseDir, `${sanitized}.jsonl`);
    }
    recordEvent(eventInput) {
        mkdirSync(this.baseDir, { recursive: true });
        const filePath = this.getProgressFilePath(eventInput.jobId);
        const now = Date.now();
        const currentSeq = (this.lastSeqByJob.get(eventInput.jobId) ?? 0) + 1;
        this.lastSeqByJob.set(eventInput.jobId, currentSeq);
        const fullEvent = {
            ...eventInput,
            seq: currentSeq,
            timestampMs: now,
        };
        const line = JSON.stringify(fullEvent) + "\n";
        const fd = openSync(filePath, "a", 0o600);
        try {
            writeSync(fd, line, null, "utf8");
            fsyncSync(fd);
        }
        finally {
            closeSync(fd);
        }
        // Notify live in-memory subscribers
        const jobListeners = this.listeners.get(eventInput.jobId);
        if (jobListeners) {
            for (const listener of jobListeners) {
                try {
                    listener(fullEvent);
                }
                catch (err) {
                    console.warn(`[OutcomeProgressManager] Subscriber threw error for job ${eventInput.jobId}`, err);
                }
            }
        }
        return fullEvent;
    }
    getEventsSince(jobId, sinceSeq, scope) {
        const filePath = this.getProgressFilePath(jobId);
        if (!existsSync(filePath))
            return [];
        try {
            const content = readFileSync(filePath, "utf8");
            const lines = content.split("\n").filter((l) => l.trim().length > 0);
            const results = [];
            for (const line of lines) {
                try {
                    const parsed = JSON.parse(line);
                    // Strict security boundary: ensure botId and threadId match scope to prevent cross-thread leakage
                    if (parsed.botId !== scope.botId || parsed.threadId !== scope.threadId) {
                        continue;
                    }
                    if (parsed.seq > sinceSeq) {
                        results.push(parsed);
                    }
                }
                catch { }
            }
            return results;
        }
        catch {
            return [];
        }
    }
    subscribe(jobId, scope, callback) {
        if (!this.listeners.has(jobId)) {
            this.listeners.set(jobId, new Set());
        }
        const scopedListener = (ev) => {
            if (ev.botId === scope.botId && ev.threadId === scope.threadId) {
                callback(ev);
            }
        };
        this.listeners.get(jobId).add(scopedListener);
        return () => {
            const set = this.listeners.get(jobId);
            if (set) {
                set.delete(scopedListener);
                if (set.size === 0)
                    this.listeners.delete(jobId);
            }
        };
    }
    renderCard(event, totalMilestones = 4) {
        const statusEmoji = event.state === "COMPLETED" ? "✅" : event.state === "FAILED" ? "❌" : "⏳";
        const title = `${statusEmoji} Task: ${event.cardId.replace("card_outcome_", "")}`;
        const subtitle = `[${event.progressPercent}%] Milestone ${event.milestoneIndex + 1}/${totalMilestones}: ${event.milestoneTitle}\n${event.message}`;
        const options = event.state === "COMPLETED" || event.state === "FAILED"
            ? ["View Report", "Dismiss"]
            : ["Pause", "Cancel Task"];
        return {
            title,
            subtitle,
            options,
            answered: event.state === "COMPLETED" ? "completed" : event.state === "FAILED" ? "failed" : undefined,
        };
    }
}
export const sharedOutcomeProgressManager = new OutcomeProgressManager();
