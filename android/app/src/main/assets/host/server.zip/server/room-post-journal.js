// The room post is MOBOT's first mutation that runs through the operation
// journal in production. `POST /api/groups/:id/messages` calls
// `dispatchRoomPost` for every send that carries a client-generated sendId.
//
// Why this mutation first: it is the only side effect that already owns all
// three things a journal needs to be truthful.
//   - a stable identity: the client-generated sendId, which survives retries,
//     task switches and restarts;
//   - a payload owner: text + reply-to + mode, all recorded in the journal, so
//     a reused sendId with different content is refused rather than merged;
//   - an authoritative reconciler: the room transcript (and the channel queue)
//     is the provider's own record. `acceptedSendMatch` answers "did this
//     exact send land?" from committed state, not from a local flag.
//
// The journal is written through to disk before `dispatch` can commit the
// message, so a crash between the commit and the HTTP response leaves a
// `dispatched` record that is reconciled on the next attempt instead of a
// silently duplicated post.
import { createHash } from "node:crypto";
import { runJournaledMutation, } from "./operation-journal.js";
/** Inventory name from `MUTATION_INVENTORY` in operation-journal.ts. */
export const ROOM_POST_ACTION = "post_to_room";
/** Idempotency-key prefix that marks an internal (tool-call) room post. */
export const INTERNAL_ROOM_POST_KEY_PREFIX = `${ROOM_POST_ACTION}:internal:`;
/** The sendId belongs to a different message already. */
export class RoomPostConflictError extends Error {
    status = 409;
}
/**
 * The operation may have committed, but neither the acknowledgement nor the
 * provider record settles it. The caller must be told the truth rather than a
 * 202 it cannot rely on.
 */
export class RoomPostUnresolvedError extends Error {
    status = 409;
    code = "post_outcome_unknown";
}
let settlementProbe = null;
export function setRoomPostSettlementProbe(probe) {
    settlementProbe = probe;
}
export function roomPostIdempotencyKey(identity) {
    if (identity.internal) {
        const scope = identity.internal;
        return `${INTERNAL_ROOM_POST_KEY_PREFIX}${scope.botId}:${scope.sourceThreadId}:${scope.sendId}`;
    }
    return `${ROOM_POST_ACTION}:group:${identity.groupId}:${identity.threadId}:${identity.sendId}`;
}
/**
 * The derived message identity for an internal post.
 *
 * The room transcript is the reconciler, so the posted message must carry an
 * identity a replay can find again. It is a pure function of the operation
 * identity, which is what makes "same tool call → same message identity" hold
 * across retries and restarts without anyone storing a mapping. The output
 * matches the public `parseSendId` contract (16-80 of `[A-Za-z0-9_-]`).
 */
export function internalRoomPostSendId(scope) {
    const digest = createHash("sha256")
        .update(canonicalJsonForId(scope))
        .digest("hex");
    return `irp_${digest.slice(0, 40)}`;
}
/** The receipt chip's own identity, derived from the post it receipts. */
export function internalRoomPostChipSendId(sendId) {
    return `${sendId}_chip`;
}
/** Deterministic serialization for identity derivation. */
function canonicalJsonForId(scope) {
    return JSON.stringify([scope.botId, scope.sourceThreadId, scope.sendId]);
}
/** The exact fields whose change makes a reused sendId a different request. */
export function roomPostPayload(identity) {
    return {
        groupId: identity.groupId,
        threadId: identity.threadId,
        sendId: identity.sendId,
        text: identity.text,
        replyToId: identity.replyToId ?? null,
        mode: identity.mode,
        ...(identity.internal ? { internal: { ...identity.internal } } : {}),
    };
}
/**
 * The production dispatch path. Everything here runs on the real request:
 * the journal record is durable before `dispatch` is invoked, and `dispatch`
 * performs the same store work the route performed before this integration.
 *
 * `finalize` runs once a receipt exists — executed, reconciled or replayed —
 * and never for a refusal. It is where derived follow-through lives (the
 * internal post's receipt chip): the message is already committed, so a
 * finalize that fails or is interrupted by a crash leaves the receipt valid
 * and the follow-up re-ensured by the next replay or the boot pass. It must
 * be idempotent.
 */
export async function dispatchRoomPost(options) {
    const { journal, identity, dispatch, reconcile, finalize } = options;
    // A refusal raised by our own stores before admission carries an HTTP
    // status: the provider never saw the request, so it is a proven negative and
    // must neither stay UNKNOWN nor be reconciled.
    let refusal = null;
    let run;
    try {
        run = await runJournaledMutation({
            journal,
            actionType: ROOM_POST_ACTION,
            idempotencyKey: roomPostIdempotencyKey(identity),
            payload: roomPostPayload(identity),
            scope: identity.internal
                ? { botId: identity.internal.botId, threadId: identity.internal.sourceThreadId }
                : { botId: identity.groupId, threadId: identity.threadId },
            dispatch: async (operationId) => {
                try {
                    const committed = await dispatch();
                    // The message is durable at this point and the journal still says
                    // "dispatched"; a crash-window test kills the process right here.
                    await settlementProbe?.({
                        operationId,
                        sendId: identity.sendId,
                        surface: identity.internal ? "internal" : "public",
                    });
                    return committed;
                }
                catch (error) {
                    const status = error?.status;
                    if (typeof status === "number") {
                        refusal = error;
                        throw Object.assign(error, { definitelyNotExecuted: true });
                    }
                    throw error;
                }
            },
            reconcile: (entry) => reconcile(entry),
        });
    }
    catch (error) {
        // Reusing a sendId for a different message is the caller's mistake, and it
        // must read exactly like the pre-journal conflict the route already sends.
        if (error instanceof Error && /already used with different payload/.test(error.message)) {
            throw new RoomPostConflictError("sendId already belongs to another message");
        }
        throw error;
    }
    if (run.outcome === "failed" && refusal) {
        // Give the caller the refusal it would have received before the journal.
        throw refusal;
    }
    if (run.result === undefined || run.result === null) {
        throw new RoomPostUnresolvedError(run.reason ?? "the room post could not be settled; it was not posted again");
    }
    let receipt = run.result;
    if (run.outcome === "deduplicated") {
        // The stored result is the acknowledgement the original call received, but
        // the channel moves on: a queued admission drains into a real message. The
        // provider's current record outranks that acknowledgement, and the stored
        // receipt is only a fallback for a send still waiting in the queue.
        const entry = journal.getOperation(run.operationId);
        if (entry) {
            const current = await reconcile(entry);
            if (current?.found)
                receipt = current.result;
        }
    }
    const entry = journal.getOperation(run.operationId);
    if (finalize && entry) {
        try {
            receipt = await finalize(receipt, entry);
        }
        catch (error) {
            // The receipt stands; the follow-through is re-ensured by the next
            // replay or the boot pass. Swallowing is safer than failing a post
            // that already committed.
            console.error("[room-post-journal] finalize failed:", error);
        }
    }
    return {
        receipt,
        outcome: run.outcome,
        operationId: run.operationId,
        replayed: run.outcome !== "executed",
    };
}
const UNCERTAIN_ENTRY_STATUSES = new Set([
    "dispatched",
    "acknowledged",
    "reconciling",
    "unknown",
]);
/**
 * Boot reconciliation for internal room posts.
 *
 * The room transcript is the provider's own record, and the append that lands
 * a post is synchronous and durable — so for an internal entry the transcript
 * can answer both ways:
 *   - the message is there: the operation completed; the stored receipt is
 *     refreshed from the transcript and the receipt chip is re-ensured;
 *   - the message is not there: the post provably never landed (the append is
 *     the commit), so the entry is closed as proven-not-executed.
 *
 * A room that no longer exists can answer neither way; such an entry is left
 * untouched rather than guessed about. Completed entries are still visited so
 * a crash between the completion write and the chip is repaired too.
 */
export async function reconcileInternalRoomPostsAtBoot(options) {
    const { journal, reconcile, finalize } = options;
    const report = { settled: 0, unresolved: 0 };
    const entries = journal
        .export()
        .filter((entry) => entry.actionType === ROOM_POST_ACTION && entry.idempotencyKey.startsWith(INTERNAL_ROOM_POST_KEY_PREFIX));
    for (const entry of entries) {
        try {
            if (UNCERTAIN_ENTRY_STATUSES.has(entry.status)) {
                const found = await reconcile(entry);
                if (found?.found) {
                    await journal.reconcile(entry.operationId, async () => ({
                        success: true,
                        data: found.result,
                    }));
                }
                else if (found && found.found === false && found.provenNotExecuted) {
                    await journal.reconcile(entry.operationId, async () => ({
                        success: false,
                        error: { code: "NOT_EXECUTED", message: "The room transcript proves the post never landed" },
                    }));
                    journal.markFailed(entry.operationId, { code: "NOT_EXECUTED", message: "The room transcript proves the post never landed" }, { provenNotExecuted: true });
                }
                // No answer at all: leave the entry exactly as it was.
            }
            const current = journal.getOperation(entry.operationId);
            if (current?.status === "completed" && current.result?.success && current.result.data !== undefined && current.result.data !== null) {
                report.settled += 1;
                if (finalize)
                    await finalize(current.result.data, current);
            }
            else if (current && !UNCERTAIN_ENTRY_STATUSES.has(current.status)) {
                report.settled += 1;
            }
            else {
                report.unresolved += 1;
            }
        }
        catch (error) {
            report.unresolved += 1;
            console.error(`[room-post-journal] boot reconciliation failed for ${entry.operationId}:`, error);
        }
    }
    if (report.settled > 0 || report.unresolved > 0)
        journal.save();
    return report;
}
