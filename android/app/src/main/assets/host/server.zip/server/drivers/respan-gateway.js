// Provider driver for the local Respan Gateway — one MOBOT engine in front of
// every provider this workspace already holds a key for.
//
// The openai-compat runtime speaks chat completions to a single base URL. The
// gateway serves that same contract and routes each model name to the vendor
// that owns it (`claude-*` to Anthropic, `grok-*` to xAI, everything else to
// the OpenAI-compatible endpoint MOBOT is configured with), so moving a bot to
// another vendor becomes a model pick, not a provider change. Nothing is
// hosted: the gateway is the open-source binary, run here as a Python sidecar
// from gateway/ on a loopback ephemeral port, spending the developer's own
// provider keys. No Respan account and no tracing export are involved.
//
// The sidecar is the one piece of this that is not Node, so its absence is a
// first-class state: `create` rejects with the command that installs it, and
// the registry shows this instance as unavailable rather than broken.
import { spawn } from "node:child_process";
import { existsSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { SERVER_ROOT } from "../proxy-paths.js";
import { createOpenAIChatRuntime } from "./openai-chat.js";
const DRIVER_KIND = "respanGateway";
const READY_TIMEOUT_MS = 20_000;
const STOP_GRACE_MS = 5_000;
const IDLE_TIMEOUT_MS = 180_000;
/** Sent as the bearer token on every call. The gateway spends the provider
 * keys it was handed, not this one: without `client_keys` in a gateway config
 * it accepts any token, and the runtime refuses to send a turn with an empty
 * one. A placeholder, never a credential. */
const LOCAL_CLIENT_KEY = "respan-gateway";
/** What the picker shows before the gateway answers with its real catalog. */
const STATIC_MODELS = {
    default: "gpt-4o-mini",
    options: [{ id: "gpt-4o-mini", label: "gpt-4o-mini", custom: true }],
};
/** Environment a sidecar inherits from the server: what a Python interpreter
 * needs to run at all, and nothing else. Same rule as every other spawned
 * helper here — a credential riding along in `process.env` does not reach a
 * child that was not given it (server/mcp-env.ts spells the reasoning out). */
const INHERITED_ENV = [
    "PATH",
    "HOME",
    "USERPROFILE",
    "SYSTEMROOT",
    "SYSTEMDRIVE",
    "WINDIR",
    "TEMP",
    "TMP",
    "TMPDIR",
    "LANG",
    "LC_ALL",
    "LD_LIBRARY_PATH",
];
/** A vendor credential the gateway reads, or one of its own `RESPAN_*`
 * overrides (RESPAN_<VENDOR>_BASE_URL and friends). Everything else in an
 * instance environment — MOBOT's own OMB_* tokens included — is dropped. */
function isGatewayCredential(name) {
    return /^RESPAN_[A-Z0-9_]+$/.test(name) || /^[A-Z0-9]+(_[A-Z0-9]+)*_API_(KEY|TOKEN)$/.test(name);
}
/** Where gateway/ sits: beside server/ in a checkout. The packaged desktop app
 * ships no Python environment, so RESPAN_GATEWAY_ROOT is the escape hatch for
 * an install that does. */
function gatewayRoot() {
    const override = process.env.RESPAN_GATEWAY_ROOT;
    return override ? resolve(override) : join(dirname(SERVER_ROOT), "gateway");
}
/** The project's own gateway environment, as `uv sync --directory gateway`
 * creates it. RESPAN_GATEWAY_PYTHON points at another interpreter that has
 * respan-gateway installed. */
function gatewayPython(root) {
    const override = process.env.RESPAN_GATEWAY_PYTHON;
    if (override)
        return override;
    return process.platform === "win32"
        ? join(root, ".venv", "Scripts", "python.exe")
        : join(root, ".venv", "bin", "python");
}
const INSTALL_COMMAND = "uv sync --directory gateway";
function sidecarEnvironment(credentials) {
    const env = {};
    for (const name of INHERITED_ENV) {
        const value = process.env[name];
        // `process.env.X = undefined` coerces to the string "undefined" in a
        // child env; never forward it as a value.
        if (value !== undefined && value !== "undefined")
            env[name] = value;
    }
    for (const [name, value] of Object.entries(credentials)) {
        if (value && isGatewayCredential(name))
            env[name] = value;
    }
    return env;
}
/** `{"url": "http://127.0.0.1:54321"}` — the sidecar's one ready line. */
function readyUrl(line) {
    try {
        const parsed = JSON.parse(line);
        return typeof parsed.url === "string" && /^http:\/\/127\.0\.0\.1:\d+$/.test(parsed.url) ? parsed.url : null;
    }
    catch {
        return null;
    }
}
function stopSidecar(child) {
    if (child.exitCode !== null || child.signalCode !== null)
        return Promise.resolve();
    return new Promise((resolveStop) => {
        const force = setTimeout(() => child.kill("SIGKILL"), STOP_GRACE_MS);
        child.once("exit", () => {
            clearTimeout(force);
            resolveStop();
        });
        child.kill("SIGTERM");
    });
}
/** Start gateway/serve.py and wait for the address it reports.
 *
 * `credentials` is the instance environment: the workspace provider keys
 * config.ts injects plus anything the instance declares itself. They travel
 * through the child env, never argv, so they are not visible in a process
 * listing. */
export async function startRespanGateway(credentials = {}, options = {}) {
    const root = gatewayRoot();
    const script = join(root, "serve.py");
    const python = gatewayPython(root);
    if (!existsSync(script)) {
        throw new Error(`no Respan Gateway sidecar at ${script} — run \`${INSTALL_COMMAND}\` in this checkout`);
    }
    if (!existsSync(python)) {
        throw new Error(`no gateway Python environment at ${python} — run \`${INSTALL_COMMAND}\` in this checkout`);
    }
    const child = spawn(python, [script, "--port", "0"], {
        cwd: dirname(root),
        env: sidecarEnvironment(credentials),
        stdio: ["ignore", "pipe", "pipe"],
    });
    let stderr = "";
    child.stderr?.setEncoding("utf8");
    child.stderr?.on("data", (chunk) => {
        stderr = (stderr + chunk).slice(-4_000);
    });
    let url;
    try {
        url = await new Promise((resolveUrl, rejectUrl) => {
            let buffer = "";
            let settled = false;
            const settle = (error, value) => {
                if (settled)
                    return;
                settled = true;
                clearTimeout(timer);
                if (error)
                    rejectUrl(error);
                else
                    resolveUrl(value);
            };
            const timer = setTimeout(() => settle(new Error(`the Respan Gateway did not report its address in ${(options.timeoutMs ?? READY_TIMEOUT_MS) / 1_000}s${stderr ? `: ${stderr.trim().slice(-400)}` : ""}`)), options.timeoutMs ?? READY_TIMEOUT_MS);
            child.stdout?.setEncoding("utf8");
            child.stdout?.on("data", (chunk) => {
                buffer += chunk;
                let newline;
                while ((newline = buffer.indexOf("\n")) !== -1) {
                    const line = buffer.slice(0, newline).trim();
                    buffer = buffer.slice(newline + 1);
                    const ready = line ? readyUrl(line) : null;
                    if (ready) {
                        settle(null, ready);
                        return;
                    }
                }
            });
            child.on("error", (error) => settle(new Error(`could not start the Respan Gateway: ${error.message}`)));
            child.on("exit", (code, signal) => settle(new Error(`the Respan Gateway stopped before it was listening (${signal ?? code})${stderr ? `: ${stderr.trim().slice(-400)}` : ""}`)));
        });
    }
    catch (error) {
        await stopSidecar(child);
        throw error;
    }
    return { url, stop: () => stopSidecar(child) };
}
function decodeConfig(raw) {
    const config = (raw ?? {});
    if (config.tools !== undefined && typeof config.tools !== "boolean")
        throw new Error("tools must be a boolean");
    if (config.model !== undefined && typeof config.model !== "string")
        throw new Error("model must be a string");
    return {
        ...(typeof config.model === "string" && config.model ? { model: config.model } : {}),
        ...(typeof config.tools === "boolean" ? { tools: config.tools } : {}),
    };
}
async function createGatewayInstance(input) {
    const { config } = input;
    const sidecar = await startRespanGateway(input.environment);
    const apiUrl = `${sidecar.url}/v1`;
    let stopped = false;
    let catalog = config.model && config.model !== STATIC_MODELS.default
        ? { default: config.model, options: [{ id: config.model, label: config.model, custom: true }, ...STATIC_MODELS.options] }
        : STATIC_MODELS;
    // The gateway merges every configured provider's catalog, which is what
    // makes routing visible in the picker: the badge is the vendor a model name
    // resolves to. A provider that cannot list its models (an offline or
    // key-less one) answers with an error, so a failed refresh keeps the seeded
    // options instead of emptying the picker.
    const fetchModels = async () => {
        try {
            const response = await fetch(`${apiUrl}/models`, { signal: AbortSignal.timeout(8_000) });
            if (!response.ok)
                return;
            const json = await response.json();
            const rows = Array.isArray(json.data) ? json.data : [];
            const options = [];
            for (const row of rows) {
                if (typeof row.id !== "string" || !row.id)
                    continue;
                // The gateway also serves image, speech, embedding and video models;
                // a chat picker offers only the ones a chat turn can use.
                if (typeof row.kind === "string" && row.kind && row.kind !== "chat")
                    continue;
                options.push({
                    id: row.id,
                    label: row.id,
                    custom: true,
                    ...(typeof row.owned_by === "string" && row.owned_by ? { provider: row.owned_by } : {}),
                });
            }
            if (!options.length)
                return;
            if (config.model && !options.some((model) => model.id === config.model)) {
                options.unshift({ id: config.model, label: config.model, custom: true });
            }
            catalog = { default: config.model ?? options[0].id, options };
        }
        catch {
            // Opportunistic, like the openai-compat catalog refresh.
        }
    };
    await fetchModels();
    const runtime = createOpenAIChatRuntime({
        input,
        driverKind: DRIVER_KIND,
        apiKey: LOCAL_CLIENT_KEY,
        apiUrl,
        tools: config.tools,
        models: () => catalog,
        refreshModels: fetchModels,
        requestBody: (model, messages, stream) => ({
            model,
            messages,
            stream,
            stream_options: stream ? { include_usage: true } : undefined,
        }),
        httpErrorLabel: "gateway",
        missingKeyError: "the local Respan Gateway is not running",
        unavailableReason: "the local Respan Gateway is not running",
        timeoutMs: IDLE_TIMEOUT_MS,
        reasoning: true,
        billing: "metered",
        includeUsageInCompleted: true,
        nativeLog: {
            source: "respan-gateway.chat.completions",
            outgoing: (_turn, messages, model) => ({ model, messageCount: messages.length }),
            incoming: ({ text, reasoning, usage }) => ({
                textLength: text.length,
                reasoningLength: reasoning.length,
                usage,
            }),
        },
    });
    const dispose = async () => {
        await runtime.dispose();
        stopped = true;
        await sidecar.stop();
    };
    return {
        instanceId: input.instanceId,
        driverKind: DRIVER_KIND,
        displayName: input.displayName,
        enabled: input.enabled,
        get models() {
            return catalog;
        },
        refreshModels: fetchModels,
        // A stopped sidecar is a real answer, not an error: a disposed instance
        // must never look like a running gateway the picker can send to.
        snapshot: async () => stopped
            ? { state: "unavailable", reason: "the local Respan Gateway was stopped" }
            : { state: "available", authenticated: true, version: null, billing: "metered" },
        adapter: runtime.adapter,
        generateText: runtime.generateText,
        dispose,
    };
}
export const RespanGatewayDriver = {
    driverKind: DRIVER_KIND,
    metadata: {
        displayName: "Respan Gateway (local)",
        supportsMultipleInstances: true,
        access: "custom",
    },
    models: STATIC_MODELS,
    install: {
        docsUrl: "https://github.com/respanai/respan-gateway",
        // The gateway needs its Python environment before this instance can run;
        // MOBOT starts and stops the sidecar itself from then on.
        command: { darwin: INSTALL_COMMAND, linux: INSTALL_COMMAND, win32: INSTALL_COMMAND },
    },
    decodeConfig,
    defaultConfig: () => decodeConfig({}),
    create: createGatewayInstance,
};
