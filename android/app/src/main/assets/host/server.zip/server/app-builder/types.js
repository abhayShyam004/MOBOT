// Types and contracts for Phase C — Full-Stack App Builder.
//
// Every generated app lives in an isolated project workspace under
// $DATA_DIR/projects/<projectId>/, tracked by a first-class ProjectRecord.
// This metadata coordinates local editing, build/test execution, localhost
// previewing, and deployment providers (Vercel, Render).
export {};
