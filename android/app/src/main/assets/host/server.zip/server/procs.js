// Cross-platform process spawning for the agent CLIs. Four Windows
// differences are exposed to drivers through this module:
//   1. CreateProcess can't exec npm .cmd/.bat shims or node-shebang scripts
//      directly. env-path resolves those to their real .exe / `node script`
//      entry without a shell, so quoting-sensitive JSON argv stays intact.
//   2. No process-group kill (kill(-pid) is POSIX) — taskkill /T reaps the
//      whole tree, CLI + its spawned MCP proxies alike.
//   3. Console apps spawned from the GUI shell flash a console window
//      unless windowsHide is set.
//   4. CreateProcess has a 32,767-character command-line limit. Keep prompt
//      bodies on stdin or in private files and fail clearly if a future
//      driver accidentally puts one back in argv.
import { spawn, execFile, } from "node:child_process";
import { join } from "node:path";
import { resolveCliSpawn } from "./env-path.js";
export function resolveCli(cli, args = [], env) {
    return resolveCliSpawn(cli, args, env);
}
/** Leave headroom below CreateProcess' 32,767 UTF-16 code-unit limit for
 * libuv's quoting and environment-specific executable expansion. */
export const WINDOWS_SAFE_COMMAND_LINE_CHARS = 30_000;
/** Conservative size of the command line libuv will give CreateProcess.
 * JSON string quoting escapes every slash/quote case Windows quoting needs,
 * so this can over-count but cannot hide a dangerous launch. */
export function estimatedWindowsCommandLineChars(resolved) {
    return [resolved.command, ...resolved.args].reduce((total, value) => total + JSON.stringify(value).length + 1, 0);
}
export function assertSafeCliArgv(resolved, platform = process.platform) {
    if (platform !== "win32")
        return;
    if (estimatedWindowsCommandLineChars(resolved) <= WINDOWS_SAFE_COMMAND_LINE_CHARS)
        return;
    const error = new Error("agent CLI launch arguments exceed Windows' safe command-line limit; pass large prompts through stdin or a file");
    error.code = "ENAMETOOLONG";
    throw error;
}
// Only spawnCli establishes a private POSIX group. A plain spawned child
// (for example inside an MCP gate) may share our own group: never signal it.
const cliGroups = new WeakSet();
const stopping = new WeakMap();
export function spawnCli(cli, args, opts) {
    const resolved = resolveCli(cli, args);
    assertSafeCliArgv(resolved);
    const child = spawn(resolved.command, resolved.args, {
        ...opts,
        // posix: own process group so kill(-pid) reaps child MCP servers;
        // win32: taskkill /T does the reaping instead (see killCliTree)
        ...(process.platform === "win32" ? { windowsHide: true } : { detached: true }),
    }); // callers always pipe all three
    if (process.platform !== "win32")
        cliGroups.add(child);
    // A write to a dying child's stdin fails differently per platform, and one
    // of the ways is fatal. On POSIX the kill is synchronous, the stream is
    // already destroyed by the time anything writes, and the write throws into
    // the caller's try/catch. On Windows killCliTree goes through taskkill — a
    // subprocess — so there is a window where the child is dead but its pipe is
    // not, and a write during it errors *asynchronously* on the stream. No
    // driver listens for that, an unlistened stream error is an uncaught
    // exception, and the whole harness exits over one dead CLI. The error
    // carries no information the drivers don't already get from `close`, which
    // is where every one of them settles the turn — so it is swallowed, not
    // logged.
    child.stdin?.on("error", () => { });
    return child;
}
export function execCli(cli, args, opts, cb) {
    const resolved = resolveCli(cli, args);
    try {
        assertSafeCliArgv(resolved);
    }
    catch (error) {
        queueMicrotask(() => cb(error instanceof Error ? error : new Error(String(error)), "", ""));
        return;
    }
    execFile(resolved.command, resolved.args, { ...opts, windowsHide: true, encoding: "utf8" }, (err, stdout, stderr) => cb(err, stdout, stderr));
}
export function describeSpawnFailure(err, cli) {
    if (err.code === "ENOENT")
        return { message: `\`${cli}\` isn't installed, or isn't on this app's PATH`, setup: true };
    if (err.code === "EACCES" || err.code === "EPERM")
        return { message: `\`${cli}\` isn't executable — check its file permissions`, setup: true };
    if (err.code === "ENAMETOOLONG")
        return {
            message: `\`${cli}\` received too much launch data for Windows; update this provider or pass its prompt through stdin/a file`,
            setup: false,
        };
    return { message: `spawn failed: ${err.message}`, setup: false };
}
/** Stop an owned CLI group, including helpers after its root exits. timeoutMs
 * is the TERM grace period; SIGKILL gets one further second to settle. Helpers
 * that deliberately detach into another group are outside this ownership. */
export function killCliTree(child, timeoutMs = 5_000) {
    const existing = stopping.get(child);
    if (existing)
        return existing;
    const pid = child.pid;
    if (!pid)
        return Promise.resolve(true);
    if (!Number.isInteger(pid) || pid <= 1 || pid === process.pid)
        return Promise.resolve(false);
    const run = stopCliTree(child, pid, Number.isFinite(timeoutMs) ? Math.max(0, timeoutMs) : 5_000);
    stopping.set(child, run);
    // A failed attempt may be retried. Remember success so a delayed caller
    // cannot signal a reused PID/group after this child's group disappeared.
    void run.then((stopped) => { if (!stopped)
        stopping.delete(child); });
    return run;
}
async function stopCliTree(child, pid, timeoutMs) {
    const exited = () => child.exitCode !== null || child.signalCode !== null;
    if (process.platform !== "win32") {
        const group = cliGroups.has(child);
        const settled = () => {
            if (!exited())
                return false;
            if (!group)
                return true;
            try {
                process.kill(-pid, 0);
                return false;
            }
            catch (error) {
                // EPERM and other failures do not prove that the group is gone.
                return error.code === "ESRCH";
            }
        };
        const signal = (value) => {
            try {
                if (group)
                    process.kill(-pid, value);
                else
                    child.kill(value);
            }
            catch {
                try {
                    child.kill(value);
                }
                catch { /* report uncertainty below */ }
            }
        };
        const wait = async (ms) => {
            const deadline = Date.now() + ms;
            while (!settled()) {
                const remaining = deadline - Date.now();
                if (remaining <= 0)
                    return false;
                await new Promise((resolve) => setTimeout(resolve, Math.min(25, remaining)));
            }
            return true;
        };
        if (settled())
            return true;
        signal("SIGTERM");
        if (await wait(timeoutMs))
            return true;
        signal("SIGKILL");
        return wait(1_000);
    }
    if (exited())
        return true;
    return new Promise((resolve) => {
        let timer;
        let finished = false;
        const done = (stopped) => {
            if (finished)
                return;
            finished = true;
            clearTimeout(timer);
            child.off("close", closed);
            child.off("exit", closed);
            resolve(stopped);
        };
        const closed = () => done(true);
        child.once("close", closed);
        timer = setTimeout(() => done(false), timeoutMs);
        timer.unref?.();
        execFile("taskkill", ["/PID", String(pid), "/T", "/F"], { windowsHide: true }, (err) => {
            if (finished)
                return;
            if (!err) {
                // taskkill can finish before Node observes the process exit. Do not
                // report success until both have happened; callers may rename the
                // executable immediately. Conversely, inherited pipes can delay
                // close after exit, so a confirmed exit need not wait for those pipes.
                if (exited())
                    done(true);
                else
                    child.once("exit", closed);
                return;
            }
            try {
                // taskkill is unavailable or the tree lookup failed. At least stop
                // the process we own instead of leaving the entire turn running.
                child.kill();
            }
            catch {
                /* already gone */
            }
        });
    });
}
/** Per-turn broker channel: unix socket on POSIX, named pipe on Windows
 * (Node can't listen on a filesystem socket path there — EACCES). */
export function brokerSocketPath(dataDir, tag) {
    return process.platform === "win32"
        // Named pipes share a global namespace; DATA_DIR cannot isolate two
        // concurrent app instances the way a POSIX socket directory does.
        ? `\\\\.\\pipe\\openmausbot-perm-${process.pid}-${tag}`
        : join(dataDir, `perm-${tag}.sock`);
}
