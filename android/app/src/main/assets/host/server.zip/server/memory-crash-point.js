const POINTS = new Set([
    "before-prepare",
    "after-prepare",
    "after-records",
    "after-manifest",
    "before-commit",
    "after-commit",
    "after-response",
]);
/** True when this boot was told to die at a transition. Diagnostics only. */
export function memoryCrashPoint() {
    const value = process.env.OMB_MEMORY_CRASH_POINT;
    return value && POINTS.has(value) ? value : null;
}
/** Die here if, and only if, this boot was told to. Never returns when armed. */
export function maybeCrashMemory(point) {
    if (process.env.OMB_MEMORY_CRASH_POINT !== point)
        return;
    process.kill(process.pid, "SIGKILL");
}
