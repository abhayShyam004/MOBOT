import { StaleWorkerFenceError } from "../tasks.js";
/**
 * Executes an outcome external mutation under strict fencing and ambiguity resolution rules.
 *
 * Flow:
 * 1. Checks if operation exists. If already completed, returns immediately (idempotent).
 * 2. If operation exists from a previous worker in an unsettled state (dispatched, unknown, reconciling),
 *    the current worker MUST reconcile it before considering any re-dispatch!
 * 3. Before calling external provider, persists status "dispatched" synchronously to disk.
 * 4. Calls external provider (mocked provider in M3.1B).
 * 5. When provider responds, validates worker lease immediately before committing status "completed".
 *    If the worker lost its lease while the request was in flight, the local commit is strictly rejected,
 *    and the operation remains unsettled for the next worker to reconcile.
 */
export async function executeFencedOutcomeMutation(params) {
    const { operationJournal, jobManager, fencingToken, actionType, idempotencyKey, payload, dispatchFn, reconcileFn } = params;
    // Step 1: Pre-flight lease validation
    jobManager.assertWorkerLeaseActive(fencingToken);
    // Step 2: Find or create journal entry
    const { entry, isNew } = operationJournal.findOrCreateOperation({
        actionType,
        idempotencyKey,
        payload,
        jobId: fencingToken.jobId,
        fencingToken,
    });
    // If already settled successfully, return cached result
    if (entry.status === "completed") {
        return { status: "committed", result: entry.result?.data, entry };
    }
    // Step 3: Handle unsettled operation from previous worker
    if (!isNew && (entry.status === "dispatched" || entry.status === "unknown" || entry.status === "reconciling" || (entry.status === "failed" && !entry.provenNotExecuted))) {
        const reconResult = await operationJournal.reconcile(entry.operationId, reconcileFn, fencingToken);
        if (reconResult.reconciled && reconResult.entry?.status === "completed") {
            return { status: "reconciled", result: reconResult.entry.result?.data, entry: reconResult.entry };
        }
        // If reconciliation failed or is still unknown, do NOT re-dispatch!
        return {
            status: "uncertain_unknown",
            entry: reconResult.entry || entry,
            error: `Unsettled operation ${entry.operationId} cannot be safely re-dispatched without authoritative negative`,
        };
    }
    // Step 4: Persist DISPATCHED state BEFORE issuing external request
    operationJournal.markDispatched(entry.operationId, undefined, fencingToken);
    // Step 5: Execute external call
    let providerResult;
    try {
        providerResult = await dispatchFn();
    }
    catch (dispatchErr) {
        // Ambiguous failure: record UNKNOWN and do NOT mark failed unless proven not executed
        operationJournal.markUnknown(entry.operationId, dispatchErr?.message ?? "Dispatch error", fencingToken);
        return {
            status: "uncertain_unknown",
            entry,
            error: dispatchErr?.message ?? "External mutation dispatch resulted in uncertain outcome",
        };
    }
    // Step 6: Atomic commit with fencing check
    try {
        const completedEntry = operationJournal.markCompleted(entry.operationId, { success: true, data: providerResult }, fencingToken);
        return { status: "committed", result: providerResult, entry: completedEntry || entry };
    }
    catch (fenceErr) {
        if (fenceErr instanceof StaleWorkerFenceError) {
            // Worker lost lease while external request was in-flight!
            // Local commit is rejected; entry remains in "dispatched" state on disk for next worker
            return {
                status: "fenced_out",
                entry,
                error: `Worker ${fencingToken.workerId} lost lease while mutation was in flight: ${fenceErr.message}`,
            };
        }
        throw fenceErr;
    }
}
