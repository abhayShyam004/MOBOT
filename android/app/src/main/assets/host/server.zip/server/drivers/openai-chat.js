import { newEventId, newId } from "../contracts.js";
import { redactSecretsInText } from "../redact.js";
import { askQuestionSummary, normalizeAskUserInput } from "../../shared/ask-question.js";
import { toolDetailPreview } from "../tool-summary.js";
import { ChatToolSessionError, mountChatTools } from "./chat-mcp-tools.js";
import { createChatToolApproval } from "./chat-tool-approval.js";
import { ChatProtocolError, ChatReasoningDetails, ChatToolCalls, MAX_CHAT_TOOL_CALLS, object } from "./openai-chat-protocol.js";
import { appendNative } from "./native.js";
import { classifyError, computeBackoff, interruptibleDelay, RETRY_MAX_ATTEMPTS } from "./retry.js";
/** The message of a JSON error body a provider returned with HTTP 200.
 *  MiniMax reports auth, balance, and parameter failures as `base_resp`. */
function providerError(json) {
    if (typeof json.error === "string")
        return json.error;
    const error = object(json.error);
    if (error)
        return typeof error.message === "string" ? error.message : "unknown error";
    const code = json.base_resp?.status_code;
    if (typeof code === "number" && code !== 0) {
        const msg = typeof json.base_resp?.status_msg === "string" ? json.base_resp.status_msg : "";
        return `upstream error ${code}${msg ? `: ${msg}` : ""}`;
    }
    return null;
}
const usageFrom = (usage) => usage
    ? { input: usage.prompt_tokens ?? 0, output: usage.completion_tokens ?? 0 }
    : null;
const asError = (value) => value instanceof Error ? value : new Error(String(value));
/** Shared runtime for the three providers that speak OpenAI chat completions. */
export function createOpenAIChatRuntime(options) {
    const { input } = options;
    const listeners = new Set();
    const active = new Map();
    const emit = (event) => {
        for (const listener of Array.from(listeners))
            listener(event);
    };
    const base = (threadId, turnId) => ({
        eventId: newEventId(),
        provider: options.driverKind,
        threadId,
        turnId,
        createdAt: new Date().toISOString(),
    });
    const complete = async (messages, model, stream, signal, onDelta, tools = []) => {
        // Idle timer that is renewed on every received chunk during streaming
        const timeoutController = new AbortController();
        let idleTimer = null;
        const resetIdleTimer = () => {
            if (idleTimer)
                clearTimeout(idleTimer);
            idleTimer = setTimeout(() => {
                timeoutController.abort(new DOMException("Streaming idle timeout elapsed", "AbortError"));
            }, options.timeoutMs);
        };
        resetIdleTimer();
        try {
            const activeSignal = signal
                ? AbortSignal.any([signal, timeoutController.signal])
                : timeoutController.signal;
            const response = await fetch(`${options.apiUrl}/chat/completions`, {
                method: "POST",
                headers: { authorization: `Bearer ${options.apiKey}`, "content-type": "application/json" },
                body: JSON.stringify({
                    ...options.requestBody(model, messages, stream),
                    ...(tools.length ? { tools, tool_choice: "auto" } : {}),
                }),
                signal: activeSignal,
            });
            if (!response.ok) {
                const body = await response.text().catch(() => "");
                throw new Error(`${options.httpErrorLabel} HTTP ${response.status}${body ? `: ${body.slice(0, 200)}` : ""}`);
            }
            if (!stream || response.headers.get("content-type")?.includes("application/json")) {
                const json = await response.json();
                const bodyError = providerError(json);
                if (bodyError)
                    throw new ChatProtocolError(`provider returned a completion error: ${bodyError.slice(0, 200)}`);
                const message = json.choices?.[0]?.message;
                if (!message || !object(message) || !["content", "reasoning_content", "reasoning", "reasoning_details", "tool_calls", "function_call"].some((key) => key in message)) {
                    throw new ChatProtocolError("provider returned no completion message");
                }
                if (message?.function_call)
                    throw new ChatProtocolError("legacy function_call is unsupported; use structured tool_calls");
                const calls = new ChatToolCalls();
                calls.add(message?.tool_calls, false);
                const details = new ChatReasoningDetails();
                details.add(message.reasoning_details);
                const reasoning = message.reasoning_content ?? message.reasoning;
                const finishReason = json.choices?.[0]?.finish_reason ?? null;
                activeSignal.throwIfAborted();
                return {
                    text: typeof message?.content === "string" ? message.content : "",
                    reasoning: options.reasoning && typeof reasoning === "string"
                        ? reasoning
                        : "",
                    usage: usageFrom(json.usage),
                    toolCalls: calls.finish(finishReason, false),
                    finishReason,
                    protocolReasoning: typeof reasoning === "string" ? reasoning : "",
                    protocolReasoningDetails: details.blocks,
                };
            }
            if (!response.body) {
                throw new Error(options.noBodyError ?? `${options.httpErrorLabel} returned no response body`);
            }
            let text = "";
            let reasoning = "";
            let protocolReasoning = "";
            let usage = null;
            let finishReason = null;
            let malformedFrame = false;
            let sawChoice = false;
            const calls = new ChatToolCalls();
            const details = new ChatReasoningDetails();
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let buffer = "";
            const consumeDataLine = (line, atEof = false) => {
                if (!line.startsWith("data:"))
                    return false;
                const data = line.slice(5).trim();
                if (data === "[DONE]")
                    return true;
                let chunk;
                try {
                    chunk = JSON.parse(data);
                }
                catch {
                    // A tail left in the buffer when the socket closed is an INCOMPLETE
                    // frame, not a bad one: a stop, an abort or a dropped connection all
                    // end mid-frame. Only a properly newline-terminated frame that will
                    // not parse means the provider actually sent something malformed.
                    // Counting the tail here turned a stopped turn into a hard,
                    // non-retryable failure (`calls.finish(finishReason, malformedFrame)`).
                    if (!atEof)
                        malformedFrame = true;
                    return false;
                }
                const chunkError = providerError(chunk);
                if (chunkError)
                    throw new ChatProtocolError(`provider returned a streaming completion error: ${chunkError.slice(0, 200)}`);
                const choice = chunk.choices?.find((row) => row.index === undefined || row.index === 0);
                const delta = choice?.delta;
                if (object(delta))
                    sawChoice = true;
                if (delta?.function_call)
                    throw new ChatProtocolError("legacy function_call is unsupported; use structured tool_calls");
                calls.add(delta?.tool_calls, true);
                details.add(delta?.reasoning_details);
                if (choice?.finish_reason)
                    finishReason = choice.finish_reason;
                const reasoningPart = delta?.reasoning_content ?? delta?.reasoning;
                if (typeof reasoningPart === "string")
                    protocolReasoning += reasoningPart;
                const reasoningDelta = options.reasoning && typeof reasoningPart === "string"
                    ? reasoningPart
                    : "";
                const contentDelta = typeof delta?.content === "string" ? delta.content : "";
                if (reasoningDelta) {
                    reasoning += reasoningDelta;
                    onDelta?.(reasoningDelta, "reasoning_text");
                }
                if (contentDelta) {
                    text += contentDelta;
                    onDelta?.(contentDelta, "assistant_text");
                }
                if (chunk.usage)
                    usage = usageFrom(chunk.usage);
                return false;
            };
            try {
                readLoop: for (;;) {
                    const { done, value } = await reader.read();
                    if (done) {
                        buffer += decoder.decode();
                        const line = buffer.trim();
                        if (line && line !== "data: [DONE]")
                            consumeDataLine(line, true);
                        // MiniMax's api.minimax.io/v1 closes the connection after the
                        // finish_reason chunk and never sends `[DONE]`.
                        if (buffer.trim() === "data: [DONE]" || finishReason)
                            break;
                        if (!sawChoice) {
                            let body;
                            try {
                                body = JSON.parse(buffer);
                            }
                            catch {
                                body = undefined;
                            }
                            const bodyError = body ? providerError(body) : null;
                            if (bodyError)
                                throw new ChatProtocolError(`provider returned a completion error: ${bodyError.slice(0, 200)}`);
                        }
                        throw new ChatProtocolError("Stream ended before completion");
                    }
                    resetIdleTimer();
                    buffer += decoder.decode(value, { stream: true });
                    if (buffer.length > 2_000_000)
                        throw new ChatProtocolError("provider stream frame exceeded the size limit");
                    let newline;
                    while ((newline = buffer.indexOf("\n")) !== -1) {
                        const line = buffer.slice(0, newline).trim();
                        buffer = buffer.slice(newline + 1);
                        if (consumeDataLine(line))
                            break readLoop;
                    }
                }
            }
            finally {
                await reader.cancel().catch(() => { });
            }
            activeSignal.throwIfAborted();
            if (!sawChoice)
                throw new ChatProtocolError("provider returned no streaming completion choice");
            return { text, reasoning, usage, toolCalls: calls.finish(finishReason, malformedFrame), finishReason, protocolReasoning, protocolReasoningDetails: details.blocks };
        }
        finally {
            if (idleTimer)
                clearTimeout(idleTimer);
        }
    };
    const messagesFor = (turn) => [
        ...(turn.system ? [{ role: "system", content: turn.system }] : []),
        ...(turn.transcript ?? []).map((message) => ({
            role: message.role,
            content: message.text,
        })),
        { role: "user", content: turn.text },
    ];
    const sendTurn = async (turn) => {
        if (!options.apiKey)
            throw new Error(options.missingKeyError);
        if (active.has(turn.threadId))
            throw new Error("a turn is already running on this thread");
        const turnId = newId();
        const abort = new AbortController();
        const messages = messagesFor(turn);
        const model = turn.model || options.models().default;
        const secrets = [options.apiKey];
        for (const integration of Object.values(turn.integrations ?? {})) {
            const entries = object(integration);
            const specs = entries && "command" in entries ? [entries] : Object.values(entries ?? {}).map(object);
            for (const spec of specs) {
                for (const [key, value] of Object.entries(object(spec?.env) ?? {})) {
                    if (/key|token|password|secret|authorization/i.test(key) && typeof value === "string" && value)
                        secrets.push(value);
                }
            }
        }
        const safeText = (text) => {
            let safe = text;
            for (const secret of secrets)
                if (secret)
                    safe = safe.split(secret).join("[redacted]");
            return redactSecretsInText(safe);
        };
        const preview = (value) => toolDetailPreview(JSON.parse(JSON.stringify(value, (_key, part) => typeof part === "string" ? safeText(part) : part)));
        const native = (dir, msg) => appendNative(turn.threadId, {
            dir, source: options.nativeLog.source,
            msg: JSON.parse(JSON.stringify(msg, (_key, part) => typeof part === "string" ? safeText(part) : part)),
        });
        const approval = createChatToolApproval({
            signal: abort.signal,
            open: (ask) => emit({
                ...base(turn.threadId, turnId), type: "request.opened", requestType: "permission",
                requestId: ask.id, tool: ask.tool, summary: ask.summary, allowSession: false,
            }),
            openQuestions: (ask) => emit({
                ...base(turn.threadId, turnId), type: "request.opened", requestType: "question",
                requestId: ask.id, tool: ask.tool, summary: ask.summary,
                ...(ask.questions?.length ? { questions: ask.questions } : {}),
                ...(ask.choices?.length ? { choices: ask.choices } : {}),
            }),
            resolved: (ask, allowed, source) => emit({
                ...base(turn.threadId, turnId), type: "request.resolved", requestId: ask.id,
                behavior: allowed ? "allow" : "deny", source,
            }),
            resolvedQuestions: (ask, answer, source) => emit({
                ...base(turn.threadId, turnId), type: "request.resolved", requestId: ask.id,
                behavior: "answer", source,
                ...(answer ? { answer } : {}),
            }),
        });
        let resolveDone;
        const done = new Promise((resolve) => { resolveDone = resolve; });
        active.set(turn.threadId, { abort, turnId, done, approval, turnTools: turn.turnTools ?? [] });
        emit({ ...base(turn.threadId, turnId), type: "turn.started" });
        emit({ ...base(turn.threadId, turnId), type: "session.started", sessionId: null, model });
        void (async () => {
            let tools;
            const usage = { input: 0, output: 0 };
            let hasUsage = false;
            let ok = false;
            let stopReason = null;
            let failure;
            let toolFailed = false;
            const denials = [];
            const seenCalls = new Set();
            try {
                tools = await mountChatTools(options.tools === false ? undefined : turn.integrations, abort.signal);
                // Harness-run tools (document page reads, ask_user) ride beside the
                // MCP tools in the model's catalog — but only when this endpoint
                // accepts tools at all: a text-only endpoint must see no tools key.
                const harnessDefinitions = options.tools === false ? [] : (turn.turnTools ?? []).map((tool) => ({
                    type: "function",
                    function: { name: tool.name, description: tool.description, parameters: tool.inputSchema },
                }));
                const allDefinitions = tools.definitions.concat(harnessDefinitions);
                for (let round = 0; round < 64; round++) {
                    abort.signal.throwIfAborted();
                    native("out", options.nativeLog.outgoing(turn, messages, model));
                    let attempt = 0;
                    let completion;
                    for (;;) {
                        let streamed = false;
                        const pending = { assistant_text: "", reasoning_text: "" };
                        const delta = (text, streamKind, flush = false) => {
                            let combined = pending[streamKind] + text;
                            // Mask complete matches before holding a suffix: otherwise a key
                            // such as "abab" could be split at its own repeated prefix.
                            for (const secret of secrets)
                                if (secret)
                                    combined = combined.split(secret).join("[redacted]");
                            let hold = 0;
                            // A configured credential can straddle chunks. Hold any suffix
                            // that could be its prefix until the next chunk disambiguates it.
                            if (!flush)
                                for (const secret of secrets) {
                                    for (let length = Math.min(secret.length - 1, combined.length); length > hold; length--) {
                                        if (combined.endsWith(secret.slice(0, length))) {
                                            hold = length;
                                            break;
                                        }
                                    }
                                }
                            pending[streamKind] = hold ? combined.slice(-hold) : "";
                            const visible = safeText(hold ? combined.slice(0, -hold) : combined);
                            if (visible)
                                emit({ ...base(turn.threadId, turnId), type: "content.delta", streamKind, delta: visible });
                        };
                        try {
                            completion = await complete(messages, model, true, abort.signal, (text, streamKind) => {
                                streamed = true;
                                delta(text, streamKind);
                            }, allDefinitions);
                            delta("", "assistant_text", true);
                            delta("", "reasoning_text", true);
                            break;
                        }
                        catch (value) {
                            const error = asError(value);
                            const verdict = classifyError(error);
                            // Once a call has been handled, never replay it through a turn retry.
                            if (options.retryScale === undefined || abort.signal.aborted || streamed || seenCalls.size ||
                                error instanceof ChatProtocolError || !verdict.transient || attempt >= RETRY_MAX_ATTEMPTS - 1)
                                throw error;
                            const delayMs = computeBackoff(attempt++);
                            emit({ ...base(turn.threadId, turnId), type: "turn.retrying", attempt, delayMs, reason: verdict.reason });
                            await interruptibleDelay(delayMs * options.retryScale, abort.signal).promise;
                            abort.signal.throwIfAborted();
                        }
                    }
                    native("in", options.nativeLog.incoming(completion));
                    if (completion.usage) {
                        usage.input += completion.usage.input;
                        usage.output += completion.usage.output;
                        hasUsage = true;
                        emit({ ...base(turn.threadId, turnId), type: "thread.token-usage.updated", ...usage });
                    }
                    // Reasoning on a tool-call round belongs to the protocol, not a final reply.
                    const reply = completion.text.trim() ? completion.text : completion.toolCalls.length ? "" : completion.reasoning;
                    if (reply.trim())
                        emit({ ...base(turn.threadId, turnId), type: "item.completed", itemType: "assistant_text", text: safeText(reply) });
                    abort.signal.throwIfAborted();
                    if (!completion.toolCalls.length) {
                        if (!reply.trim())
                            throw new ChatProtocolError("provider returned an empty response");
                        if (completion.finishReason && completion.finishReason !== "stop") {
                            throw new ChatProtocolError(`provider did not finish the response (${completion.finishReason})`);
                        }
                        if (toolFailed) {
                            stopReason = "tool_error";
                            // Plain words for a real condition: steps failed, so the answer
                            // may claim more than happened. The names, codes and recovery
                            // steps of those failures are diagnostics — they stay in the
                            // turn's own records, never in the person's chat.
                            throw new ChatProtocolError("Some steps in this turn did not succeed, so the reply above may be incomplete.");
                        }
                        ok = true;
                        break;
                    }
                    if (!allDefinitions.length)
                        throw new ChatProtocolError("provider returned tool calls, but no tools are available for this turn");
                    // Validate IDs for the entire batch before executing any of its calls.
                    for (const call of completion.toolCalls) {
                        if (seenCalls.has(call.id))
                            throw new ChatProtocolError("provider reused a tool-call ID; refusing to repeat an operation");
                        seenCalls.add(call.id);
                    }
                    if (seenCalls.size > MAX_CHAT_TOOL_CALLS)
                        throw new ChatProtocolError("tool-call limit reached");
                    messages.push({ role: "assistant", content: completion.text || null, tool_calls: completion.toolCalls,
                        ...(completion.protocolReasoning ? { reasoning_content: completion.protocolReasoning } : {}),
                        ...(completion.protocolReasoningDetails.length ? { reasoning_details: completion.protocolReasoningDetails } : {}),
                    });
                    let roundHadFailure = false;
                    for (const call of completion.toolCalls) {
                        abort.signal.throwIfAborted();
                        let result;
                        let started = false;
                        let fatal;
                        try {
                            let args;
                            try {
                                args = JSON.parse(call.function.arguments);
                            }
                            catch {
                                throw new ChatProtocolError("tool arguments are not complete JSON");
                            }
                            if (!object(args))
                                throw new ChatProtocolError("tool arguments must be a JSON object");
                            const inputPreview = preview(args);
                            // A harness-run tool (document page reads) needs no MCP session
                            // and no permission card: it reads only what the user attached.
                            const harnessTool = (turn.turnTools ?? []).find((tool) => tool.name === call.function.name);
                            const startItem = () => {
                                if (started)
                                    return;
                                started = true;
                                emit({ ...base(turn.threadId, turnId), type: "item.started", itemType: "tool", itemId: call.id,
                                    title: call.function.name, ...(inputPreview ? { input: inputPreview } : {}) });
                            };
                            // Either branch below settles the call on its own — no MCP
                            // session, no permission card — and marks it handled so the
                            // permission path is skipped entirely. ask_user is checked by
                            // name first, so a question can never become a permission ask.
                            let handled = false;
                            if (call.function.name === "ask_user") {
                                // The bot's own mid-task question — never a permission ask.
                                // It blocks here until the person answers the card; their
                                // words become the tool result, so the SAME task resumes with
                                // the answer in hand rather than starting over. Structured,
                                // flat, and v2-typed shapes all normalize into the one card
                                // every client renders, free text included.
                                const questions = normalizeAskUserInput(args);
                                if (!questions)
                                    throw new ChatProtocolError("ask_user needs a question");
                                startItem();
                                const answer = await approval.askQuestion("ask_user", askQuestionSummary(questions), { questions });
                                abort.signal.throwIfAborted();
                                if (answer === null) {
                                    denials.push(call.function.name);
                                    result = { ok: false, text: "The question was left unanswered because the turn was stopped or closed. Wrap up the task without the answer, or say what is still needed." };
                                }
                                else {
                                    result = { ok: true, text: answer };
                                }
                                handled = true;
                            }
                            else if (harnessTool) {
                                // A harness-run tool (document page reads) needs no MCP
                                // session and no permission card: it reads only what the
                                // user attached.
                                startItem();
                                const output = await harnessTool.execute(args);
                                result = { text: output, ok: !/^Error:/m.test(output.slice(0, 200)) };
                                handled = true;
                            }
                            else {
                                tools.validate(call.function.name, args);
                            }
                            if (!handled) {
                                // Full access is the person's explicit grant to answer every
                                // prompt. This runtime has no provider reviewer to hand it to,
                                // so it is honoured here: without it every single tool call on
                                // an OpenAI-compatible engine stops for a card, and a Chief's
                                // delegated Full access cannot help either.
                                const allowed = turn.approvalMode === "full"
                                    || await approval.ask(call.function.name, inputPreview ?? "This tool has no arguments.");
                                abort.signal.throwIfAborted();
                                startItem();
                                if (allowed) {
                                    result = await tools.execute(call.function.name, args, abort.signal);
                                }
                                else {
                                    denials.push(call.function.name);
                                    result = { ok: false, text: "Permission denied or expired; the tool was not executed." };
                                }
                            }
                        }
                        catch (error) {
                            if (error instanceof ChatToolSessionError)
                                fatal = error;
                            result = { ok: false, text: abort.signal.aborted
                                    ? "Tool interrupted; an operation already dispatched may have taken effect. Verify its state before retrying."
                                    : safeText(asError(error).message).slice(0, 2_000) };
                        }
                        if (!started)
                            emit({ ...base(turn.threadId, turnId), type: "item.started", itemType: "tool", itemId: call.id, title: call.function.name });
                        // Every branch above assigns a result; the catch does too. The
                        // undefined case is the impossible one, and stays honest about it.
                        const settledResult = result ?? { ok: false, text: "The tool produced no result." };
                        const text = safeText(settledResult.text);
                        const output = preview({ ok: settledResult.ok, result: text });
                        emit({ ...base(turn.threadId, turnId), type: "item.completed", itemType: "tool", itemId: call.id, ok: settledResult.ok, output });
                        if (!settledResult.ok) {
                            toolFailed = true;
                            roundHadFailure = true;
                        }
                        messages.push({ role: "tool", tool_call_id: call.id, content: JSON.stringify({ ok: settledResult.ok, result: text }) });
                        abort.signal.throwIfAborted();
                        if (fatal)
                            throw fatal;
                    }
                    if (!roundHadFailure && completion.toolCalls.length > 0) {
                        toolFailed = false;
                    }
                }
                if (!ok)
                    throw new ChatProtocolError("model-call limit reached before a final response");
            }
            catch (value) {
                stopReason = abort.signal.aborted ? "interrupted" : stopReason ?? "error";
                failure = safeText(asError(value).message).slice(0, 2_000);
            }
            finally {
                approval.close();
                let cleanupFailed = false;
                try {
                    await tools?.close();
                }
                catch {
                    ok = false;
                    stopReason = "error";
                    cleanupFailed = true;
                    failure = "Tool processes could not be stopped; their execution state is uncertain.";
                }
                if (abort.signal.aborted) {
                    ok = false;
                    stopReason = "interrupted";
                }
                if (failure && (!abort.signal.aborted || cleanupFailed)) {
                    emit({ ...base(turn.threadId, turnId), type: "runtime.error", message: failure, terminal: !abort.signal.aborted });
                }
                active.delete(turn.threadId);
                emit({ ...base(turn.threadId, turnId), type: "turn.completed", ok, stopReason, cost: null,
                    ...(hasUsage && (options.includeUsageInCompleted || seenCalls.size) ? { usage } : {}),
                    ...(denials.length ? { denials } : {}),
                });
                resolveDone();
            }
        })();
        return { turnId };
    };
    return {
        instanceId: input.instanceId,
        driverKind: options.driverKind,
        displayName: input.displayName,
        enabled: input.enabled,
        get models() {
            return options.models();
        },
        ...(options.refreshModels ? { refreshModels: options.refreshModels } : {}),
        snapshot: async () => options.apiKey
            ? { state: "available", authenticated: true, version: null, ...(options.billing ? { billing: options.billing } : {}) }
            : { state: "unavailable", reason: options.unavailableReason },
        adapter: {
            provider: options.driverKind,
            capabilities: { sessionModelSwitch: "in-session", customMcp: options.tools !== false, agentsMcp: options.tools !== false, composioMcp: options.tools !== false },
            sendTurn,
            interruptTurn: async (threadId, turnId) => {
                const turn = active.get(threadId);
                if (!turn || (turnId && turn.turnId !== turnId))
                    return;
                turn.abort.abort();
                await turn.done;
            },
            respondToRequest: async (threadId, requestId, decision) => active.get(threadId)?.approval.answer(requestId, decision.behavior, decision.message) ?? "unavailable",
            hasSession: (threadId) => active.has(threadId),
            stopAll: async () => {
                const turns = [...active.values()];
                for (const turn of turns)
                    turn.abort.abort();
                await Promise.all(turns.map((turn) => turn.done));
            },
            onEvent: (listener) => {
                listeners.add(listener);
                return () => listeners.delete(listener);
            },
        },
        generateText: async (prompt, { signal } = {}) => {
            const model = options.generateModel?.() ?? options.models().default;
            const { text, reasoning, toolCalls } = await complete([{ role: "user", content: prompt }], model, false, signal);
            if (toolCalls.length)
                throw new ChatProtocolError("provider returned tool calls to a text-only helper");
            return text.trim() ? text : reasoning;
        },
        dispose: async () => {
            const turns = [...active.values()];
            for (const turn of turns)
                turn.abort.abort();
            await Promise.all(turns.map((turn) => turn.done));
            listeners.clear();
        },
    };
}
