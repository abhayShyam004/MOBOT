// What a running turn had actually done, written down before it says so.
//
// Android kills the app whenever it likes. The chat transcript survives that
// (it is SQLite), and a pending approval card survives it too — but the turn
// itself does not: `busy` is reset on load, and the provider session that was
// mid-flight is gone. The next boot knew a message had been sent and nothing
// about what it had already done, so resuming meant guessing, and guessing
// means either repeating side effects or claiming work that never happened.
//
// This journal is the missing half: at turn start, and after every tool call
// the harness completed, one small atomic file records the request and the
// receipts. Recovery reads it, reconstructs the model's working context from
// what really ran, and continues — never replaying a call whose receipt it
// holds. It is not a task engine and does not try to be one; it is the durable
// fact of "this turn existed and got this far".
import { mkdirSync, readFileSync } from "node:fs";
import { dirname } from "node:path";
import { writeFileAtomic } from "./atomic.js";
const MAX_ENTRIES = 200;
const MAX_RECEIPTS = 40;
const MAX_REQUEST = 4_000;
const MAX_SUMMARY = 180;
/** A turn interrupted days ago is not "recover the app" any more. */
export const RESUME_WINDOW_MS = 6 * 60 * 60_000;
function clamp(text, limit) {
    const trimmed = text.replace(/\s+/g, " ").trim();
    return trimmed.length > limit ? `${trimmed.slice(0, limit - 1)}…` : trimmed;
}
/** A receipt is evidence, not a transcript: it must not become a place where a
 *  token, a JWT or a long payload is parked on disk. */
export function summarizeToolInput(input) {
    let value = "";
    if (typeof input === "string")
        value = input;
    else if (input && typeof input === "object") {
        const record = input;
        for (const key of ["command", "cmd", "path", "file_path", "file", "url", "query", "name"]) {
            const found = record[key];
            if (typeof found === "string" && found.trim()) {
                value = found;
                break;
            }
        }
        if (!value)
            value = JSON.stringify(record);
    }
    return clamp(value
        .replace(/\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}\b/g, "[redacted token]")
        .replace(/\b(sk|pk|ghp|xox[baprs])[-_][A-Za-z0-9_-]{12,}\b/g, "[redacted key]"), MAX_SUMMARY);
}
export class TurnJournal {
    entries = {};
    // A plain field, not a parameter property: the server runs under Node's
    // type stripping (`pnpm dev:server`), which cannot transform the latter and
    // failed to load this module at all.
    file;
    constructor(file) {
        this.file = file;
        try {
            const raw = JSON.parse(readFileSync(file, "utf8"));
            if (raw?.version === 1 && raw.entries && typeof raw.entries === "object")
                this.entries = raw.entries;
        }
        catch {
            // No journal yet, or one this build cannot read: recovery has nothing to
            // stand on, which is exactly what an absent file means.
            this.entries = {};
        }
        // Anything still marked running belonged to a process that is gone. The
        // next boot is the only place that can know that, so it says so before any
        // turn starts.
        let changed = false;
        for (const entry of Object.values(this.entries)) {
            if (entry.state === "running") {
                entry.state = "interrupted";
                changed = true;
            }
        }
        if (changed)
            this.save();
    }
    save() {
        try {
            mkdirSync(dirname(this.file), { recursive: true });
            const ordered = Object.values(this.entries).sort((a, b) => b.updatedAt - a.updatedAt).slice(0, MAX_ENTRIES);
            const body = { version: 1, entries: Object.fromEntries(ordered.map((entry) => [entry.threadId, entry])) };
            writeFileAtomic(this.file, `${JSON.stringify(body, null, 2)}\n`, { mode: 0o600 });
        }
        catch {
            // A journal that cannot be written must not fail the turn it describes;
            // recovery is then unavailable, which is the state it was already in.
        }
    }
    /** A new person turn supersedes whatever recovery was pending on the thread. */
    begin(input) {
        const at = input.at ?? Date.now();
        const entry = {
            threadId: input.threadId,
            botId: input.botId,
            state: "running",
            request: clamp(input.request, MAX_REQUEST),
            startedAt: at,
            updatedAt: at,
            receipts: [],
            resumes: this.entries[input.threadId]?.state === "interrupted" ? this.entries[input.threadId].resumes : 0,
        };
        this.entries[input.threadId] = entry;
        this.save();
        return entry;
    }
    /** The driver mints the turn id after admission; keep it when it appears. */
    observe(threadId, turnId) {
        if (!turnId)
            return;
        const entry = this.entries[threadId];
        if (!entry || entry.turnId === turnId)
            return;
        entry.turnId = turnId;
        entry.updatedAt = Date.now();
        this.save();
    }
    receipt(threadId, receipt) {
        const entry = this.entries[threadId];
        if (!entry || entry.state !== "running")
            return;
        entry.receipts.push({
            tool: clamp(receipt.tool, 120),
            summary: clamp(receipt.summary, MAX_SUMMARY),
            ok: receipt.ok,
            at: receipt.at ?? Date.now(),
        });
        if (entry.receipts.length > MAX_RECEIPTS)
            entry.receipts = entry.receipts.slice(-MAX_RECEIPTS);
        entry.updatedAt = Date.now();
        this.save();
    }
    settle(threadId, state, turnId) {
        const entry = this.entries[threadId];
        if (!entry)
            return;
        // A late completion from a superseded turn must not overwrite the new one.
        if (turnId && entry.turnId && turnId !== entry.turnId)
            return;
        entry.state = state;
        if (turnId)
            entry.turnId = turnId;
        entry.updatedAt = Date.now();
        this.save();
    }
    /** Stop is not an interruption to recover from: the person ended it. */
    cancel(threadId) {
        const entry = this.entries[threadId];
        if (!entry || entry.state !== "running")
            return;
        entry.state = "cancelled";
        entry.updatedAt = Date.now();
        this.save();
    }
    markResumed(threadId, at = Date.now()) {
        const entry = this.entries[threadId];
        if (!entry || entry.state !== "interrupted")
            return;
        entry.resumes += 1;
        entry.lastResumeAt = at;
        entry.state = "running";
        entry.updatedAt = at;
        this.save();
    }
    entry(threadId) {
        return this.entries[threadId];
    }
    list() {
        return Object.values(this.entries).sort((a, b) => b.updatedAt - a.updatedAt);
    }
    /** Interrupted turns recovery may continue, newest first. */
    resumable(now = Date.now(), windowMs = RESUME_WINDOW_MS) {
        return this.list().filter((entry) => entry.state === "interrupted"
            && entry.resumes < 1
            && now - entry.startedAt <= windowMs);
    }
}
/**
 * The prompt a recovered turn carries.
 *
 * It is control-plane context, not a new request: the person's ask is quoted
 * back verbatim, and the receipts say what already happened. The model is told
 * what it must not do (repeat a completed call, claim an unverified result)
 * and what it must do instead (inspect the real state and continue).
 */
export function resumePromptFor(entry) {
    const when = new Date(entry.startedAt).toISOString();
    const lines = [
        "This turn was interrupted when the app stopped. Continue the same task to completion; do not start a different one.",
        "",
        `The person's request (sent ${when}):`,
        entry.request,
        "",
    ];
    if (entry.receipts.length === 0) {
        lines.push("No tool call had completed before the interruption.");
    }
    else {
        lines.push("Tool calls that already completed before the interruption (durable receipts, newest last):");
        for (const receipt of entry.receipts) {
            lines.push(`- ${new Date(receipt.at).toISOString()} ${receipt.tool} (${receipt.ok ? "ok" : "failed"}): ${receipt.summary}`);
        }
    }
    lines.push("", "Before acting:", "- Inspect the workspace and confirm the state those receipts describe. A completed call is not to be repeated.", "- If a call's outcome is missing or uncertain, check the real files or processes before retrying; never assume it failed, and never repeat a step that already has an effect.", "- Do not re-send messages, re-create projects, or re-install anything the receipts say already happened.", "", "Then finish the task and report what you actually verified, including anything still incomplete.");
    return lines.join("\n");
}
/** A short line for the transcript, so the person can see the turn came back. */
export function resumeNoticeFor(entry) {
    const count = entry.receipts.length;
    return count === 0
        ? "Resuming your task…"
        : `Resuming your task from ${count} completed step${count === 1 ? "" : "s"}…`;
}
