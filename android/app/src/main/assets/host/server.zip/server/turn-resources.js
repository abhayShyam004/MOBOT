import { realpathSync } from "node:fs";
import { relative, resolve, sep } from "node:path";
/** One harness owns the data directory. Claims are synchronous and last for
 * the whole turn, not just a click: a screenshot and its following click
 * must see the same desktop. These coordinate app-managed resources; they
 * are not a sandbox for arbitrary shell commands. */
export class TurnResources {
    owners = new Map();
    blocker(resource, owner) {
        for (const [key, current] of this.owners) {
            if (overlaps(key, resource) && !sameOwner(current, owner))
                return current;
        }
        return undefined;
    }
    claim(resource, owner) {
        if (this.blocker(resource, owner))
            return false;
        this.owners.set(resource, owner);
        return true;
    }
    owns(resource, owner) {
        const current = this.owners.get(resource);
        return Boolean(current && sameOwner(current, owner));
    }
    release(owner) {
        for (const [key, current] of this.owners) {
            if (sameOwner(current, owner))
                this.owners.delete(key);
        }
    }
    /** Drop one of an owner's claims early, when the sequence that took it
     * could not finish. The owner's other claims stand until settle. */
    releaseOne(resource, owner) {
        if (this.owns(resource, owner))
            this.owners.delete(resource);
    }
}
function sameOwner(a, b) {
    return a.threadId === b.threadId && a.generation === b.generation;
}
export function workspaceResource(cwd) {
    // Selected folders must exist before the engine starts. Resolve symlinks
    // and native filename casing so aliases cannot grant two writers to the
    // same project on case-insensitive volumes.
    const canonical = realpathSync.native(resolve(cwd));
    return `workspace:${process.platform === "win32" ? canonical.toLowerCase() : canonical}`;
}
function overlaps(a, b) {
    if (a === b)
        return true;
    if (!a.startsWith("workspace:") || !b.startsWith("workspace:"))
        return false;
    const left = a.slice("workspace:".length);
    const right = b.slice("workspace:".length);
    const contains = (parent, child) => {
        const path = relative(parent, child);
        return path === "" || (path !== ".." && !path.startsWith(`..${sep}`) && !path.startsWith(sep) && !/^[A-Za-z]:/.test(path));
    };
    return contains(left, right) || contains(right, left);
}
