import { randomUUID } from "node:crypto";
import { sharedPersistentJobManager, StaleWorkerFenceError, } from "../tasks.js";
import { sharedOutcomeProgressManager } from "./outcome-progress.js";
export class OutcomeExecutionSupervisor {
    workerId;
    jobManager;
    progressManager;
    leaseDurationMs;
    heartbeatIntervalMs;
    mockStepDelayMs;
    patchMessageFn;
    heartbeatTimer = null;
    running = false;
    activeJobs = new Set();
    constructor(options) {
        this.workerId = options?.workerId ?? `worker_${process.pid}_${randomUUID().slice(0, 8)}`;
        this.jobManager = options?.jobManager ?? sharedPersistentJobManager;
        this.progressManager = options?.progressManager ?? sharedOutcomeProgressManager;
        this.leaseDurationMs = options?.leaseDurationMs ?? 60_000;
        this.heartbeatIntervalMs = options?.heartbeatIntervalMs ?? 15_000;
        this.mockStepDelayMs = options?.mockStepDelayMs ?? 10;
        this.patchMessageFn = options?.patchMessageFn;
    }
    setPatchMessageFn(fn) {
        this.patchMessageFn = fn;
    }
    start() {
        if (this.running)
            return;
        this.running = true;
        this.heartbeatTimer = setInterval(() => {
            void this.tick();
        }, this.heartbeatIntervalMs);
    }
    stop() {
        this.running = false;
        if (this.heartbeatTimer) {
            clearInterval(this.heartbeatTimer);
            this.heartbeatTimer = null;
        }
    }
    /**
     * Periodic supervisor tick:
     * 1. Renews active leases for jobs currently being executed by this worker.
     * 2. Recovers orphaned or expired jobs from crashed workers.
     * 3. Claims and begins executing newly QUEUED outcome jobs.
     */
    async tick() {
        const jobs = this.jobManager.listJobs();
        for (const job of jobs) {
            // 1. Process queued jobs
            if (job.state === "QUEUED" && !this.activeJobs.has(job.jobId)) {
                void this.claimAndExecute(job.jobId);
                continue;
            }
            // 2. Takeover check for crashed or expired running jobs
            if (job.state === "RUNNING" && !this.activeJobs.has(job.jobId)) {
                try {
                    // Attempt takeover if lease expired
                    const claimed = this.jobManager.claimJob(job.jobId, this.workerId, this.leaseDurationMs);
                    if (claimed) {
                        void this.executeJobFromCurrentState(claimed.jobId, claimed.fencingGeneration ?? 1);
                    }
                }
                catch { }
            }
        }
    }
    /**
     * Claims a queued job and starts execution loop
     */
    async claimAndExecute(jobId, waitForCompletion = false) {
        if (this.activeJobs.has(jobId))
            return null;
        try {
            const claimedJob = this.jobManager.claimJob(jobId, this.workerId, this.leaseDurationMs);
            this.activeJobs.add(jobId);
            if (waitForCompletion) {
                await this.executeJobFromCurrentState(jobId, claimedJob.fencingGeneration ?? 1);
            }
            else {
                void this.executeJobFromCurrentState(jobId, claimedJob.fencingGeneration ?? 1);
            }
            return claimedJob;
        }
        catch (err) {
            if (err instanceof StaleWorkerFenceError) {
                console.warn(`[OutcomeSupervisor ${this.workerId}] Stale fence claiming job ${jobId}`, err);
            }
            return null;
        }
    }
    /**
     * Core execution loop for a claimed outcome job.
     * M3.1A executes mock steps only with full validation of leases, checkpoints, and progress cards.
     */
    async executeJobFromCurrentState(jobId, fencingGeneration) {
        this.activeJobs.add(jobId);
        try {
            const job = this.jobManager.getJob(jobId);
            if (!job || job.state !== "RUNNING")
                return;
            const cardId = job.stableCardId ?? `card_outcome_${job.jobId}`;
            const totalMilestones = 4;
            const milestoneTitles = [
                "Objective intake & parameter validation",
                "Deterministic workspace synthesis",
                "Independent verification gate",
                "Final outcome delivery & resource release",
            ];
            const startIndex = job.currentMilestoneIndex;
            for (let idx = startIndex; idx < totalMilestones; idx++) {
                // Step A: Pre-execution lease renewal
                this.jobManager.renewLease(jobId, this.workerId, fencingGeneration, this.leaseDurationMs);
                // Step B: Mock execution delay (M3.1A mock-steps only)
                if (this.mockStepDelayMs > 0) {
                    await new Promise((resolve) => setTimeout(resolve, this.mockStepDelayMs));
                }
                const progressPercent = Math.round(((idx + 1) / totalMilestones) * 100);
                const milestoneTitle = milestoneTitles[idx] || `Milestone ${idx + 1}`;
                // Step C: Fenced Checkpoint Write
                const checkpointData = {
                    milestoneIndex: idx,
                    milestoneTitle,
                    progressPercent,
                    completedByWorker: this.workerId,
                    timestamp: Date.now(),
                };
                this.jobManager.writeCheckpointPayloadFenced({
                    jobId,
                    milestoneIndex: idx,
                    workerId: this.workerId,
                    fencingGeneration,
                    payload: {
                        jobId,
                        botId: job.botId,
                        milestoneIndex: idx,
                        milestoneTitle,
                        progressPercent,
                        state: "RUNNING",
                        timestampMs: Date.now(),
                        checksum: "",
                        data: checkpointData,
                    },
                });
                // Step D: Fenced State Transition
                this.jobManager.advanceMilestone({
                    jobId,
                    milestoneIndex: idx,
                    milestoneTitle,
                    progressPercent,
                    workerId: this.workerId,
                    fencingGeneration,
                    data: checkpointData,
                });
                // Step E: Fenced Progress Card Update
                const progressMessage = `Completed ${milestoneTitle}`;
                this.jobManager.updateJobProgressCardFenced({
                    jobId,
                    workerId: this.workerId,
                    fencingGeneration,
                    progressPercent,
                    message: progressMessage,
                });
                // Step F: Append to Durable Progress Event Log
                const progressEvent = this.progressManager.recordEvent({
                    jobId,
                    botId: job.botId,
                    threadId: job.threadId,
                    turnId: job.turnId ?? "",
                    cardId,
                    state: "RUNNING",
                    progressPercent,
                    milestoneIndex: idx,
                    milestoneTitle,
                    message: progressMessage,
                });
                // Step G: Render Card via Chat Store if provided
                if (this.patchMessageFn) {
                    const cardPayload = this.progressManager.renderCard(progressEvent, totalMilestones);
                    this.patchMessageFn(job.threadId, cardId, { card: cardPayload });
                }
            }
            // Final Completion
            const completedJob = this.jobManager.completeJob(jobId, { success: true, finishedAt: Date.now() }, this.workerId, fencingGeneration);
            const finalEvent = this.progressManager.recordEvent({
                jobId,
                botId: completedJob.botId,
                threadId: completedJob.threadId,
                turnId: completedJob.turnId ?? "",
                cardId,
                state: "COMPLETED",
                progressPercent: 100,
                milestoneIndex: totalMilestones - 1,
                milestoneTitle: "Outcome Complete",
                message: "Objective successfully executed and verified.",
            });
            if (this.patchMessageFn) {
                const cardPayload = this.progressManager.renderCard(finalEvent, totalMilestones);
                this.patchMessageFn(completedJob.threadId, cardId, { card: cardPayload });
            }
        }
        catch (err) {
            if (err instanceof StaleWorkerFenceError) {
                console.warn(`[OutcomeSupervisor ${this.workerId}] Fencing error on job ${jobId}, aborting stale worker loop: ${err.message}`);
            }
            else {
                console.error(`[OutcomeSupervisor ${this.workerId}] Error executing job ${jobId}`, err);
            }
        }
        finally {
            this.activeJobs.delete(jobId);
        }
    }
}
export const sharedOutcomeSupervisor = new OutcomeExecutionSupervisor();
