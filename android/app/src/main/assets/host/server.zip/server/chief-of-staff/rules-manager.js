import { randomUUID } from "node:crypto";
import { defaultChiefStore } from "./chief-store.js";
import { defaultCommitmentDetector } from "./commitment-detector.js";
/**
 * Rules Manager for recurring Chief of Staff automation workflows.
 * Strict security: Rules can only propose drafts or generate reminders.
 * Rules never automatically send emails without human authorization.
 */
export class RulesManager {
    store;
    detector;
    constructor(opts) {
        this.store = opts?.store ?? defaultChiefStore;
        this.detector = opts?.detector ?? defaultCommitmentDetector;
    }
    listRules() {
        return this.store.listRules();
    }
    getRule(id) {
        return this.store.getRule(id);
    }
    createRule(input) {
        const id = `rule_${randomUUID().slice(0, 10)}`;
        const now = new Date().toISOString();
        const rule = {
            id,
            name: input.name.trim(),
            description: (input.description || "").trim(),
            trigger: input.trigger,
            sourceScope: input.sourceScope ?? ["googlecalendar", "gmail"],
            conditions: input.conditions ?? [],
            intendedAction: input.intendedAction || "propose_followup_draft",
            permissionLevel: "auto_propose_draft_only", // Strict security policy
            schedule: input.schedule,
            enabled: true,
            createdAt: now,
            updatedAt: now,
            executionHistory: [],
        };
        this.store.saveRule(rule);
        return rule;
    }
    updateRule(id, updates) {
        const rule = this.store.getRule(id);
        if (!rule)
            return undefined;
        if (updates.name !== undefined)
            rule.name = updates.name.trim();
        if (updates.description !== undefined)
            rule.description = updates.description.trim();
        if (updates.trigger !== undefined)
            rule.trigger = updates.trigger;
        if (updates.sourceScope !== undefined)
            rule.sourceScope = updates.sourceScope;
        if (updates.conditions !== undefined)
            rule.conditions = updates.conditions;
        if (updates.intendedAction !== undefined)
            rule.intendedAction = updates.intendedAction;
        if (updates.schedule !== undefined)
            rule.schedule = updates.schedule;
        if (updates.enabled !== undefined)
            rule.enabled = updates.enabled;
        rule.updatedAt = new Date().toISOString();
        this.store.saveRule(rule);
        return rule;
    }
    deleteRule(id) {
        return this.store.deleteRule(id);
    }
    toggleRule(id) {
        const rule = this.store.getRule(id);
        if (!rule)
            return undefined;
        rule.enabled = !rule.enabled;
        rule.updatedAt = new Date().toISOString();
        this.store.saveRule(rule);
        return rule;
    }
    /**
     * Evaluate active rules against current context items.
     */
    evaluateRules(items) {
        const activeRules = this.listRules().filter((r) => r.enabled);
        const results = [];
        const now = new Date().toISOString();
        for (const rule of activeRules) {
            const scopedItems = items.filter((item) => rule.sourceScope.includes(item.source));
            let triggered = false;
            let summary = "Conditions not met";
            let generatedTaskId;
            switch (rule.trigger) {
                case "meeting_ended": {
                    // Check for calendar events that have commitments
                    const commitments = this.detector.detectCommitments(scopedItems);
                    if (commitments.length > 0) {
                        triggered = true;
                        summary = `Detected ${commitments.length} commitments from recent meetings`;
                        generatedTaskId = commitments[0].id;
                    }
                    break;
                }
                case "email_unanswered": {
                    // Find email threads awaiting response
                    const emailItems = scopedItems.filter((i) => i.source === "gmail");
                    if (emailItems.length > 0) {
                        triggered = true;
                        summary = `Identified ${emailItems.length} active email threads requiring follow-up`;
                        generatedTaskId = emailItems[0].id;
                    }
                    break;
                }
                case "weekly_summary": {
                    triggered = true;
                    summary = `Weekly commitment digest compiled (${scopedItems.length} items evaluated)`;
                    break;
                }
                default:
                    summary = `Trigger ${rule.trigger} checked`;
                    break;
            }
            const record = {
                executedAt: now,
                status: triggered ? "success" : "skipped",
                summary,
                generatedTaskId,
            };
            this.store.recordRuleExecution(rule.id, record);
            results.push({
                ruleId: rule.id,
                ruleName: rule.name,
                triggered,
                actionTaken: rule.intendedAction,
                summary,
                generatedTaskId,
            });
        }
        return results;
    }
}
export const defaultRulesManager = new RulesManager();
