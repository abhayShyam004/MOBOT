// Project lifecycle tools over stdio MCP for hosts that are not the Android
// app (desktop / `pnpm dev:server`).
//
// The tools themselves are the canonical `APP_BUILDER_TOOLS` — the app builder
// UI, the Android adapter and this surface all drive the same ProjectManager,
// ProjectLifecycle and durable task state. This file adds a *transport* only:
// MOBOT's desktop chat previously had no way to mount the lifecycle at all,
// because the tool table was reachable exclusively through android-computer.
//
// Identity is bound the way android-computer binds it: `project_start` is
// stamped from OMB_BOT_ID / OMB_THREAD_ID in the environment the harness set,
// never from model-supplied arguments.
import { mkdirSync } from "node:fs";
import { join } from "node:path";
// `OMB_*` names are reserved by the harness for its own MCP entries, so this
// server is seeded with PT_* and translates them before any module that reads
// them is imported (DATA_DIR and friends are computed at import time).
if (process.env.PT_DATA_DIR && !process.env.OMB_DATA_DIR)
    process.env.OMB_DATA_DIR = process.env.PT_DATA_DIR;
if (process.env.PT_PROJECTS_DIR && !process.env.OMB_PROJECTS_DIR)
    process.env.OMB_PROJECTS_DIR = process.env.PT_PROJECTS_DIR;
const { APP_BUILDER_TOOLS, getProjectManager, setProjectManager } = await import("./app-builder-tools.js");
const { ProjectManager } = await import("./project-manager.js");
const { checkToolPermission, loadDiskPermissions } = await import("../permission-policy.js");
const MAX_OUTPUT_BYTES = 512 * 1024;
const FRAME_BYTES = 4 * 1024 * 1024;
const MAX_FRAMES = 100_000;
const dataDir = process.env.OMB_DATA_DIR || "";
const projectsDir = process.env.OMB_PROJECTS_DIR || (dataDir ? join(dataDir, "projects") : "");
if (projectsDir) {
    mkdirSync(projectsDir, { recursive: true });
    setProjectManager(new ProjectManager(projectsDir));
}
function toolError(message) {
    return { ok: false, error: message };
}
function bounded(value, limit) {
    if (Buffer.byteLength(value) <= limit)
        return value;
    return value.slice(0, Math.max(0, limit)) + "\n…truncated";
}
function textResult(payload, isError = false) {
    const full = JSON.stringify(payload, null, 1);
    if (Buffer.byteLength(full) <= MAX_OUTPUT_BYTES) {
        return { content: [{ type: "text", text: full }], ...(isError ? { isError: true } : {}) };
    }
    // Never cut serialized JSON mid-string: shrink string fields first so the
    // payload re-serializes as valid JSON.
    const shrunk = { ...payload, truncated: true };
    for (const [key, value] of Object.entries(shrunk)) {
        if (typeof value === "string")
            shrunk[key] = bounded(value, 8 * 1024);
    }
    const text = JSON.stringify(shrunk, null, 1);
    return {
        content: [{ type: "text", text: bounded(text, MAX_OUTPUT_BYTES - 64) }],
        ...(isError ? { isError: true } : {}),
    };
}
const TOOL_LIST = Object.entries(APP_BUILDER_TOOLS).map(([name, spec]) => ({
    name,
    description: spec.description,
    inputSchema: spec.inputSchema,
}));
function write(message) {
    process.stdout.write(JSON.stringify(message) + "\n");
}
function reply(id, result) {
    write({ jsonrpc: "2.0", id, result });
}
function replyError(id, message, code = -32000) {
    write({ jsonrpc: "2.0", id, error: { code, message } });
}
function handle(message) {
    const id = message.id;
    if (typeof id !== "number" && typeof id !== "string")
        return;
    if (message.method === "initialize") {
        reply(id, {
            protocolVersion: "2024-11-05",
            capabilities: { tools: {} },
            serverInfo: { name: "project_tools", version: "1.0.0" },
        });
        return;
    }
    if (message.method === "tools/list") {
        reply(id, { tools: TOOL_LIST });
        return;
    }
    if (message.method === "tools/call") {
        const params = (message.params ?? {});
        const name = typeof params.name === "string" ? params.name : "";
        const spec = APP_BUILDER_TOOLS[name];
        if (!spec) {
            replyError(id, `unknown tool: ${name}`, -32602);
            return;
        }
        const args = (params.arguments ?? {});
        const permission = checkToolPermission(name, loadDiskPermissions(), args);
        if (!permission.allowed) {
            reply(id, textResult(toolError(permission.reason || "Permission Denied"), true));
            return;
        }
        // Same server-side identity binding as the Android adapter.
        const contextualArgs = name === "project_start"
            ? {
                ...args,
                ...(process.env.OMB_BOT_ID ? { botId: process.env.OMB_BOT_ID } : {}),
                ...(process.env.OMB_THREAD_ID ? { threadId: process.env.OMB_THREAD_ID } : {}),
            }
            : args;
        const controller = new AbortController();
        const abort = () => controller.abort();
        process.on("SIGTERM", abort);
        Promise.resolve()
            .then(() => spec.handler(contextualArgs, controller.signal))
            .then((result) => {
            process.removeListener("SIGTERM", abort);
            const value = result;
            const ranSomething = result && typeof result === "object" &&
                ("exitCode" in result || "timedOut" in result);
            reply(id, textResult(result, value?.ok === false && !ranSomething));
        }, (error) => {
            process.removeListener("SIGTERM", abort);
            reply(id, textResult(toolError(error instanceof Error ? error.message : String(error)), true));
        });
        return;
    }
    if (message.method === "ping") {
        reply(id, {});
        return;
    }
    if (message.method === "notifications/initialized")
        return;
    replyError(id, "method not supported", -32601);
}
let buffer = "";
let frames = 0;
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => {
    buffer += chunk;
    let newline;
    while ((newline = buffer.indexOf("\n")) !== -1) {
        const line = buffer.slice(0, newline);
        buffer = buffer.slice(newline + 1);
        if (!line.trim())
            continue;
        if (++frames > MAX_FRAMES) {
            process.stderr.write("project-mcp: frame limit exceeded\n");
            process.exit(2);
        }
        if (Buffer.byteLength(line) > FRAME_BYTES) {
            process.stderr.write("project-mcp: frame too large\n");
            process.exit(2);
        }
        let message;
        try {
            message = JSON.parse(line);
        }
        catch {
            process.stderr.write("project-mcp: invalid JSON frame\n");
            continue;
        }
        try {
            handle(message);
        }
        catch (error) {
            const id = message.id;
            if (typeof id === "number" || typeof id === "string") {
                replyError(id, error instanceof Error ? error.message : String(error));
            }
        }
    }
});
process.stdin.on("end", () => process.exit(0));
// Keep the imported manager factory referenced so a future host that needs to
// inspect the same instance does not silently build a second one.
export const projectManagerForTests = getProjectManager;
