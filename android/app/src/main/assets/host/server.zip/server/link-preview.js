/**
 * Automatic rich link previews for ordinary chat messages.
 *
 * A phone that renders a message with a URL asks this module for one preview.
 * Everything that touches the network happens here, on the server, behind one
 * SSRF gate:
 *
 *   • only http(s), never credentials, never a bare/intranet hostname;
 *   • every hostname is resolved first and *every* returned address must be
 *     public — including after each redirect, not just the first hop;
 *   • the resolved address is pinned into the socket lookup, so a DNS answer
 *     that changes between our check and the connection cannot reach a private
 *     network (DNS rebinding);
 *   • bounded timeout, redirect count, response size and content type;
 *   • thumbnails are only returned after their host passes the same address
 *     check, so the phone is never handed a private-network image URL.
 *
 * Metadata is only ever what the page actually declares. When nothing usable
 * is declared the caller gets a failure and renders the plain link.
 */
import { lookup as dnsLookup } from "node:dns/promises";
import { request as httpRequest } from "node:http";
import { request as httpsRequest } from "node:https";
/**
 * Prefer IPv4: many mobile networks hand out an IPv6 address that is not
 * actually routable, and a pinned IPv6 socket then hangs until the timeout.
 * IPv6 is still used when it is the only answer.
 */
export function preferredAddress(addresses) {
    return addresses.find((address) => address.family === 4) ?? addresses[0];
}
export const LINK_PREVIEW_MAX_BYTES = 512 * 1024;
export const LINK_PREVIEW_TIMEOUT_MS = 6_000;
export const LINK_PREVIEW_MAX_REDIRECTS = 4;
export const LINK_PREVIEW_CACHE_TTL_MS = 10 * 60 * 1_000;
export const LINK_PREVIEW_CACHE_MAX = 256;
const USER_AGENT = "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Mobile Safari/537.36 OpenMausBot/1.0";
// ── address classification ──────────────────────────────────────────────────
function parseIpv4(value) {
    const parts = value.split(".");
    if (parts.length !== 4)
        return null;
    let packed = 0;
    for (const part of parts) {
        if (!/^\d{1,3}$/.test(part))
            return null;
        const byte = Number(part);
        if (byte > 255)
            return null;
        packed = ((packed << 8) | byte) >>> 0;
    }
    return packed >>> 0;
}
export function isPrivateIpv4(packed) {
    const a = (packed >>> 24) & 0xff;
    const b = (packed >>> 16) & 0xff;
    const c = (packed >>> 8) & 0xff;
    if (a === 0)
        return true; // "this network"
    if (a === 10)
        return true; // RFC1918
    if (a === 127)
        return true; // loopback
    if (a === 169 && b === 254)
        return true; // link-local / cloud metadata
    if (a === 172 && b >= 16 && b <= 31)
        return true; // RFC1918
    if (a === 192 && b === 168)
        return true; // RFC1918
    if (a === 100 && b >= 64 && b <= 127)
        return true; // CGNAT
    if (a === 192 && b === 0 && (c === 0 || c === 2))
        return true; // IETF / TEST-NET-1
    if (a === 198 && (b === 18 || b === 19))
        return true; // benchmarking
    if (a === 198 && b === 51 && c === 100)
        return true; // TEST-NET-2
    if (a === 203 && b === 0 && c === 113)
        return true; // TEST-NET-3
    if (a >= 224)
        return true; // multicast, reserved, broadcast
    return false;
}
/** Expand an IPv6 literal to eight 16-bit groups, handling `::`, zones and a
 *  dotted IPv4 tail. Returns null when the literal is malformed. */
export function expandIpv6(raw) {
    let text = raw.trim().toLowerCase();
    const zone = text.indexOf("%");
    if (zone >= 0)
        text = text.slice(0, zone);
    if (!text.includes(":"))
        return null;
    const dotted = text.match(/^(.*:)(\d{1,3}(?:\.\d{1,3}){3})$/);
    if (dotted) {
        const v4 = parseIpv4(dotted[2]);
        if (v4 === null)
            return null;
        if (!dotted[1].endsWith("::") && !dotted[1].endsWith(":"))
            return null;
        text = `${dotted[1]}${((v4 >>> 16) & 0xffff).toString(16)}:${(v4 & 0xffff).toString(16)}`;
    }
    const halves = text.split("::");
    if (halves.length > 2)
        return null;
    const left = halves[0] ? halves[0].split(":") : [];
    const right = halves.length === 2 && halves[1] ? halves[1].split(":") : [];
    const missing = 8 - left.length - right.length;
    if (halves.length === 1) {
        if (missing !== 0)
            return null;
    }
    else if (missing < 1) {
        // A `::` must stand for at least one zero group.
        return null;
    }
    const groups = [...left, ...new Array(Math.max(0, missing)).fill("0"), ...right];
    if (groups.length !== 8)
        return null;
    const out = [];
    for (const group of groups) {
        if (!/^[0-9a-f]{1,4}$/.test(group))
            return null;
        out.push(parseInt(group, 16));
    }
    return out;
}
function isPrivateIpv6(groups) {
    if (groups.every((group) => group === 0))
        return true; // ::
    if (groups.slice(0, 7).every((group) => group === 0) && groups[7] === 1)
        return true; // ::1
    if (groups.slice(0, 5).every((group) => group === 0) && groups[5] === 0xffff) {
        return isPrivateIpv4((((groups[6] << 16) | groups[7]) >>> 0));
    }
    // NAT64 64:ff9b::/96 wraps an IPv4 destination.
    if (groups[0] === 0x64 && groups[1] === 0xff9b && groups.slice(2, 6).every((group) => group === 0)) {
        return isPrivateIpv4((((groups[6] << 16) | groups[7]) >>> 0));
    }
    // 6to4 2002::/16 embeds the IPv4 address in the next two groups.
    if (groups[0] === 0x2002)
        return isPrivateIpv4((((groups[1] << 16) | groups[2]) >>> 0));
    if ((groups[0] & 0xfe00) === 0xfc00)
        return true; // unique local fc00::/7
    if ((groups[0] & 0xffc0) === 0xfe80)
        return true; // link-local fe80::/10
    if ((groups[0] & 0xff00) === 0xff00)
        return true; // multicast ff00::/8
    if (groups[0] === 0x2001 && groups[1] === 0x0db8)
        return true; // documentation
    if (groups[0] === 0x0100 && groups.slice(1, 4).every((group) => group === 0))
        return true; // 100::/64
    return false;
}
/** True for any address a chat link must never fetch: loopback, RFC1918,
 *  link-local (cloud metadata), CGNAT, multicast, ULA, NAT64/6to4 wrappers. */
export function isPrivateAddress(address) {
    const value = address.trim();
    if (!value)
        return true;
    const v4 = parseIpv4(value);
    if (v4 !== null)
        return isPrivateIpv4(v4);
    const v6 = expandIpv6(value);
    if (v6 !== null)
        return isPrivateIpv6(v6);
    // An address we cannot parse is not one we will connect to.
    return true;
}
const BLOCKED_HOST_SUFFIXES = [".localhost", ".local", ".localdomain", ".internal", ".home.arpa", ".lan"];
const BLOCKED_HOSTS = new Set([
    "localhost",
    "metadata",
    "metadata.google.internal",
    "metadata.goog",
    "instance-data",
]);
function normalizedHostname(url) {
    return url.hostname.toLowerCase().replace(/^\[/, "").replace(/\]$/, "");
}
function hostIsObviouslyBlocked(hostname) {
    if (!hostname)
        return true;
    if (BLOCKED_HOSTS.has(hostname))
        return true;
    if (BLOCKED_HOST_SUFFIXES.some((suffix) => hostname.endsWith(suffix)))
        return true;
    // A single-label host is an intranet name, never a public page.
    if (!hostname.includes(".") && parseIpv4(hostname) === null && !hostname.includes(":"))
        return true;
    return false;
}
/**
 * Validates one hop: scheme, shape and *all* resolved addresses. Callers must
 * run this for the initial URL and again for every redirect target.
 */
export async function checkTarget(url, deps = {}) {
    if (url.protocol !== "http:" && url.protocol !== "https:") {
        return { ok: false, reason: "unsupported-scheme", detail: url.protocol };
    }
    if (url.username || url.password) {
        return { ok: false, reason: "unsafe-host", detail: "credentials in URL" };
    }
    const hostname = normalizedHostname(url);
    if (hostIsObviouslyBlocked(hostname)) {
        return { ok: false, reason: "unsafe-host", detail: `blocked host ${hostname}` };
    }
    const literalV4 = parseIpv4(hostname);
    const literalV6 = hostname.includes(":") ? expandIpv6(hostname) : null;
    if (literalV4 !== null || literalV6 !== null) {
        if (isPrivateAddress(hostname)) {
            return { ok: false, reason: "unsafe-host", detail: `private address ${hostname}` };
        }
        return {
            ok: true,
            addresses: [{ address: hostname, family: literalV4 !== null ? 4 : 6 }],
        };
    }
    const resolve = deps.resolve ?? (async (host) => dnsLookup(host, { all: true, verbatim: true }));
    let addresses;
    try {
        addresses = await resolve(hostname);
    }
    catch (error) {
        return {
            ok: false,
            reason: "network",
            detail: `DNS lookup failed: ${error instanceof Error ? error.message : String(error)}`,
        };
    }
    if (!addresses || addresses.length === 0) {
        return { ok: false, reason: "network", detail: `no addresses for ${hostname}` };
    }
    // Every answer is checked: a host that resolves to one public and one
    // private address must not be fetched at all.
    for (const address of addresses) {
        if (isPrivateAddress(address.address)) {
            return { ok: false, reason: "unsafe-host", detail: `${hostname} resolves to ${address.address}` };
        }
    }
    return { ok: true, addresses };
}
// ── HTTP transport ──────────────────────────────────────────────────────────
/**
 * Fetches one hop with the already-validated address pinned into the socket
 * lookup. Native `fetch` would resolve the name a second time, which is the
 * hole DNS rebinding walks through.
 */
/**
 * A `lookup` implementation that always answers with the address already
 * validated above, so the socket cannot be steered to a different host.
 *
 * `net` calls this in two shapes: `all: false` expects
 * `(error, address, family)`, while `all: true` (family autoselection, which
 * Node enables by default on many platforms) expects `(error, addresses[])`.
 * Answering the array shape with a bare string makes Node read
 * `addresses[0].address` as undefined and fail with `Invalid IP address` —
 * which is what happened on-device before this branch existed.
 */
export function createPinnedLookup(address) {
    return (_hostname, lookupOptions, callback) => {
        if (lookupOptions?.all) {
            callback(null, [{ address: address.address, family: address.family }]);
            return;
        }
        callback(null, address.address, address.family);
    };
}
const nodeTransport = (url, address, options) => new Promise((resolve, reject) => {
    const secure = url.protocol === "https:";
    const request = secure ? httpsRequest : httpRequest;
    const hostname = normalizedHostname(url);
    const pinnedLookup = createPinnedLookup(address);
    let settled = false;
    const finish = (value) => {
        if (settled)
            return;
        settled = true;
        resolve(value);
    };
    const req = request({
        protocol: url.protocol,
        hostname,
        port: url.port || (secure ? 443 : 80),
        path: `${url.pathname}${url.search}`,
        method: "GET",
        servername: secure ? hostname : undefined,
        headers: {
            "user-agent": USER_AGENT,
            accept: "text/html,application/xhtml+xml;q=0.9,*/*;q=0.5",
            "accept-language": "en",
            "accept-encoding": "identity",
        },
        lookup: pinnedLookup,
        timeout: options.timeoutMs,
    }, (response) => {
        const headers = {};
        for (const [key, value] of Object.entries(response.headers)) {
            if (typeof value === "string")
                headers[key.toLowerCase()] = value;
            else if (Array.isArray(value))
                headers[key.toLowerCase()] = value.join(", ");
        }
        const chunks = [];
        let total = 0;
        let truncated = false;
        response.on("data", (chunk) => {
            if (truncated)
                return;
            total += chunk.length;
            if (total > options.maxBytes) {
                // Resolve with the head we already have instead of destroying and
                // waiting for an `end` that will never arrive. Metadata lives in
                // `<head>`, and large real pages (GitHub, YouTube) always exceed
                // the cap — the old destroy-without-resolve left the caller
                // hanging until its own timeout.
                truncated = true;
                finish({ status: response.statusCode ?? 0, headers, body: Buffer.concat(chunks), truncated: true });
                response.destroy();
                return;
            }
            chunks.push(chunk);
        });
        response.on("end", () => {
            finish({ status: response.statusCode ?? 0, headers, body: Buffer.concat(chunks), truncated });
        });
        response.on("error", (error) => reject(error));
    });
    req.on("timeout", () => {
        const error = new Error("timeout");
        error.code = "ETIMEDOUT";
        req.destroy(error);
    });
    req.on("error", reject);
    req.end();
});
// ── metadata parsing ────────────────────────────────────────────────────────
const NAMED_ENTITIES = {
    amp: "&",
    lt: "<",
    gt: ">",
    quot: '"',
    apos: "'",
    nbsp: " ",
    mdash: "—",
    ndash: "–",
    hellip: "…",
    rsquo: "’",
    lsquo: "‘",
    ldquo: "“",
    rdquo: "”",
    copy: "©",
    reg: "®",
    trade: "™",
};
export function decodeHtmlEntities(value) {
    return value.replace(/&(#x?[0-9a-fA-F]+|[a-zA-Z][a-zA-Z0-9]*);/g, (match, entity) => {
        if (entity.startsWith("#x") || entity.startsWith("#X")) {
            const code = Number.parseInt(entity.slice(2), 16);
            return Number.isFinite(code) && code > 0 && code <= 0x10ffff ? String.fromCodePoint(code) : match;
        }
        if (entity.startsWith("#")) {
            const code = Number.parseInt(entity.slice(1), 10);
            return Number.isFinite(code) && code > 0 && code <= 0x10ffff ? String.fromCodePoint(code) : match;
        }
        return NAMED_ENTITIES[entity.toLowerCase()] ?? match;
    });
}
function collapse(value) {
    return decodeHtmlEntities(value).replace(/\s+/g, " ").trim();
}
function parseAttributes(tag) {
    const attributes = {};
    const pattern = /([a-zA-Z_:][-a-zA-Z0-9_:.]*)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>`]+))/g;
    let match;
    while ((match = pattern.exec(tag)) !== null) {
        const name = match[1].toLowerCase();
        const value = match[2] ?? match[3] ?? match[4] ?? "";
        if (!(name in attributes))
            attributes[name] = value;
    }
    return attributes;
}
function absoluteHttpUrl(candidate, base) {
    if (!candidate)
        return undefined;
    const trimmed = candidate.trim();
    if (!trimmed)
        return undefined;
    try {
        const resolved = new URL(trimmed, base);
        if (resolved.protocol !== "http:" && resolved.protocol !== "https:")
            return undefined;
        return resolved.toString();
    }
    catch {
        return undefined;
    }
}
function youtubeVideoId(url) {
    const host = normalizedHostname(url).replace(/^www\./, "");
    const valid = (id) => id && /^[A-Za-z0-9_-]{6,20}$/.test(id) ? id : null;
    if (host === "youtu.be")
        return valid(url.pathname.split("/").filter(Boolean)[0]);
    if (host === "youtube.com" || host === "m.youtube.com" || host === "music.youtube.com") {
        const fromQuery = valid(url.searchParams.get("v"));
        if (fromQuery)
            return fromQuery;
        const match = url.pathname.match(/\/(?:shorts|embed|live|v)\/([A-Za-z0-9_-]{6,20})/);
        return valid(match?.[1]);
    }
    return null;
}
/**
 * Reads only what the document declares: OpenGraph first, then Twitter cards,
 * then the plain `<title>` / meta description a page has always had.
 */
export function parseLinkMetadata(html, finalUrl) {
    const meta = new Map();
    const metaTag = /<meta\b[^>]*>/gi;
    let tag;
    while ((tag = metaTag.exec(html)) !== null) {
        const attributes = parseAttributes(tag[0]);
        const key = (attributes.property ?? attributes.name ?? "").toLowerCase();
        const content = attributes.content;
        if (key && content && !meta.has(key))
            meta.set(key, content);
    }
    const pick = (...keys) => {
        for (const key of keys) {
            const value = meta.get(key);
            if (value && value.trim())
                return collapse(value);
        }
        return undefined;
    };
    let documentTitle;
    const titleMatch = html.match(/<title\b[^>]*>([\s\S]*?)<\/title>/i);
    if (titleMatch?.[1])
        documentTitle = collapse(titleMatch[1]);
    const videoId = youtubeVideoId(finalUrl);
    let title = pick("og:title", "twitter:title") ?? documentTitle;
    if (title && videoId)
        title = title.replace(/\s*[-–|]\s*YouTube\s*$/i, "").trim();
    const description = pick("og:description", "twitter:description", "description");
    const declaredImage = pick("og:image:secure_url", "og:image:url", "og:image", "twitter:image", "twitter:image:src");
    let imageUrl = absoluteHttpUrl(declaredImage, finalUrl);
    // A YouTube thumbnail derived from the video id is the video's own artwork,
    // not invented content, and is only used when the page declared none.
    if (!imageUrl && videoId)
        imageUrl = `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
    const type = (meta.get("og:type") ?? "").toLowerCase();
    const host = normalizedHostname(finalUrl).replace(/^www\./, "");
    const kind = videoId || type.startsWith("video") ? "video" : host === "github.com" ? "code" : type === "article" ? "article" : "site";
    const siteName = pick("og:site_name") ??
        (host === "github.com" ? "GitHub" : host === "youtube.com" || host === "youtu.be" ? "YouTube" : undefined) ??
        host;
    return { title, description, imageUrl, siteName, kind };
}
/**
 * YouTube's watch page, served to a non-browser agent, often carries only a
 * generic `<title>YouTube</title>` and no OpenGraph tags, so the preview would
 * show the site instead of the video. Its public oEmbed endpoint returns the
 * video's own title and author; it is fetched through the same address-checked
 * transport as every other hop.
 */
async function youtubeOEmbed(page, deps) {
    const endpoint = new URL("https://www.youtube.com/oembed");
    endpoint.searchParams.set("url", page.toString());
    endpoint.searchParams.set("format", "json");
    const target = await checkTarget(endpoint, deps);
    if (!target.ok || !target.addresses?.length)
        return null;
    const transport = deps.transport ?? nodeTransport;
    const response = await transport(endpoint, preferredAddress(target.addresses), {
        timeoutMs: 6_000,
        maxBytes: 64 * 1024,
    });
    if (response.status < 200 || response.status >= 300)
        return null;
    try {
        const json = JSON.parse(response.body.toString("utf8"));
        return {
            title: typeof json.title === "string" ? json.title : undefined,
            author: typeof json.author_name === "string" ? json.author_name : undefined,
        };
    }
    catch {
        return null;
    }
}
const cache = new Map();
function cacheKey(url) {
    try {
        const parsed = new URL(url);
        // Fragments are client-side only; the document is the same.
        parsed.hash = "";
        return parsed.toString();
    }
    catch {
        return url;
    }
}
function readCache(key, now) {
    const entry = cache.get(key);
    if (!entry)
        return undefined;
    if (now - entry.storedAt > LINK_PREVIEW_CACHE_TTL_MS) {
        cache.delete(key);
        return undefined;
    }
    // Refresh insertion order so the newest entries survive eviction.
    cache.delete(key);
    cache.set(key, entry);
    return { ...entry.result, cached: true };
}
function writeCache(key, result, now) {
    if (cache.size >= LINK_PREVIEW_CACHE_MAX) {
        const oldest = cache.keys().next().value;
        if (oldest !== undefined)
            cache.delete(oldest);
    }
    cache.set(key, { result, storedAt: now });
}
/** Test seam: forget every cached preview. */
export function resetLinkPreviewCache() {
    cache.clear();
}
// ── fetch ───────────────────────────────────────────────────────────────────
const REDIRECT_STATUSES = new Set([301, 302, 303, 307, 308]);
function failure(reason, detail) {
    return { ok: false, reason, detail };
}
/**
 * Fetches and parses one URL, following redirects manually so that every hop
 * is validated before it is requested.
 */
export async function fetchLinkPreview(rawUrl, deps = {}) {
    const now = deps.now ?? Date.now;
    const transport = deps.transport ?? nodeTransport;
    let start;
    try {
        start = new URL(rawUrl);
    }
    catch {
        return failure("invalid-url", "not an absolute URL");
    }
    const key = cacheKey(start.toString());
    const cached = readCache(key, now());
    if (cached)
        return cached;
    let current = start;
    for (let hop = 0; hop <= LINK_PREVIEW_MAX_REDIRECTS; hop++) {
        const target = await checkTarget(current, deps);
        if (!target.ok || !target.addresses?.length) {
            const result = failure(target.reason ?? "unsafe-host", target.detail);
            // An unsafe destination is a property of the URL, not a transient
            // failure: remembering it stops a retry loop on the same bad link.
            if (target.reason === "unsafe-host" || target.reason === "unsupported-scheme")
                writeCache(key, result, now());
            return result;
        }
        let response;
        try {
            response = await transport(current, preferredAddress(target.addresses), {
                timeoutMs: LINK_PREVIEW_TIMEOUT_MS,
                maxBytes: LINK_PREVIEW_MAX_BYTES,
            });
        }
        catch (error) {
            const code = error?.code;
            if (code === "ETIMEDOUT" || (error instanceof Error && /timeout/i.test(error.message))) {
                return failure("timeout", "the page did not answer in time");
            }
            return failure("network", error instanceof Error ? error.message : String(error));
        }
        if (REDIRECT_STATUSES.has(response.status)) {
            const location = response.headers.location;
            if (!location)
                return failure("http-error", `redirect without a location (${response.status})`);
            let next;
            try {
                next = new URL(location, current);
            }
            catch {
                return failure("invalid-url", "redirect location is not a URL");
            }
            // Loop detection: a redirect back to a hop we already visited is abuse.
            if (next.toString() === current.toString()) {
                return failure("http-error", "redirect loop");
            }
            current = next;
            continue;
        }
        if (response.status < 200 || response.status >= 300) {
            return failure("http-error", `HTTP ${response.status}`);
        }
        const contentType = (response.headers["content-type"] ?? "").toLowerCase();
        if (contentType && !contentType.includes("text/html") && !contentType.includes("application/xhtml")) {
            return failure("unsupported-content", contentType.split(";")[0].trim());
        }
        const html = response.body.toString("utf8");
        if (!html.trim())
            return failure("no-metadata", "empty document");
        const parsed = parseLinkMetadata(html, current);
        const title = parsed.title?.trim();
        if (!title)
            return failure("no-metadata", "the page declared no title");
        // The thumbnail is handed to the phone, which will fetch it: its host has
        // to clear the same gate before that can happen.
        let imageUrl;
        if (parsed.imageUrl) {
            try {
                const imageTarget = await checkTarget(new URL(parsed.imageUrl), deps);
                if (imageTarget.ok)
                    imageUrl = parsed.imageUrl;
            }
            catch {
                imageUrl = undefined;
            }
        }
        const preview = {
            url: start.toString(),
            finalUrl: current.toString(),
            title: title.slice(0, 200),
            description: parsed.description?.slice(0, 300) || undefined,
            siteName: (parsed.siteName ?? normalizedHostname(current)).slice(0, 80),
            imageUrl,
            kind: parsed.kind,
        };
        // A generic YouTube title means the watch page gave us nothing usable;
        // ask oEmbed for the video's real title. Any failure keeps the honest
        // generic one rather than inventing a name.
        if (preview.kind === "video" && youtubeVideoId(current) && preview.title.trim() === "YouTube") {
            const oembed = await youtubeOEmbed(current, deps).catch(() => null);
            if (oembed?.title) {
                preview.title = oembed.title.slice(0, 200);
                if (oembed.author)
                    preview.description = `by ${oembed.author}`.slice(0, 300);
                preview.siteName = "YouTube";
            }
        }
        const result = { ok: true, preview };
        writeCache(key, result, now());
        return result;
    }
    return failure("http-error", "too many redirects");
}
// ── thumbnail proxy ─────────────────────────────────────────────────────────
export const PREVIEW_IMAGE_MAX_BYTES = 3 * 1024 * 1024;
/**
 * Fetches a preview thumbnail through the same gate as the page itself: every
 * hop is address-checked, the body is capped, and only an image content type is
 * accepted. The phone therefore never connects to an arbitrary URL to show a
 * thumbnail.
 */
export async function fetchPreviewImage(rawUrl, deps = {}) {
    const transport = deps.transport ?? nodeTransport;
    let current;
    try {
        current = new URL(rawUrl);
    }
    catch {
        return { ok: false, reason: "invalid-url", detail: "not an absolute URL" };
    }
    for (let hop = 0; hop <= LINK_PREVIEW_MAX_REDIRECTS; hop++) {
        const target = await checkTarget(current, deps);
        if (!target.ok || !target.addresses?.length) {
            return { ok: false, reason: target.reason ?? "unsafe-host", detail: target.detail };
        }
        let response;
        try {
            response = await transport(current, preferredAddress(target.addresses), {
                timeoutMs: LINK_PREVIEW_TIMEOUT_MS,
                maxBytes: PREVIEW_IMAGE_MAX_BYTES,
            });
        }
        catch (error) {
            const code = error?.code;
            if (code === "ETIMEDOUT" || (error instanceof Error && /timeout/i.test(error.message))) {
                return { ok: false, reason: "timeout" };
            }
            return { ok: false, reason: "network", detail: error instanceof Error ? error.message : String(error) };
        }
        if (response.truncated)
            return { ok: false, reason: "too-large" };
        if (REDIRECT_STATUSES.has(response.status)) {
            const location = response.headers.location;
            if (!location)
                return { ok: false, reason: "http-error", detail: "redirect without a location" };
            try {
                current = new URL(location, current);
            }
            catch {
                return { ok: false, reason: "invalid-url" };
            }
            continue;
        }
        if (response.status < 200 || response.status >= 300) {
            return { ok: false, reason: "http-error", detail: `HTTP ${response.status}` };
        }
        const contentType = (response.headers["content-type"] ?? "").toLowerCase().split(";")[0].trim();
        if (!contentType.startsWith("image/")) {
            return { ok: false, reason: "unsupported-content", detail: contentType || "missing content type" };
        }
        if (response.body.length === 0)
            return { ok: false, reason: "no-metadata", detail: "empty image" };
        return { ok: true, bytes: response.body, contentType };
    }
    return { ok: false, reason: "http-error", detail: "too many redirects" };
}
// ── URL extraction ──────────────────────────────────────────────────────────
const URL_PATTERN = /\bhttps?:\/\/[^\s<>"'`]+/gi;
/**
 * The HTTP(S) URLs in a message, in order, de-duplicated, with trailing
 * sentence punctuation removed. `www.` links without a scheme are not previews:
 * the renderer cannot know whether they are http or https.
 */
export function extractUrls(text, limit = 4) {
    if (!text)
        return [];
    const seen = new Set();
    const urls = [];
    const matches = text.match(URL_PATTERN) ?? [];
    for (const match of matches) {
        let candidate = match;
        // Strip punctuation that the sentence owns, not the URL.
        while (candidate.length > 0 && /[.,;:!?)\]}>]$/.test(candidate)) {
            candidate = candidate.slice(0, -1);
        }
        if (!candidate)
            continue;
        try {
            const parsed = new URL(candidate);
            if (parsed.protocol !== "http:" && parsed.protocol !== "https:")
                continue;
            const normalized = parsed.toString();
            if (seen.has(normalized))
                continue;
            seen.add(normalized);
            urls.push(normalized);
            if (urls.length >= limit)
                break;
        }
        catch {
            continue;
        }
    }
    return urls;
}
