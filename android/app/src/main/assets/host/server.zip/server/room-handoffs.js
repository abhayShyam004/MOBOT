import { randomUUID } from "node:crypto";
import { readFileSync } from "node:fs";
import { z } from "zod";
import { writeFileAtomic } from "./atomic.js";
const nodeSchema = z.object({
    id: z.string(), rootId: z.string(), parentId: z.string().optional(),
    groupId: z.string().optional(), threadId: z.string(), botId: z.string(),
    key: z.string(), text: z.string(), createdAt: z.number(),
    status: z.enum(["source", "queued", "running", "waiting", "resume", "completed", "failed", "cancelled"]),
    result: z.string().default(""), reported: z.boolean().default(false),
    executions: z.number().int().nonnegative().default(0), startedAt: z.number().optional(),
    approvalGranted: z.boolean().default(false),
    kind: z.enum(["work", "assignment"]).default("work"),
});
export const ROOM_HANDOFF_LIMITS = { depth: 4, requests: 24, executions: 48, lifetimeMs: 30 * 60_000, minRunwayMs: 10 * 60_000, queueMs: 60 * 60_000, hardCapMs: 4 * 60 * 60_000 };
/** Renders elapsed milliseconds as whole minutes, or seconds under one minute. */
const duration = (ms) => ms >= 60_000 ? `${Math.floor(ms / 60_000)}m` : `${Math.floor(ms / 1000)}s`;
const terminal = (n) => ["completed", "failed", "cancelled"].includes(n.status);
/** A bounded tree of addressed room turns. Waiting for children never holds a
 * room/provider queue; reporting is data, and only the named parent is resumed.
 * Interrupted processes are never replayed after restart (tools may have effects).
 */
export class RoomHandoffs {
    nodes = new Map();
    controllers = new Map();
    loadError;
    file;
    hooks;
    now;
    limits;
    /** Per-root pause accounting for the tree lifetime clock. */
    pauses = new Map();
    constructor(file, hooks, now = Date.now, limits = {}) {
        this.file = file;
        this.hooks = hooks;
        this.now = now;
        this.limits = { ...ROOM_HANDOFF_LIMITS, ...limits };
        try {
            const saved = z.array(nodeSchema).max(10_000).parse(JSON.parse(readFileSync(file, "utf8")));
            const ids = new Map(saved.map(n => [n.id, n]));
            if (ids.size !== saved.length || saved.some(n => !ids.has(n.rootId) || ids.get(n.rootId)?.parentId ||
                (n.parentId && (!ids.has(n.parentId) || ids.get(n.parentId)?.rootId !== n.rootId))))
                throw new Error("Invalid room handoff tree");
            for (const n of saved) {
                if (!terminal(n)) {
                    n.status = "failed";
                    n.result = "Interrupted by server restart; not replayed.";
                }
                this.nodes.set(n.id, n);
            }
            this.save();
        }
        catch (e) {
            if (e.code !== "ENOENT")
                this.loadError = "Room handoff storage is unreadable; repair it before sending new work.";
        }
    }
    save() { writeFileAtomic(this.file, JSON.stringify([...this.nodes.values()]), { mode: 0o600 }); }
    publish(...nodes) {
        this.save();
        this.hooks.changed(new Set(nodes.flatMap(node => node.groupId ? [node.groupId] : [])), new Set(nodes.filter(node => !node.groupId).map(node => node.threadId)));
    }
    children(id) { return [...this.nodes.values()].filter(n => n.parentId === id); }
    root(n) { return this.nodes.get(n.rootId); }
    path(n) {
        const path = [];
        for (let cur = n; cur; cur = cur.parentId ? this.nodes.get(cur.parentId) : undefined) {
            if (path.some(p => p.id === cur.id))
                throw new Error("Invalid handoff ancestry");
            path.unshift(cur);
        }
        return path;
    }
    /** The tree lifetime clock pauses while any node in the tree is actively
     * executing: the budget bounds coordination sprawl, not the runtime of
     * dispatched work. Accounting is in-memory; a restart fails every
     * interrupted node anyway, so no pause span survives one. */
    trackExecutionPauses() {
        const now = this.now();
        const executing = new Set();
        // Roots that still own unsettled nodes. A conversation stopped while a
        // dispatched teammate executes leaves a terminal root above live work;
        // pause accounting must survive that root until the whole tree settles.
        const unsettled = new Set();
        for (const n of this.nodes.values()) {
            if (terminal(n))
                continue;
            unsettled.add(n.rootId);
            if (n.status === "running")
                executing.add(n.rootId);
        }
        for (const rootId of executing) {
            const pause = this.pauses.get(rootId) ?? { accumulatedMs: 0 };
            pause.since ??= now;
            this.pauses.set(rootId, pause);
        }
        for (const [rootId, pause] of this.pauses) {
            if (pause.since != null && !executing.has(rootId)) {
                pause.accumulatedMs += now - pause.since;
                pause.since = undefined;
            }
            const root = this.nodes.get(rootId);
            if (!root || !unsettled.has(rootId))
                this.pauses.delete(rootId);
        }
    }
    pausedMs(root) {
        const pause = this.pauses.get(root.id);
        if (!pause)
            return 0;
        return pause.accumulatedMs + (pause.since != null ? this.now() - pause.since : 0);
    }
    /** The lifetime budget consumed so far: wall clock minus paused time. */
    effectiveAgeMs(root) {
        return Math.max(0, this.now() - root.createdAt - this.pausedMs(root));
    }
    /** The earliest moment this node may be failed for lifetime: the tree
     * ceiling, a running node's own start plus a minimum runway, or, for work
     * parked in a busy teammate's queue, its own queue window (#1238). The
     * wall-clock hard cap clamps every extension: a tree that never stops
     * executing still dies, so runway extensions cannot compound forever. */
    deadline(n) {
        const anchor = n.status === "running" ? n.startedAt ?? n.createdAt : n.createdAt;
        const root = this.root(n);
        const ceiling = n.status === "queued" && n.executions === 0
            ? anchor + this.limits.queueMs
            : root.createdAt + this.limits.lifetimeMs + this.pausedMs(root);
        return Math.min(Math.max(ceiling, anchor + this.limits.minRunwayMs), root.createdAt + this.limits.hardCapMs);
    }
    /** An ancestor past its ceiling is not failed while a descendant is still
     * running inside its own runway; cancelling would cascade into that work. */
    protectsRunner(n) {
        return this.children(n.id).some(c => !terminal(c) && ((c.status === "running" && this.now() <= this.deadline(c)) || this.protectsRunner(c)));
    }
    /** A parent still owes the follow-up execution that decides on its
     * children's results; the ceiling defers to that execution's own runway.
     * A child parked in a queue has produced nothing to decide on yet. */
    owesFollowUp(n) {
        if (n.status === "resume")
            return true;
        if (n.status !== "waiting")
            return false;
        const children = this.children(n.id);
        return (children.length > 0 && children.every(c => terminal(c))) ||
            children.some(c => this.owesFollowUp(c) || (c.status === "queued" && c.executions === 0));
    }
    /** Names the budget, the node's status, and the elapsed time. Work that
     * never started reports the queue window it waited out, not the tree's. */
    lifetimeError(n) {
        if (n.status === "queued" && n.executions === 0) {
            return `Room handoff queue budget exhausted: never started while waiting for a busy teammate after ${duration(this.now() - n.createdAt)} of the ${duration(this.limits.queueMs)} queue window`;
        }
        const root = this.root(n);
        return `Room handoff lifetime budget exhausted: node was ${n.status} after ${duration(this.effectiveAgeMs(root))} of the ${duration(this.limits.lifetimeMs)} tree lifetime`;
    }
    /** The wall-clock ceiling ignores pauses: it is what stops a tree whose
     * execution never pauses long enough to age its lifetime budget. */
    hardCapError(n) {
        const root = this.root(n);
        return `Room handoff hard cap exhausted: node was ${n.status} after ${duration(this.now() - root.createdAt)} of the ${duration(this.limits.hardCapMs)} wall-clock cap`;
    }
    enqueue(source, generation, parentId, target, key, text, approvalGranted = false, rework = false, sourceText = "") {
        if (this.loadError)
            throw new Error(this.loadError);
        let parent = parentId ? this.nodes.get(parentId) : this.nodes.get(generation);
        if (parentId && (!parent || parent.status !== "running"))
            throw new Error("The originating room task is no longer running");
        if (parent && (parent.groupId !== source.groupId || parent.threadId !== source.threadId || parent.botId !== source.botId)) {
            throw new Error("The handoff belongs to a different room speaker");
        }
        const fresh = !parent;
        parent ??= { ...source, id: generation, rootId: generation, key: "root", text: sourceText.slice(0, 12_000), createdAt: this.now(), status: "source", result: "", reported: true, executions: 0, approvalGranted: false, kind: "work" };
        const kind = target.groupId && target.groupId === source.groupId ? "assignment" : "work";
        const path = this.path(parent);
        if (path.some(n => n.botId === target.botId && (!n.groupId || !target.groupId || n.groupId === target.groupId))) {
            throw new Error("Cannot assign work back to an ancestor; results return automatically");
        }
        const existing = this.children(parent.id).find(n => n.key === key);
        if (existing) {
            if (existing.groupId !== target.groupId || existing.botId !== target.botId || existing.text !== text ||
                existing.kind !== kind)
                throw new Error("request_key was already used for different work");
            return { node: existing, duplicate: true };
        }
        if (!rework && this.children(parent.id).some(n => n.kind === kind &&
            n.groupId === target.groupId && n.botId === target.botId && n.status === "completed")) {
            throw new Error("This agent already completed your assignment. Do not send acknowledgements or approvals as new work. Finish with your decision; results return automatically. Only use rework=true for concrete additional work.");
        }
        if (kind === "work" && target.groupId && path.some(n => n.groupId === target.groupId))
            throw new Error("A room request cannot return to an ancestor room; results are returned automatically");
        // The path includes the source root, so its work-node count is the
        // proposed edge depth: four edges are allowed; the fifth is refused.
        if (kind === "work" && path.filter(n => n.kind === "work").length > this.limits.depth)
            throw new Error("Room handoff depth limit reached");
        const root = fresh ? parent : this.root(parent);
        const count = [...this.nodes.values()].filter(n => n.rootId === parent.rootId && n.parentId).length;
        if (count >= this.limits.requests)
            throw new Error("Room handoff budget exhausted");
        // Refuse work the tree's lifetime budget cannot honestly serve: a node
        // accepted in the root's last minutes would be doomed at enqueue time.
        // The wall-clock hard cap ignores pauses, so the runway actually
        // available is the shorter of the two remainders.
        const lifetimeRemaining = this.limits.lifetimeMs - this.effectiveAgeMs(root);
        const hardCapRemaining = root.createdAt + this.limits.hardCapMs - this.now();
        const remaining = Math.min(lifetimeRemaining, hardCapRemaining);
        if (remaining < this.limits.minRunwayMs) {
            throw new Error(`Room handoff budget exhausted: only ${duration(Math.max(remaining, 0))} of the ${duration(this.limits.lifetimeMs)} tree lifetime remains`);
        }
        // Retain a bounded audit history without evicting active requests.
        if (this.nodes.size >= 1000) {
            const oldRoots = [...this.nodes.values()].filter(n => !n.parentId && terminal(n)).sort((a, b) => a.createdAt - b.createdAt);
            for (const old of oldRoots) {
                if (this.nodes.size < 800)
                    break;
                for (const n of this.nodes.values())
                    if (n.rootId === old.id)
                        this.nodes.delete(n.id);
            }
            if (this.nodes.size >= 1000)
                throw new Error("Too many active room requests");
        }
        const node = { ...target, id: randomUUID(), rootId: parent.rootId, parentId: parent.id,
            key, text, createdAt: this.now(), status: "queued", result: "", reported: false, executions: 0, approvalGranted,
            kind };
        const problem = this.hooks.validate(node, parent);
        if (problem)
            throw new Error(problem);
        if (fresh)
            this.nodes.set(parent.id, parent);
        this.nodes.set(node.id, node);
        try {
            this.publish(node, parent);
        }
        catch (e) {
            this.nodes.delete(node.id);
            if (fresh)
                this.nodes.delete(parent.id);
            throw e;
        }
        return { node, duplicate: false };
    }
    sourceSettled(generation, ok) {
        const node = this.nodes.get(generation);
        if (!node || node.status !== "source")
            return;
        if (!ok)
            this.cancelTree(node, "The originating room turn did not finish", "failed");
        else {
            node.status = "waiting";
            this.publish(node);
        }
    }
    cancelTree(node, reason, status = "cancelled") {
        for (const child of this.children(node.id))
            if (!terminal(child))
                this.cancelTree(child, reason, status);
        if (!terminal(node)) {
            node.status = status;
            node.result = reason;
            this.controllers.get(node.id)?.abort();
        }
        // Settlement closes the paused span now, not at the next periodic tick.
        this.trackExecutionPauses();
        this.publish(node);
    }
    cancelRoom(groupId, threadId) {
        for (const n of this.nodes.values()) {
            if (n.groupId === groupId && (!threadId || n.threadId === threadId) && !terminal(n))
                this.cancelTree(n, "Stopped by user");
        }
    }
    cancelDirect(threadId, reason = "Stopped by user") {
        for (const n of this.nodes.values()) {
            if (!n.groupId && n.threadId === threadId && !terminal(n))
                this.cancelTree(n, reason);
        }
    }
    activeDirect(threadId) {
        return [...this.nodes.values()].some(n => !n.groupId && n.threadId === threadId && !terminal(n));
    }
    /** Work this conversation handed out that has not settled yet. The
     * conversation's own node is not outstanding — only what it waits on. */
    outstandingDirect(threadId) {
        return [...this.nodes.values()].filter(node => {
            if (terminal(node) || !node.parentId)
                return false;
            const parent = this.nodes.get(node.parentId);
            return Boolean(parent && !parent.groupId && parent.threadId === threadId);
        });
    }
    /** Stop this conversation without reaching into a teammate that is already
     * working. Its provider process is left alone: it finishes and its result
     * is still reported here. Work that never started is cancelled, because
     * nothing is lost. This conversation stops being awaited either way, so no
     * teammate result resumes a stopped chat. Returns what was left running. */
    stopAwaitingDirect(threadId, reason = "Stopped by user") {
        const left = [];
        for (const node of this.nodes.values()) {
            if (node.groupId || node.threadId !== threadId || terminal(node))
                continue;
            for (const child of this.children(node.id)) {
                if (terminal(child))
                    continue;
                if (child.status === "queued")
                    this.cancelTree(child, "Stopped before it started");
                else
                    left.push(child);
            }
            node.status = "cancelled";
            node.result = reason;
            this.controllers.get(node.id)?.abort();
            this.trackExecutionPauses();
            this.publish(node);
        }
        return left;
    }
    tick() {
        if (this.loadError)
            return;
        this.trackExecutionPauses();
        // Validate and expire deepest nodes first so each one is failed with its
        // own status; an ancestor's cancellation then only sweeps what is left.
        // The hard cap overrides the runner and follow-up protections: it is the
        // bound that stops a tree whose execution never pauses.
        for (const n of [...this.nodes.values()].reverse()) {
            if (terminal(n))
                continue;
            const error = this.hooks.validate(n, n.parentId ? this.nodes.get(n.parentId) : undefined);
            const hardCapped = this.now() >= this.root(n).createdAt + this.limits.hardCapMs;
            if (error || hardCapped || (this.now() > this.deadline(n) && !this.protectsRunner(n) && !this.owesFollowUp(n))) {
                this.cancelTree(n, error ?? (hardCapped ? this.hardCapError(n) : this.lifetimeError(n)), "failed");
            }
        }
        for (const n of this.nodes.values()) {
            const parent = n.parentId ? this.nodes.get(n.parentId) : undefined;
            if (terminal(n) && parent && !n.reported) {
                this.hooks.report(n, parent);
                n.reported = true;
                this.publish(n, parent);
            }
            if (n.status === "waiting") {
                const children = this.children(n.id);
                if (children.length && children.every(c => terminal(c) && c.reported)) {
                    n.status = "resume";
                    this.publish(n);
                }
            }
            if (n.status !== "queued" && n.status !== "resume")
                continue;
            // A newly queued child starts only after its author has settled.
            if (parent && (parent.status === "source" || parent.status === "running"))
                continue;
            // A stopped source stops waiting; only work that never started is
            // dropped with it. A teammate mid-turn keeps its process and reports.
            if (parent && terminal(parent) && n.status === "queued") {
                this.cancelTree(n, "Originating request has ended");
                continue;
            }
            if (this.hooks.busy(n))
                continue;
            const root = this.root(n);
            const executionCost = 1;
            if (root.executions + executionCost > this.limits.executions) {
                this.cancelTree(n, "Room execution budget exhausted", "failed");
                continue;
            }
            const resumed = n.status === "resume";
            const childCount = this.children(n.id).length;
            root.executions += executionCost;
            n.status = "running";
            n.startedAt = this.now();
            // Open the pause at the moment execution starts, not at the next tick:
            // the lifetime clock must not charge the gap before observation.
            const pause = this.pauses.get(root.id) ?? { accumulatedMs: 0 };
            pause.since ??= this.now();
            this.pauses.set(root.id, pause);
            this.publish(n, root);
            const controller = new AbortController();
            this.controllers.set(n.id, controller);
            void this.hooks.run(n, resumed, controller.signal).then(result => {
                if (terminal(n))
                    return;
                n.result = result.text.slice(0, 12_000);
                if (!result.ok)
                    this.cancelTree(n, n.result || "Room agent failed", "failed");
                else if (this.children(n.id).length > childCount)
                    n.status = "waiting";
                else
                    n.status = "completed";
                // Close the paused span with the settlement itself: work enqueued
                // before the next periodic tick must be admitted against the aged
                // budget, not the still-open pause's overstated runway.
                this.trackExecutionPauses();
                this.publish(n);
            }).catch(e => { this.cancelTree(n, String(e).slice(0, 1000), "failed"); })
                .finally(() => this.controllers.delete(n.id));
        }
    }
}
