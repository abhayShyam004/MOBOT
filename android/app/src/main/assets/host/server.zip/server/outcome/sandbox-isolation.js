/**
 * Sandbox Isolation & Execution Engine (Milestone 3.2A)
 *
 * Provides kernel-isolated, unprivileged, cgroup v2 bounded execution for untrusted
 * Python programs and Jupyter notebooks via Bubblewrap (bwrap).
 *
 * Security Invariants & Protections:
 * 1. Strict namespace unsharing: user, net, pid, ipc, uts.
 * 2. Mandatory drop of all capabilities (--cap-drop ALL) and PR_SET_NO_NEW_PRIVS = 1.
 * 3. Read-only system roots, isolated empty /workspace, bounded /tmp and /outputs.
 * 4. Dedicated control channel (FD 6) inaccessible to untrusted execution, preventing
 *    cell control token forgery (CELL_START/CELL_END) through stdout/stderr.
 * 5. Complete process-tree termination via cgroup.kill, --die-with-parent, and systemd scope.
 * 6. Directory-anchored artifact extraction via openat2(RESOLVE_BENEATH | RESOLVE_NO_SYMLINKS).
 * 7. Host-enforced hard timeout bounds reconciling in-guest cooperative alarm limits.
 */
import { spawn, execFileSync } from "node:child_process";
import { openSync, closeSync, fstatSync, readSync, readdirSync, existsSync, readFileSync, writeFileSync, mkdirSync, rmSync, constants as fsConstants, } from "node:fs";
import { join, basename, resolve } from "node:path";
import { tmpdir } from "node:os";
import { createHash } from "node:crypto";
import { AggregateStorageLimitExceededError, UnsupportedSandboxEnvironmentError, } from "../tasks.js";
import { checkSandboxCapability, assertSandboxSupported, findCuratedPackagesPath, } from "./sandbox-capability.js";
// Storage and Execution Limits
export const MAX_SINGLE_FILE_BYTES = 20 * 1024 * 1024; // 20 MB
export const MAX_TOTAL_OUTPUT_BYTES = 50 * 1024 * 1024; // 50 MB
export const MAX_TOTAL_OUTPUT_FILES = 32;
export const MAX_STREAM_OUTPUT_BYTES = 512 * 1024; // 512 KB stdout/stderr buffer cap
export const DEFAULT_SANDBOX_WALL_TIMEOUT_MS = 60_000; // 60s default job timeout
export const DEFAULT_SANDBOX_CELL_TIMEOUT_SEC = 15; // 15s default per-cell timeout
export const DEFAULT_SANDBOX_CPU_TIMEOUT_SEC = 30; // 30s aggregate CPU budget
export const DEFAULT_SANDBOX_MEMORY_BYTES = 1024 * 1024 * 1024; // 1 GB memory limit
export const DEFAULT_SANDBOX_TASKS_MAX = 32; // Max 32 tasks/pids in cgroup
export const DEFAULT_SANDBOX_CPU_QUOTA = "200%"; // 2 CPU cores max
/**
 * Creates a bounded ext4 filesystem image and mounts it via fuse2fs.
 * Enforces aggregate byte and file/inode quotas directly at the kernel ext4 boundary.
 */
export async function createStagingFilesystem(taskId, sizeMb = 50, maxInodes = 64) {
    const tempDir = join(tmpdir(), `mobot-stage-${taskId}-${Date.now()}`);
    mkdirSync(tempDir, { recursive: true, mode: 0o700 });
    const imagePath = join(tempDir, "outputs.ext4");
    const mountPath = join(tempDir, "mnt");
    mkdirSync(mountPath, { recursive: true, mode: 0o700 });
    try {
        // 1. Create sparse image file
        execFileSync("truncate", ["-s", `${sizeMb}M`, imagePath], { stdio: "ignore" });
        const uid = typeof process.getuid === "function" ? process.getuid() : 1000;
        const gid = typeof process.getgid === "function" ? process.getgid() : 1000;
        // 2. Format with ext4 with strictly bounded inode count and root owner
        execFileSync("mkfs.ext4", [
            "-F",
            "-q",
            "-N",
            String(maxInodes),
            "-m",
            "0",
            "-E",
            `root_owner=${uid}:${gid}`,
            imagePath,
        ], { stdio: "ignore" });
        // 3. Mount via fuse2fs with nodev, nosuid, noexec
        execFileSync("fuse2fs", [imagePath, mountPath, "-o", "rw,nodev,nosuid,noexec"], { stdio: "ignore" });
    }
    catch (err) {
        try {
            execFileSync("fusermount", ["-u", "-z", mountPath], { stdio: "ignore" });
        }
        catch { }
        try {
            rmSync(tempDir, { recursive: true, force: true });
        }
        catch { }
        throw new Error(`Failed to create ext4 staging filesystem: ${err.message}`);
    }
    let cleanedUp = false;
    const cleanup = async () => {
        if (cleanedUp)
            return;
        cleanedUp = true;
        try {
            execFileSync("fusermount", ["-u", "-z", mountPath], { stdio: "ignore" });
        }
        catch { }
        try {
            rmSync(tempDir, { recursive: true, force: true });
        }
        catch { }
    };
    return {
        mountPath,
        imagePath,
        cleanup,
    };
}
const OPENAT2_EXTRACT_PY = `
import ctypes, os, sys, json, stat, hashlib, base64

SYS_openat2 = 437
RESOLVE_BENEATH = 0x08
RESOLVE_NO_SYMLINKS = 0x04
RESOLVE_NO_MAGICLINKS = 0x02

class OpenHow(ctypes.Structure):
    _fields_ = [
        ("flags", ctypes.c_uint64),
        ("mode", ctypes.c_uint64),
        ("resolve", ctypes.c_uint64),
    ]

dir_path = sys.argv[1]
max_files = int(sys.argv[2])
max_total_bytes = int(sys.argv[3])
max_single_bytes = int(sys.argv[4])

try:
    dirfd = os.open(dir_path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
except Exception as e:
    print(json.dumps({"error": f"Failed to open staging mount directory: {e}"}))
    sys.exit(0)

try:
    dir_stat = os.fstat(dirfd)
    if not stat.S_ISDIR(dir_stat.st_mode):
        print(json.dumps({"error": "ArtifactSecurityError: Staging mount is not a directory"}))
        sys.exit(0)

    entries = [e for e in os.listdir(dir_path) if e != "lost+found"]
    if len(entries) > max_files:
        print(json.dumps({
            "error_type": "AggregateStorageLimitExceededError",
            "error": f"ERR_AGGREGATE_STORAGE_LIMIT_EXCEEDED: Staging output contains {len(entries)} files, exceeding limit of {max_files}."
        }))
        sys.exit(0)

    libc = ctypes.CDLL(None, use_errno=True)
    how = OpenHow(os.O_RDONLY, 0, RESOLVE_BENEATH | RESOLVE_NO_SYMLINKS | RESOLVE_NO_MAGICLINKS)

    artifacts = []
    total_bytes = 0

    for name in entries:
        if "/" in name or "\\\\" in name or "\\0" in name or name in ("..", "."):
            print(json.dumps({"error": f"ArtifactSecurityError: Illegal filename characters detected: {name}"}))
            sys.exit(0)

        fd = libc.syscall(SYS_openat2, dirfd, name.encode("utf-8"), ctypes.byref(how), ctypes.sizeof(how))
        if fd < 0:
            err = ctypes.get_errno()
            if err in (40, 17):
                print(json.dumps({"error": f"ArtifactSecurityError: Symlink detected in outputs: {name}. Symlinks are strictly prohibited."}))
                sys.exit(0)
            if err == 18:
                print(json.dumps({"error": f"ArtifactSecurityError: Path traversal outside staging boundary detected for: {name}"}))
                sys.exit(0)
            print(json.dumps({"error": f"Failed to open artifact {name} via openat2: errno {err}"}))
            sys.exit(0)

        try:
            st = os.fstat(fd)
            if not stat.S_ISREG(st.st_mode):
                print(json.dumps({"error": f"ArtifactSecurityError: Output entry {name} is not a regular file."}))
                sys.exit(0)
            if st.st_dev != dir_stat.st_dev:
                print(json.dumps({"error": f"ArtifactSecurityError: Output file {name} is on device {st.st_dev}, expected staging device {dir_stat.st_dev}. Cross-device mount tampering detected."}))
                sys.exit(0)
            if st.st_size > max_single_bytes:
                print(json.dumps({
                    "error_type": "AggregateStorageLimitExceededError",
                    "error": f"ERR_AGGREGATE_STORAGE_LIMIT_EXCEEDED: File {name} exceeds maximum single file size ({st.st_size} > {max_single_bytes})."
                }))
                sys.exit(0)

            total_bytes += st.st_size
            if total_bytes > max_total_bytes:
                print(json.dumps({
                    "error_type": "AggregateStorageLimitExceededError",
                    "error": f"ERR_AGGREGATE_STORAGE_LIMIT_EXCEEDED: Aggregate output bytes exceeded ({total_bytes} > {max_total_bytes})."
                }))
                sys.exit(0)

            data = b""
            while len(data) < st.st_size:
                chunk = os.read(fd, st.st_size - len(data))
                if not chunk: break
                data += chunk

            sha256 = hashlib.sha256(data).hexdigest()
            artifacts.append({
                "name": name,
                "sizeBytes": st.st_size,
                "sha256": sha256,
                "base64": base64.b64encode(data).decode("ascii")
            })
        finally:
            os.close(fd)

    print(json.dumps({"artifacts": artifacts}))
finally:
    os.close(dirfd)
`;
/**
 * Security Model & Invariants: Exclusive Staging-Directory Ownership
 * 1. Directory created with mode 0700 owned exclusively by the host process.
 * 2. Staging image is mounted via FUSE with options 'nodev, nosuid, noexec'.
 * 3. Extraction runs strictly AFTER container termination and verification that cgroup.procs == 0.
 *    No concurrent guest processes exist during extraction.
 * 4. Extraction is anchored via directory file descriptor using Linux kernel openat2 with
 *    RESOLVE_BENEATH | RESOLVE_NO_SYMLINKS | RESOLVE_NO_MAGICLINKS.
 * 5. Staging filesystem is cleanly unmounted and backing sparse image unlinked immediately upon completion.
 */
export function extractSandboxArtifacts(stagingMountPath, options = {}) {
    const maxFiles = options.maxFiles ?? MAX_TOTAL_OUTPUT_FILES;
    const maxTotalBytes = options.maxTotalBytes ?? MAX_TOTAL_OUTPUT_BYTES;
    const maxSingleFileBytes = options.maxSingleFileBytes ?? MAX_SINGLE_FILE_BYTES;
    // 1. Primary extraction via kernel openat2
    try {
        const rawOut = execFileSync("python3", [
            "-c",
            OPENAT2_EXTRACT_PY,
            stagingMountPath,
            String(maxFiles),
            String(maxTotalBytes),
            String(maxSingleFileBytes),
        ], { encoding: "utf8", maxBuffer: 100 * 1024 * 1024 });
        const parsed = JSON.parse(rawOut.trim());
        if (parsed.error_type === "AggregateStorageLimitExceededError") {
            throw new AggregateStorageLimitExceededError(parsed.error);
        }
        if (parsed.error) {
            throw new Error(parsed.error);
        }
        if (Array.isArray(parsed.artifacts)) {
            return parsed.artifacts.map((a) => ({
                name: a.name,
                sizeBytes: a.sizeBytes,
                sha256: a.sha256,
                buffer: Buffer.from(a.base64, "base64"),
            }));
        }
    }
    catch (err) {
        if (err instanceof AggregateStorageLimitExceededError)
            throw err;
        if (err.message && err.message.includes("ArtifactSecurityError"))
            throw err;
        if (err.message && err.message.includes("ERR_AGGREGATE_STORAGE_LIMIT_EXCEEDED")) {
            throw new AggregateStorageLimitExceededError(err.message);
        }
        if (err.stdout) {
            try {
                const parsed = JSON.parse(err.stdout.trim());
                if (parsed.error_type === "AggregateStorageLimitExceededError") {
                    throw new AggregateStorageLimitExceededError(parsed.error);
                }
                if (parsed.error) {
                    throw new Error(parsed.error);
                }
            }
            catch (inner) {
                if (inner instanceof AggregateStorageLimitExceededError)
                    throw inner;
            }
        }
        // If openat2 failed because of a security rejection in stdout:
        const outStr = (err.stdout || "") + (err.stderr || "") + (err.message || "");
        if (outStr.includes("Symlink detected")) {
            throw new Error("ArtifactSecurityError: Symlink detected in outputs. Symlinks are strictly prohibited.");
        }
        if (outStr.includes("Path traversal outside staging")) {
            throw new Error("ArtifactSecurityError: Path traversal outside staging boundary detected.");
        }
        if (outStr.includes("Cross-device mount tampering")) {
            throw new Error("ArtifactSecurityError: Cross-device mount tampering detected.");
        }
        if (outStr.includes("AggregateStorageLimitExceededError") || outStr.includes("exceeding limit of")) {
            throw new AggregateStorageLimitExceededError(outStr);
        }
        // Otherwise fallback to descriptor-relative extraction
    }
    // 2. Verified fallback: Descriptor-relative /proc/self/fd extraction
    let dirFd;
    try {
        dirFd = openSync(stagingMountPath, fsConstants.O_RDONLY | fsConstants.O_DIRECTORY | fsConstants.O_NOFOLLOW);
    }
    catch (err) {
        throw new Error(`Failed to open staging mount directory with O_NOFOLLOW: ${err.message}`);
    }
    try {
        const dirStat = fstatSync(dirFd);
        if (!dirStat.isDirectory()) {
            throw new Error(`ArtifactSecurityError: Staging mount is not a directory.`);
        }
        const entries = readdirSync(stagingMountPath);
        const fileEntries = entries.filter((e) => e !== "lost+found");
        if (fileEntries.length > maxFiles) {
            throw new AggregateStorageLimitExceededError(`ERR_AGGREGATE_STORAGE_LIMIT_EXCEEDED: Staging output contains ${fileEntries.length} files, exceeding limit of ${maxFiles}.`);
        }
        const artifacts = [];
        let totalBytes = 0;
        for (const name of fileEntries) {
            if (name.includes("/") || name.includes("\\") || name.includes("\0") || name === ".." || name === ".") {
                throw new Error(`ArtifactSecurityError: Illegal filename characters detected: ${JSON.stringify(name)}`);
            }
            // Open strictly relative to dirFd via /proc/self/fd/${dirFd}/${name}
            const descPath = `/proc/self/fd/${dirFd}/${name}`;
            let fileFd;
            try {
                fileFd = openSync(descPath, fsConstants.O_RDONLY | fsConstants.O_NOFOLLOW);
            }
            catch (err) {
                const errno = err.code;
                if (errno === "ELOOP" || errno === "EEXIST") {
                    throw new Error(`ArtifactSecurityError: Symlink detected in outputs: ${name}. Symlinks are strictly prohibited.`);
                }
                throw new Error(`Failed to open output artifact ${name} with O_NOFOLLOW: ${err.message}`);
            }
            try {
                const stat = fstatSync(fileFd);
                if (!stat.isFile()) {
                    throw new Error(`ArtifactSecurityError: Output entry ${name} is not a regular file.`);
                }
                if (stat.dev !== dirStat.dev) {
                    throw new Error(`ArtifactSecurityError: Output file ${name} is on device ${stat.dev}, expected staging device ${dirStat.dev}. Cross-device mount tampering detected.`);
                }
                if (stat.size > maxSingleFileBytes) {
                    throw new AggregateStorageLimitExceededError(`ERR_AGGREGATE_STORAGE_LIMIT_EXCEEDED: File ${name} exceeds maximum single file size (${stat.size} > ${maxSingleFileBytes}).`, stat.size, maxSingleFileBytes);
                }
                totalBytes += stat.size;
                if (totalBytes > maxTotalBytes) {
                    throw new AggregateStorageLimitExceededError(`ERR_AGGREGATE_STORAGE_LIMIT_EXCEEDED: Aggregate output bytes exceeded (${totalBytes} > ${maxTotalBytes}).`, totalBytes, maxTotalBytes);
                }
                const buffer = Buffer.alloc(stat.size);
                let bytesReadTotal = 0;
                while (bytesReadTotal < stat.size) {
                    const read = readSync(fileFd, buffer, bytesReadTotal, stat.size - bytesReadTotal, bytesReadTotal);
                    if (read === 0)
                        break;
                    bytesReadTotal += read;
                }
                const sha256 = createHash("sha256").update(buffer).digest("hex");
                artifacts.push({
                    name,
                    sizeBytes: stat.size,
                    sha256,
                    buffer,
                });
            }
            finally {
                closeSync(fileFd);
            }
        }
        return artifacts;
    }
    finally {
        closeSync(dirFd);
    }
}
/**
 * Terminates the entire sandbox process tree atomically across all layers:
 * 1. cgroup.kill (kernel atomic kill of all cgroup tasks)
 * 2. child.kill("SIGKILL") (triggers bwrap --die-with-parent)
 * 3. systemctl --user stop <unit>.scope (systemd unit cleanup)
 * 4. Verification that cgroup.procs contains zero processes
 */
export async function terminateSandboxProcessTree(cgroupPath, child, unitName) {
    // 1. Cgroup v2 atomic kill
    if (cgroupPath && existsSync(cgroupPath)) {
        const killPath = join(cgroupPath, "cgroup.kill");
        try {
            if (existsSync(killPath)) {
                writeFileSync(killPath, "1\n");
            }
        }
        catch { }
    }
    // 2. Kill immediate child process
    try {
        child.kill("SIGKILL");
    }
    catch { }
    // 3. Stop systemd scope unit
    try {
        execFileSync("systemctl", ["--user", "stop", `${unitName}.scope`], { stdio: "ignore" });
    }
    catch { }
    // 4. Verify cgroup.procs is empty
    if (cgroupPath && existsSync(cgroupPath)) {
        const procsPath = join(cgroupPath, "cgroup.procs");
        for (let i = 0; i < 30; i++) {
            if (!existsSync(cgroupPath))
                break;
            try {
                const procs = readFileSync(procsPath, "utf8").trim();
                if (!procs)
                    break;
            }
            catch {
                break;
            }
            await new Promise((r) => setTimeout(r, 50));
        }
    }
}
export function buildSandboxArgs(options) {
    const bwrapArgs = [
        "--unshare-user",
        "--unshare-net",
        "--unshare-pid",
        "--unshare-ipc",
        "--unshare-uts",
        "--unshare-cgroup-try",
        "--disable-userns",
        "--assert-userns-disabled",
        "--cap-drop", "ALL",
        "--die-with-parent",
        "--new-session",
        "--clearenv",
        "--setenv", "PATH", "/opt/packages/bin:/usr/bin:/bin",
        "--setenv", "LANG", "C.UTF-8",
        "--setenv", "HOME", "/home/sandbox",
        "--setenv", "TMPDIR", "/tmp",
        "--setenv", "PYTHONPATH", "/opt/packages",
        "--setenv", "PYTHONUNBUFFERED", "1",
        "--ro-bind", "/usr", "/usr",
        "--symlink", "usr/lib64", "/lib64",
        "--symlink", "usr/lib", "/lib",
        "--symlink", "usr/bin", "/bin",
        "--symlink", "usr/sbin", "/sbin",
        "--proc", "/proc",
        "--dev", "/dev",
        // Note: --size must precede --tmpfs immediately
        "--size", "67108864", "--tmpfs", "/tmp",
        "--size", "16777216", "--tmpfs", "/home/sandbox",
        "--size", "104857600", "--tmpfs", "/workspace",
    ];
    if (options.curatedPackagesDir && existsSync(options.curatedPackagesDir)) {
        bwrapArgs.push("--ro-bind", options.curatedPackagesDir, "/opt/packages");
    }
    bwrapArgs.push("--ro-bind", options.runnerScriptPath, "/opt/mobot-runner.py", "--ro-bind", options.inputsDir, "/inputs", "--bind", options.stagingOutputsDir, "/outputs", "--chdir", "/workspace");
    if (options.syncFd !== undefined && options.syncFd >= 0) {
        bwrapArgs.push("--sync-fd", String(options.syncFd));
    }
    if (options.infoFd !== undefined && options.infoFd >= 0) {
        bwrapArgs.push("--info-fd", String(options.infoFd));
    }
    const commandArgs = [
        "/usr/bin/prlimit",
        `--cpu=${DEFAULT_SANDBOX_CPU_TIMEOUT_SEC}`,
        `--fsize=${MAX_SINGLE_FILE_BYTES}`,
        "--nofile=64",
        "/usr/bin/python3",
        "-S",
        "/opt/mobot-runner.py",
        "--notebook", options.notebookTarget,
        "--output-dir", "/outputs",
        "--scratch-dir", "/workspace",
    ];
    if (options.barrierFd !== undefined && options.barrierFd >= 0) {
        commandArgs.push("--barrier-fd", String(options.barrierFd));
    }
    if (options.controlFd !== undefined && options.controlFd >= 0) {
        commandArgs.push("--control-fd", String(options.controlFd));
    }
    if (options.perCellTimeoutSec !== undefined) {
        commandArgs.push("--cell-timeout", String(options.perCellTimeoutSec));
    }
    return { bwrapArgs, commandArgs };
}
export async function executeSandboxTask(options) {
    // 1. Fail-closed capability gate
    await assertSandboxSupported();
    const report = await checkSandboxCapability();
    const bwrapBin = report.details?.bwrapPath || "/usr/bin/bwrap";
    const curatedPackages = findCuratedPackagesPath() || undefined;
    const runnerScript = resolve(import.meta.dirname, "sandbox-notebook-runner.py");
    if (!existsSync(runnerScript)) {
        throw new Error(`Trusted runner script not found at ${runnerScript}`);
    }
    // 2. Create bounded staging filesystem
    const staging = await createStagingFilesystem(options.taskId, 50, 64);
    const wallTimeoutMs = options.wallTimeoutMs ?? DEFAULT_SANDBOX_WALL_TIMEOUT_MS;
    const memoryMax = options.memoryMaxBytes ?? DEFAULT_SANDBOX_MEMORY_BYTES;
    const tasksMax = options.tasksMax ?? DEFAULT_SANDBOX_TASKS_MAX;
    const cpuQuota = DEFAULT_SANDBOX_CPU_QUOTA;
    const unitName = `mobot-sandbox-${options.taskId}-${Date.now()}`;
    // Inputs path mapping
    let targetInSandbox = options.notebookTarget;
    if (!targetInSandbox.startsWith("/inputs/")) {
        targetInSandbox = join("/inputs", basename(options.notebookTarget));
    }
    // 3. Command construction with FD assignments:
    // stdio[0]: stdin (pipe)
    // stdio[1]: stdout (pipe)
    // stdio[2]: stderr (pipe)
    // stdio[3]: barrier pipe (pipe)  -> FD 3 in child
    // stdio[4]: sync pipe (pipe)     -> FD 4 in child (for --sync-fd 4)
    // stdio[5]: info pipe (pipe)     -> FD 5 in child (for --info-fd 5)
    // stdio[6]: control pipe (pipe)  -> FD 6 in child (for CELL_START/CELL_END protocol)
    const { bwrapArgs, commandArgs } = buildSandboxArgs({
        bwrapBin,
        inputsDir: options.inputsDir,
        stagingOutputsDir: staging.mountPath,
        runnerScriptPath: runnerScript,
        notebookTarget: targetInSandbox,
        curatedPackagesDir: curatedPackages,
        barrierFd: 3,
        syncFd: 4,
        infoFd: 5,
        controlFd: 6,
        perCellTimeoutSec: options.perCellTimeoutSec ?? DEFAULT_SANDBOX_CELL_TIMEOUT_SEC,
    });
    let spawnBin;
    let spawnArgs;
    if (options.skipCgroupScope) {
        spawnBin = bwrapBin;
        spawnArgs = [...bwrapArgs, ...commandArgs];
    }
    else {
        spawnBin = "systemd-run";
        spawnArgs = [
            "--user",
            "--scope",
            "--quiet",
            `--unit=${unitName}`,
            `-p`, `MemoryMax=${memoryMax}`,
            `-p`, `MemorySwapMax=0`,
            `-p`, `TasksMax=${tasksMax}`,
            `-p`, `CPUQuota=${cpuQuota}`,
            bwrapBin,
            ...bwrapArgs,
            ...commandArgs,
        ];
    }
    const startTime = Date.now();
    let timedOut = false;
    let cancelled = false;
    return new Promise((resolvePromise, rejectPromise) => {
        let child;
        try {
            child = spawn(spawnBin, spawnArgs, {
                stdio: ["pipe", "pipe", "pipe", "pipe", "pipe", "pipe", "pipe"],
            });
        }
        catch (err) {
            staging.cleanup().finally(() => {
                rejectPromise(new Error(`Failed to spawn sandbox runner: ${err.message}`));
            });
            return;
        }
        const stdioPipes = child.stdio;
        const barrierPipe = stdioPipes[3];
        const syncPipe = stdioPipes[4];
        const infoPipe = stdioPipes[5];
        const controlPipe = stdioPipes[6];
        if (!barrierPipe || !syncPipe || !infoPipe || !controlPipe) {
            try {
                child.kill("SIGKILL");
            }
            catch { }
            staging.cleanup().finally(() => {
                rejectPromise(new UnsupportedSandboxEnvironmentError("Failed to initialize sandbox IPC file descriptors"));
            });
            return;
        }
        child.stdin?.on("error", () => { });
        child.stdout?.on("error", () => { });
        child.stderr?.on("error", () => { });
        barrierPipe?.on("error", () => { });
        syncPipe?.on("error", () => { });
        infoPipe?.on("error", () => { });
        controlPipe?.on("error", () => { });
        let stdout = "";
        let stderr = "";
        let infoData = "";
        let cgroupVerified = false;
        let verifiedHostPid;
        let cellWatchdogTimer = null;
        let cellTimedOut = false;
        let cpuTimedOut = false;
        let aggregateCpuUsageUsec = 0;
        let cpuMonitorInterval = null;
        let cgroupPath = "";
        // Hard upper bound: host watchdog fires at exact perCellTimeoutSec limit
        const perCellTimeoutMs = (options.perCellTimeoutSec ?? DEFAULT_SANDBOX_CELL_TIMEOUT_SEC) * 1000;
        // Collect unprivileged stdout/stderr streams - NEVER parse for supervisory control tokens!
        child.stdout?.on("data", (chunk) => {
            const text = chunk.toString("utf8");
            if (stdout.length < MAX_STREAM_OUTPUT_BYTES) {
                stdout += text;
            }
        });
        child.stderr?.on("data", (chunk) => {
            if (stderr.length < MAX_STREAM_OUTPUT_BYTES) {
                stderr += chunk.toString("utf8");
            }
        });
        // Dedicated control channel: ONLY FD 6 is parsed for CELL_START and CELL_END
        let controlBuffer = "";
        controlPipe.on("data", (chunk) => {
            controlBuffer += chunk.toString("utf8");
            let newlineIdx;
            while ((newlineIdx = controlBuffer.indexOf("\n")) !== -1) {
                const line = controlBuffer.slice(0, newlineIdx).trim();
                controlBuffer = controlBuffer.slice(newlineIdx + 1);
                if (line.startsWith("CELL_START ")) {
                    if (cellWatchdogTimer)
                        clearTimeout(cellWatchdogTimer);
                    cellWatchdogTimer = setTimeout(async () => {
                        cellTimedOut = true;
                        timedOut = true;
                        await terminateSandboxProcessTree(cgroupPath, child, unitName);
                    }, perCellTimeoutMs);
                }
                else if (line.startsWith("CELL_END ")) {
                    if (cellWatchdogTimer) {
                        clearTimeout(cellWatchdogTimer);
                        cellWatchdogTimer = null;
                    }
                }
            }
        });
        infoPipe.on("data", (chunk) => {
            infoData += chunk.toString("utf8");
        });
        // 4. Host Cgroup Verification & Barrier Release
        const barrierTimeout = setTimeout(async () => {
            if (!cgroupVerified) {
                await terminateSandboxProcessTree(cgroupPath, child, unitName);
                await staging.cleanup();
                rejectPromise(new UnsupportedSandboxEnvironmentError("Sandbox cgroup barrier timeout: launcher failed to handshake or cgroup verification timed out."));
            }
        }, 5000);
        const performBarrierHandshake = async () => {
            let childPid;
            try {
                const parsed = JSON.parse(infoData.trim());
                childPid = typeof parsed["child-pid"] === "number" ? parsed["child-pid"] : undefined;
            }
            catch {
                childPid = undefined;
            }
            if (!childPid) {
                clearTimeout(barrierTimeout);
                await terminateSandboxProcessTree(cgroupPath, child, unitName);
                await staging.cleanup();
                rejectPromise(new UnsupportedSandboxEnvironmentError("Failed to read host-namespace child-pid from bwrap --info-fd."));
                return;
            }
            verifiedHostPid = childPid;
            // If cgroup scope is active, verify cgroup controllers and process membership
            if (!options.skipCgroupScope) {
                try {
                    const procCgroup = readFileSync(`/proc/${childPid}/cgroup`, "utf8").trim();
                    const rel = procCgroup.split("::")[1]?.replace(/^\/+/, "");
                    if (rel) {
                        cgroupPath = join("/sys/fs/cgroup", rel);
                    }
                }
                catch { }
                if (!cgroupPath || !existsSync(cgroupPath)) {
                    cgroupPath = `/sys/fs/cgroup/user.slice/user-${process.getuid?.() ?? 1000}.slice/user@${process.getuid?.() ?? 1000}.service/app.slice/${unitName}.scope`;
                }
                if (existsSync(cgroupPath)) {
                    try {
                        const memVal = readFileSync(join(cgroupPath, "memory.max"), "utf8").trim();
                        const pidsVal = readFileSync(join(cgroupPath, "pids.max"), "utf8").trim();
                        const cpuVal = readFileSync(join(cgroupPath, "cpu.max"), "utf8").trim();
                        const procsVal = readFileSync(join(cgroupPath, "cgroup.procs"), "utf8").trim().split(/\s+/);
                        if (!cpuVal || memVal !== String(memoryMax) || pidsVal !== String(tasksMax)) {
                            clearTimeout(barrierTimeout);
                            await terminateSandboxProcessTree(cgroupPath, child, unitName);
                            await staging.cleanup();
                            rejectPromise(new UnsupportedSandboxEnvironmentError(`Effective cgroup limits mismatch: memory.max=${memVal} (expected ${memoryMax}), pids.max=${pidsVal} (expected ${tasksMax}), cpu.max=${cpuVal}`));
                            return;
                        }
                        if (!procsVal.includes(String(childPid))) {
                            clearTimeout(barrierTimeout);
                            await terminateSandboxProcessTree(cgroupPath, child, unitName);
                            await staging.cleanup();
                            rejectPromise(new UnsupportedSandboxEnvironmentError(`Cgroup membership verification failed: PID ${childPid} not found in ${join(cgroupPath, "cgroup.procs")}`));
                            return;
                        }
                    }
                    catch (err) {
                        clearTimeout(barrierTimeout);
                        await terminateSandboxProcessTree(cgroupPath, child, unitName);
                        await staging.cleanup();
                        rejectPromise(new UnsupportedSandboxEnvironmentError(`Failed to verify cgroup limits at ${cgroupPath}: ${err.message}`));
                        return;
                    }
                }
            }
            cgroupVerified = true;
            clearTimeout(barrierTimeout);
            // Release barrier: write 1 byte to barrierPipe
            try {
                barrierPipe.write("G");
                barrierPipe.end();
            }
            catch { }
            // Start host-side cgroup v2 aggregate CPU usage watchdog
            if (cgroupPath && existsSync(cgroupPath)) {
                const readCpuUsec = () => {
                    try {
                        const statText = readFileSync(join(cgroupPath, "cpu.stat"), "utf8");
                        const m = statText.match(/usage_usec\s+(\d+)/);
                        return m ? Number(m[1]) : 0;
                    }
                    catch {
                        return 0;
                    }
                };
                const initialCpuUsec = readCpuUsec();
                const aggregateCpuLimitUsec = (options.aggregateCpuTimeoutSec ?? DEFAULT_SANDBOX_CPU_TIMEOUT_SEC) * 1_000_000;
                cpuMonitorInterval = setInterval(async () => {
                    if (cgroupPath && existsSync(cgroupPath)) {
                        const currentUsec = readCpuUsec();
                        aggregateCpuUsageUsec = currentUsec - initialCpuUsec;
                        if (aggregateCpuUsageUsec >= aggregateCpuLimitUsec) {
                            cpuTimedOut = true;
                            timedOut = true;
                            if (cpuMonitorInterval)
                                clearInterval(cpuMonitorInterval);
                            await terminateSandboxProcessTree(cgroupPath, child, unitName);
                        }
                    }
                }, 100);
            }
        };
        const tryParseChildPid = () => {
            try {
                const parsed = JSON.parse(infoData.trim());
                return typeof parsed["child-pid"] === "number" ? parsed["child-pid"] : undefined;
            }
            catch {
                return undefined;
            }
        };
        const checkHandshakeReady = () => {
            if (!cgroupVerified && tryParseChildPid() !== undefined) {
                performBarrierHandshake().catch((err) => {
                    rejectPromise(err);
                });
            }
        };
        infoPipe.on("data", checkHandshakeReady);
        // Wall-clock watchdog timer
        const watchdogTimer = setTimeout(async () => {
            timedOut = true;
            await terminateSandboxProcessTree(cgroupPath, child, unitName);
        }, wallTimeoutMs);
        // User cancellation support
        if (options.abortSignal) {
            if (options.abortSignal.aborted) {
                timedOut = true;
                cancelled = true;
                terminateSandboxProcessTree(cgroupPath, child, unitName).finally(async () => {
                    await staging.cleanup();
                    rejectPromise(new Error("Sandbox execution cancelled by caller."));
                });
                return;
            }
            options.abortSignal.addEventListener("abort", async () => {
                timedOut = true;
                cancelled = true;
                await terminateSandboxProcessTree(cgroupPath, child, unitName);
            });
        }
        child.on("close", async (exitCode, signalCode) => {
            clearTimeout(watchdogTimer);
            clearTimeout(barrierTimeout);
            if (cellWatchdogTimer)
                clearTimeout(cellWatchdogTimer);
            if (cpuMonitorInterval)
                clearInterval(cpuMonitorInterval);
            try {
                syncPipe.end();
            }
            catch { }
            // Guarantee complete process tree termination and 0 processes in cgroup
            await terminateSandboxProcessTree(cgroupPath, child, unitName);
            const durationMs = Date.now() - startTime;
            // 5. Safe Artifact Extraction (openat2 with RESOLVE_BENEATH | RESOLVE_NO_SYMLINKS)
            let artifacts = [];
            let manifest;
            try {
                artifacts = extractSandboxArtifacts(staging.mountPath);
                const manifestArt = artifacts.find((a) => a.name === "execution_manifest.json");
                if (manifestArt) {
                    try {
                        manifest = JSON.parse(manifestArt.buffer.toString("utf8"));
                    }
                    catch { }
                }
            }
            catch (err) {
                await staging.cleanup();
                rejectPromise(err);
                return;
            }
            await staging.cleanup();
            resolvePromise({
                success: exitCode === 0 && !timedOut && !cancelled,
                exitCode,
                signalCode,
                artifacts,
                executionManifest: manifest,
                stdout,
                stderr,
                timedOut,
                cpuTimedOut,
                cellTimedOut,
                cancelled,
                durationMs,
                cgroupUsage: {
                    memoryMaxBytes: memoryMax,
                    tasksMax,
                    cpuQuota,
                    verifiedHostPid,
                    aggregateCpuUsageUsec,
                },
            });
        });
        child.on("error", async (err) => {
            clearTimeout(watchdogTimer);
            clearTimeout(barrierTimeout);
            if (cellWatchdogTimer)
                clearTimeout(cellWatchdogTimer);
            if (cpuMonitorInterval)
                clearInterval(cpuMonitorInterval);
            await terminateSandboxProcessTree(cgroupPath, child, unitName);
            await staging.cleanup();
            rejectPromise(err);
        });
    });
}
