/** A short, renewable ownership fence for one Local VM desktop.
 * Runtime events keep an active turn's lease alive; a dead provider cannot
 * pin the VM forever. All methods are synchronous so lifecycle routes and
 * turn dispatch can claim their side of the race before either awaits. */
export class LocalVmLease {
    record = null;
    ttlMs;
    constructor(ttlMs) {
        if (!Number.isFinite(ttlMs) || ttlMs <= 0)
            throw new Error("Local VM lease TTL must be positive");
        this.ttlMs = ttlMs;
    }
    current(isBotBusy, now = Date.now()) {
        if (this.record && (this.record.expiresAt <= now || !isBotBusy(this.record.botId)))
            this.record = null;
        return this.record ? { ...this.record } : null;
    }
    claim(threadId, botId, isBotBusy, now = Date.now()) {
        const current = this.current(isBotBusy, now);
        if (current && current.threadId !== threadId)
            return false;
        this.record = { threadId, botId, expiresAt: now + this.ttlMs };
        return true;
    }
    touch(threadId, now = Date.now()) {
        if (this.record && this.record.expiresAt <= now) {
            this.record = null;
            return;
        }
        if (this.record?.threadId === threadId)
            this.record.expiresAt = now + this.ttlMs;
    }
    release(threadId) {
        if (this.record?.threadId === threadId)
            this.record = null;
    }
}
/** Independent lease lanes keyed by an already-validated Local VM target.
 * Shared mode uses one key; per-bot mode uses one digest-derived key per bot,
 * so separate desktops never block each other while each desktop remains a
 * strict singleton. */
export class LocalVmLeasePool {
    leases = new Map();
    ttlMs;
    constructor(ttlMs) {
        if (!Number.isFinite(ttlMs) || ttlMs <= 0)
            throw new Error("Local VM lease TTL must be positive");
        this.ttlMs = ttlMs;
    }
    forTarget(targetKey) {
        let lease = this.leases.get(targetKey);
        if (!lease) {
            lease = new LocalVmLease(this.ttlMs);
            this.leases.set(targetKey, lease);
        }
        return lease;
    }
    /** Drop an idle per-target lane after its owning bot and VM are gone. */
    forget(targetKey) {
        this.leases.delete(targetKey);
    }
}
