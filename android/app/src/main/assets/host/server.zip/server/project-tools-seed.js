// Seed the `project_tools` MCP server into config.json on hosts that are not
// the Android app.
//
// Why this exists: the canonical app-builder tool table was mounted only by
// android-computer, so a bot talking to MOBOT's desktop/dev server had no
// `project_start` and could never open a durable project — even though the
// desktop UI lists projects and the same server owns the ProjectManager.
//
// Rules kept conservative, mirroring android-seed.ts:
//   • only ever touches `mcpServers.project_tools`;
//   • never reorders or rewrites another entry;
//   • writes nothing when the stored entry already matches;
//   • validates through the same parser the runtime uses before writing.
import { existsSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { parseStoredMcpServer } from "./mcp-registry.js";
export const PROJECT_TOOLS_SERVER_NAME = "project_tools";
function entryMatches(existing, args) {
    if (!existing || typeof existing !== "object" || Array.isArray(existing))
        return false;
    const entry = existing;
    const env = entry.env;
    if (entry.enabled !== true)
        return false;
    if (entry.command !== (args.node ?? process.execPath))
        return false;
    if (!Array.isArray(entry.args))
        return false;
    const expectedArgs = ["--experimental-strip-types", args.entrypoint];
    if (entry.args.length !== expectedArgs.length)
        return false;
    if (entry.args.some((value, index) => value !== expectedArgs[index]))
        return false;
    if (!env || typeof env !== "object" || Array.isArray(env))
        return false;
    const stored = env;
    return (stored.PT_PROJECTS_DIR === (args.projectsDir ?? join(args.dataDir, "projects")) &&
        stored.PT_DATA_DIR === args.dataDir);
}
/** Add/refresh `project_tools` idempotently. A malformed user entry is never
 *  overwritten — the caller gets `skipped` and the reason. */
export function seedProjectToolsServer(args) {
    const log = args.log ?? (() => { });
    const configPath = join(args.dataDir, "config.json");
    let config = {};
    if (existsSync(configPath)) {
        try {
            config = JSON.parse(readFileSync(configPath, "utf8"));
        }
        catch {
            // An unreadable config belongs to the user (or a mid-edit write); do not
            // clobber it. The next boot retries.
            return { status: "skipped", reason: "config.json is not readable JSON" };
        }
    }
    else {
        mkdirSync(args.dataDir, { recursive: true });
    }
    const mcpServers = config.mcpServers && typeof config.mcpServers === "object" && !Array.isArray(config.mcpServers)
        ? { ...config.mcpServers }
        : {};
    const existing = mcpServers[PROJECT_TOOLS_SERVER_NAME];
    if (entryMatches(existing, args))
        return { status: "current" };
    if (existing !== undefined) {
        // Somebody already configured this name by hand. Respect it unless it is
        // clearly ours and merely stale.
        const owned = typeof existing === "object" && existing !== null &&
            existing.command === (args.node ?? process.execPath);
        if (!owned) {
            return { status: "skipped", reason: `${PROJECT_TOOLS_SERVER_NAME} is user-configured` };
        }
    }
    const desired = {
        command: args.node ?? process.execPath,
        args: ["--experimental-strip-types", args.entrypoint],
        env: {
            PT_PROJECTS_DIR: args.projectsDir ?? join(args.dataDir, "projects"),
            PT_DATA_DIR: args.dataDir,
        },
        enabled: true,
    };
    const candidate = { ...mcpServers, [PROJECT_TOOLS_SERVER_NAME]: desired };
    for (const [name, raw] of Object.entries(candidate)) {
        const parsed = parseStoredMcpServer(name, raw);
        if (!parsed.ok) {
            log(`project-tools-seed: entry ${name} invalid (${parsed.error}); config left untouched`);
            return { status: "skipped", reason: `entry ${name} invalid: ${parsed.error}` };
        }
    }
    writeFileSync(configPath, JSON.stringify({ ...config, mcpServers: candidate }, null, 2));
    log(`project-tools-seed: ${PROJECT_TOOLS_SERVER_NAME} MCP server ${existing ? "updated" : "added"} in config.json`);
    return { status: "written" };
}
