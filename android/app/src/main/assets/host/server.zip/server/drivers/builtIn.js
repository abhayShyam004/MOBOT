import { AntigravityDriver } from "./antigravity.js";
import { BoxAgentDriver } from "./boxagent.js";
import { ClaudeDriver } from "./claude.js";
import { CodexDriver } from "./codex.js";
import { GrokDriver } from "./grok.js";
import { GrokAgentDriver } from "./acp/grok.js";
import { GeminiAgentDriver } from "./acp/gemini.js";
import { KimiAgentDriver } from "./acp/kimi.js";
import { DroidAgentDriver } from "./acp/droid.js";
import { CursorAgentDriver } from "./acp/cursor.js";
import { OpenCodeDriver } from "./acp/opencode-go.js";
import { QwenAgentDriver } from "./acp/qwen.js";
import { CustomAcpDriver } from "./acp/custom.js";
import { HermesAgentDriver } from "./acp/hermes.js";
import { OpenAICompatDriver } from "./openai-compat.js";
import { AnthropicCompatDriver } from "./anthropic-compat.js";
import { PiDriver } from "./pi.js";
import { MinimaxDriver } from "./minimax.js";
export const BUILT_IN_DRIVERS = [
    GrokDriver,
    GrokAgentDriver,
    GeminiAgentDriver,
    KimiAgentDriver,
    DroidAgentDriver,
    CursorAgentDriver,
    OpenCodeDriver,
    QwenAgentDriver,
    HermesAgentDriver,
    CustomAcpDriver,
    PiDriver,
    OpenAICompatDriver,
    AnthropicCompatDriver,
    ClaudeDriver,
    CodexDriver,
    AntigravityDriver,
    BoxAgentDriver,
    MinimaxDriver,
];
