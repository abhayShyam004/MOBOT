/** The author a message implies when an attachment carries no explicit one.
 * Tool activity rows are the one bot-role shape that is not the assistant's
 * own visual output. */
export function defaultAttachmentAuthor(message) {
    if (message.role === "user")
        return "user";
    if (message.tool)
        return "tool";
    return "assistant";
}
/** A user-role row can never claim to be anything but a user upload, and a
 * bot row can never claim a user upload. Internal callers may narrow a bot
 * attachment to `tool`; everything else falls back to the message's role. */
function trustedAuthor(requested, fallback, role) {
    if (role === "user")
        return "user";
    if (requested === "assistant" || requested === "tool")
        return requested;
    return fallback;
}
export function stampAttachment(attachment, message, threadId, messageId, 
/** The already-durable attachment at the same path, when a patch merges an
 *  existing list. Provenance is immutable once bound: re-attaching the same
 *  file cannot turn a user upload into a tool artifact or vice versa. */
previous) {
    const fallback = defaultAttachmentAuthor(message);
    const author = previous?.author ?? trustedAuthor(attachment.author, fallback, message.role);
    const tool = previous?.tool ?? attachment.tool ?? (author === "tool" ? message.tool?.name : undefined);
    return {
        ...previous,
        ...attachment,
        author,
        ...(tool ? { tool } : {}),
        ownerThreadId: previous?.ownerThreadId ?? attachment.ownerThreadId ?? threadId,
        boundMessageId: previous?.boundMessageId ?? attachment.boundMessageId ?? messageId,
    };
}
/** Stamp every attachment on one message. The original array is not mutated:
 * the durable row and the in-memory cache receive the same new values. */
export function stampMessageAttachments(message, threadId, messageId) {
    if (!message.attachments?.length)
        return message;
    return {
        ...message,
        attachments: message.attachments.map((attachment) => stampAttachment(attachment, message, threadId, messageId)),
    };
}
