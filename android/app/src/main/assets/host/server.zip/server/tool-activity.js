// Canonical activity translation.
//
// A provider names its tools for a machine: `android_computer_project_start`,
// `mcp__android_computer__workspace_read`, `Bash`. Those identifiers are right
// for dispatch and wrong for a transcript — a person reading their chat should
// see "Starting the project", not the registry key. The translation lives here,
// once, so the phone, the desktop transcript, and call-mode narration cannot
// drift into three different descriptions of the same step.
//
// Labels are title-case chips; spoken phrases are the lower-case register the
// voice uses. Raw names stay on the wire (`tool.name`) because the details
// sheet is allowed to be technical — the summary line is not.
/** Order matters: the first match wins, so specific lifecycle tools come
 * before the generic `project_` family and page capture comes before plain
 * screenshot. */
const RULES = [
    {
        pattern: /^(?:project_start|start_project|begin_project)$/,
        label: "Starting the project",
        spoken: "starting the project",
        category: "project",
    },
    {
        pattern: /^(?:project_lifecycle_status|project_status|lifecycle_status|resume_project)$/,
        label: "Checking the project plan",
        spoken: "checking the project plan",
        category: "project",
    },
    {
        pattern: /^(?:project_step_complete|step_complete|complete_step)$/,
        label: "Recording a completed step",
        spoken: "recording a completed step",
        category: "project",
    },
    {
        pattern: /^(?:project_criterion_verify|criterion_verify|verify_criterion)$/,
        label: "Verifying an acceptance criterion",
        spoken: "verifying an acceptance criterion",
        category: "verify",
    },
    {
        pattern: /^(?:project_finish|finish_project|complete_project)$/,
        label: "Finishing the project",
        spoken: "finishing the project",
        category: "project",
    },
    {
        pattern: /^project_/,
        label: "Working on the project",
        spoken: "working on the project",
        category: "project",
    },
    {
        pattern: /^(?:workspace_list|list_workspace|list_files|list_dir|ls)$/,
        label: "Listing project files",
        spoken: "listing project files",
        category: "files",
    },
    {
        pattern: /^(?:workspace_read|read_file|view_file|open_file|read_resource|read_doc|read)$/,
        label: "Reading project files",
        spoken: "reading a file",
        category: "files",
    },
    {
        pattern: /^(?:workspace_write|write_file|create_file|save_file|write)$/,
        label: "Writing project files",
        spoken: "writing a file",
        category: "files",
    },
    {
        pattern: /^(?:workspace_append|append_file)$/,
        label: "Updating project files",
        spoken: "updating project files",
        category: "files",
    },
    {
        pattern: /^(?:workspace_edit|edit_file|modify_file|patch|apply_patch|str_replace|multiedit|edit)$/,
        label: "Editing project files",
        spoken: "editing a file",
        category: "files",
    },
    {
        pattern: /^(?:workspace_delete|delete_file|remove_file|rm)$/,
        label: "Deleting project files",
        spoken: "deleting project files",
        category: "files",
    },
    {
        pattern: /^(?:artifact_register|register_artifact)$/,
        label: "Registering a deliverable",
        spoken: "registering a deliverable",
        category: "delivery",
    },
    {
        pattern: /^(?:artifact_list|list_artifacts)$/,
        label: "Checking deliverables",
        spoken: "checking deliverables",
        category: "delivery",
    },
    {
        pattern: /^(?:artifact_read|inspect_artifact)$/,
        label: "Inspecting a deliverable",
        spoken: "inspecting a deliverable",
        category: "delivery",
    },
    {
        pattern: /^(?:run_tests?|tests?|pytest|vitest|jest|gradle_test|test_suite)$/,
        label: "Running tests",
        spoken: "running tests",
        category: "tests",
    },
    {
        pattern: /^(?:run_shell|run_command|shell|bash|terminal|exec|execute|command)$/,
        label: "Running a command",
        spoken: "running a command",
        category: "command",
    },
    {
        pattern: /^(?:install_dependencies|install|npm_install|pnpm_install|yarn_install|pip_install|gradle)$/,
        label: "Installing dependencies",
        spoken: "installing dependencies",
        category: "command",
    },
    {
        pattern: /^(?:read_screen|inspect_screen|screen_read)$/,
        label: "Inspecting the screen",
        spoken: "inspecting the screen",
        category: "computer",
    },
    {
        pattern: /^(?:browser_screenshot|capture_page|page_screenshot)$/,
        label: "Capturing the page",
        spoken: "capturing the page",
        category: "browser",
    },
    {
        pattern: /^(?:take_screenshot|screenshot|screen_capture|capture_screen)$/,
        label: "Capturing the screen",
        spoken: "looking at the screen",
        category: "computer",
    },
    {
        pattern: /^(?:click|tap|press_key|type_text|input_text|scroll|swipe|computer_batch|computer)$/,
        label: "Using the computer",
        spoken: "using the computer",
        category: "computer",
    },
    {
        pattern: /^(?:open_app|launch_app)$/,
        label: "Opening an app",
        spoken: "opening an app",
        category: "computer",
    },
    {
        pattern: /^(?:open_url|navigate|goto)$/,
        label: "Opening a page",
        spoken: "opening a page",
        category: "browser",
    },
    {
        pattern: /^(?:web_search|search_web|websearch|browser_search)$/,
        label: "Searching the web",
        spoken: "searching the web",
        category: "search",
    },
    {
        pattern: /^(?:web_fetch|fetch_url|read_page|browse_page|browse)$/,
        label: "Reading a page",
        spoken: "reading a page",
        category: "browser",
    },
    {
        pattern: /^(?:grep|glob|find|rg|search_files)$/,
        label: "Searching files",
        spoken: "searching files",
        category: "search",
    },
    {
        pattern: /^(?:session_search|search_sessions|search_history)$/,
        label: "Searching recent activity",
        spoken: "searching recent activity",
        category: "search",
    },
    {
        pattern: /^(?:select_computer|connect_computer)$/,
        label: "Connecting to the computer",
        spoken: "connecting to the computer",
        category: "computer",
    },
    {
        pattern: /^(?:list_bots|list_agents)$/,
        label: "Checking who's around",
        spoken: "checking who's around",
        category: "communication",
    },
    {
        pattern: /^(?:ask_bot|message_bot|send_message|delegate_bot|start_thread|ask_teammate)$/,
        label: "Asking a teammate",
        spoken: "asking a teammate",
        category: "communication",
    },
    {
        pattern: /^(?:list_rooms|list_groups)$/,
        label: "Checking the groups",
        spoken: "checking the groups",
        category: "communication",
    },
    {
        pattern: /^(?:post_to_room|post_to_group)$/,
        label: "Posting in a group",
        spoken: "posting in a group",
        category: "communication",
    },
    {
        pattern: /^(?:calendar|list_events|get_event|find_free_slots|view_calendar|search_events)$/,
        label: "Checking the calendar",
        spoken: "checking the calendar",
        category: "general",
    },
    {
        pattern: /^(?:calendar_create_event|create_event|add_event|insert_event)$/,
        label: "Scheduling an event",
        spoken: "scheduling an event",
        category: "general",
    },
    {
        pattern: /^(?:reminder|set_reminder|create_reminder)$/,
        label: "Setting a reminder",
        spoken: "setting a reminder",
        category: "general",
    },
    {
        pattern: /^(?:alarm|set_alarm|create_alarm)$/,
        label: "Setting an alarm",
        spoken: "setting an alarm",
        category: "general",
    },
    {
        pattern: /^(?:send_email|draft_email|read_email|gmail|email)$/,
        label: "Working with email",
        spoken: "working with email",
        category: "communication",
    },
    {
        pattern: /^(?:deploy|publish|release|ship)$/,
        label: "Publishing the result",
        spoken: "publishing the result",
        category: "delivery",
    },
    {
        pattern: /^(?:download|download_file)$/,
        label: "Downloading a file",
        spoken: "downloading a file",
        category: "files",
    },
    {
        pattern: /^(?:upload|upload_file)$/,
        label: "Uploading a file",
        spoken: "uploading a file",
        category: "files",
    },
    {
        pattern: /^(?:generate_image|create_image|image_generation)$/,
        label: "Generating an image",
        spoken: "generating an image",
        category: "delivery",
    },
    {
        pattern: /^(?:verify|verify_output|check_status|health_check|status|check)$/,
        label: "Verifying the result",
        spoken: "verifying the result",
        category: "verify",
    },
];
/** First-token verbs for tool families this build has never heard of. The
 * point is not to guess the whole operation; it is to avoid reading an
 * identifier aloud and still give the step an honest shape. */
const FALLBACK_VERBS = {
    start: ["Starting", "starting"],
    begin: ["Starting", "starting"],
    create: ["Creating", "creating"],
    add: ["Adding", "adding"],
    read: ["Reading", "reading"],
    inspect: ["Inspecting", "inspecting"],
    get: ["Reading", "reading"],
    list: ["Listing", "listing"],
    fetch: ["Fetching", "fetching"],
    write: ["Writing", "writing"],
    save: ["Writing", "writing"],
    edit: ["Editing", "editing"],
    update: ["Updating", "updating"],
    modify: ["Updating", "updating"],
    delete: ["Deleting", "deleting"],
    remove: ["Deleting", "deleting"],
    run: ["Running", "running"],
    execute: ["Running", "running"],
    search: ["Searching", "searching"],
    find: ["Finding", "finding"],
    open: ["Opening", "opening"],
    close: ["Closing", "closing"],
    send: ["Sending", "sending"],
    post: ["Posting", "posting"],
    click: ["Clicking", "clicking"],
    tap: ["Tapping", "tapping"],
    type: ["Typing", "typing"],
    press: ["Pressing", "pressing"],
    scroll: ["Scrolling", "scrolling"],
    swipe: ["Swiping", "swiping"],
    take: ["Taking", "taking"],
    capture: ["Capturing", "capturing"],
    install: ["Installing", "installing"],
    verify: ["Verifying", "verifying"],
    check: ["Checking", "checking"],
    set: ["Setting", "setting"],
    select: ["Selecting", "selecting"],
    connect: ["Connecting", "connecting"],
    deploy: ["Publishing", "publishing"],
    publish: ["Publishing", "publishing"],
    upload: ["Uploading", "uploading"],
    download: ["Downloading", "downloading"],
    generate: ["Generating", "generating"],
    test: ["Testing", "testing"],
    finish: ["Finishing", "finishing"],
    complete: ["Completing", "completing"],
    register: ["Registering", "registering"],
    ask: ["Asking", "asking"],
    message: ["Messaging", "messaging"],
    schedule: ["Scheduling", "scheduling"],
};
/** Strip MCP server prefixes and the harness's own tool namespaces. The
 * result is the operation part only, in the provider's spelling. */
function operationName(raw) {
    let name = raw.trim();
    // `mcp__<server>__<tool>` — server names contain underscores, so consume
    // non-greedily up to the delimiter rather than up to the first `_`.
    name = name.replace(/^mcp__.+?__/, "");
    name = name.replace(/^(?:android_computer|android_browser|openmausbot-phone|phone|agents|app_builder|appbuilder)[_:]/i, "");
    return name.trim();
}
/** Split camelCase and any punctuation into lower-case words. */
function words(value) {
    return value
        .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
        .split(/[^A-Za-z0-9]+/)
        .map((word) => word.toLowerCase())
        .filter(Boolean);
}
function normalise(value) {
    return words(value).join("_");
}
/** A noun phrase for the fallback verb table. Deterministic and free of
 * identifiers: three words at most, because this is a chip, not a log. */
function objectPhrase(rest) {
    if (!rest.length)
        return "the task";
    const joined = rest.slice(0, 3).join(" ");
    return /^[a-z][a-z0-9 ]*$/.test(joined) ? joined : "the task";
}
function describeName(rawName) {
    // Some providers title a call `Bash: pnpm test`. The prefix names the tool;
    // the rest is argv and belongs in the details sheet, not the chip.
    const operation = operationName(rawName).replace(/\s*:\s*.*$/, "");
    const key = normalise(operation);
    if (!key) {
        return { label: "Working on a step", spoken: "working on a step", category: "general" };
    }
    for (const rule of RULES) {
        if (rule.pattern.test(key)) {
            return { label: rule.label, spoken: rule.spoken, category: rule.category };
        }
    }
    const parts = words(operation);
    const verbIndex = parts.findIndex((part) => part in FALLBACK_VERBS);
    const verb = verbIndex >= 0 ? FALLBACK_VERBS[parts[verbIndex]] : undefined;
    if (verb) {
        const object = objectPhrase(parts.filter((_, index) => index !== verbIndex));
        return {
            label: `${verb[0]} ${object}`,
            spoken: `${verb[1]} ${object}`,
            category: "general",
        };
    }
    // No recognisable verb: say that a step is happening instead of echoing
    // whatever registry key the provider invented.
    return { label: "Working on a step", spoken: "working on a step", category: "general" };
}
/** Translate one provider tool name into the row a person reads. */
export function describeToolActivity(rawName) {
    return describeName(rawName);
}
/** True for chips the harness writes as already-readable prose (approval
 * receipts, provider errors). Those are not tool identifiers and must not be
 * re-labelled — they keep their own words. */
export function isNarratableToolName(rawName) {
    const name = rawName.trim();
    if (!name)
        return false;
    if (/^(?:auto-approved|error):/i.test(name))
        return false;
    // A shell command is also not a tool identifier; its provider already put
    // the command in `summary`, and the generic label is the honest chip.
    return !/\s/.test(name) || /^[A-Za-z0-9_.:/-]+$/.test(name);
}
/** The canonical state for a tool row: an explicit state wins, then the
 * historical `ok` flag, then "running" because a row without an outcome is
 * still in flight as far as the transcript knows. */
export function toolActivityState(ok, explicit) {
    if (explicit)
        return explicit;
    if (ok === true)
        return "succeeded";
    if (ok === false)
        return "failed";
    return "running";
}
export function isTerminalToolState(state) {
    return state === "succeeded" || state === "failed" || state === "cancelled";
}
/** The row a start event creates. `label`/`spoken` are derived once here so
 * every client renders the same phrase. */
export function beginToolActivity(name, operationId) {
    const description = describeToolActivity(name);
    return {
        name,
        label: description.label,
        spoken: description.spoken,
        state: "running",
        ...(operationId ? { operationId } : {}),
    };
}
/** Settle a running row. Returns null when the row already has an outcome:
 * a duplicate or replayed completion must never rewrite what happened first. */
export function settleToolActivity(existing, outcome) {
    if (existing && isTerminalToolState(existing.state))
        return null;
    const name = existing?.name ?? outcome.name ?? "tool";
    const description = describeToolActivity(name);
    return {
        ...existing,
        name,
        label: existing?.label ?? description.label,
        spoken: existing?.spoken ?? description.spoken,
        state: toolActivityState(outcome.ok),
        ...(existing?.operationId ? { operationId: existing.operationId } : {}),
        ok: outcome.ok,
        output: outcome.output,
        error: outcome.error,
        ...(outcome.durationMs === undefined ? {} : { durationMs: outcome.durationMs }),
    };
}
/** A row still marked running when its turn ends. A clean turn did not
 * complete the step, so the honest state is cancelled; a broken turn failed. */
export function settleInterruptedToolActivity(existing, options) {
    const cancelled = options.interrupted || options.ok;
    return {
        ...existing,
        state: cancelled ? "cancelled" : "failed",
        ...(cancelled ? {} : { ok: false }),
        ...(options.durationMs === undefined ? {} : { durationMs: options.durationMs }),
    };
}
/** The retry chip: in flight, never a success, and one row per attempt. */
export function retryToolActivity(attempt, maxAttempts, reason, delaySeconds) {
    return {
        name: `retrying — attempt ${attempt}/${maxAttempts} in ${delaySeconds}s — ${reason}`,
        label: `Retrying — attempt ${attempt} of ${maxAttempts}`,
        spoken: `retrying the request, attempt ${attempt} of ${maxAttempts}`,
        state: "retrying",
        summary: `${delaySeconds}s · ${reason}`,
    };
}
