import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { DATA_DIR } from "../config.js";
import { writeFileAtomic } from "../atomic.js";
const STORE_FILENAME = "chief-of-staff.json";
export class ChiefStore {
    state;
    filePath;
    constructor(customPath) {
        this.filePath = customPath ?? join(DATA_DIR, STORE_FILENAME);
        this.state = this.loadState();
    }
    loadState() {
        const emptyState = {
            version: 1,
            tasks: {},
            activeBriefing: undefined,
            historicalBriefings: [],
            composers: {},
            rules: {},
            auditLog: [],
        };
        if (!existsSync(this.filePath)) {
            return emptyState;
        }
        try {
            const raw = readFileSync(this.filePath, "utf-8");
            const parsed = JSON.parse(raw);
            if (parsed && typeof parsed === "object" && parsed.version === 1) {
                return {
                    version: 1,
                    tasks: parsed.tasks ?? {},
                    activeBriefing: parsed.activeBriefing ?? undefined,
                    historicalBriefings: Array.isArray(parsed.historicalBriefings) ? parsed.historicalBriefings : [],
                    composers: parsed.composers ?? {},
                    rules: parsed.rules ?? {},
                    auditLog: Array.isArray(parsed.auditLog) ? parsed.auditLog : [],
                };
            }
            return emptyState;
        }
        catch {
            return emptyState;
        }
    }
    persist() {
        try {
            writeFileAtomic(this.filePath, JSON.stringify(this.state, null, 2), { mode: 0o600 });
        }
        catch (err) {
            // Best-effort in non-persisted test environments
        }
    }
    getState() {
        return { ...this.state };
    }
    getTask(id) {
        return this.state.tasks[id];
    }
    getTaskByDisplayNumber(ordinal) {
        if (!this.state.activeBriefing || !Array.isArray(this.state.activeBriefing.displayOrder)) {
            return undefined;
        }
        const index = ordinal - 1;
        if (index < 0 || index >= this.state.activeBriefing.displayOrder.length) {
            return undefined;
        }
        const taskId = this.state.activeBriefing.displayOrder[index];
        return this.state.tasks[taskId];
    }
    saveTask(task) {
        this.state.tasks[task.id] = { ...task, updatedAt: new Date().toISOString() };
        this.persist();
    }
    saveTasks(tasks) {
        const now = new Date().toISOString();
        for (const task of tasks) {
            this.state.tasks[task.id] = { ...task, updatedAt: now };
        }
        this.persist();
    }
    getActiveBriefing() {
        return this.state.activeBriefing;
    }
    setActiveBriefing(briefing) {
        if (this.state.activeBriefing && this.state.activeBriefing.id !== briefing.id) {
            this.state.historicalBriefings.unshift(this.state.activeBriefing.id);
            if (this.state.historicalBriefings.length > 20) {
                this.state.historicalBriefings.pop();
            }
        }
        this.state.activeBriefing = briefing;
        this.logAudit("briefing_activated", {
            briefingId: briefing.id,
            itemCount: briefing.displayOrder.length,
            generatedAt: briefing.generatedAt,
        });
        this.persist();
    }
    updateTaskStatus(taskId, status) {
        const task = this.state.tasks[taskId];
        if (!task)
            return undefined;
        task.status = status;
        task.updatedAt = new Date().toISOString();
        this.logAudit("task_status_updated", { taskId, status });
        this.persist();
        return task;
    }
    recordExecutionReceipt(taskId, receipt) {
        const task = this.state.tasks[taskId];
        if (!task)
            return undefined;
        if (task.action) {
            task.action.executionReceipt = receipt;
            task.action.status = receipt.success ? "completed" : "failed";
        }
        task.status = receipt.success ? "completed" : "failed";
        task.updatedAt = new Date().toISOString();
        this.logAudit("action_executed", {
            taskId,
            actionId: receipt.actionId,
            toolName: receipt.toolName,
            success: receipt.success,
            externalId: receipt.externalId,
        });
        this.persist();
        return task;
    }
    // ── Composer Management (Phase D & E) ──
    getComposer(id) {
        return (this.state.composers ?? {})[id];
    }
    listComposers() {
        return Object.values(this.state.composers ?? {});
    }
    saveComposer(composer) {
        if (!this.state.composers)
            this.state.composers = {};
        this.state.composers[composer.id] = { ...composer, updatedAt: new Date().toISOString() };
        this.logAudit("composer_saved", { composerId: composer.id, status: composer.status });
        this.persist();
    }
    updateComposerStatus(id, status, receipt) {
        if (!this.state.composers)
            this.state.composers = {};
        const comp = this.state.composers[id];
        if (!comp)
            return undefined;
        comp.status = status;
        comp.updatedAt = new Date().toISOString();
        if (receipt) {
            comp.executionReceipt = receipt;
        }
        this.logAudit("composer_status_updated", { composerId: id, status, externalId: receipt?.externalId });
        this.persist();
        return comp;
    }
    deleteComposer(id) {
        if (!this.state.composers || !this.state.composers[id])
            return false;
        delete this.state.composers[id];
        this.logAudit("composer_deleted", { composerId: id });
        this.persist();
        return true;
    }
    // ── Rule Management (Phase G) ──
    getRule(id) {
        return (this.state.rules ?? {})[id];
    }
    listRules() {
        return Object.values(this.state.rules ?? {});
    }
    saveRule(rule) {
        if (!this.state.rules)
            this.state.rules = {};
        this.state.rules[rule.id] = { ...rule, updatedAt: new Date().toISOString() };
        this.logAudit("rule_saved", { ruleId: rule.id, name: rule.name, enabled: rule.enabled });
        this.persist();
    }
    deleteRule(id) {
        if (!this.state.rules || !this.state.rules[id])
            return false;
        delete this.state.rules[id];
        this.logAudit("rule_deleted", { ruleId: id });
        this.persist();
        return true;
    }
    recordRuleExecution(id, record) {
        if (!this.state.rules)
            this.state.rules = {};
        const rule = this.state.rules[id];
        if (!rule)
            return;
        rule.lastExecutedAt = record.executedAt;
        if (!Array.isArray(rule.executionHistory))
            rule.executionHistory = [];
        rule.executionHistory.unshift(record);
        if (rule.executionHistory.length > 50)
            rule.executionHistory.pop();
        this.logAudit("rule_executed", { ruleId: id, status: record.status, summary: record.summary });
        this.persist();
    }
    logAudit(event, details) {
        this.state.auditLog.push({
            timestamp: new Date().toISOString(),
            event,
            details,
        });
        if (this.state.auditLog.length > 200) {
            this.state.auditLog.shift();
        }
        this.persist();
    }
    reset(initial) {
        this.state = {
            version: 1,
            tasks: initial?.tasks ?? {},
            activeBriefing: initial?.activeBriefing,
            historicalBriefings: initial?.historicalBriefings ?? [],
            composers: initial?.composers ?? {},
            rules: initial?.rules ?? {},
            auditLog: initial?.auditLog ?? [],
        };
        this.persist();
    }
}
export const defaultChiefStore = new ChiefStore();
