import { defaultChiefStore } from "./chief-store.js";
import { PersonalContextAggregator } from "./context-aggregator.js";
import { TaskExtractor } from "./task-extractor.js";
import { BriefingEngine } from "./briefing-engine.js";
import { DelegationResolver } from "./delegation-resolver.js";
import { ActionExecutor } from "./action-executor.js";
import { defaultActionAuthorizationManager, } from "../capabilities/safety-policy.js";
import { CommitmentDetector } from "./commitment-detector.js";
import { EmailComposerService, composerToOptionCard, } from "./email-composer.js";
export { composerToOptionCard };
import { RulesManager, } from "./rules-manager.js";
export class ChiefOfStaffService {
    store;
    aggregator;
    extractor;
    briefingEngine;
    delegationResolver;
    actionExecutor;
    authManager;
    detector;
    composerService;
    rulesManager;
    constructor(opts) {
        this.store = opts?.store ?? defaultChiefStore;
        this.authManager = opts?.authManager ?? defaultActionAuthorizationManager;
        this.aggregator = new PersonalContextAggregator({
            transport: opts?.transport,
            config: opts?.config,
        });
        this.extractor = new TaskExtractor({ clock: opts?.clock });
        this.briefingEngine = new BriefingEngine(this.store, { clock: opts?.clock });
        this.delegationResolver = new DelegationResolver(this.store);
        this.actionExecutor = new ActionExecutor({
            store: this.store,
            transport: opts?.transport,
            config: opts?.config,
            authManager: this.authManager,
        });
        this.detector = new CommitmentDetector();
        this.composerService = new EmailComposerService({
            store: this.store,
            authManager: this.authManager,
            transport: opts?.transport,
            config: opts?.config,
        });
        this.rulesManager = new RulesManager({
            store: this.store,
            detector: this.detector,
        });
    }
    async generateBriefing() {
        const { items, sourcesSummary } = await this.aggregator.aggregate();
        const tasks = this.extractor.extractTasks(items, this.store.getState().tasks);
        return this.briefingEngine.generateBriefing(tasks, sourcesSummary);
    }
    delegate(userInput) {
        return this.delegationResolver.resolve(userInput);
    }
    async delegateContextual(userInput, contactDirectory) {
        const { items } = await this.aggregator.aggregate();
        return this.delegationResolver.resolveContextual(userInput, items, this.composerService, contactDirectory);
    }
    /**
     * Authoritatively grant approval for a task's proposed action.
     * Can ONLY be invoked by human confirmation (UI card response or explicit user approval endpoint).
     * Generates a single-use, time-bound, parameter-hashed grant in the ActionAuthorizationManager.
     */
    grantApproval(taskId, opts) {
        const task = this.store.getTask(taskId);
        if (!task) {
            return { ok: false, error: `Task ${taskId} not found` };
        }
        const action = task.action;
        if (!action) {
            return { ok: false, error: `Task "${task.title}" has no action to approve` };
        }
        if (task.status === "completed" || action.status === "completed") {
            return { ok: false, error: `Task "${task.title}" has already been completed` };
        }
        const payload = (action.payload ?? {});
        const grant = this.authManager.createGrant({
            capabilityId: `chief_of_staff:${action.id}`,
            operation: action.type,
            parameters: payload,
            botId: opts?.botId,
            threadId: opts?.threadId,
            ttlMs: opts?.ttlMs ?? 300_000,
        });
        action.approvalGrantId = grant.grantId;
        action.status = "approved";
        this.store.updateTaskStatus(taskId, "approved");
        return {
            ok: true,
            grantId: grant.grantId,
            expiresAt: grant.expiresAtMs,
        };
    }
    async executeAction(taskId, opts) {
        return this.actionExecutor.execute(taskId, opts);
    }
    listTasks() {
        return Object.values(this.store.getState().tasks);
    }
    getBriefing() {
        return this.store.getActiveBriefing();
    }
    // ── Context-Aware Commitments & Attachments (Phase B & C) ──
    async detectCommitments() {
        const { items } = await this.aggregator.aggregate();
        return this.detector.detectCommitments(items);
    }
    async discoverAttachments(query) {
        const { items } = await this.aggregator.aggregate();
        const driveItems = items.filter((i) => i.source === "googledrive");
        return this.detector.discoverAttachments(query, driveItems);
    }
    // ── Email Composer Operations (Phase D, E, F) ──
    proposeEmail(input) {
        return this.composerService.propose(input);
    }
    editEmail(composerId, edits) {
        return this.composerService.edit(composerId, edits);
    }
    grantEmailApproval(composerId, operation, opts) {
        return this.composerService.grantApproval(composerId, operation, opts);
    }
    async saveEmailDraft(composerId, opts) {
        return this.composerService.saveDraft(composerId, opts);
    }
    async sendEmail(composerId, opts) {
        return this.composerService.sendEmail(composerId, opts);
    }
    cancelEmail(composerId) {
        return this.composerService.cancel(composerId);
    }
    listComposers() {
        return this.store.listComposers();
    }
    getComposer(id) {
        return this.store.getComposer(id);
    }
    // ── Rule Management (Phase G & H) ──
    listRules() {
        return this.rulesManager.listRules();
    }
    getRule(id) {
        return this.rulesManager.getRule(id);
    }
    createRule(input) {
        return this.rulesManager.createRule(input);
    }
    updateRule(id, updates) {
        return this.rulesManager.updateRule(id, updates);
    }
    deleteRule(id) {
        return this.rulesManager.deleteRule(id);
    }
    toggleRule(id) {
        return this.rulesManager.toggleRule(id);
    }
    async evaluateRules() {
        const { items } = await this.aggregator.aggregate();
        return this.rulesManager.evaluateRules(items);
    }
}
export const defaultChiefService = new ChiefOfStaffService();
