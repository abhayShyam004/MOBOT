/**
 * Authoritative Execution Memory & Adaptive Context Management
 *
 * Implements:
 * 1. AuthoritativeToolStore: Immutable retention of exact raw arguments, start/end timestamps,
 *    side-effect classifications, and raw outputs. Never summarized or discarded.
 * 2. Stable Artifact References: artifact://<threadId>/<callId> for compacting large outputs
 *    while preserving 100% retrievability.
 * 3. artifact_read: Harness tool for model to retrieve slices of past compacted tool outputs on demand.
 * 4. Adaptive Compaction: Considers size, relevance, failure diagnostics (never loses errors!),
 *    irreversible side effects, and stable references.
 * 5. StructuredExecutionMemory: Tracks objective, active plan, current stage, verified completed
 *    milestones, pending steps, touched files, failed attempts, and recovery state.
 * 6. ContextBudgetManager: Dynamic context allocation adhering to provider model window, output
 *    reservations, and prioritized partitions.
 */
export function classifySideEffect(name, args) {
    const n = name.toLowerCase();
    // Irreversible operations (destructive, external deployments, drops)
    if (n.includes("delete") ||
        n.includes("remove") ||
        n.includes("drop") ||
        n.includes("destroy") ||
        n.includes("kill") ||
        n.includes("deploy")) {
        return "irreversible";
    }
    // Check command string in terminal tools
    if (args && (typeof args.command === "string" || typeof args.cmd === "string")) {
        const cmd = String(args.command || args.cmd).trim();
        if (/\b(?:rm\s+-rf?|git\s+reset\s+--hard|git\s+clean\s+-fdx?|dropdb|terraform\s+destroy)\b/i.test(cmd)) {
            return "irreversible";
        }
        if (/\b(?:cat|ls|pwd|head|tail|grep|find|git\s+status|git\s+log|git\s+diff|npm\s+test|vitest|node\s+-v|pnpm\s+test)\b/i.test(cmd)) {
            return "read_only";
        }
        return "state_mutating";
    }
    // State mutating operations (writes, edits, creation, configuration)
    if (n.includes("write") ||
        n.includes("edit") ||
        n.includes("create") ||
        n.includes("update") ||
        n.includes("patch") ||
        n.includes("install") ||
        n.includes("apply") ||
        n.includes("post") ||
        n.includes("send")) {
        return "state_mutating";
    }
    // Reads, inspections, searches, status checks
    return "read_only";
}
export class AuthoritativeToolStore {
    records = new Map();
    recordExecution(entry) {
        const sideEffect = entry.sideEffect ?? classifySideEffect(entry.name, entry.args);
        const artifactRef = `artifact://${entry.threadId}/${entry.callId}`;
        const record = {
            callId: entry.callId,
            name: entry.name,
            args: JSON.parse(JSON.stringify(entry.args ?? {})), // defensive copy of exact args
            startedAt: entry.startedAt,
            completedAt: entry.completedAt,
            ok: entry.ok,
            rawOutput: entry.rawOutput,
            sideEffect,
            botId: entry.botId,
            threadId: entry.threadId,
            artifactRef,
        };
        this.records.set(entry.callId, record);
        this.records.set(artifactRef, record);
        return record;
    }
    get(callIdOrRef) {
        return this.records.get(callIdOrRef);
    }
    getAll() {
        const unique = new Map();
        for (const record of this.records.values()) {
            unique.set(record.callId, record);
        }
        return Array.from(unique.values());
    }
    readArtifact(ref, options = {}) {
        const record = this.records.get(ref);
        if (!record) {
            return { ok: false, text: `Artifact reference "${ref}" not found in authoritative storage.`, totalChars: 0, totalLines: 0 };
        }
        const fullText = record.rawOutput;
        const lines = fullText.split("\n");
        const totalLines = lines.length;
        const totalChars = fullText.length;
        let resultLines = lines;
        if (options.search) {
            const q = options.search.toLowerCase();
            resultLines = lines.filter((line) => line.toLowerCase().includes(q));
        }
        if (typeof options.startLine === "number" && options.startLine > 0) {
            const start = options.startLine - 1;
            const count = Math.min(options.lineCount ?? 100, 500);
            resultLines = resultLines.slice(start, start + count);
        }
        else if (typeof options.lineCount === "number") {
            resultLines = resultLines.slice(0, Math.min(options.lineCount, 500));
        }
        let text = resultLines.join("\n");
        const maxChars = options.maxChars ?? 20_000;
        if (text.length > maxChars) {
            text = text.slice(0, maxChars) + `\n[... truncated ${text.length - maxChars} chars]`;
        }
        return {
            ok: true,
            text: `[Artifact ${ref} (${record.name})]:\n${text}`,
            totalChars,
            totalLines,
        };
    }
}
export const ARTIFACT_READ_TOOL_NAME = "artifact_read";
export function artifactReadDefinition() {
    return {
        type: "function",
        function: {
            name: ARTIFACT_READ_TOOL_NAME,
            description: "Retrieve full or sliced content of an earlier compacted tool output by its artifact reference (artifact://threadId/callId). Use this when you need diagnostic details or raw data from an earlier step that was summarized.",
            parameters: {
                type: "object",
                properties: {
                    ref: {
                        type: "string",
                        description: "The artifact reference URI (e.g. artifact://threadId/callId).",
                    },
                    search: {
                        type: "string",
                        description: "Optional substring to filter matching lines.",
                    },
                    startLine: {
                        type: "number",
                        description: "Optional 1-based start line number.",
                    },
                    lineCount: {
                        type: "number",
                        description: "Optional number of lines to return (default 100, max 500).",
                    },
                },
                required: ["ref"],
                additionalProperties: false,
            },
        },
    };
}
export function createStructuredExecutionMemory(initial) {
    return {
        objective: initial?.objective ?? "",
        constraints: initial?.constraints ?? [],
        activePlan: initial?.activePlan,
        currentStage: initial?.currentStage,
        completedSteps: initial?.completedSteps ?? [],
        pendingSteps: initial?.pendingSteps ?? [],
        failedSteps: initial?.failedSteps ?? [],
        touchedFiles: initial?.touchedFiles ?? [],
        verifiedFacts: initial?.verifiedFacts ?? [],
        recoveryCount: initial?.recoveryCount ?? 0,
    };
}
export function formatStructuredContinuation(memory, steps) {
    const lines = [
        "[Recovery] The previous model response ended before producing anything. This is a transport interruption in the middle of the task, not a verdict on it.",
        "The operations below already ran in this turn and their results are in this conversation. Do not repeat them; continue with the next unfinished step.",
    ];
    if (memory.objective) {
        lines.push(`Objective: ${memory.objective}`);
    }
    if (memory.currentStage) {
        lines.push(`Current Stage: ${memory.currentStage}`);
    }
    if (memory.activePlan) {
        lines.push(`Active Plan: ${memory.activePlan}`);
    }
    const completed = steps ? steps.filter((s) => s.ok) : memory.completedSteps;
    if (completed.length) {
        lines.push(`Completed: ${completed.map((s) => `${s.name} [${s.callId}] ${s.summary}`).join(" | ")}`);
    }
    else {
        lines.push("Completed: none");
    }
    const failed = steps ? steps.filter((s) => !s.ok) : memory.failedSteps.map((f) => ({ callId: f.callId, name: f.name, summary: f.errorSummary }));
    if (failed.length) {
        lines.push(`Failed (fix the cause; assume no effect unless its result says otherwise): ${failed.map((s) => `${s.name} [${s.callId}] ${s.summary}`).join(" | ")}`);
    }
    else {
        lines.push("Failed: none");
    }
    if (memory.touchedFiles.length) {
        lines.push(`Modified Files: ${memory.touchedFiles.join(", ")}`);
    }
    if (memory.pendingSteps.length) {
        lines.push(`Pending Next Steps: ${memory.pendingSteps.join("; ")}`);
    }
    lines.push("Continue the task from here, verify anything you are unsure of, and do not start over.");
    return lines.join("\n");
}
export const TOOL_OUTPUT_BUDGET_CHARS = 32_000;
export const TOOL_OUTPUTS_KEPT_VERBATIM = 4;
function object(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
/**
 * Replace older tool results with bounded summaries while preserving exact
 * outcome flags, call ids, error diagnostics, and stable artifact references.
 */
export function compactToolOutputs(input, options = {}) {
    const budget = options.budgetChars ?? TOOL_OUTPUT_BUDGET_CHARS;
    const keep = options.keepVerbatim ?? TOOL_OUTPUTS_KEPT_VERBATIM;
    const outputs = input.filter((item) => item.type === "function_call_output");
    const total = outputs.reduce((sum, item) => sum + (typeof item.output === "string" ? item.output.length : 0), 0);
    if (total <= budget)
        return 0;
    let compacted = 0;
    for (const item of outputs.slice(0, Math.max(0, outputs.length - keep))) {
        const text = typeof item.output === "string" ? item.output : "";
        if (text.length <= 400)
            continue;
        let ok = null;
        let rawResult = "";
        try {
            const parsed = JSON.parse(text);
            if (object(parsed)) {
                ok = parsed.ok;
                if (typeof parsed.result === "string")
                    rawResult = parsed.result;
            }
        }
        catch {
            ok = null;
        }
        const callId = typeof item.call_id === "string" ? item.call_id : "unknown";
        const threadId = options.threadId ?? "thread";
        const artifactRef = `artifact://${threadId}/${callId}`;
        // If this call represents a failure (ok === false), preserve diagnostic error info up to 1,000 chars!
        if (ok === false) {
            const errorDiag = rawResult.slice(0, 1_000);
            item.output = JSON.stringify({
                ok,
                result: `[compacted error: ${text.length} chars from step ${callId}; status: failed; artifact_ref: ${artifactRef}] ${errorDiag}`,
            });
        }
        else {
            item.output = JSON.stringify({
                ok,
                result: `[compacted: ${text.length} chars from an earlier step; the full output is in this turn's event log; artifact_ref: ${artifactRef}] ${text.slice(0, 200)}`,
            });
        }
        compacted++;
    }
    return compacted;
}
/**
 * Replace large payload strings in older function_call arguments with bounded summaries
 * while preserving JSON structure, parameter keys, and stable artifact references.
 */
export function compactFunctionCallArguments(input, options = {}) {
    const keep = options.keepVerbatim ?? TOOL_OUTPUTS_KEPT_VERBATIM;
    const calls = input.filter((item) => item.type === "function_call");
    if (calls.length <= keep)
        return 0;
    let compacted = 0;
    for (const item of calls.slice(0, Math.max(0, calls.length - keep))) {
        const raw = typeof item.arguments === "string" ? item.arguments : "";
        if (raw.length <= 400)
            continue;
        try {
            const parsed = JSON.parse(raw);
            if (object(parsed)) {
                let modified = false;
                const callId = typeof item.call_id === "string" ? item.call_id : "unknown";
                const threadId = options.threadId ?? "thread";
                const artifactRef = `artifact://${threadId}/${callId}`;
                for (const [k, v] of Object.entries(parsed)) {
                    if (typeof v === "string" && v.length > 300) {
                        parsed[k] = `[compacted ${v.length} chars from earlier step: ${v.slice(0, 100)}...; artifact_ref: ${artifactRef}]`;
                        modified = true;
                    }
                }
                if (modified) {
                    item.arguments = JSON.stringify(parsed);
                    compacted++;
                }
            }
        }
        catch {
            // Keep as-is if not valid JSON
        }
    }
    return compacted;
}
/**
 * Compact tool outputs and arguments in OpenAI-format message arrays.
 */
export function compactOpenAIMessages(messages, options = {}) {
    const budget = options.budgetChars ?? TOOL_OUTPUT_BUDGET_CHARS;
    const keep = options.keepVerbatim ?? TOOL_OUTPUTS_KEPT_VERBATIM;
    const toolMessages = messages.filter((m) => m.role === "tool");
    const total = toolMessages.reduce((sum, item) => sum + (typeof item.content === "string" ? item.content.length : 0), 0);
    let compacted = 0;
    if (total > budget) {
        for (const item of toolMessages.slice(0, Math.max(0, toolMessages.length - keep))) {
            const text = typeof item.content === "string" ? item.content : "";
            if (text.length <= 400)
                continue;
            let ok = null;
            let rawResult = "";
            try {
                const parsed = JSON.parse(text);
                if (object(parsed)) {
                    ok = parsed.ok;
                    if (typeof parsed.result === "string")
                        rawResult = parsed.result;
                }
            }
            catch {
                ok = null;
            }
            const callId = typeof item.tool_call_id === "string" ? item.tool_call_id : "unknown";
            const threadId = options.threadId ?? "thread";
            const artifactRef = `artifact://${threadId}/${callId}`;
            if (ok === false) {
                item.content = JSON.stringify({
                    ok,
                    result: `[compacted error: ${text.length} chars from step ${callId}; status: failed; artifact_ref: ${artifactRef}] ${rawResult.slice(0, 1000)}`,
                });
            }
            else {
                item.content = JSON.stringify({
                    ok,
                    result: `[compacted: ${text.length} chars from an earlier step; the full output is in this turn's event log; artifact_ref: ${artifactRef}] ${text.slice(0, 200)}`,
                });
            }
            compacted++;
        }
    }
    const assistantToolMsgs = messages.filter((m) => m.role === "assistant" && Array.isArray(m.tool_calls) && m.tool_calls.length > 0);
    if (assistantToolMsgs.length > keep) {
        for (const msg of assistantToolMsgs.slice(0, Math.max(0, assistantToolMsgs.length - keep))) {
            const calls = msg.tool_calls;
            for (const call of calls) {
                const raw = typeof call?.function?.arguments === "string" ? call.function.arguments : "";
                if (raw.length <= 400)
                    continue;
                try {
                    const parsed = JSON.parse(raw);
                    if (object(parsed)) {
                        let mod = false;
                        const callId = typeof call.id === "string" ? call.id : "unknown";
                        const threadId = options.threadId ?? "thread";
                        const artifactRef = `artifact://${threadId}/${callId}`;
                        for (const [k, v] of Object.entries(parsed)) {
                            if (typeof v === "string" && v.length > 300) {
                                parsed[k] = `[compacted ${v.length} chars from earlier step: ${v.slice(0, 100)}...; artifact_ref: ${artifactRef}]`;
                                mod = true;
                            }
                        }
                        if (mod)
                            call.function.arguments = JSON.stringify(parsed);
                    }
                }
                catch { }
            }
        }
    }
    return compacted;
}
/**
 * Compact tool results and tool use inputs in Anthropic-format message arrays.
 */
export function compactAnthropicMessages(messages, options = {}) {
    const budget = options.budgetChars ?? TOOL_OUTPUT_BUDGET_CHARS;
    const keep = options.keepVerbatim ?? TOOL_OUTPUTS_KEPT_VERBATIM;
    const allToolResults = [];
    for (const m of messages) {
        if (m.role === "user" && Array.isArray(m.content)) {
            for (const block of m.content) {
                if (object(block) && block.type === "tool_result") {
                    allToolResults.push({ item: block });
                }
            }
        }
    }
    const total = allToolResults.reduce((sum, entry) => sum + (typeof entry.item.content === "string" ? entry.item.content.length : 0), 0);
    let compacted = 0;
    if (total > budget) {
        for (const entry of allToolResults.slice(0, Math.max(0, allToolResults.length - keep))) {
            const block = entry.item;
            const text = typeof block.content === "string" ? block.content : "";
            if (text.length <= 400)
                continue;
            let ok = null;
            let rawResult = "";
            try {
                const parsed = JSON.parse(text);
                if (object(parsed)) {
                    ok = parsed.ok;
                    if (typeof parsed.result === "string")
                        rawResult = parsed.result;
                }
            }
            catch {
                ok = null;
            }
            const callId = typeof block.tool_use_id === "string" ? block.tool_use_id : "unknown";
            const threadId = options.threadId ?? "thread";
            const artifactRef = `artifact://${threadId}/${callId}`;
            if (ok === false || block.is_error) {
                block.content = JSON.stringify({
                    ok: false,
                    result: `[compacted error: ${text.length} chars from step ${callId}; status: failed; artifact_ref: ${artifactRef}] ${rawResult.slice(0, 1000)}`,
                });
            }
            else {
                block.content = JSON.stringify({
                    ok: true,
                    result: `[compacted: ${text.length} chars from an earlier step; the full output is in this turn's event log; artifact_ref: ${artifactRef}] ${text.slice(0, 200)}`,
                });
            }
            compacted++;
        }
    }
    // Compact tool_use inputs in older assistant messages
    const allToolUses = [];
    for (const m of messages) {
        if (m.role === "assistant" && Array.isArray(m.content)) {
            for (const block of m.content) {
                if (object(block) && block.type === "tool_use") {
                    allToolUses.push({ block });
                }
            }
        }
    }
    if (allToolUses.length > keep) {
        for (const entry of allToolUses.slice(0, Math.max(0, allToolUses.length - keep))) {
            const block = entry.block;
            if (object(block.input)) {
                const callId = typeof block.id === "string" ? block.id : "unknown";
                const threadId = options.threadId ?? "thread";
                const artifactRef = `artifact://${threadId}/${callId}`;
                for (const [k, v] of Object.entries(block.input)) {
                    if (typeof v === "string" && v.length > 300) {
                        block.input[k] = `[compacted ${v.length} chars from earlier step: ${v.slice(0, 100)}...; artifact_ref: ${artifactRef}]`;
                    }
                }
            }
        }
    }
    return compacted;
}
export class ContextBudgetManager {
    journals = [];
    recordTurnBudget(report) {
        this.journals.push(report);
    }
    getJournals() {
        return [...this.journals];
    }
}
