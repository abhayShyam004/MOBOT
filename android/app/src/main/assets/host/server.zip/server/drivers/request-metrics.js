// What one provider request actually contains, in bytes.
//
// A turn's cost is the sum of what it re-sends. Without a measurement of the
// request itself, "the prompt is too big" stays a guess: a 190k-char request can
// be mostly tool schemas, mostly tool output, or mostly instructions, and each
// one has a different fix. This module measures the wire body the driver is
// about to POST — the same object it serialises — and reports each component
// separately, plus a fingerprint of the stable prefix (instructions + tool
// definitions) so a changing prefix can be seen instead of assumed.
//
// It reports sizes only: no prompt text, no tool arguments, no file contents.
import { createHash } from "node:crypto";
const utf8 = (text) => Buffer.byteLength(text, "utf8");
const asString = (value) => (typeof value === "string" ? value : "");
const RECOVERY_MARK = "[Recovery]";
function messageText(item) {
    if (!Array.isArray(item.content))
        return "";
    return item.content.map((part) => (part && typeof part === "object" && typeof part.text === "string"
        ? part.text
        : "")).join("");
}
export function measureRequest(input) {
    const itemCounts = {};
    const itemBytes = {};
    let encryptedReasoningBytes = 0;
    let toolOutputBytes = 0;
    let functionArgsBytes = 0;
    let recoveryItems = 0;
    let recoveryBytes = 0;
    for (const item of input.items) {
        const type = asString(item.type) || "unknown";
        const serialised = JSON.stringify(item) ?? "";
        itemCounts[type] = (itemCounts[type] ?? 0) + 1;
        itemBytes[type] = (itemBytes[type] ?? 0) + utf8(serialised);
        if (type === "reasoning")
            encryptedReasoningBytes += utf8(asString(item.encrypted_content));
        else if (type === "function_call_output")
            toolOutputBytes += utf8(asString(item.output));
        else if (type === "function_call")
            functionArgsBytes += utf8(asString(item.arguments));
        if (type === "message" && messageText(item).startsWith(RECOVERY_MARK)) {
            recoveryItems += 1;
            recoveryBytes += utf8(serialised);
        }
    }
    const toolJson = JSON.stringify(input.wireTools);
    const body = input.body ?? JSON.stringify({
        instructions: input.instructions,
        input: input.items,
        tools: input.wireTools,
    });
    return {
        bodyBytes: utf8(body),
        instructionsBytes: utf8(input.instructions),
        inputBytes: utf8(JSON.stringify(input.items)),
        toolsBytes: utf8(toolJson),
        toolCount: input.wireTools.length,
        itemCounts,
        itemBytes,
        encryptedReasoningBytes,
        toolOutputBytes,
        functionArgsBytes,
        recoveryItems,
        recoveryBytes,
        prefixHash: createHash("sha256").update(`${input.instructions}\u0000${toolJson}`).digest("hex").slice(0, 16),
        bodyHash: createHash("sha256").update(body).digest("hex").slice(0, 16),
    };
}
