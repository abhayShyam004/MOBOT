/**
 * High-Precision Conservative Outcome Intent Classifier
 *
 * Classifies user instructions into one of five categories:
 * - CONVERSATIONAL: greetings, small talk, jokes, polite acknowledgments
 * - INFORMATION_RETRIEVAL: definitions, conceptual explanations, search/lookups
 * - ARTIFACT_MUTATION_SINGLE: single-file edits, localized bug fixes, formatting
 * - OUTCOME_EXECUTION: multi-step autonomous task requiring planning, iterative execution, verification, and artifact delivery
 * - AMBIGUOUS_ACTION: unclear or under-specified intents
 *
 * Strict Invariant: Conservative policy. Zero false-positive tolerance for conversational banter or simple Q&A.
 */
const CONVERSATIONAL_PATTERNS = [
    /^(hi|hello|hey|howdy|sup|greetings|good\s+(morning|afternoon|evening|day|night))\b/i,
    /^(how\s+are\s+you|who\s+are\s+you|what\s+is\s+your\s+name|what\s+can\s+you\s+do|tell\s+me\s+about\s+yourself)\b/i,
    /^(thanks|thank\s+you|thx|cheers|much\s+appreciated|great\s+job|cool|awesome|nice|okay|ok|got\s+it)\b/i,
    /^(bye|goodbye|see\s+ya|farewell|have\s+a\s+good\s+day)\b/i,
    /^(tell\s+me\s+a\s+joke|make\s+me\s+laugh|are\s+you\s+an\s+ai|are\s+you\s+human)\b/i,
];
const INFO_RETRIEVAL_PATTERNS = [
    /^(what\s+is|what\s+are|what\s+does|how\s+does|how\s+do|why\s+is|why\s+are|who\s+is|who\s+was|when\s+did|where\s+is)\b/i,
    /^(can\s+you\s+explain|explain\s+to\s+me|explain\s+how|explain\s+what|describe\s+how|describe\s+what)\b/i,
    /^(tell\s+me\s+about|give\s+me\s+an\s+overview\s+of|summarize\s+the\s+concept\s+of)\b/i,
    /^(what('s|\s+is)\s+the\s+difference\s+between)\b/i,
    /^(list\s+the\s+(top|best|common)|compare\s+and\s+contrast)\b/i,
];
const SINGLE_MUTATION_PATTERNS = [
    /^(fix\s+the\s+typo|correct\s+the\s+spelling|rename\s+(variable|function)|change\s+the\s+(background\s+)?color|format\s+this\s+file)\b/i,
    /^(add\s+a\s+comment|remove\s+the\s+log|delete\s+line|update\s+line\s+\d+|in\s+line\s+\d+)\b/i,
    /^(format\s+(this|the)\s+(json|markdown|code|css|html)|correct\s+the\s+spelling)\b/i,
    /^(indent\s+this|lint\s+fix|simple\s+fix|one-line\s+fix)\b/i,
];
const OUTCOME_STRONG_VERBS = [
    /\b(create|build|develop)\s+and\s+(deploy|publish)\b/i,
    /\b(create|build|develop|implement)\s+.*?\s+and\s+(deploy|publish)\b/i,
    /\bresearch\b.*?\b(produce|generate|deliver)\b.*?\b(report|document|paper|dossier)\b/i,
    /\banalyze\s+.*?\s+and\s+(deliver|produce|export|build)\s+.*?\s*(model|workbook|spreadsheet|deck|presentation)\b/i,
    /\bexecute\s+.*?\s+and\s+verify\s+.*?\s+and\s+deliver\b/i,
    /\b(build|develop|implement)\s+(an?\s+)?end-to-end\b/i,
    /\bautomate\s+.*?\s+and\s+(deliver|provide)\s+(finished|completed|verified)\b/i,
    /\btake\s+(a|the|this)\s+pdf\b.*?\bnotebook\b.*?\bdeliver\b/i,
    /\b(pdf|questions)\b.*?\bcolab\b.*?\bnotebook\b/i,
    /\bdesign,\s*implement,\s*and\s*(test|run|verify)\b/i,
    /\b(design|build|implement)\s+.*?\s*(automated test suite|test suite|ci\/cd pipeline)\b/i,
];
const OUTCOME_INDICATOR_KEYWORDS = [
    "deploy", "deliver", "verify", "verification", "end-to-end",
    "pipeline", "notebook", "report", "workbook", "automated test suite",
    "full system", "production-ready", "complete outcome"
];
export function classifyOutcomeIntent(text) {
    const trimmed = (text || "").trim();
    if (!trimmed) {
        return {
            category: "CONVERSATIONAL",
            confidence: 1.0,
            reason: "Empty prompt classified as conversational",
        };
    }
    // 1. Strict conversational filter (Zero false positive rule)
    for (const pattern of CONVERSATIONAL_PATTERNS) {
        if (pattern.test(trimmed)) {
            // Unless it explicitly contains an outcome strong verb, conversational always wins
            const hasOutcomeVerb = OUTCOME_STRONG_VERBS.some((v) => v.test(trimmed));
            if (!hasOutcomeVerb) {
                return {
                    category: "CONVERSATIONAL",
                    confidence: 0.98,
                    reason: "Matches conversational/social pattern",
                };
            }
        }
    }
    // 2. Information Retrieval filter
    for (const pattern of INFO_RETRIEVAL_PATTERNS) {
        if (pattern.test(trimmed)) {
            const hasOutcomeVerb = OUTCOME_STRONG_VERBS.some((v) => v.test(trimmed));
            if (!hasOutcomeVerb) {
                return {
                    category: "INFORMATION_RETRIEVAL",
                    confidence: 0.95,
                    reason: "Matches informational query or conceptual explanation request",
                };
            }
        }
    }
    // 3. Single Artifact Mutation filter
    for (const pattern of SINGLE_MUTATION_PATTERNS) {
        if (pattern.test(trimmed)) {
            return {
                category: "ARTIFACT_MUTATION_SINGLE",
                confidence: 0.92,
                reason: "Matches localized single-file or single-step edit pattern",
            };
        }
    }
    // 4. Outcome Execution matching
    let outcomeScore = 0;
    let matchingPatternReason = "";
    for (const verb of OUTCOME_STRONG_VERBS) {
        if (verb.test(trimmed)) {
            outcomeScore += 0.70;
            matchingPatternReason = `Matched outcome execution verb pattern: ${verb.source}`;
            break;
        }
    }
    const lower = trimmed.toLowerCase();
    let keywordHits = 0;
    for (const kw of OUTCOME_INDICATOR_KEYWORDS) {
        if (lower.includes(kw)) {
            keywordHits++;
            outcomeScore += 0.12;
        }
    }
    // Check multi-phase structure (commas, 'then', 'and', numbered lists)
    if (/\b(then|after that|finally|subsequently|and then)\b/i.test(trimmed)) {
        outcomeScore += 0.15;
    }
    if (trimmed.length > 80 && keywordHits >= 2) {
        outcomeScore += 0.10;
    }
    // Bounded confidence
    const confidence = Math.min(0.99, Math.round(outcomeScore * 100) / 100);
    // Conservative threshold: only classify as OUTCOME_EXECUTION if confidence >= 0.70
    if (confidence >= 0.70) {
        const proposedMilestones = deriveProposedMilestones(trimmed);
        return {
            category: "OUTCOME_EXECUTION",
            confidence,
            reason: matchingPatternReason || `High-confidence outcome intent with ${keywordHits} outcome indicators`,
            formalObjective: trimmed,
            proposedMilestones,
            estimatedComplexity: keywordHits >= 3 || trimmed.length > 200 ? "high" : "medium",
        };
    }
    // If score is ambiguous
    if (confidence >= 0.35 && confidence < 0.70) {
        return {
            category: "AMBIGUOUS_ACTION",
            confidence: 0.60,
            reason: "Potential outcome intent but insufficient composite signals or clarity",
        };
    }
    // Default fallback is conversational or informational based on length/question mark
    if (trimmed.includes("?")) {
        return {
            category: "INFORMATION_RETRIEVAL",
            confidence: 0.75,
            reason: "Question without outcome delivery signals classified as informational",
        };
    }
    return {
        category: "CONVERSATIONAL",
        confidence: 0.70,
        reason: "General dialogue turn without actionable outcome or tool directives",
    };
}
function deriveProposedMilestones(prompt) {
    const lower = prompt.toLowerCase();
    if (lower.includes("deploy") && (lower.includes("website") || lower.includes("app"))) {
        return [
            "Analyze requirements and design site architecture",
            "Implement frontend interface and responsive layouts",
            "Run verification checks and build pipeline",
            "Deploy live site and verify health endpoint",
        ];
    }
    if (lower.includes("notebook") || (lower.includes("pdf") && lower.includes("colab"))) {
        return [
            "Extract and parse required questions",
            "Construct computational solution and notebook cells",
            "Execute notebook and verify execution outputs",
            "Export verified notebook link and final artifacts",
        ];
    }
    if (lower.includes("report") || lower.includes("research")) {
        return [
            "Gather research sources and synthesize findings",
            "Draft structured report sections with citations and figures",
            "Verify factual accuracy, formatting, and completeness",
            "Render and deliver final document",
        ];
    }
    if (lower.includes("model") || lower.includes("spreadsheet") || lower.includes("workbook")) {
        return [
            "Ingest and validate input dataset",
            "Construct analytical formulas and financial projections",
            "Verify mathematical consistency and edge-case calculations",
            "Deliver validated workbook and executive summary",
        ];
    }
    // Default 4-phase outcome progression
    return [
        `Analyze objective and establish baseline`,
        `Execute core implementation and asset generation`,
        `Perform independent verification against success criteria`,
        `Deliver verified outcome and release resources`,
    ];
}
