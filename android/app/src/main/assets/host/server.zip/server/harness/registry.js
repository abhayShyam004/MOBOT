// Provider instance registry — port of upstream's ProviderInstanceRegistryLive
// behavior, minus Effect: config map → live instances; unknown driver or
// config-decode failure becomes an UNAVAILABLE SHADOW SNAPSHOT instead of a
// startup failure (that behavior is what makes settings forward/backward
// compatible — do not remove it); dispose tears an instance down without
// touching its siblings.
import { findCliCandidates } from "../env-path.js";
import { installNpmEngine, npmAvailable, serverInstallFor } from "../engine-install.js";
/** The driver's install descriptor plus what this machine can do about it. */
function withServerInstall(install, npmPresent) {
    const server = install ? serverInstallFor(install, npmPresent) : null;
    return server ? { ...install, server } : install;
}
/** The `cli` field off a driver's default config, when it has one — the
 * placeholder an override input shows when nothing is set. */
function cliDefaultOf(driver) {
    if (!driver)
        return undefined;
    try {
        const cfg = driver.defaultConfig();
        return typeof cfg?.cli === "string" ? cfg.cli : undefined;
    }
    catch {
        return undefined;
    }
}
/** Raw `config.cli` straight from disk — shadow snapshots can't decode, so
 * this is the only faithful way to echo back what was configured. */
function cliOfRaw(raw) {
    const cli = raw?.cli;
    return typeof cli === "string" && cli ? cli : undefined;
}
export class ProviderRegistry {
    byId = new Map();
    /** decoded per-instance `cli` overrides, for describe() — drivers spawn
     * from their own config; this map only reports what was configured */
    cliByInstance = new Map();
    driversByKind;
    /** Where Settings-driven npm installs go; the data directory by default. */
    enginesBaseDir;
    /** Whether npm is on this machine; injectable because the PATH scan also
     * looks in standard install locations, which tests cannot empty. */
    npmPresent;
    constructor(drivers, options = {}) {
        this.enginesBaseDir = options.enginesBaseDir;
        this.npmPresent = options.npmAvailable ?? npmAvailable;
        this.driversByKind = new Map(drivers.map((d) => [d.driverKind, d]));
    }
    async load(configs, decorate) {
        for (const [instanceId, entry] of Object.entries(configs)) {
            // Account edits replace only their own process/session state.
            await this.dispose(instanceId);
            const driver = this.driversByKind.get(entry.driver);
            if (!driver) {
                this.byId.set(instanceId, {
                    instanceId,
                    shadow: {
                        instanceId,
                        driverKind: entry.driver,
                        displayName: entry.displayName,
                        cli: cliOfRaw(entry.config),
                        shadow: true,
                        reason: `unknown driver "${entry.driver}" — kept as configured, unavailable here`,
                    },
                });
                continue;
            }
            try {
                const config = entry.config === undefined ? driver.defaultConfig() : driver.decodeConfig(entry.config);
                // Override detection is on the RAW config, never the decoded one:
                // decodeConfig fills in the driver default ("claude", "codex", …),
                // so reading `cli` there would flag every instance as overridden.
                const rawCli = cliOfRaw(entry.config);
                if (rawCli)
                    this.cliByInstance.set(instanceId, rawCli);
                const live = await driver.create({
                    instanceId,
                    displayName: entry.displayName ?? driver.metadata.displayName,
                    environment: entry.environment ?? {},
                    enabled: entry.enabled ?? true,
                    config,
                });
                this.byId.set(instanceId, { instanceId, live: decorate ? decorate(live) : live });
            }
            catch (e) {
                this.byId.set(instanceId, {
                    instanceId,
                    shadow: {
                        instanceId,
                        driverKind: entry.driver,
                        displayName: entry.displayName ?? driver.metadata.displayName,
                        cli: cliOfRaw(entry.config),
                        shadow: true,
                        reason: e instanceof Error ? e.message : String(e),
                    },
                });
            }
        }
    }
    get(instanceId) {
        return this.byId.get(instanceId)?.live ?? null;
    }
    /** The configured executable for instance-scoped maintenance actions.
     * This deliberately comes from the registry/config, never an HTTP body. */
    cliTarget(instanceId) {
        const entry = this.byId.get(instanceId);
        if (!entry)
            return null;
        const driverKind = entry.shadow?.driverKind ?? entry.live.driverKind;
        const driver = this.driversByKind.get(driverKind);
        return {
            driverKind,
            cli: this.cliByInstance.get(instanceId) ?? entry.shadow?.cli ?? cliDefaultOf(driver) ?? null,
        };
    }
    entries() {
        return [...this.byId.values()];
    }
    instances() {
        return [...this.byId.values()].flatMap((e) => (e.live ? [e.live] : []));
    }
    async refreshModels(instanceId) {
        const instance = this.get(instanceId);
        if (!instance)
            return false;
        await instance.refreshModels?.();
        return true;
    }
    /** A driver's own installer (a managed download) first; otherwise the
     * app's npm prefix, when the driver's install one-liner is an npm package
     * and npm is on PATH. False means Settings has nothing to offer here. */
    async installRuntime(instanceId) {
        const entry = this.byId.get(instanceId);
        if (!entry)
            return false;
        if (entry.live?.installRuntime) {
            await entry.live.installRuntime();
            return true;
        }
        const driver = this.driversByKind.get(entry.shadow?.driverKind ?? entry.live.driverKind);
        const server = serverInstallFor(driver?.install, this.npmPresent());
        if (!server)
            return false;
        await installNpmEngine(server.package, { baseDir: this.enginesBaseDir, cli: cliDefaultOf(driver) });
        return true;
    }
    async startAuthentication(instanceId) {
        const instance = this.get(instanceId);
        return instance?.startAuthentication ? instance.startAuthentication() : null;
    }
    async getAuthentication(instanceId, flowId) {
        const instance = this.get(instanceId);
        return instance?.getAuthentication ? instance.getAuthentication(flowId) : null;
    }
    async completeAuthentication(instanceId, flowId, callbackUrl) {
        const instance = this.get(instanceId);
        if (!instance?.completeAuthentication)
            return false;
        await instance.completeAuthentication(flowId, callbackUrl);
        return true;
    }
    async cancelAuthentication(instanceId) {
        const instance = this.get(instanceId);
        if (!instance?.cancelAuthentication)
            return false;
        await instance.cancelAuthentication();
        return true;
    }
    /** instance snapshots for the model picker: id, driver, models, health */
    async describe() {
        // Multiple instances may share a driver. Scan each default binary once
        // per response instead of repeating filesystem work for every row.
        const candidatesByName = new Map();
        const candidatesFor = (driver) => {
            const name = cliDefaultOf(driver);
            if (!name)
                return [];
            const cached = candidatesByName.get(name);
            if (cached)
                return cached;
            const found = findCliCandidates(name);
            candidatesByName.set(name, found);
            return found;
        };
        const npmPresent = this.npmPresent();
        return Promise.all(this.entries().map(async (entry) => {
            const driver = this.driversByKind.get(entry.shadow?.driverKind ?? entry.live.driverKind);
            if (entry.shadow) {
                return {
                    instanceId: entry.instanceId,
                    driverKind: entry.shadow.driverKind,
                    displayName: entry.shadow.displayName ?? entry.shadow.driverKind,
                    snapshot: { state: "unavailable", reason: entry.shadow.reason },
                    models: { default: "", options: [] },
                    capabilities: { computerMcp: false, agentsMcp: false, localComputerMcp: false },
                    // an unknown driver has no driver record, hence no install path
                    access: driver?.metadata.access ?? "subscription",
                    install: withServerInstall(driver?.install, npmPresent),
                    cli: entry.shadow.cli,
                    cliDefault: cliDefaultOf(driver),
                    // a shadow is exactly the "your CLI is broken, pick another"
                    // case where the detected-path dropdown matters most
                    cliCandidates: candidatesFor(driver),
                };
            }
            const inst = entry.live;
            let snapshot;
            try {
                snapshot = await inst.snapshot();
            }
            catch (e) {
                snapshot = { state: "unavailable", reason: e instanceof Error ? e.message : String(e) };
            }
            // Authentication capability is a fact of its own, next to — never
            // inside — the runtime snapshot: the Codex device-code sign-in runs
            // natively on a host with no Codex runtime, while Claude's flow signs
            // in the CLI and exists exactly while that runtime does.
            let auth = { available: true };
            if (inst.authCapability) {
                try {
                    auth = await inst.authCapability();
                }
                catch (e) {
                    auth = { available: false, reason: e instanceof Error ? e.message : String(e) };
                }
            }
            return {
                instanceId: inst.instanceId,
                driverKind: inst.driverKind,
                displayName: inst.displayName ?? inst.driverKind,
                snapshot,
                models: inst.models,
                capabilities: {
                    computerMcp: inst.adapter.capabilities.computerMcp === true,
                    agentsMcp: inst.adapter.capabilities.agentsMcp === true,
                    composioMcp: inst.adapter.capabilities.composioMcp === true,
                    phoneMcp: inst.adapter.capabilities.phoneMcp === true,
                    browserMcp: inst.adapter.capabilities.browserMcp === true,
                    images: inst.adapter.capabilities.images === true,
                    effortLevels: inst.adapter.capabilities.effortLevels,
                    modelVariants: inst.adapter.capabilities.modelVariants === true,
                    queueing: inst.adapter.capabilities.queueing === true,
                    localComputerMcp: inst.adapter.capabilities.localComputerMcp === true,
                    approvalReview: inst.reviewPermission !== undefined,
                },
                access: driver?.metadata.access ?? "subscription",
                install: withServerInstall(driver?.install, npmPresent),
                authentication: inst.startAuthentication
                    ? {
                        method: authMethod(inst),
                        // the browser may remove the stored sign-in to switch accounts
                        signOut: inst.signOut !== undefined,
                        // Can the sign-in run on this host even without the runtime?
                        available: auth.available,
                        ...(auth.reason ? { reason: auth.reason } : {}),
                    }
                    : undefined,
                cli: this.cliByInstance.get(inst.instanceId),
                cliDefault: cliDefaultOf(driver),
                // every copy of the driver's default binary on the augmented PATH —
                // the dropdown's "detected" entries. Snapshotted per describe() so a
                // newly installed CLI shows up on the next refresh.
                cliCandidates: candidatesFor(driver),
            };
        }));
    }
    async disposeAll() {
        await Promise.allSettled(this.instances().map((i) => i.dispose()));
        this.byId.clear();
        this.cliByInstance.clear();
    }
    async dispose(instanceId) {
        const entry = this.byId.get(instanceId);
        this.byId.delete(instanceId);
        this.cliByInstance.delete(instanceId);
        await entry?.live?.dispose();
    }
}
/** How an instance's account sign-in completes. A driver that knows its own
 * shape declares it (`authMethod`); the historical inference — which is a
 * fact about how the driver wires its SPI, not what the person experiences —
 * still covers drivers that have not opted in. */
function authMethod(inst) {
    const declared = inst.authMethod?.();
    if (declared)
        return declared;
    return inst.getAuthentication && inst.completeAuthentication
        ? "paste-code" // a link to open, then a code pasted back (Claude)
        : inst.getAuthentication
            ? "device-code" // a code to enter at the provider's page
            : "browser"; // a link and a callback URL (managed engines)
}
