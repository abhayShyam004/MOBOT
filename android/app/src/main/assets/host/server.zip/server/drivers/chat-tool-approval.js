// Per-turn permission gate, adapted from the approval lifecycle in #780.
// Register before publishing: a harness listener may answer synchronously.
import { newId } from "../contracts.js";
export function createChatToolApproval(options) {
    const pending = new Map();
    let closed = false;
    return {
        ask(tool, summary) {
            if (closed || options.signal.aborted)
                return Promise.resolve(false);
            const ask = { id: newId(), tool, summary };
            return new Promise((resolve) => {
                const finish = (outcome, source) => {
                    if (!pending.delete(ask.id))
                        return;
                    clearTimeout(timer);
                    options.signal.removeEventListener("abort", abort);
                    options.resolved(ask, outcome.allowed, source);
                    resolve(outcome.allowed);
                };
                const abort = () => finish({ allowed: false }, "system");
                const timer = setTimeout(() => finish({ allowed: false }, "timeout"), options.timeoutMs ?? 15 * 60_000);
                timer.unref?.();
                pending.set(ask.id, finish);
                options.signal.addEventListener("abort", abort, { once: true });
                options.open(ask);
            });
        },
        /**
         * A model's own question (ask_user): resolves with the person's words
         * instead of an allow/deny, and those words become the tool result. There
         * is deliberately no timeout — the turn is allowed to wait on a human for
         * as long as the card is open; only closing the turn (interrupt, session
         * end) resolves it unanswered.
         */
        askQuestion(tool, summary, spec) {
            if (closed || options.signal.aborted)
                return Promise.resolve(null);
            const ask = { id: newId(), tool, summary, ...spec };
            return new Promise((resolve) => {
                // Same outcome shape every finisher in the map takes: the answer, if
                // any, rides in `answer` and is the tool result the model receives.
                const finish = (outcome, source) => {
                    if (!pending.delete(ask.id))
                        return;
                    options.signal.removeEventListener("abort", abort);
                    const answer = typeof outcome.answer === "string" && outcome.answer.trim() ? outcome.answer : null;
                    if (answer === null)
                        options.resolved(ask, false, source);
                    else
                        options.resolvedQuestions?.(ask, answer, source);
                    resolve(answer);
                };
                const abort = () => finish({ allowed: false }, "system");
                options.signal.addEventListener("abort", abort, { once: true });
                pending.set(ask.id, finish);
                if (options.openQuestions)
                    options.openQuestions(ask);
                else
                    options.open(ask);
            });
        },
        answer(id, behavior, message) {
            const finish = pending.get(id);
            if (!finish || options.signal.aborted)
                return "unavailable";
            if (behavior === "answer") {
                // A text answer only fits a question ask; a permission ask has no
                // question to answer, so nothing here consumes it.
                if (typeof message !== "string" || !message.trim())
                    return "unavailable";
                finish({ allowed: false, answer: message }, "user");
                return "answered";
            }
            finish({ allowed: behavior === "allow" }, "user");
            return behavior === "allow" ? "allowed-once" : "rejected";
        },
        close() {
            closed = true;
            for (const finish of pending.values())
                finish({ allowed: false }, "system");
        },
    };
}
