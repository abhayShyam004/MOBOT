import { join, dirname } from "node:path";
import { writeFileSync, readFileSync, existsSync, openSync, fsyncSync, closeSync, renameSync } from "node:fs";
import { PersistentJobManager } from "../tasks.js";
import { OperationJournal } from "../operation-journal.js";
import { executeFencedOutcomeMutation } from "./outcome-mutation-coordinator.js";
function readProviderStore(filePath) {
    if (!existsSync(filePath)) {
        return { mutationCount: 0, operations: {} };
    }
    return JSON.parse(readFileSync(filePath, "utf8"));
}
function writeProviderStore(filePath, state) {
    const tmp = `${filePath}.tmp.${Date.now()}.${Math.random().toString(36).slice(2, 6)}`;
    const fd = openSync(tmp, "w", 0o600);
    writeFileSync(fd, JSON.stringify(state, null, 2) + "\n");
    fsyncSync(fd);
    closeSync(fd);
    renameSync(tmp, filePath);
    try {
        const dirFd = openSync(dirname(filePath), "r");
        fsyncSync(dirFd);
        closeSync(dirFd);
    }
    catch { }
}
async function main() {
    const args = process.argv.slice(2);
    const dataDir = args[0];
    const jobId = args[1];
    const workerId = args[2];
    const mode = args[3];
    if (!dataDir || !jobId || !workerId || !mode) {
        console.error("Usage: sigkill-worker-runner <dataDir> <jobId> <workerId> <mode>");
        process.exit(1);
    }
    const jobsFile = join(dataDir, "jobs.json");
    const journalFile = join(dataDir, "job-journal.jsonl");
    const checkpointsDir = join(dataDir, "checkpoints");
    const jobManager = new PersistentJobManager({
        file: jobsFile,
        journalFile,
        checkpointsDir,
    });
    if (mode === "execute-until-milestone-1") {
        // Worker claims job with short lease for test takeover
        const claim = jobManager.claimJob(jobId, workerId, 800);
        // Advance milestone 0
        await jobManager.advanceMilestone({
            jobId,
            milestoneIndex: 0,
            milestoneTitle: "Intake & Setup",
            progressPercent: 25,
            workerId,
            fencingGeneration: claim.fencingGeneration,
        });
        // Advance milestone 1
        await jobManager.advanceMilestone({
            jobId,
            milestoneIndex: 1,
            milestoneTitle: "Data Processing",
            progressPercent: 50,
            data: { processedRows: 500 },
            workerId,
            fencingGeneration: claim.fencingGeneration,
        });
        // Write checkpoint 1 payload with checksum
        jobManager.writeCheckpointPayloadFenced({
            jobId,
            milestoneIndex: 1,
            workerId,
            fencingGeneration: claim.fencingGeneration ?? 1,
            payload: {
                jobId,
                botId: "bot_sigkill",
                milestoneIndex: 1,
                milestoneTitle: "Data Processing Snapshot",
                progressPercent: 50,
                state: "RUNNING",
                timestampMs: Date.now(),
                checksum: "",
                data: { checkpointStage: 1, processedRows: 500 },
            },
        });
        // Notify test harness that milestone 1 is committed and child is ready for SIGKILL
        const readyFile = join(dataDir, "milestone1.ready");
        writeFileSync(readyFile, `READY_FOR_SIGKILL:${process.pid}\n`, "utf8");
        // Sleep indefinitely awaiting SIGKILL
        setInterval(() => { }, 1000);
    }
    else if (mode === "resume-to-completion") {
        // Resume execution
        const jobBefore = jobManager.getJob(jobId);
        if (!jobBefore) {
            console.error(`Job ${jobId} not found`);
            process.exit(2);
        }
        // Verify recovery discovered milestone 1
        if (jobBefore.currentMilestoneIndex !== 1) {
            console.error(`Expected currentMilestoneIndex 1, found ${jobBefore.currentMilestoneIndex}`);
            process.exit(3);
        }
        // Worker B claims job (takeover)
        const claimB = jobManager.claimJob(jobId, workerId, 30_000);
        // Advance milestone 2
        await jobManager.advanceMilestone({
            jobId,
            milestoneIndex: 2,
            milestoneTitle: "Model Synthesis",
            progressPercent: 75,
            workerId,
            fencingGeneration: claimB.fencingGeneration,
        });
        // Advance milestone 3
        await jobManager.advanceMilestone({
            jobId,
            milestoneIndex: 3,
            milestoneTitle: "Final Verification",
            progressPercent: 90,
            workerId,
            fencingGeneration: claimB.fencingGeneration,
        });
        // Complete job
        jobManager.completeJob(jobId, { success: true, verifiedRows: 500 }, workerId, claimB.fencingGeneration);
        const completionFile = join(dataDir, "completion.ready");
        writeFileSync(completionFile, `COMPLETED:${jobId}\n`, "utf8");
        process.exit(0);
    }
    else if (mode === "mutation-dispatch-and-hold") {
        const providerFile = join(dataDir, "mock-provider-store.json");
        const journalFileOp = join(dataDir, "operation-journal.json");
        const idempotencyKey = args[4] || "doc-export-key-01";
        const claim = jobManager.claimJob(jobId, workerId, 1000);
        const tokenA = {
            jobId,
            workerId,
            fencingGeneration: claim.fencingGeneration ?? 1,
        };
        const operationJournal = new OperationJournal({
            filePath: journalFileOp,
            leaseValidator: (token) => jobManager.assertWorkerLeaseActive(token),
            outcomeJobChecker: (jId) => jobManager.isOutcomeJob(jId),
        });
        // Worker A creates operation with fencing token
        const { entry } = operationJournal.findOrCreateOperation({
            actionType: "cloud.document.export",
            idempotencyKey,
            payload: { docId: "doc_101", title: "Quarterly Audit Report" },
            jobId,
            fencingToken: tokenA,
        });
        // Worker A persists DISPATCHED, including fsync
        operationJournal.markDispatched(entry.operationId, undefined, tokenA);
        // Mock external provider executes and records independently durable state
        const providerState = readProviderStore(providerFile);
        providerState.mutationCount += 1;
        providerState.operations[idempotencyKey] = {
            providerId: "prov_tx_777",
            status: "applied",
            data: { exportedUrl: "https://cloud.storage/report.pdf", bytes: 2048 },
        };
        writeProviderStore(providerFile, providerState);
        // Notify test harness that Worker A is dispatched and awaiting SIGKILL
        const readyFile = join(dataDir, "workerA_dispatched.ready");
        writeFileSync(readyFile, `READY_FOR_SIGKILL:${process.pid}:${entry.operationId}\n`, "utf8");
        // Sleep indefinitely awaiting SIGKILL without committing local receipt
        setInterval(() => { }, 1000);
    }
    else if (mode === "mutation-reconcile-and-commit") {
        const providerFile = join(dataDir, "mock-provider-store.json");
        const journalFileOp = join(dataDir, "operation-journal.json");
        const idempotencyKey = args[4] || "doc-export-key-01";
        const providerUnavailable = args[5] === "simulate-unavailable";
        const claimB = jobManager.claimJob(jobId, workerId, 1000);
        const tokenB = {
            jobId,
            workerId,
            fencingGeneration: claimB.fencingGeneration ?? 1,
        };
        const operationJournal = new OperationJournal({
            filePath: journalFileOp,
            leaseValidator: (token) => jobManager.assertWorkerLeaseActive(token),
            outcomeJobChecker: (jId) => jobManager.isOutcomeJob(jId),
        });
        let duplicateDispatchAttempted = false;
        const dispatchFn = async () => {
            duplicateDispatchAttempted = true;
            const state = readProviderStore(providerFile);
            state.mutationCount += 1;
            writeProviderStore(providerFile, state);
            return { duplicate: true };
        };
        const reconcileFn = async (entry) => {
            if (providerUnavailable) {
                return {
                    success: false,
                    error: { code: "UNAVAILABLE", message: "Mock provider temporarily offline" },
                };
            }
            const state = readProviderStore(providerFile);
            const rec = state.operations[entry.idempotencyKey];
            if (rec) {
                return {
                    success: true,
                    providerId: rec.providerId,
                    data: rec.data,
                };
            }
            return {
                success: false,
                error: { code: "NOT_FOUND", message: "Operation not found in provider store" },
            };
        };
        const mutationResult = await executeFencedOutcomeMutation({
            operationJournal,
            jobManager,
            fencingToken: tokenB,
            actionType: "cloud.document.export",
            idempotencyKey,
            payload: { docId: "doc_101", title: "Quarterly Audit Report" },
            dispatchFn,
            reconcileFn,
        });
        if (duplicateDispatchAttempted) {
            console.error("FATAL: Duplicate dispatch was attempted during reconciliation!");
            process.exit(10);
        }
        if (providerUnavailable) {
            // In unavailable mode, verify it refused to re-dispatch and returned uncertain_unknown
            if (mutationResult.status !== "uncertain_unknown") {
                console.error(`Expected uncertain_unknown, got ${mutationResult.status}`);
                process.exit(11);
            }
            writeFileSync(join(dataDir, "workerB_unavailable.ready"), "UNAVAILABLE_VERIFIED\n", "utf8");
            process.exit(0);
        }
        if (mutationResult.status !== "reconciled" || mutationResult.entry.status !== "completed") {
            console.error("Failed to reconcile existing operation:", mutationResult);
            process.exit(12);
        }
        // Worker B leaves job RUNNING so Worker C can test repeated restart under separate process claim
        writeFileSync(join(dataDir, "workerB_reconciled.ready"), `RECONCILED:${jobId}\n`, "utf8");
        process.exit(0);
    }
    else if (mode === "mutation-repeat-restart") {
        const providerFile = join(dataDir, "mock-provider-store.json");
        const journalFileOp = join(dataDir, "operation-journal.json");
        const idempotencyKey = args[4] || "doc-export-key-01";
        const claimC = jobManager.claimJob(jobId, workerId, 15_000);
        const tokenC = {
            jobId,
            workerId,
            fencingGeneration: claimC.fencingGeneration ?? 1,
        };
        const operationJournal = new OperationJournal({
            filePath: journalFileOp,
            leaseValidator: (token) => jobManager.assertWorkerLeaseActive(token),
            outcomeJobChecker: (jId) => jobManager.isOutcomeJob(jId),
        });
        let duplicateDispatchAttempted = false;
        const dispatchFn = async () => {
            duplicateDispatchAttempted = true;
            const state = readProviderStore(providerFile);
            state.mutationCount += 1;
            writeProviderStore(providerFile, state);
            return { duplicate: true };
        };
        const reconcileFn = async (_entry) => {
            return { success: false, error: { code: "NOT_CALLED", message: "Should not be called for completed entry" } };
        };
        // Query operation
        const entry = operationJournal.getOperationByIdempotencyKey(idempotencyKey);
        if (!entry || entry.status !== "completed") {
            console.error("Expected entry to be in completed status, got:", entry?.status);
            process.exit(20);
        }
        // Attempting to execute should immediately return committed without provider interaction
        const mutationResult = await executeFencedOutcomeMutation({
            operationJournal,
            jobManager,
            fencingToken: tokenC,
            actionType: "cloud.document.export",
            idempotencyKey,
            payload: { docId: "doc_101", title: "Quarterly Audit Report" },
            dispatchFn,
            reconcileFn,
        });
        if (duplicateDispatchAttempted) {
            console.error("FATAL: Repeated restart caused duplicate dispatch!");
            process.exit(21);
        }
        if (mutationResult.status !== "committed") {
            console.error(`Expected committed, got ${mutationResult.status}`);
            process.exit(22);
        }
        // Worker C advances milestone and completes job
        await jobManager.advanceMilestone({
            jobId,
            milestoneIndex: 1,
            milestoneTitle: "Document Exported",
            progressPercent: 100,
            workerId,
            fencingGeneration: claimC.fencingGeneration,
            data: { exported: true, result: mutationResult.result },
        });
        jobManager.completeJob(jobId, { exportComplete: true, result: mutationResult.result }, workerId, claimC.fencingGeneration);
        writeFileSync(join(dataDir, "workerC_repeated.ready"), "REPEATED_RESTART_VERIFIED\n", "utf8");
        process.exit(0);
        writeFileSync(join(dataDir, "workerC_repeated.ready"), "REPEATED_RESTART_VERIFIED\n", "utf8");
        process.exit(0);
    }
    else {
        console.error(`Unknown mode ${mode}`);
        process.exit(4);
    }
}
main().catch((err) => {
    console.error("Worker runner failed", err);
    process.exit(1);
});
