// Grok Build harness support — the official `grok` CLI over ACP stdio
// (`grok … agent stdio`), on the grok.com subscription login
// (~/.grok/auth.json), NOT the xAI API key (that driver is drivers/grok.ts).
// The generic protocol runtime lives in acp/core.ts; this file is only the
// per-harness quirks. Verified against grok 1.0.0.
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { decodeInjectId, hostApiKey, localHost, mergeLocalInject } from "../local-inject.js";
import { createAcpDriver } from "./core.js";
export const STATIC_GROK_MODELS = {
    default: "grok-4.6",
    options: [
        { id: "grok-4.6", label: "Grok 4.6" },
        { id: "grok-4.5", label: "Grok 4.5" },
    ],
};
const SLUG = /^[a-z0-9][a-z0-9._-]*$/i;
function grokHome(env) {
    if (env.GROK_HOME)
        return env.GROK_HOME;
    return join(env.HOME || env.USERPROFILE || homedir(), ".grok");
}
function unquote(raw) {
    const value = raw.trim();
    if (value.length >= 2 && value.startsWith('"') && value.endsWith('"')) {
        return value.slice(1, -1).replace(/\\"/g, '"');
    }
    return value;
}
/** Local slugs from ~/.grok/config.toml, plus the two cloud defaults.
 *  `grok -m <slug>` already accepts these; the picker just didn't list them. */
export function readGrokModelCatalog(env = process.env) {
    const path = join(grokHome(env), "config.toml");
    let text = "";
    try {
        text = readFileSync(path, "utf8");
    }
    catch {
        return STATIC_GROK_MODELS;
    }
    const options = STATIC_GROK_MODELS.options.map((o) => ({ ...o }));
    const seen = new Set(options.map((o) => o.id));
    let configuredDefault = null;
    let current = null;
    let inModels = false;
    const flush = () => {
        if (!current || !SLUG.test(current.slug) || seen.has(current.slug)) {
            current = null;
            return;
        }
        seen.add(current.slug);
        options.push({ id: current.slug, label: current.name || current.slug, custom: true });
        current = null;
    };
    for (const line of text.split(/\r?\n/)) {
        const stripped = line.trim();
        if (stripped === "[models]") {
            flush();
            inModels = true;
            continue;
        }
        if (stripped.startsWith("[model.") && stripped.endsWith("]")) {
            flush();
            inModels = false;
            let inner = stripped.slice("[model.".length, -1);
            if (inner.startsWith('"') && inner.endsWith('"'))
                inner = inner.slice(1, -1);
            current = { slug: inner };
            continue;
        }
        if (stripped.startsWith("[")) {
            flush();
            inModels = false;
            continue;
        }
        if (!stripped || stripped.startsWith("#") || !stripped.includes("="))
            continue;
        const eq = stripped.indexOf("=");
        const key = stripped.slice(0, eq).trim();
        const value = unquote(stripped.slice(eq + 1));
        if (current && key === "name" && value)
            current.name = value;
        if (!current && inModels && key === "default")
            configuredDefault = value;
    }
    flush();
    return {
        default: configuredDefault && seen.has(configuredDefault) ? configuredDefault : STATIC_GROK_MODELS.default,
        options,
    };
}
function suggestGrokSlug(host, model, taken) {
    let base = `${host}-${model}`.toLowerCase().replace(/[^a-z0-9._-]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
    if (!base || !/^[a-z]/.test(base))
        base = `m-${base || "model"}`;
    let slug = base;
    let n = 2;
    while (taken.has(slug)) {
        slug = `${base}-${n}`;
        n += 1;
    }
    return slug;
}
function quoteToml(value) {
    return `"${value.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
}
/** Write a [model.slug] block so `grok -m` can reach the injected host. */
export function ensureGrokInjectSlug(modelId, env = process.env) {
    const inject = decodeInjectId(modelId);
    if (!inject)
        return modelId;
    const host = localHost(inject.host);
    if (!host)
        return modelId;
    const path = join(grokHome(env), "config.toml");
    let text = "";
    try {
        text = readFileSync(path, "utf8");
    }
    catch {
        text = "";
    }
    const taken = new Set(STATIC_GROK_MODELS.options.map((option) => option.id));
    let current = null;
    const flush = () => {
        if (!current)
            return;
        taken.add(current.slug);
        if (current.model === inject.model && current.baseUrl === host.baseUrl) {
            found = current.slug;
        }
        current = null;
    };
    let found = null;
    for (const line of text.split(/\r?\n/)) {
        const stripped = line.trim();
        if (stripped.startsWith("[model.") && stripped.endsWith("]")) {
            flush();
            let inner = stripped.slice("[model.".length, -1);
            if (inner.startsWith('"') && inner.endsWith('"'))
                inner = inner.slice(1, -1);
            current = { slug: inner };
            continue;
        }
        if (stripped.startsWith("[")) {
            flush();
            continue;
        }
        if (!current || !stripped.includes("="))
            continue;
        const eq = stripped.indexOf("=");
        const key = stripped.slice(0, eq).trim();
        const value = unquote(stripped.slice(eq + 1));
        if (key === "model")
            current.model = value;
        if (key === "base_url")
            current.baseUrl = value;
    }
    flush();
    if (found)
        return found;
    const slug = suggestGrokSlug(inject.host, inject.model, taken);
    const heading = /[^a-z0-9_-]/i.test(slug) ? `[model."${slug}"]` : `[model.${slug}]`;
    const block = [
        heading,
        `model = ${quoteToml(inject.model)}`,
        `base_url = ${quoteToml(host.baseUrl)}`,
        `name = ${quoteToml(`${inject.model} (${host.label})`)}`,
        `api_backend = "chat_completions"`,
        `api_key = ${quoteToml(hostApiKey(host, env))}`,
        "",
    ].join("\n");
    const next = text && !text.endsWith("\n") ? `${text}\n\n${block}` : `${text}${text ? "\n" : ""}${block}`;
    writeFileSync(path, next);
    return slug;
}
/** Grok 1.0.25 consumes native image blocks but advertises image:false.
 * Verified with the real CLI and a loopback model: scripts/verify-grok-images.ts.
 * Keep unknown/older runtimes on the normal capability negotiation path. */
export function grokAcceptsUnadvertisedImages(init) {
    const meta = init?._meta;
    if (meta?.grokShell !== true || typeof meta.agentVersion !== "string")
        return false;
    const version = /^1\.0\.(\d+)$/.exec(meta.agentVersion);
    return Boolean(version && Number(version[1]) >= 25);
}
const support = {
    driverKind: "grokAgent",
    displayName: "Grok",
    images: true,
    acceptsUnadvertisedImages: grokAcceptsUnadvertisedImages,
    models: STATIC_GROK_MODELS,
    resolveModels: (env) => mergeLocalInject(readGrokModelCatalog(env), env),
    // Grok's accepted levels vary by model and the CLI validates lazily — a
    // rejected level only logs and falls back. Offer the intersection shared
    // by every model in this driver's picker; notably, grok-4.5 rejects xhigh.
    effortLevels: ["low", "medium", "high"],
    defaultCli: "grok",
    nativeSource: "grok.acp",
    loginNote: "Grok CLI is not signed in — run `grok login` in a terminal",
    // No Windows one-liner: the installer is a POSIX shell script, and offering
    // `curl … | bash` there would be advice that cannot run. Windows falls back
    // to docsUrl, which is honest rather than broken.
    install: {
        command: {
            darwin: "curl -fsSL https://x.ai/cli/install.sh | bash",
            linux: "curl -fsSL https://x.ai/cli/install.sh | bash",
        },
        docsUrl: "https://x.ai/cli",
        signInCommand: "grok login",
    },
    // Write the [model.slug] block with the instance HOME/GROK_HOME, then pass
    // the slug on argv. spawnArgs must not call ensureGrokInjectSlug itself —
    // that helper defaults to process.env and would miss the instance override.
    resolveTurnModel: (model, env) => (model ? ensureGrokInjectSlug(model, env) : model),
    // --permission-mode is a global grok flag. -m and --reasoning-effort are
    // agent flags: Grok 1.0.6 only applies them when they sit AFTER `agent`
    // and BEFORE `stdio` (`grok agent -m slug stdio`). Putting -m first is
    // accepted as a TUI option and then ignored, so ACP session/new keeps
    // [models].default (grok-4.6) and oMLX never sees a request.
    // Auto selects Grok's native classifier; if its feature gate is disabled,
    // residual requests still ask. Never replace it with bypassPermissions.
    // Verified: grok 1.0.3 --help and xai-org/grok-build@37949780,
    // crates/codegen/xai-grok-pager-bin/src/main.rs:1259-1273.
    spawnArgs: (config, turn) => [
        "--permission-mode",
        config.fullAuto
            ? "bypassPermissions"
            : turn.approvalMode === "auto" ? "auto" : turn.approvalMode === "edits" ? "acceptEdits" : "default",
        "agent",
        ...(turn.model ? ["-m", turn.model] : []),
        // long form on purpose: `--effort` is documented as an alias, and an
        // alias is the part a CLI is free to rename
        ...(turn.effort ? ["--reasoning-effort", turn.effort] : []),
        "stdio",
    ],
    // -m on argv is necessary but not sufficient: session/new still starts on
    // [models].default. Pin the slug over the wire, same as Hermes/Droid.
    async configureSession({ request, sessionId, turn }) {
        if (!turn.model)
            return;
        try {
            await request("session/set_model", { sessionId, modelId: turn.model });
        }
        catch (e) {
            throw new Error(`Grok rejected model "${turn.model}" via session/set_model: ${e.message}. ` +
                `Check that grok is current (1.0.6+ supports it) and that this slug exists in ~/.grok/config.toml.`);
        }
    },
    // The CLI owns its own grok.com login; a leaked API key silently flips
    // billing from the subscription to pay-as-you-go.
    transformEnv: (env) => {
        delete env.XAI_API_KEY;
    },
    // Bind the grok.com subscription login. No API-key fallback by design —
    // an unauthenticated CLI is a user action, not something to paper over.
    pickAuthMethod: (methods) => (methods.some((m) => m.id === "cached_token") ? "cached_token" : null),
    authFailure: "fail",
    isAuthenticated: () => existsSync(join(homedir(), ".grok", "auth.json")),
    // `--append-system-prompt`/`--rules` are accepted by the CLI but do NOT
    // reach the agent-stdio system prompt (verified against 1.0.0), so the
    // persona is prepended codex-style.
    buildPromptText: (turn) => (turn.system ? `${turn.system}\n\n${turn.text}` : turn.text),
};
export const GrokAgentDriver = createAcpDriver(support);
