import { existsSync, mkdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { writeFileAtomic } from "./atomic.js";
import { createHash, randomUUID } from "node:crypto";
import { DATA_DIR } from "./config.js";
import { StaleWorkerFenceError, sharedPersistentJobManager, isOutcomeJob } from "./tasks.js";
/** Complete mutation inventory - every side-effecting operation exposed to MOBOT */
export const MUTATION_INVENTORY = {
    // === Messaging & Communication ===
    "send_message": {
        category: "provider-supported",
        provider: "various",
        idempotencyKey: "sendId (client-generated)",
        reconciliation: "Check message history by sendId",
        description: "Send chat message (SMS, WhatsApp, etc.)",
    },
    "post_to_room": {
        category: "provider-supported",
        provider: "internal",
        idempotencyKey: "public: client sendId; internal: botId + sourceThreadId + caller-minted post identity (message sendId derived from it)",
        reconciliation: "Check room message log",
        description: "Post message to a room/channel",
    },
    // === Calendar Operations ===
    "calendar.create_event": {
        category: "provider-supported",
        provider: "google-calendar",
        idempotencyKey: "Google Calendar event ID",
        reconciliation: "Query Calendar API by event ID or search by title/time",
        description: "Create Google Calendar event",
    },
    "calendar.update_event": {
        category: "provider-supported",
        provider: "google-calendar",
        idempotencyKey: "Google Calendar event ID",
        reconciliation: "Query Calendar API by event ID",
        description: "Update Google Calendar event",
    },
    "calendar.delete_event": {
        category: "provider-supported",
        provider: "google-calendar",
        idempotencyKey: "Google Calendar event ID",
        reconciliation: "Query Calendar API - 404 means deleted",
        description: "Delete Google Calendar event",
    },
    // === Reminders ===
    "reminder.schedule": {
        category: "locally-managed",
        provider: "android-system",
        idempotencyKey: "botId:threadId:text:minuteWindow",
        reconciliation: "Check local reminder store by idempotencyKey",
        description: "Schedule device reminder",
    },
    // === Device/Phone Control ===
    "device.phone_control": {
        category: "uncertain-external",
        provider: "android-accessibility",
        idempotencyKey: "operationId (generated per action)",
        reconciliation: "Cannot reliably reconcile - screenshot/artifact verification",
        description: "Phone UI automation (tap, type, screenshot)",
    },
    "browser.screenshot": {
        category: "naturally-idempotent",
        provider: "browser",
        idempotencyKey: "url + viewport + timestamp",
        reconciliation: "Check artifact store for recent screenshot of URL",
        description: "Capture browser screenshot",
    },
    "browser.search_fallback": {
        category: "naturally-idempotent",
        provider: "browser",
        idempotencyKey: "query + engine",
        reconciliation: "Check search cache/artifacts",
        description: "Browser search fallback",
    },
    // === File Operations ===
    "workspace_write": {
        category: "locally-managed",
        provider: "local-fs",
        idempotencyKey: "path + contentHash",
        reconciliation: "Read file and compare content hash",
        description: "Write file to workspace",
    },
    "workspace_delete": {
        category: "locally-managed",
        provider: "local-fs",
        idempotencyKey: "path",
        reconciliation: "Check if file exists - absent means success",
        description: "Delete file from workspace",
    },
    "workspace_move": {
        category: "locally-managed",
        provider: "local-fs",
        idempotencyKey: "sourcePath + destPath",
        reconciliation: "Check dest exists and source absent",
        description: "Move/rename file",
    },
    "workspace_copy": {
        category: "locally-managed",
        provider: "local-fs",
        idempotencyKey: "sourcePath + destPath",
        reconciliation: "Check dest exists with matching content",
        description: "Copy file",
    },
    // === Terminal/Shell ===
    "run_shell": {
        category: "uncertain-external",
        provider: "shell",
        idempotencyKey: "command + cwd + envHash",
        reconciliation: "Check output artifacts, exit codes, side effects",
        description: "Execute shell command",
    },
    "run_command": {
        category: "uncertain-external",
        provider: "shell",
        idempotencyKey: "argv + cwd + envHash",
        reconciliation: "Check output artifacts, exit codes, side effects",
        description: "Execute command (argv style)",
    },
    // === Infrastructure/Provisioning ===
    "box.create": {
        category: "provider-supported",
        provider: "box-provisioning",
        idempotencyKey: "idempotencyKey (persistent)",
        reconciliation: "Query box API by idempotencyKey",
        description: "Provision cloud development box",
    },
    "box.delete": {
        category: "provider-supported",
        provider: "box-provisioning",
        idempotencyKey: "boxId",
        reconciliation: "Query box API - 404 means deleted",
        description: "Delete cloud development box",
    },
    "deploy_project": {
        category: "provider-supported",
        provider: "deployment-target",
        idempotencyKey: "deploymentId",
        reconciliation: "Query deployment status by ID",
        description: "Deploy project to hosting",
    },
    // === External Services (Composio, etc.) ===
    "service.mutation": {
        category: "provider-supported",
        provider: "composio",
        idempotencyKey: "composio execution ID",
        reconciliation: "Query Composio by execution ID",
        description: "External service mutation via Composio",
    },
    // === Android Actions ===
    "android_computer_workspace_write": {
        category: "locally-managed",
        provider: "android-fs",
        idempotencyKey: "path + contentHash",
        reconciliation: "Read file and compare content hash",
        description: "Write file on Android device",
    },
    "android_computer_run_shell": {
        category: "uncertain-external",
        provider: "android-shell",
        idempotencyKey: "command + cwd + envHash",
        reconciliation: "Check output artifacts, exit codes",
        description: "Run shell command on Android",
    },
    "android_computer_artifact_register": {
        category: "naturally-idempotent",
        provider: "android-fs",
        idempotencyKey: "artifactPath + contentHash",
        reconciliation: "Check artifact store",
        description: "Register artifact on Android",
    },
    // === Git Operations ===
    "git.commit": {
        category: "locally-managed",
        provider: "git",
        idempotencyKey: "repoPath + commitMessage + treeHash",
        reconciliation: "Check git log for matching commit",
        description: "Create git commit",
    },
    "git.push": {
        category: "provider-supported",
        provider: "git-remote",
        idempotencyKey: "remote + refspec + commitSHA",
        reconciliation: "Query remote refs",
        description: "Push git commits to remote",
    },
    // === Notifications ===
    "notification.send": {
        category: "uncertain-external",
        provider: "android-notifications",
        idempotencyKey: "notificationId (system-generated)",
        reconciliation: "No provider reconciliation. A system-generated id does not prove the notification was shown, so an uncertain outcome stays UNKNOWN and is never blindly resent",
        description: "Send local notification",
    },
};
/** Durable operation journal for mutation idempotency */
export class OperationJournal {
    filePath;
    entries = new Map();
    byIdempotencyKey = new Map(); // idempotencyKey -> operationId
    nowFn;
    leaseValidator;
    outcomeJobChecker;
    /** False once a durable write failed and no later write succeeded. */
    durable = true;
    constructor(options) {
        this.filePath = options?.filePath || join(DATA_DIR, "operation-journal.json");
        this.nowFn = options?.now || (() => Date.now());
        this.leaseValidator = options?.leaseValidator;
        this.outcomeJobChecker = options?.outcomeJobChecker;
        this.load();
    }
    setLeaseValidator(validator) {
        this.leaseValidator = validator;
    }
    setOutcomeJobChecker(checker) {
        this.outcomeJobChecker = checker;
    }
    isOutcomeJob(jobId) {
        if (this.outcomeJobChecker) {
            return this.outcomeJobChecker(jobId);
        }
        try {
            const job = sharedPersistentJobManager.getJob(jobId);
            if (job) {
                return isOutcomeJob(job);
            }
        }
        catch {
            // ignore
        }
        return true; // Fail closed: if targetJobId is specified, assume outcome job unless explicitly known otherwise
    }
    validateFencing(entry, token) {
        const targetJobId = token?.jobId || entry.jobId;
        if (targetJobId && this.isOutcomeJob(targetJobId)) {
            if (!token) {
                throw new StaleWorkerFenceError(targetJobId, entry.fencingGeneration ?? 1, 0, "Missing mandatory fencing token for outcome operation mutation");
            }
            if (entry.jobId && token.jobId && entry.jobId !== token.jobId) {
                throw new StaleWorkerFenceError(targetJobId, token.fencingGeneration ?? 1, token.fencingGeneration ?? 1, `Mismatched job ID in fencing token: expected ${entry.jobId}, got ${token.jobId}`);
            }
            if (this.leaseValidator) {
                this.leaseValidator(token);
            }
            else {
                sharedPersistentJobManager.assertWorkerLeaseActive(token);
            }
            entry.workerId = token.workerId;
            entry.fencingGeneration = token.fencingGeneration;
        }
    }
    load() {
        this.entries.clear();
        this.byIdempotencyKey.clear();
        if (!existsSync(this.filePath))
            return;
        try {
            const raw = readFileSync(this.filePath, "utf8");
            const parsed = JSON.parse(raw);
            if (parsed.version === 1 && Array.isArray(parsed.entries)) {
                for (const entry of parsed.entries) {
                    if (entry && typeof entry.operationId === "string") {
                        this.entries.set(entry.operationId, entry);
                        this.byIdempotencyKey.set(entry.idempotencyKey, entry.operationId);
                    }
                }
            }
        }
        catch {
            // Ignore corrupt file
        }
    }
    /**
     * Persist immediately and synchronously. The journal is the durability
     * boundary in front of a provider side effect, so a debounced write would
     * allow a dispatch to outlive its own record.
     */
    scheduleSave() {
        this.save();
    }
    /** Append one bounded transition record before persisting. */
    record(entry, note) {
        const history = (entry.history ??= []);
        history.push({ at: this.nowFn(), status: entry.status, ...(note ? { note } : {}) });
        if (history.length > 20)
            history.splice(0, history.length - 20);
    }
    save() {
        try {
            const dir = dirname(this.filePath);
            if (!existsSync(dir))
                mkdirSync(dir, { recursive: true, mode: 0o700 });
            const payload = {
                version: 1,
                entries: Array.from(this.entries.values()),
            };
            // Payloads carry message text: restrict the file to the account that
            // owns DATA_DIR, exactly like the other sensitive stores beside it.
            writeFileAtomic(this.filePath, JSON.stringify(payload, null, 2), { mode: 0o600 });
            this.durable = true;
        }
        catch (err) {
            // The record no longer exists only in memory by choice: a caller that is
            // about to cause a side effect must be able to see this.
            this.durable = false;
            console.error("[OperationJournal] Failed to persist:", err);
        }
    }
    /**
     * Whether the last durable write succeeded. A mutation must not be
     * dispatched while its journal record exists only in memory.
     */
    isDurable() {
        return this.durable;
    }
    /** Create or find existing operation by idempotency key */
    findOrCreateOperation(params) {
        const existingId = this.byIdempotencyKey.get(params.idempotencyKey);
        if (existingId) {
            const existing = this.entries.get(existingId);
            // Verify payload matches (prevent reuse with different args)
            const payloadHash = this.hashPayload(params.payload);
            const existingHash = this.hashPayload(existing.payload);
            if (payloadHash !== existingHash) {
                throw new Error(`Idempotency key "${params.idempotencyKey}" already used with different payload`);
            }
            const existingTargetJobId = existing.jobId || params.jobId || params.fencingToken?.jobId;
            if (existingTargetJobId && this.isOutcomeJob(existingTargetJobId)) {
                if (!params.fencingToken) {
                    throw new StaleWorkerFenceError(existingTargetJobId, existing.fencingGeneration ?? 1, 0, "Missing mandatory fencing token for outcome operation lookup");
                }
                if (params.jobId && params.fencingToken.jobId && params.jobId !== params.fencingToken.jobId) {
                    throw new StaleWorkerFenceError(existingTargetJobId, params.fencingToken.fencingGeneration ?? 1, params.fencingToken.fencingGeneration ?? 1, `Mismatched job ID in fencing token: expected ${params.jobId}, got ${params.fencingToken.jobId}`);
                }
                this.validateFencing(existing, params.fencingToken);
            }
            return { entry: existing, isNew: false };
        }
        const targetJobId = params.jobId || params.fencingToken?.jobId;
        if (targetJobId && this.isOutcomeJob(targetJobId)) {
            if (!params.fencingToken) {
                throw new StaleWorkerFenceError(targetJobId, 1, 0, "Missing mandatory fencing token for outcome operation creation");
            }
            if (params.jobId && params.fencingToken.jobId && params.jobId !== params.fencingToken.jobId) {
                throw new StaleWorkerFenceError(targetJobId, params.fencingToken.fencingGeneration ?? 1, params.fencingToken.fencingGeneration ?? 1, `Mismatched job ID in fencing token: expected ${params.jobId}, got ${params.fencingToken.jobId}`);
            }
            this.validateFencing({ jobId: targetJobId }, params.fencingToken);
        }
        const operationId = `op_${Date.now()}_${randomUUID().slice(0, 8)}`;
        const now = this.nowFn();
        const entry = {
            operationId,
            actionType: params.actionType,
            idempotencyKey: params.idempotencyKey,
            status: "pending",
            payload: params.payload,
            createdAt: now,
            updatedAt: now,
            retryCount: 0,
            maxRetries: params.maxRetries ?? 3,
            botId: params.botId,
            threadId: params.threadId,
            turnId: params.turnId,
            jobId: targetJobId,
            workerId: params.fencingToken?.workerId,
            fencingGeneration: params.fencingToken?.fencingGeneration,
            reconciliationAttempts: 0,
        };
        this.record(entry, "recorded before dispatch");
        this.entries.set(operationId, entry);
        this.byIdempotencyKey.set(params.idempotencyKey, operationId);
        this.scheduleSave();
        return { entry, isNew: true };
    }
    /** Mark operation as dispatched to provider */
    markDispatched(operationId, providerId, fencingToken) {
        const entry = this.entries.get(operationId);
        if (!entry)
            return null;
        this.validateFencing(entry, fencingToken);
        entry.status = "dispatched";
        entry.dispatchedAt = this.nowFn();
        entry.updatedAt = entry.dispatchedAt;
        if (providerId)
            entry.result = { success: false, ...(entry.result || {}), providerId };
        this.record(entry);
        this.scheduleSave();
        return entry;
    }
    /** Mark operation as acknowledged by provider (got response, awaiting final result) */
    markAcknowledged(operationId, providerResponse, fencingToken) {
        const entry = this.entries.get(operationId);
        if (!entry)
            return null;
        this.validateFencing(entry, fencingToken);
        entry.status = "acknowledged";
        entry.acknowledgedAt = this.nowFn();
        entry.updatedAt = entry.acknowledgedAt;
        entry.result = { success: false, ...(entry.result || {}), providerResponse };
        this.record(entry);
        this.scheduleSave();
        return entry;
    }
    /** Mark operation as completed successfully */
    markCompleted(operationId, result, fencingToken) {
        const entry = this.entries.get(operationId);
        if (!entry)
            return null;
        this.validateFencing(entry, fencingToken);
        entry.status = result.success ? "completed" : "failed";
        entry.completedAt = this.nowFn();
        entry.updatedAt = entry.completedAt;
        entry.result = { ...entry.result, ...result };
        this.record(entry);
        this.scheduleSave();
        return entry;
    }
    /**
     * Mark operation as failed.
     *
     * `provenNotExecuted` is the only evidence that permits a redispatch: the
     * provider itself confirmed the operation never ran.
     */
    markFailed(operationId, error, options, fencingToken) {
        const entry = this.entries.get(operationId);
        if (!entry)
            return null;
        const token = fencingToken || options?.fencingToken;
        this.validateFencing(entry, token);
        entry.status = "failed";
        entry.completedAt = this.nowFn();
        entry.updatedAt = entry.completedAt;
        entry.result = { success: false, error };
        if (options?.provenNotExecuted)
            entry.provenNotExecuted = true;
        this.record(entry, options?.provenNotExecuted ? "provider proved it never ran" : undefined);
        this.scheduleSave();
        return entry;
    }
    /** Mark operation as unknown (lost acknowledgment) */
    markUnknown(operationId, note, fencingToken) {
        const entry = this.entries.get(operationId);
        if (!entry)
            return null;
        this.validateFencing(entry, fencingToken);
        entry.status = "unknown";
        entry.updatedAt = this.nowFn();
        // UNKNOWN means "not settled": no completion timestamp may survive from an
        // earlier attempt, or the record would claim two contradictory things.
        entry.completedAt = undefined;
        entry.notes = (entry.notes ? entry.notes + "; " : "") + (note || "Acknowledgment lost");
        this.record(entry, note);
        this.scheduleSave();
        return entry;
    }
    /** Get operation by ID */
    getOperation(operationId) {
        return this.entries.get(operationId);
    }
    /** Get operation by idempotency key */
    getOperationByIdempotencyKey(idempotencyKey) {
        const opId = this.byIdempotencyKey.get(idempotencyKey);
        return opId ? this.entries.get(opId) : undefined;
    }
    /** List operations for a thread */
    listOperations(filter) {
        let list = Array.from(this.entries.values());
        if (filter?.botId)
            list = list.filter((e) => e.botId === filter.botId);
        if (filter?.threadId)
            list = list.filter((e) => e.threadId === filter.threadId);
        if (filter?.status)
            list = list.filter((e) => e.status === filter.status);
        return list.sort((a, b) => b.createdAt - a.createdAt);
    }
    /** Increment retry count, recording the transition like every other state. */
    incrementRetry(operationId, fencingToken) {
        const entry = this.entries.get(operationId);
        if (!entry)
            return null;
        this.validateFencing(entry, fencingToken);
        entry.retryCount += 1;
        entry.updatedAt = this.nowFn();
        if (entry.retryCount >= entry.maxRetries) {
            entry.status = "failed";
            // This attempt is finished, but the record stays unresolved: without a
            // provider-proved negative it must never be pruned or blindly retried.
            entry.completedAt = entry.updatedAt;
            entry.result = { success: false, error: { code: "MAX_RETRIES", message: "Max retries exceeded" } };
            this.record(entry, "max retries exceeded");
        }
        else {
            this.record(entry, `retry ${entry.retryCount}`);
        }
        this.scheduleSave();
        return entry;
    }
    /**
     * Whether a fresh dispatch is permitted.
     *
     * Only an operation that provably never reached a provider may be dispatched
     * again. `dispatched`, `acknowledged`, `reconciling` and `unknown` mean the
     * provider may already have acted, so they must be reconciled instead. A
     * lost acknowledgement is not evidence that the side effect did not happen.
     */
    canRetry(operationId) {
        const entry = this.entries.get(operationId);
        if (!entry)
            return false;
        if (entry.retryCount >= entry.maxRetries)
            return false;
        if (entry.status === "pending")
            return entry.dispatchedAt === undefined;
        if (entry.status === "failed")
            return entry.provenNotExecuted === true;
        return false;
    }
    /** Attempt reconciliation for uncertain operations */
    async reconcile(operationId, reconciler, fencingToken) {
        const entry = this.entries.get(operationId);
        if (!entry)
            return { reconciled: false, entry: null };
        if (entry.status !== "unknown" && entry.status !== "dispatched" && entry.status !== "acknowledged") {
            return { reconciled: false, entry };
        }
        this.validateFencing(entry, fencingToken);
        entry.status = "reconciling";
        entry.reconciliationAttempts += 1;
        entry.lastReconciliationAt = this.nowFn();
        entry.updatedAt = entry.lastReconciliationAt;
        entry.completedAt = undefined;
        this.record(entry, "reconciliation started");
        this.scheduleSave();
        try {
            const result = await reconciler(entry);
            // Validate again before committing local status
            this.validateFencing(entry, fencingToken);
            if (result.success) {
                entry.status = "completed";
                entry.completedAt = this.nowFn();
                entry.result = { success: true, data: result.data, providerId: result.providerId };
            }
            else {
                // An incomplete or unavailable reconciliation result never proves absence: remain UNKNOWN
                entry.status = "unknown";
                entry.completedAt = undefined;
                entry.result = { success: false, error: result.error };
                entry.notes = (entry.notes ? entry.notes + "; " : "") + `Reconciliation inconclusive: ${result.error?.message || "Incomplete"}`;
            }
            entry.updatedAt = this.nowFn();
            this.record(entry, result.success ? "reconciled" : "reconciliation inconclusive");
            this.scheduleSave();
            return { reconciled: true, entry };
        }
        catch (err) {
            if (err instanceof StaleWorkerFenceError) {
                // Do not update record if fence failed
                throw err;
            }
            entry.status = "unknown";
            entry.updatedAt = this.nowFn();
            entry.completedAt = undefined;
            entry.notes = (entry.notes ? entry.notes + "; " : "") + `Reconciliation error: ${err instanceof Error ? err.message : String(err)}`;
            this.record(entry, "reconciliation failed");
            this.scheduleSave();
            return { reconciled: false, entry };
        }
    }
    /**
     * Clean up settled entries older than maxAge.
     *
     * A `failed` record that never proved non-execution still blocks a blind
     * redispatch, so it is not settled and is never pruned — removing it would
     * silently re-open the identity for a second side effect.
     */
    prune(maxAgeMs = 30 * 24 * 60 * 60 * 1000) {
        const cutoff = this.nowFn() - maxAgeMs;
        let removed = 0;
        for (const [id, entry] of this.entries.entries()) {
            const settled = entry.status === "completed" || (entry.status === "failed" && entry.provenNotExecuted === true);
            if (settled && entry.completedAt && entry.completedAt < cutoff) {
                this.entries.delete(id);
                this.byIdempotencyKey.delete(entry.idempotencyKey);
                removed++;
            }
        }
        if (removed > 0)
            this.scheduleSave();
        return removed;
    }
    hashPayload(payload) {
        return createHash("sha256").update(canonicalJson(payload)).digest("hex");
    }
    /** Export all entries for backup/inspection */
    export() {
        return Array.from(this.entries.values());
    }
    /** Get statistics */
    getStats() {
        const byStatus = {};
        for (const entry of this.entries.values()) {
            byStatus[entry.status] = (byStatus[entry.status] || 0) + 1;
        }
        return { total: this.entries.size, byStatus };
    }
}
/**
 * Run one mutation through the journal.
 *
 * Contract:
 * - the record is durably written before `dispatch` is called;
 * - a completed operation returns the stored result without dispatching again;
 * - an operation whose acknowledgement was lost is reconciled, never re-dispatched;
 * - without a reconciler, an uncertain operation stays UNKNOWN.
 */
export async function runJournaledMutation(params) {
    const { journal, actionType, idempotencyKey, payload, scope, dispatch, reconcile } = params;
    const { entry } = journal.findOrCreateOperation({
        actionType,
        idempotencyKey,
        payload,
        botId: scope?.botId,
        threadId: scope?.threadId,
        turnId: scope?.turnId,
    });
    if (entry.status === "completed") {
        return { outcome: "deduplicated", operationId: entry.operationId, result: entry.result?.data };
    }
    const uncertain = entry.status === "dispatched" ||
        entry.status === "acknowledged" ||
        entry.status === "unknown" ||
        entry.status === "reconciling";
    if (uncertain) {
        if (!reconcile) {
            return {
                outcome: "unknown",
                operationId: entry.operationId,
                reason: "Operation may already have reached the provider; no reconciler is registered",
            };
        }
        // Only a provider that answers "I never performed this" authoritatively
        // re-opens the operation for dispatch. Absence of a record alone does not.
        let provenNotExecuted = false;
        const reconciled = await journal.reconcile(entry.operationId, async (current) => {
            const found = await reconcile(current);
            if (!found || !found.found) {
                provenNotExecuted = found?.provenNotExecuted === true;
                return {
                    success: false,
                    error: provenNotExecuted
                        ? { code: "NOT_EXECUTED", message: "The provider proved it never performed the operation" }
                        : { code: "NOT_FOUND", message: "Provider has no record of the operation" },
                };
            }
            return {
                success: true,
                data: found.result,
                providerId: current.result?.providerId ?? undefined,
            };
        });
        if (!reconciled.reconciled) {
            return { outcome: "unknown", operationId: entry.operationId, reason: "Reconciliation was inconclusive" };
        }
        if (reconciled.entry?.result?.success) {
            return {
                outcome: "reconciled",
                operationId: entry.operationId,
                result: reconciled.entry.result.data,
            };
        }
        if (!provenNotExecuted) {
            return {
                outcome: "reconciled",
                operationId: entry.operationId,
                reason: "The provider reports no record, but only a provable negative may be dispatched again",
            };
        }
        journal.markFailed(entry.operationId, { code: "NOT_EXECUTED", message: "The provider proved it never performed the operation" }, { provenNotExecuted: true });
    }
    if (!journal.canRetry(entry.operationId)) {
        return { outcome: "unknown", operationId: entry.operationId, reason: "Operation was already dispatched" };
    }
    if (!journal.isDurable()) {
        return {
            outcome: "failed",
            operationId: entry.operationId,
            reason: "The journal record could not be persisted; refusing to dispatch",
        };
    }
    // Durable "dispatched" record must exist before the provider can act.
    journal.markDispatched(entry.operationId);
    if (!journal.isDurable()) {
        return {
            outcome: "failed",
            operationId: entry.operationId,
            reason: "The dispatch record could not be persisted; refusing to dispatch",
        };
    }
    try {
        const result = await dispatch(entry.operationId);
        journal.markCompleted(entry.operationId, { success: true, data: result });
        return { outcome: "executed", operationId: entry.operationId, result };
    }
    catch (err) {
        const definitelyNotExecuted = err?.definitelyNotExecuted === true;
        const message = err instanceof Error ? err.message : String(err);
        if (definitelyNotExecuted) {
            journal.markFailed(entry.operationId, { code: "NOT_DISPATCHED", message }, { provenNotExecuted: true });
            journal.incrementRetry(entry.operationId);
            return { outcome: "failed", operationId: entry.operationId, reason: message };
        }
        // The provider may have acted: keep UNKNOWN and refuse a blind retry.
        journal.markUnknown(entry.operationId, message);
        return { outcome: "unknown", operationId: entry.operationId, reason: message };
    }
}
export const defaultOperationJournal = new OperationJournal();
/** Deterministic JSON: recursively sorted keys, so equal payloads always hash equally. */
export function canonicalJson(value) {
    if (value === null || typeof value !== "object")
        return JSON.stringify(value) ?? "null";
    if (Array.isArray(value))
        return `[${value.map((v) => canonicalJson(v)).join(",")}]`;
    const record = value;
    const keys = Object.keys(record).sort();
    return `{${keys.map((k) => `${JSON.stringify(k)}:${canonicalJson(record[k])}`).join(",")}}`;
}
/** Helper to generate idempotency keys for common operations */
export function generateIdempotencyKey(actionType, params, context) {
    const base = `${actionType}:${JSON.stringify(params, Object.keys(params).sort())}`;
    if (context?.botId && context?.threadId) {
        return `${context.botId}:${context.threadId}:${base}`;
    }
    return base;
}
/** Get mutation spec from inventory */
export function getMutationSpec(actionType) {
    return MUTATION_INVENTORY[actionType];
}
/** Check if an action type is a mutation (not read-only) */
export function isMutationAction(actionType) {
    const spec = MUTATION_INVENTORY[actionType];
    if (!spec)
        return true; // Unknown actions assumed to be mutations for safety
    return spec.category !== "read-only";
}
/** Get the recommended reconciliation strategy for an action */
export function getReconciliationStrategy(actionType) {
    const spec = MUTATION_INVENTORY[actionType];
    return spec?.reconciliation || "No reconciliation strategy defined";
}
