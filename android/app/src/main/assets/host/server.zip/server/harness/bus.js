// Fan-in event bus — port of upstream's ProviderService fan-in +
// EventNdjsonLogger tee, minus Effect. Every adapter's event stream merges
// into one bus; each event is stamped with its providerInstanceId, teed to
// a per-thread canonical NDJSON log (the debugging trick both upstream and
// agentcal lean on), and delivered to subscribers (the SSE endpoint and
// the server-side message folder).
import { appendFileSync } from "node:fs";
import { join } from "node:path";
import { EVENTS_DIR } from "../config.js";
import { redactSecrets } from "../redact.js";
import { capThreadLog, currentThreadLogCap } from "../thread-log-rotation.js";
import { newId } from "../contracts.js";
const INCOMPLETE_LOG_MESSAGE = "Canonical event history is incomplete: OpenMausBot could not write one or more events to disk. Live updates will continue.";
export class EventBus {
    listeners = new Set();
    unsubscribes = new Map();
    pendingLogWarnings = new Map();
    appendLog;
    constructor(appendLog = appendFileSync) {
        this.appendLog = appendLog;
    }
    attach(instances) {
        for (const instance of instances) {
            this.detach(instance.instanceId);
            const unsub = instance.adapter.onEvent((event) => {
                // hard invariant borrowed from correlateRuntimeEventWithInstance:
                // an adapter may only emit events for its own driver kind
                if (event.provider !== instance.driverKind) {
                    console.error(`bus: dropped cross-driver event from ${instance.instanceId}`);
                    return;
                }
                this.publish({ ...event, providerInstanceId: instance.instanceId });
            });
            this.unsubscribes.set(instance.instanceId, unsub);
        }
    }
    publish(event) {
        const pendingWarning = this.pendingLogWarnings.get(event.threadId);
        const persistedEvents = pendingWarning ? [pendingWarning, redactSecrets(event)] : [redactSecrets(event)];
        try {
            // the canonical log is a file people paste into bug reports; scrub
            // credential-shaped content (tool titles, request summaries, reply
            // text) the same way the native tee does
            this.appendLog(join(EVENTS_DIR, `${event.threadId}.ndjson`), persistedEvents.map((entry) => JSON.stringify(entry)).join("\n") + "\n", { mode: 0o600 });
            if (pendingWarning)
                this.pendingLogWarnings.delete(event.threadId);
            // Best-effort size cap (#1280): an open thread's canonical log
            // otherwise grows without bound for as long as the thread stays open.
            capThreadLog(join(EVENTS_DIR, `${event.threadId}.ndjson`), currentThreadLogCap());
        }
        catch (error) {
            // Never feed this warning back through publish(): that would retry the
            // same failed write and recurse. Deliver it once for this outage, then
            // persist the same marker before the first event written after recovery.
            if (!pendingWarning) {
                const warning = {
                    eventId: newId(),
                    provider: event.provider,
                    providerInstanceId: event.providerInstanceId,
                    threadId: event.threadId,
                    createdAt: new Date().toISOString(),
                    turnId: event.turnId,
                    type: "runtime.error",
                    message: INCOMPLETE_LOG_MESSAGE,
                };
                this.pendingLogWarnings.set(event.threadId, warning);
                console.error("bus: canonical event log write failed", error);
                this.deliver(warning);
            }
        }
        this.deliver(event);
    }
    deliver(event) {
        for (const listener of Array.from(this.listeners)) {
            try {
                listener(event);
            }
            catch (e) {
                console.error("bus: listener threw", e);
            }
        }
    }
    subscribe(listener) {
        this.listeners.add(listener);
        return () => this.listeners.delete(listener);
    }
    detachAll() {
        for (const id of this.unsubscribes.keys())
            this.detach(id);
    }
    detach(instanceId) {
        this.unsubscribes.get(instanceId)?.();
        this.unsubscribes.delete(instanceId);
    }
}
