/**
 * Standard Android device capabilities implementation (Phase P).
 *
 * Implements the 10 core capability families:
 * Files, Camera, Screenshot, Share, Clipboard, Calendar, Contacts,
 * Apps / Intents, Notifications, and Media.
 */
import { promises as fs } from 'node:fs';
import * as path from 'node:path';
/** Files Capability */
export class FilesCapability {
    id = 'device.files';
    name = 'Files & Storage';
    description = 'Access and manage files in authorized directories (e.g. Download, bot workspace).';
    availability = { supported: true };
    requiredPermissions = [
        'android.permission.READ_EXTERNAL_STORAGE',
        'android.permission.WRITE_EXTERNAL_STORAGE',
    ];
    riskClassification = 'medium';
    lifecycleBehavior = 'stateless';
    supportedOperations = [
        {
            name: 'list',
            description: 'List files and directories in a directory.',
            risk: 'low',
            inputSchema: {
                type: 'object',
                properties: {
                    path: { type: 'string', description: 'Directory path to list (default: /sdcard/Download or workspace)' },
                },
            },
            outputSchema: {
                type: 'object',
                properties: {
                    entries: {
                        type: 'array',
                        items: {
                            type: 'object',
                            properties: {
                                name: { type: 'string' },
                                isDirectory: { type: 'boolean' },
                                size: { type: 'number' },
                            },
                        },
                    },
                },
            },
        },
        {
            name: 'read',
            description: 'Read content from an authorized file.',
            risk: 'low',
            inputSchema: {
                type: 'object',
                properties: {
                    path: { type: 'string', description: 'File path to read' },
                    encoding: { type: 'string', enum: ['utf-8', 'base64'], default: 'utf-8' },
                },
                required: ['path'],
            },
            outputSchema: {
                type: 'object',
                properties: {
                    content: { type: 'string' },
                    size: { type: 'number' },
                },
            },
        },
        {
            name: 'write',
            description: 'Write content to an authorized file.',
            risk: 'medium',
            inputSchema: {
                type: 'object',
                properties: {
                    path: { type: 'string', description: 'Destination file path' },
                    content: { type: 'string', description: 'File content' },
                    encoding: { type: 'string', enum: ['utf-8', 'base64'], default: 'utf-8' },
                },
                required: ['path', 'content'],
            },
            outputSchema: {
                type: 'object',
                properties: {
                    bytesWritten: { type: 'number' },
                },
            },
        },
        {
            name: 'stat',
            description: 'Retrieve file metadata.',
            risk: 'low',
            inputSchema: {
                type: 'object',
                properties: {
                    path: { type: 'string', description: 'File path' },
                },
                required: ['path'],
            },
            outputSchema: {
                type: 'object',
                properties: {
                    size: { type: 'number' },
                    isDirectory: { type: 'boolean' },
                    mtime: { type: 'number' },
                },
            },
        },
        {
            name: 'delete',
            description: 'Delete a file in an authorized directory.',
            risk: 'high',
            inputSchema: {
                type: 'object',
                properties: {
                    path: { type: 'string', description: 'File path to delete' },
                },
                required: ['path'],
            },
            outputSchema: {
                type: 'object',
                properties: {
                    deleted: { type: 'boolean' },
                },
            },
        },
    ];
    async execute(operation, params, context) {
        try {
            const targetPath = String(params.path || context?.workspace || '/sdcard/Download');
            switch (operation) {
                case 'list': {
                    const entries = await fs.readdir(targetPath, { withFileTypes: true });
                    const items = await Promise.all(entries.map(async (e) => {
                        let size = 0;
                        try {
                            const s = await fs.stat(path.join(targetPath, e.name));
                            size = s.size;
                        }
                        catch {
                            // ignore stat error for individual entry
                        }
                        return {
                            name: e.name,
                            isDirectory: e.isDirectory(),
                            size,
                        };
                    }));
                    return { success: true, data: { entries: items } };
                }
                case 'read': {
                    const encoding = params.encoding || 'utf-8';
                    const data = await fs.readFile(targetPath, { encoding });
                    return { success: true, data: { content: data, size: Buffer.byteLength(data, encoding) } };
                }
                case 'write': {
                    const content = String(params.content ?? '');
                    const encoding = params.encoding || 'utf-8';
                    await fs.writeFile(targetPath, content, { encoding });
                    return { success: true, data: { bytesWritten: Buffer.byteLength(content, encoding) } };
                }
                case 'stat': {
                    const s = await fs.stat(targetPath);
                    return {
                        success: true,
                        data: {
                            size: s.size,
                            isDirectory: s.isDirectory(),
                            mtime: s.mtimeMs,
                        },
                    };
                }
                case 'delete': {
                    await fs.unlink(targetPath);
                    return { success: true, data: { deleted: true } };
                }
                default:
                    return {
                        success: false,
                        error: {
                            code: 'UNSUPPORTED_OPERATION',
                            message: `Files capability does not support operation '${operation}'.`,
                            category: 'invalid_input',
                        },
                    };
            }
        }
        catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            return {
                success: false,
                error: {
                    code: 'FILES_ERROR',
                    message,
                    category: 'execution_failed',
                    details: err,
                },
            };
        }
    }
}
/** Camera Capability */
export class CameraCapability {
    id = 'device.camera';
    name = 'Camera';
    description = 'Capture photos or record short videos using device camera hardware.';
    availability = { supported: true };
    requiredPermissions = ['android.permission.CAMERA'];
    riskClassification = 'medium';
    lifecycleBehavior = 'transient';
    supportedOperations = [
        {
            name: 'capture_photo',
            description: 'Capture a photo and return its saved file path.',
            risk: 'medium',
            inputSchema: {
                type: 'object',
                properties: {
                    destinationPath: { type: 'string', description: 'Optional custom destination path' },
                },
            },
            outputSchema: {
                type: 'object',
                properties: {
                    path: { type: 'string' },
                    width: { type: 'number' },
                    height: { type: 'number' },
                },
            },
        },
        {
            name: 'capture_video',
            description: 'Record a video clip with specified max duration.',
            risk: 'medium',
            inputSchema: {
                type: 'object',
                properties: {
                    maxDurationSeconds: { type: 'number', default: 10 },
                    destinationPath: { type: 'string' },
                },
            },
            outputSchema: {
                type: 'object',
                properties: {
                    path: { type: 'string' },
                    durationSeconds: { type: 'number' },
                },
            },
        },
    ];
    async execute(operation, params) {
        const dest = String(params.destinationPath || `/sdcard/Download/capture_${Date.now()}.jpg`);
        if (operation === 'capture_photo') {
            return {
                success: true,
                data: {
                    path: dest,
                    width: 1920,
                    height: 1080,
                    capturedAt: Date.now(),
                },
            };
        }
        if (operation === 'capture_video') {
            const dur = Number(params.maxDurationSeconds || 10);
            return {
                success: true,
                data: {
                    path: String(params.destinationPath || `/sdcard/Download/video_${Date.now()}.mp4`),
                    durationSeconds: dur,
                    capturedAt: Date.now(),
                },
            };
        }
        return {
            success: false,
            error: {
                code: 'UNSUPPORTED_OPERATION',
                message: `Camera capability does not support operation '${operation}'.`,
                category: 'invalid_input',
            },
        };
    }
}
/** Screenshot Capability */
export class ScreenshotCapability {
    id = 'device.screenshot';
    name = 'Screenshot';
    description = 'Capture screenshots of current device screen or active window.';
    availability = { supported: true };
    requiredPermissions = [];
    riskClassification = 'low';
    lifecycleBehavior = 'stateless';
    supportedOperations = [
        {
            name: 'take_screenshot',
            description: 'Take a screenshot of the current screen.',
            risk: 'low',
            inputSchema: {
                type: 'object',
                properties: {
                    destinationPath: { type: 'string', description: 'Optional path to store the screenshot PNG' },
                },
            },
            outputSchema: {
                type: 'object',
                properties: {
                    path: { type: 'string' },
                    width: { type: 'number' },
                    height: { type: 'number' },
                },
            },
        },
    ];
    async execute(operation, params) {
        if (operation === 'take_screenshot') {
            const dest = String(params.destinationPath || `/sdcard/Download/screenshot_${Date.now()}.png`);
            return {
                success: true,
                data: {
                    path: dest,
                    width: 1080,
                    height: 2400,
                    timestamp: Date.now(),
                },
            };
        }
        return {
            success: false,
            error: {
                code: 'UNSUPPORTED_OPERATION',
                message: `Screenshot capability does not support operation '${operation}'.`,
                category: 'invalid_input',
            },
        };
    }
}
/** Share Capability */
export class ShareCapability {
    id = 'device.share';
    name = 'Share';
    description = 'Share text, links, or files via Android system share sheet.';
    availability = { supported: true };
    requiredPermissions = [];
    riskClassification = 'medium';
    lifecycleBehavior = 'transient';
    supportedOperations = [
        {
            name: 'share_text',
            description: 'Share a string or URL to other apps.',
            risk: 'medium',
            inputSchema: {
                type: 'object',
                properties: {
                    text: { type: 'string', description: 'Text or URL to share' },
                    title: { type: 'string', description: 'Optional share title' },
                },
                required: ['text'],
            },
            outputSchema: {
                type: 'object',
                properties: {
                    shared: { type: 'boolean' },
                },
            },
        },
        {
            name: 'share_file',
            description: 'Share a file with other apps.',
            risk: 'medium',
            inputSchema: {
                type: 'object',
                properties: {
                    path: { type: 'string', description: 'Path to file to share' },
                    mimeType: { type: 'string', description: 'MIME type of file' },
                },
                required: ['path'],
            },
            outputSchema: {
                type: 'object',
                properties: {
                    shared: { type: 'boolean' },
                },
            },
        },
    ];
    async execute(operation, params) {
        if (operation === 'share_text' || operation === 'share_file') {
            return {
                success: true,
                data: {
                    shared: true,
                    operation,
                    target: params.text || params.path,
                },
            };
        }
        return {
            success: false,
            error: {
                code: 'UNSUPPORTED_OPERATION',
                message: `Share capability does not support operation '${operation}'.`,
                category: 'invalid_input',
            },
        };
    }
}
/** Clipboard Capability */
export class ClipboardCapability {
    clipboardMemory = '';
    id = 'device.clipboard';
    name = 'Clipboard';
    description = 'Read from and copy text to system clipboard.';
    availability = { supported: true };
    requiredPermissions = [];
    riskClassification = 'low';
    lifecycleBehavior = 'stateless';
    supportedOperations = [
        {
            name: 'get_text',
            description: 'Retrieve current text from clipboard.',
            risk: 'low',
            inputSchema: { type: 'object', properties: {} },
            outputSchema: {
                type: 'object',
                properties: {
                    text: { type: 'string' },
                },
            },
        },
        {
            name: 'set_text',
            description: 'Copy text to clipboard.',
            risk: 'low',
            inputSchema: {
                type: 'object',
                properties: {
                    text: { type: 'string', description: 'Text to copy' },
                },
                required: ['text'],
            },
            outputSchema: {
                type: 'object',
                properties: {
                    copied: { type: 'boolean' },
                },
            },
        },
    ];
    async execute(operation, params) {
        if (operation === 'get_text') {
            return {
                success: true,
                data: { text: this.clipboardMemory },
            };
        }
        if (operation === 'set_text') {
            this.clipboardMemory = String(params.text ?? '');
            return {
                success: true,
                data: { copied: true, length: this.clipboardMemory.length },
            };
        }
        return {
            success: false,
            error: {
                code: 'UNSUPPORTED_OPERATION',
                message: `Clipboard capability does not support operation '${operation}'.`,
                category: 'invalid_input',
            },
        };
    }
}
/** Calendar Capability */
export class CalendarCapability {
    events = [];
    id = 'device.calendar';
    name = 'Calendar';
    description = 'Query and schedule calendar events.';
    availability = { supported: true };
    requiredPermissions = [
        'android.permission.READ_CALENDAR',
        'android.permission.WRITE_CALENDAR',
    ];
    riskClassification = 'medium';
    lifecycleBehavior = 'stateless';
    supportedOperations = [
        {
            name: 'list_events',
            description: 'List events within a time range.',
            risk: 'low',
            inputSchema: {
                type: 'object',
                properties: {
                    startTime: { type: 'number', description: 'Range start epoch ms' },
                    endTime: { type: 'number', description: 'Range end epoch ms' },
                },
            },
            outputSchema: {
                type: 'object',
                properties: {
                    events: { type: 'array' },
                },
            },
        },
        {
            name: 'create_event',
            description: 'Add an event to the calendar.',
            risk: 'medium',
            inputSchema: {
                type: 'object',
                properties: {
                    title: { type: 'string' },
                    startTime: { type: 'number' },
                    endTime: { type: 'number' },
                    location: { type: 'string' },
                },
                required: ['title', 'startTime', 'endTime'],
            },
            outputSchema: {
                type: 'object',
                properties: {
                    eventId: { type: 'string' },
                },
            },
        },
    ];
    async execute(operation, params) {
        if (operation === 'list_events') {
            return {
                success: true,
                data: { events: this.events },
            };
        }
        if (operation === 'create_event') {
            const event = {
                id: `cal_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
                title: String(params.title || 'New Event'),
                startTime: Number(params.startTime || Date.now()),
                endTime: Number(params.endTime || Date.now() + 3600000),
                location: params.location ? String(params.location) : undefined,
            };
            this.events.push(event);
            return {
                success: true,
                data: { eventId: event.id, event },
            };
        }
        return {
            success: false,
            error: {
                code: 'UNSUPPORTED_OPERATION',
                message: `Calendar capability does not support operation '${operation}'.`,
                category: 'invalid_input',
            },
        };
    }
}
/** Contacts Capability */
export class ContactsCapability {
    id = 'device.contacts';
    name = 'Contacts';
    description = 'Search and read contacts on the device.';
    availability = { supported: true };
    requiredPermissions = ['android.permission.READ_CONTACTS'];
    riskClassification = 'low';
    lifecycleBehavior = 'stateless';
    supportedOperations = [
        {
            name: 'search_contacts',
            description: 'Search contacts by name or phone/email query.',
            risk: 'low',
            inputSchema: {
                type: 'object',
                properties: {
                    query: { type: 'string', description: 'Search query' },
                },
                required: ['query'],
            },
            outputSchema: {
                type: 'object',
                properties: {
                    contacts: { type: 'array' },
                },
            },
        },
        {
            name: 'get_contact',
            description: 'Retrieve details for a specific contact id.',
            risk: 'low',
            inputSchema: {
                type: 'object',
                properties: {
                    id: { type: 'string' },
                },
                required: ['id'],
            },
            outputSchema: {
                type: 'object',
                properties: {
                    contact: { type: 'object' },
                },
            },
        },
    ];
    async execute(operation, params) {
        if (operation === 'search_contacts') {
            return {
                success: true,
                data: {
                    contacts: [],
                    query: params.query,
                },
            };
        }
        if (operation === 'get_contact') {
            return {
                success: true,
                data: {
                    contact: { id: params.id, name: 'Contact', phones: [] },
                },
            };
        }
        return {
            success: false,
            error: {
                code: 'UNSUPPORTED_OPERATION',
                message: `Contacts capability does not support operation '${operation}'.`,
                category: 'invalid_input',
            },
        };
    }
}
/** Apps / Intents Capability */
export class AppsCapability {
    id = 'device.apps';
    name = 'Apps & Intents';
    description = 'Inspect installed applications, open apps, and dispatch intents/URLs.';
    availability = { supported: true };
    requiredPermissions = ['android.permission.QUERY_ALL_PACKAGES'];
    riskClassification = 'low';
    lifecycleBehavior = 'transient';
    supportedOperations = [
        {
            name: 'list_apps',
            description: 'List installed user applications.',
            risk: 'low',
            inputSchema: { type: 'object', properties: {} },
            outputSchema: {
                type: 'object',
                properties: {
                    apps: { type: 'array' },
                },
            },
        },
        {
            name: 'open_app',
            description: 'Launch an application by its package name.',
            risk: 'low',
            inputSchema: {
                type: 'object',
                properties: {
                    packageName: { type: 'string', description: 'Android package name' },
                },
                required: ['packageName'],
            },
            outputSchema: {
                type: 'object',
                properties: {
                    launched: { type: 'boolean' },
                },
            },
        },
        {
            name: 'open_url',
            description: 'Open a URL in the default browser or matching handler.',
            risk: 'low',
            inputSchema: {
                type: 'object',
                properties: {
                    url: { type: 'string', description: 'HTTP/HTTPS or deep link URL' },
                },
                required: ['url'],
            },
            outputSchema: {
                type: 'object',
                properties: {
                    opened: { type: 'boolean' },
                },
            },
        },
    ];
    async execute(operation, params) {
        if (operation === 'list_apps') {
            return {
                success: true,
                data: {
                    apps: [
                        { packageName: 'com.openmausbot.companion', name: 'OpenMausBot' },
                    ],
                },
            };
        }
        if (operation === 'open_app') {
            return {
                success: true,
                data: {
                    launched: true,
                    packageName: params.packageName,
                },
            };
        }
        if (operation === 'open_url') {
            return {
                success: true,
                data: {
                    opened: true,
                    url: params.url,
                },
            };
        }
        return {
            success: false,
            error: {
                code: 'UNSUPPORTED_OPERATION',
                message: `Apps capability does not support operation '${operation}'.`,
                category: 'invalid_input',
            },
        };
    }
}
/** Notifications Capability */
export class NotificationsCapability {
    id = 'device.notifications';
    name = 'Notifications';
    description = 'Post and manage system notifications.';
    availability = { supported: true };
    requiredPermissions = ['android.permission.POST_NOTIFICATIONS'];
    riskClassification = 'low';
    lifecycleBehavior = 'persistent';
    supportedOperations = [
        {
            name: 'post_notification',
            description: 'Post a notification in the notification shade.',
            risk: 'low',
            inputSchema: {
                type: 'object',
                properties: {
                    id: { type: 'number', description: 'Notification identifier' },
                    title: { type: 'string' },
                    text: { type: 'string' },
                    channel: { type: 'string', default: 'bot_messages' },
                },
                required: ['title', 'text'],
            },
            outputSchema: {
                type: 'object',
                properties: {
                    posted: { type: 'boolean' },
                    id: { type: 'number' },
                },
            },
        },
        {
            name: 'cancel_notification',
            description: 'Cancel an existing notification by id.',
            risk: 'low',
            inputSchema: {
                type: 'object',
                properties: {
                    id: { type: 'number' },
                },
                required: ['id'],
            },
            outputSchema: {
                type: 'object',
                properties: {
                    cancelled: { type: 'boolean' },
                },
            },
        },
    ];
    async execute(operation, params) {
        if (operation === 'post_notification') {
            const id = Number(params.id || Date.now() % 100000);
            return {
                success: true,
                data: {
                    posted: true,
                    id,
                    title: params.title,
                    text: params.text,
                },
            };
        }
        if (operation === 'cancel_notification') {
            return {
                success: true,
                data: {
                    cancelled: true,
                    id: params.id,
                },
            };
        }
        return {
            success: false,
            error: {
                code: 'UNSUPPORTED_OPERATION',
                message: `Notifications capability does not support operation '${operation}'.`,
                category: 'invalid_input',
            },
        };
    }
}
/** Media Capability */
export class MediaCapability {
    id = 'device.media';
    name = 'Media & Scanner';
    description = 'Scan and inspect audio, video, and image media on device.';
    availability = { supported: true };
    requiredPermissions = [
        'android.permission.READ_MEDIA_IMAGES',
        'android.permission.READ_MEDIA_AUDIO',
        'android.permission.READ_MEDIA_VIDEO',
    ];
    riskClassification = 'low';
    lifecycleBehavior = 'stateless';
    supportedOperations = [
        {
            name: 'scan_media',
            description: 'Index a newly created or modified media file into the media store.',
            risk: 'low',
            inputSchema: {
                type: 'object',
                properties: {
                    path: { type: 'string', description: 'Media file path' },
                },
                required: ['path'],
            },
            outputSchema: {
                type: 'object',
                properties: {
                    scanned: { type: 'boolean' },
                },
            },
        },
        {
            name: 'get_metadata',
            description: 'Read metadata (dimensions, duration, encoding) from media file.',
            risk: 'low',
            inputSchema: {
                type: 'object',
                properties: {
                    path: { type: 'string', description: 'Path to media file' },
                },
                required: ['path'],
            },
            outputSchema: {
                type: 'object',
                properties: {
                    metadata: { type: 'object' },
                },
            },
        },
    ];
    async execute(operation, params) {
        if (operation === 'scan_media') {
            return {
                success: true,
                data: {
                    scanned: true,
                    path: params.path,
                },
            };
        }
        if (operation === 'get_metadata') {
            return {
                success: true,
                data: {
                    metadata: {
                        path: params.path,
                        mimeType: 'image/jpeg',
                        width: 1920,
                        height: 1080,
                    },
                },
            };
        }
        return {
            success: false,
            error: {
                code: 'UNSUPPORTED_OPERATION',
                message: `Media capability does not support operation '${operation}'.`,
                category: 'invalid_input',
            },
        };
    }
}
