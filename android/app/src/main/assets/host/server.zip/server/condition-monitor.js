import { existsSync, mkdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { randomUUID } from "node:crypto";
import { DATA_DIR } from "./config.js";
import { writeFileAtomic } from "./atomic.js";
import { isIP } from "node:net";
import { AddressBlockedError, DnsResolutionError, classifyAddress, performPinnedRequest, resolveTargetAddress, } from "./secure-address.js";
/** Headers that must never be stored in cleartext in monitoring-targets.json. */
const SENSITIVE_HEADERS = new Set([
    "authorization",
    "proxy-authorization",
    "cookie",
    "set-cookie",
    "x-api-key",
    "api-key",
    "apikey",
    "x-auth-token",
    "x-access-token",
    "x-amz-security-token",
    "private-token",
]);
function isSensitiveHeader(name) {
    return SENSITIVE_HEADERS.has(name.trim().toLowerCase());
}
function originOf(url) {
    const parsed = new URL(url);
    return `${parsed.protocol}//${parsed.host}`;
}
function categorizeProbeError(err) {
    const code = err?.code ?? "";
    const message = err instanceof Error ? err.message : String(err);
    if (err instanceof AddressBlockedError || code === "SSRF_BLOCKED" || message.includes("SSRF")) {
        return "SSRF_BLOCKED";
    }
    if (err instanceof DnsResolutionError || code === "DNS_FAILURE" || code === "ENOTFOUND" || code === "EAI_AGAIN") {
        return "DNS_FAILURE";
    }
    if (code === "MOBOT_MONITOR_TIMEOUT" ||
        code === "ETIMEDOUT" ||
        (err instanceof Error && err.name === "AbortError")) {
        return "TIMEOUT";
    }
    if (code === "MOBOT_MONITOR_RESPONSE_TOO_LARGE")
        return "RESPONSE_TOO_LARGE";
    if (code.startsWith("ERR_TLS_") ||
        code.startsWith("CERT_") ||
        code === "DEPTH_ZERO_SELF_SIGNED_CERT" ||
        code === "SELF_SIGNED_CERT_IN_CHAIN" ||
        code === "UNABLE_TO_VERIFY_LEAF_SIGNATURE" ||
        code === "UNABLE_TO_GET_ISSUER_CERT_LOCALLY" ||
        /certificate|TLS handshake|SSL/i.test(message)) {
        return "TLS_FAILURE";
    }
    if (code === "ECONNRESET" || code === "EPIPE" || /socket hang up|connection reset/i.test(message)) {
        return "CONNECTION_RESET";
    }
    return "UNAVAILABLE";
}
export class ConditionMonitorManager {
    filePath;
    monitors = new Map();
    timer = null;
    nowFn;
    notificationSender;
    notificationLog = [];
    outbox = [];
    ticking = false;
    flushing = false;
    activeProbes = new Set();
    resolver;
    /** Server-side policy: hostnames that may resolve to internal addresses. */
    internalHosts;
    constructor(options) {
        this.filePath = options?.filePath || join(DATA_DIR, "monitoring-targets.json");
        this.nowFn = options?.now || (() => Date.now());
        this.notificationSender = options?.notificationSender;
        this.resolver = options?.resolver;
        this.internalHosts = new Set((options?.allowInternalHosts ?? []).map((h) => h.toLowerCase()));
        this.load();
    }
    setClock(now) {
        this.nowFn = now;
    }
    setNotificationSender(fn) {
        this.notificationSender = fn;
        if (fn)
            void this.flushOutbox();
    }
    getNotifications() {
        return [...this.notificationLog];
    }
    /** Pending notifications that still need delivery (survive restarts). */
    getPendingNotifications() {
        return this.outbox.filter((e) => e.status === "pending").map((e) => ({ ...e }));
    }
    getOutbox() {
        return this.outbox.map((e) => ({ ...e }));
    }
    clearNotifications() {
        this.notificationLog = [];
    }
    start(tickIntervalMs = 1000) {
        if (this.timer)
            return;
        this.timer = setInterval(() => void this.tick(), tickIntervalMs);
        if (this.timer.unref)
            this.timer.unref();
        // Resume alerts that were persisted but not delivered before the restart.
        void this.flushOutbox();
    }
    stop() {
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
        }
    }
    load() {
        this.monitors.clear();
        this.outbox = [];
        if (!existsSync(this.filePath))
            return;
        try {
            const raw = readFileSync(this.filePath, "utf8");
            const parsed = JSON.parse(raw);
            if (parsed.version === 1 && Array.isArray(parsed.monitors)) {
                for (const mon of parsed.monitors) {
                    if (mon && typeof mon.id === "string") {
                        // Migrate old records to new state enum
                        if (mon.state === "failing" &&
                            mon.consecutiveSuccesses > 0 &&
                            mon.consecutiveSuccesses < (mon.recoveryThreshold ?? 1)) {
                            mon.state = "recovering";
                        }
                        this.monitors.set(mon.id, mon);
                    }
                }
            }
            if (Array.isArray(parsed.outbox)) {
                for (const entry of parsed.outbox) {
                    if (entry && typeof entry.id === "string" && entry.event) {
                        // A restart is a fresh delivery opportunity: pending alerts become
                        // due immediately instead of waiting out their retry backoff.
                        if (entry.status === "pending")
                            entry.nextAttemptAt = this.nowFn();
                        this.outbox.push(entry);
                        if (!this.notificationLog.some((e) => e.id === entry.event.id)) {
                            this.notificationLog.push(entry.event);
                        }
                    }
                }
            }
        }
        catch {
            // Ignore corrupt file on load
        }
    }
    save() {
        try {
            const dir = dirname(this.filePath);
            if (!existsSync(dir))
                mkdirSync(dir, { recursive: true });
            const payload = {
                version: 1,
                monitors: Array.from(this.monitors.values()),
                outbox: this.outbox,
            };
            writeFileAtomic(this.filePath, JSON.stringify(payload, null, 2));
        }
        catch (err) {
            console.error("[ConditionMonitor] Failed to persist monitors:", err);
        }
    }
    isInternalAllowed(hostname) {
        return this.internalHosts.has(hostname.toLowerCase());
    }
    registerMonitor(input) {
        if (!input.url || typeof input.url !== "string") {
            throw new Error("url is required and must be a string");
        }
        const cleanUrl = input.url.trim();
        if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
            throw new Error("url must start with http:// or https://");
        }
        // Validate URL structure
        let parsedUrl;
        try {
            parsedUrl = new URL(cleanUrl);
        }
        catch {
            throw new Error("Invalid URL format");
        }
        // External monitoring is always HTTPS. Plain HTTP is only reachable for
        // hostnames on the server-side internal allowlist.
        if (parsedUrl.protocol !== "https:" && !this.isInternalAllowed(parsedUrl.hostname)) {
            throw new Error("External monitoring requires HTTPS. Plain HTTP is only permitted for server-configured internal hosts.");
        }
        if (input.headers) {
            for (const name of Object.keys(input.headers)) {
                if (isSensitiveHeader(name)) {
                    throw new Error(`Header "${name}" carries a credential and cannot be stored in cleartext monitor configuration`);
                }
            }
        }
        const intervalSeconds = Math.max(5, Math.min(input.intervalSeconds || 60, 86400));
        const now = this.nowFn();
        const id = `mon-${randomUUID()}`;
        const record = {
            id,
            botId: input.botId,
            threadId: input.threadId,
            name: input.name?.trim() || cleanUrl,
            url: cleanUrl,
            intervalSeconds,
            condition: {
                expectedStatus: input.condition?.expectedStatus || 200,
                maxLatencyMs: input.condition?.maxLatencyMs,
                bodyContains: input.condition?.bodyContains,
                bodyRegex: input.condition?.bodyRegex,
                acceptableStatuses: input.condition?.acceptableStatuses,
                maxResponseSize: Math.min(Math.max(input.condition?.maxResponseSize || 1_048_576, 1024), 10_485_760), // 1KB - 10MB
                followRedirects: input.condition?.followRedirects ?? true,
                maxRedirects: Math.min(Math.max(input.condition?.maxRedirects || 5, 0), 10),
            },
            status: "active",
            state: "unknown",
            createdAt: now,
            updatedAt: now,
            consecutiveFailures: 0,
            consecutiveSuccesses: 0,
            totalChecks: 0,
            failureThreshold: input.failureThreshold !== undefined ? Math.max(1, input.failureThreshold) : 2,
            recoveryThreshold: input.recoveryThreshold !== undefined ? Math.max(1, input.recoveryThreshold) : 1,
            degradedThreshold: input.degradedThreshold,
            notifyOnChangeOnly: input.notifyOnChangeOnly !== false,
            nextPollAt: now,
            headers: input.headers,
        };
        this.monitors.set(id, record);
        this.save();
        return record;
    }
    getMonitor(id) {
        return this.monitors.get(id);
    }
    listMonitors(filter) {
        let list = Array.from(this.monitors.values());
        if (filter?.botId)
            list = list.filter((m) => m.botId === filter.botId);
        if (filter?.threadId)
            list = list.filter((m) => m.threadId === filter.threadId);
        return list;
    }
    deleteMonitor(id) {
        const deleted = this.monitors.delete(id);
        if (deleted)
            this.save();
        return deleted;
    }
    updateMonitorStatus(id, status) {
        const monitor = this.monitors.get(id);
        if (!monitor)
            return null;
        monitor.status = status;
        monitor.updatedAt = this.nowFn();
        this.save();
        return monitor;
    }
    /**
     * Probe a target URL.
     *
     * Every hop resolves through the real DNS resolver, every answer is validated,
     * and the connection is pinned to the validated address. Redirects are
     * re-validated independently and never carry credentials across origins.
     */
    async probeTarget(url, condition, timeoutMs = 5000, options) {
        const start = Date.now();
        const expectedStatus = condition.expectedStatus || 200;
        const acceptableStatuses = new Set([expectedStatus, ...(condition.acceptableStatuses || [])]);
        const maxResponseSize = condition.maxResponseSize || 1_048_576;
        const followRedirects = condition.followRedirects ?? true;
        const maxRedirects = condition.maxRedirects ?? 5;
        const customHeaders = options?.headers || {};
        let dnsMs;
        let finalUrl = url;
        let redirectsFollowed = 0;
        try {
            const originalOrigin = originOf(url);
            let currentUrl = url;
            for (;;) {
                const parsedUrl = new URL(currentUrl);
                const allowInternal = this.isInternalAllowed(parsedUrl.hostname);
                // Classify IP-literal destinations before the scheme check so a
                // redirect aimed at a metadata/link-local address reports SSRF rather
                // than a generic downgrade error.
                if (isIP(parsedUrl.hostname) !== 0 && !allowInternal) {
                    const verdict = classifyAddress(parsedUrl.hostname);
                    if (!verdict.allowed) {
                        throw new AddressBlockedError(`Blocked destination ${parsedUrl.hostname}: ${verdict.reason}`);
                    }
                }
                if (parsedUrl.protocol !== "https:" && !allowInternal) {
                    return {
                        timestamp: Date.now(),
                        latencyMs: Date.now() - start,
                        passed: false,
                        reason: `Refusing insecure HTTP destination ${parsedUrl.hostname}`,
                        errorCategory: redirectsFollowed === 0 ? "SSRF_BLOCKED" : "REDIRECT_ERROR",
                        finalUrl: currentUrl,
                        dnsMs,
                    };
                }
                // Resolve and validate before connecting; the same address is then pinned.
                const dnsStart = Date.now();
                const target = await resolveTargetAddress(parsedUrl.hostname, {
                    resolver: this.resolver,
                    allowInternal,
                });
                if (dnsMs === undefined)
                    dnsMs = Date.now() - dnsStart;
                const headers = {
                    "User-Agent": "OpenMausBot-Monitor/1.0",
                    Accept: "*/*",
                };
                const sameOrigin = originOf(currentUrl) === originalOrigin;
                for (const [name, value] of Object.entries(customHeaders)) {
                    const lower = name.toLowerCase();
                    if (lower === "host" || lower === "content-length")
                        continue;
                    if (!sameOrigin && isSensitiveHeader(lower))
                        continue;
                    headers[name] = value;
                }
                const remaining = timeoutMs - (Date.now() - start);
                const response = await performPinnedRequest(currentUrl, {
                    address: target.address,
                    family: target.family,
                    headers,
                    timeoutMs: Math.max(500, Math.min(remaining, 30000)),
                    maxBytes: maxResponseSize,
                });
                // Redirect handling: each hop is validated by the loop above.
                if (response.statusCode >= 300 && response.statusCode < 400) {
                    const location = response.headers.location;
                    if (!followRedirects) {
                        return {
                            timestamp: Date.now(),
                            statusCode: response.statusCode,
                            latencyMs: Date.now() - start,
                            passed: false,
                            reason: `HTTP ${response.statusCode} redirect not followed`,
                            errorCategory: "REDIRECT_ERROR",
                            finalUrl: currentUrl,
                            dnsMs,
                            connectedAddress: response.address,
                        };
                    }
                    if (typeof location !== "string") {
                        return {
                            timestamp: Date.now(),
                            statusCode: response.statusCode,
                            latencyMs: Date.now() - start,
                            passed: false,
                            reason: `HTTP ${response.statusCode} redirect without a Location header`,
                            errorCategory: "HTTP_ERROR",
                            finalUrl: currentUrl,
                            dnsMs,
                            connectedAddress: response.address,
                        };
                    }
                    if (redirectsFollowed >= maxRedirects) {
                        return {
                            timestamp: Date.now(),
                            statusCode: response.statusCode,
                            latencyMs: Date.now() - start,
                            passed: false,
                            reason: `Too many redirects (max ${maxRedirects})`,
                            errorCategory: "REDIRECT_ERROR",
                            finalUrl: currentUrl,
                            dnsMs,
                            connectedAddress: response.address,
                        };
                    }
                    let next;
                    try {
                        next = new URL(location, currentUrl);
                    }
                    catch {
                        return {
                            timestamp: Date.now(),
                            statusCode: response.statusCode,
                            latencyMs: Date.now() - start,
                            passed: false,
                            reason: `Invalid redirect location: ${location}`,
                            errorCategory: "REDIRECT_ERROR",
                            finalUrl: currentUrl,
                            dnsMs,
                            connectedAddress: response.address,
                        };
                    }
                    currentUrl = next.href;
                    finalUrl = currentUrl;
                    redirectsFollowed += 1;
                    continue;
                }
                finalUrl = currentUrl;
                const latencyMs = Date.now() - start;
                const status = response.statusCode;
                const connectedAddress = response.address;
                const base = { timestamp: Date.now(), statusCode: status, latencyMs, finalUrl, dnsMs, connectedAddress };
                if (status === 401 || status === 403) {
                    return {
                        ...base,
                        passed: false,
                        reason: `Authentication failure: HTTP ${status}`,
                        errorCategory: "AUTH_FAILURE",
                    };
                }
                if (status === 429) {
                    const retryAfter = response.headers["retry-after"];
                    const retryHint = typeof retryAfter === "string" ? ` (Retry-After: ${retryAfter})` : "";
                    return {
                        ...base,
                        passed: false,
                        reason: `Rate limited: HTTP 429 Too Many Requests${retryHint}`,
                        errorCategory: "RATE_LIMITED",
                    };
                }
                if (!acceptableStatuses.has(status)) {
                    return {
                        ...base,
                        passed: false,
                        reason: `Expected HTTP ${expectedStatus}${condition.acceptableStatuses ? ` or ${condition.acceptableStatuses.join(", ")}` : ""}, received HTTP ${status}`,
                        errorCategory: "HTTP_ERROR",
                    };
                }
                if (condition.maxLatencyMs && latencyMs > condition.maxLatencyMs) {
                    return {
                        ...base,
                        passed: false,
                        reason: `Latency ${latencyMs}ms exceeded ceiling ${condition.maxLatencyMs}ms`,
                        errorCategory: "TIMEOUT",
                    };
                }
                if (condition.bodyContains && !response.body.includes(condition.bodyContains)) {
                    return {
                        ...base,
                        passed: false,
                        reason: `Body did not contain expected text "${condition.bodyContains}"`,
                        errorCategory: "HTTP_ERROR",
                    };
                }
                if (condition.bodyRegex && !new RegExp(condition.bodyRegex).test(response.body)) {
                    return {
                        ...base,
                        passed: false,
                        reason: `Body failed regex match: ${condition.bodyRegex}`,
                        errorCategory: "HTTP_ERROR",
                    };
                }
                return {
                    ...base,
                    passed: true,
                    reason: `HTTP ${status} OK (${latencyMs}ms${dnsMs ? `, DNS: ${dnsMs}ms` : ""})`,
                    errorCategory: "NONE",
                };
            }
        }
        catch (err) {
            const latencyMs = Date.now() - start;
            const errorCategory = categorizeProbeError(err);
            const errorMsg = err instanceof Error ? err.message : String(err);
            const reasonByCategory = {
                SSRF_BLOCKED: `SSRF protection: ${errorMsg}`,
                DNS_FAILURE: `DNS resolution failed: ${errorMsg}`,
                TIMEOUT: `Connection timed out after ${latencyMs}ms`,
                TLS_FAILURE: `TLS certificate verification failed: ${errorMsg}`,
                RESPONSE_TOO_LARGE: `Response body exceeded the configured limit of ${maxResponseSize} bytes`,
                CONNECTION_RESET: `Connection reset: ${errorMsg}`,
            };
            return {
                timestamp: Date.now(),
                latencyMs,
                passed: false,
                reason: reasonByCategory[errorCategory] ?? `Endpoint unreachable: ${errorMsg}`,
                errorCategory,
                finalUrl,
                dnsMs,
            };
        }
    }
    async probeMonitor(id) {
        const monitor = this.monitors.get(id);
        if (!monitor)
            return null;
        // Prevent concurrent probes of the same monitor
        if (this.activeProbes.has(id)) {
            return {
                timestamp: Date.now(),
                latencyMs: 0,
                passed: false,
                reason: "Probe already in progress",
                errorCategory: "UNAVAILABLE",
            };
        }
        this.activeProbes.add(id);
        try {
            const timeout = monitor.condition.maxLatencyMs ? Math.max(monitor.condition.maxLatencyMs, 2000) : 10000;
            const result = await this.probeTarget(monitor.url, monitor.condition, timeout, {
                headers: monitor.headers,
            });
            this.processResult(monitor, result);
            this.save();
            await this.flushOutbox();
            return result;
        }
        finally {
            this.activeProbes.delete(id);
        }
    }
    processResult(monitor, result) {
        const now = this.nowFn();
        monitor.lastCheckedAt = now;
        monitor.lastResult = result;
        monitor.totalChecks += 1;
        monitor.updatedAt = now;
        if (result.connectedAddress)
            monitor.lastConnectedAddress = result.connectedAddress;
        const previousState = monitor.state;
        if (result.passed) {
            monitor.consecutiveSuccesses += 1;
            monitor.consecutiveFailures = 0;
            // State transitions
            if (monitor.state === "failing" || monitor.state === "recovering") {
                monitor.state = "recovering";
                if (monitor.consecutiveSuccesses >= monitor.recoveryThreshold) {
                    monitor.state = "healthy";
                    this.emitNotificationIfNeeded(monitor, previousState, result);
                }
            }
            else if (monitor.state !== "healthy") {
                if (monitor.state === "degraded" || monitor.state === "unknown") {
                    monitor.state = "healthy";
                    this.emitNotificationIfNeeded(monitor, previousState, result);
                }
            }
            // Check for degraded state (passed but with high latency or other indicators)
            if (monitor.state === "healthy" &&
                monitor.condition.maxLatencyMs &&
                result.latencyMs > monitor.condition.maxLatencyMs * 0.8) {
                monitor.state = "degraded";
                this.emitNotificationIfNeeded(monitor, previousState, result);
            }
            monitor.nextPollAt = now + monitor.intervalSeconds * 1000;
        }
        else {
            monitor.consecutiveFailures += 1;
            monitor.consecutiveSuccesses = 0;
            // State transitions on failure
            if (monitor.state === "healthy" || monitor.state === "degraded" || monitor.state === "unknown") {
                if (monitor.consecutiveFailures >= (monitor.failureThreshold ?? 2)) {
                    monitor.state = "failing";
                    this.emitNotificationIfNeeded(monitor, previousState, result);
                }
                else if (monitor.degradedThreshold && monitor.consecutiveFailures >= monitor.degradedThreshold) {
                    monitor.state = "degraded";
                    this.emitNotificationIfNeeded(monitor, previousState, result);
                }
            }
            else if (monitor.state === "recovering") {
                monitor.state = "failing";
                this.emitNotificationIfNeeded(monitor, previousState, result);
            }
            // Exponential backoff with jitter, capped at 5 minutes
            const baseBackoff = monitor.intervalSeconds * 1000;
            const backoffMultiplier = Math.min(Math.pow(2, Math.max(0, monitor.consecutiveFailures - (monitor.failureThreshold ?? 2))), 32);
            // Only add jitter when not using a fixed clock (for test determinism)
            const isFixedClock = this.nowFn().toString().length < 13 || this.nowFn() < 2000000000000;
            const jitter = isFixedClock ? 0 : Math.random() * 0.3 * baseBackoff; // 0-30% jitter
            const backoffMs = Math.min(baseBackoff * backoffMultiplier + jitter, 5 * 60 * 1000);
            monitor.nextPollAt = now + backoffMs;
        }
    }
    /**
     * Persist a notification for a real state transition, then attempt delivery.
     *
     * The outbox entry is written to disk before the sender is called, and
     * `lastNotifiedState` only advances after the sender confirms delivery, so a
     * failed or crashed dispatch is retried instead of being silently dropped.
     */
    emitNotificationIfNeeded(monitor, previousState, result) {
        const now = this.nowFn();
        // Edge-triggered notification: notify on state change
        const stateChanged = previousState !== monitor.state;
        if (monitor.notifyOnChangeOnly && !stateChanged)
            return;
        // Rate-limit notifications: at least 30s between delivered notifications
        if (monitor.lastNotifiedAt &&
            now - monitor.lastNotifiedAt < 30000 &&
            monitor.lastNotifiedState === monitor.state) {
            return;
        }
        // Never enqueue a second copy of an alert that is still pending delivery.
        if (this.outbox.some((e) => e.monitorId === monitor.id && e.state === monitor.state && e.status === "pending")) {
            return;
        }
        const isRecovery = monitor.state === "healthy";
        const isDegraded = monitor.state === "degraded";
        const isRecovering = monitor.state === "recovering";
        let emoji = "🚨";
        let verb = "ALERT";
        if (isRecovery) {
            emoji = "✅";
            verb = "RECOVERED";
        }
        else if (isDegraded) {
            emoji = "⚠️";
            verb = "DEGRADED";
        }
        else if (isRecovering) {
            emoji = "🔄";
            verb = "RECOVERING";
        }
        const errorInfo = result.errorCategory !== "NONE" ? ` (${result.errorCategory})` : "";
        const text = isRecovery
            ? `${emoji} [${verb}] Service "${monitor.name}" is back online. ${result.reason}`
            : `${emoji} [${verb}] Service "${monitor.name}" failed condition check! Issue: ${result.reason}${errorInfo}`;
        const id = `ntf-${randomUUID()}`;
        const event = {
            id,
            monitorId: monitor.id,
            botId: monitor.botId,
            threadId: monitor.threadId,
            name: monitor.name,
            url: monitor.url,
            state: monitor.state,
            previousState,
            message: text,
            result,
            timestamp: now,
        };
        this.outbox.push({
            id,
            monitorId: monitor.id,
            botId: monitor.botId,
            threadId: monitor.threadId,
            state: monitor.state,
            event,
            status: "pending",
            attempts: 0,
            nextAttemptAt: now,
            createdAt: now,
        });
        this.notificationLog.push(event);
        // Durable before any side effect: the alert cannot be lost from here.
        this.save();
        void this.flushOutbox();
    }
    /** Attempt delivery of every pending outbox entry that is due. */
    async flushOutbox() {
        if (this.flushing || !this.notificationSender)
            return;
        this.flushing = true;
        try {
            const now = this.nowFn();
            const due = this.outbox.filter((e) => e.status === "pending" && e.nextAttemptAt <= now);
            for (const entry of due) {
                let delivered = false;
                let error;
                try {
                    delivered = (await this.notificationSender(entry.event)) === true;
                    if (!delivered)
                        error = "notification sender returned false";
                }
                catch (err) {
                    error = err instanceof Error ? err.message : String(err);
                }
                if (delivered) {
                    entry.status = "delivered";
                    entry.deliveredAt = this.nowFn();
                    entry.lastError = undefined;
                    const monitor = this.monitors.get(entry.monitorId);
                    if (monitor) {
                        monitor.lastNotifiedState = entry.state;
                        monitor.lastNotifiedAt = entry.deliveredAt;
                    }
                }
                else {
                    entry.attempts += 1;
                    entry.lastError = error;
                    const backoff = Math.min(30_000 * Math.pow(2, Math.min(entry.attempts - 1, 5)), 15 * 60_000);
                    entry.nextAttemptAt = this.nowFn() + backoff;
                    console.warn(`[ConditionMonitor] Notification ${entry.id} for ${entry.monitorId} not delivered (attempt ${entry.attempts}); will retry: ${error}`);
                }
                // Persist the delivery outcome (durable record of success or retry).
                this.save();
            }
        }
        finally {
            this.flushing = false;
        }
    }
    async tick() {
        if (this.ticking)
            return;
        this.ticking = true;
        try {
            const now = this.nowFn();
            const due = Array.from(this.monitors.values()).filter((m) => m.status === "active" && m.nextPollAt <= now);
            // Probe due targets concurrently up to 5 at a time
            const batch = due.slice(0, 5);
            await Promise.all(batch.map(async (monitor) => {
                try {
                    const timeout = monitor.condition.maxLatencyMs
                        ? Math.max(monitor.condition.maxLatencyMs, 2000)
                        : 10000;
                    const result = await this.probeTarget(monitor.url, monitor.condition, timeout, {
                        headers: monitor.headers,
                    });
                    this.processResult(monitor, result);
                }
                catch (e) {
                    console.warn(`[ConditionMonitor] Probe error on ${monitor.id}:`, e);
                }
            }));
            if (batch.length > 0) {
                this.save();
            }
            await this.flushOutbox();
        }
        finally {
            this.ticking = false;
        }
    }
    /** Get monitors that are currently being probed */
    getActiveProbes() {
        return Array.from(this.activeProbes);
    }
    /** Force a check on all active monitors (for testing) */
    async forceCheckAll() {
        const results = [];
        for (const monitor of this.monitors.values()) {
            if (monitor.status === "active") {
                const result = await this.probeMonitor(monitor.id);
                if (result)
                    results.push(result);
            }
        }
        return results;
    }
}
export const defaultConditionMonitor = new ConditionMonitorManager();
