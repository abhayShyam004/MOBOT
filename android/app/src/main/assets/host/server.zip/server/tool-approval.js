// How much a tool call deserves a person's attention, and what to say when it
// does.
//
// The chat gate used to stop on every call that was not Full access, so one
// ordinary request ("create a notebook answering this PDF") opened eight
// Allow/Deny cards whose only explanation was the raw JSON argument. Routine
// workspace work is what the person already asked for by sending the task; a
// card per file write is not a security boundary, it is noise that trains
// people to tap Allow without reading.
//
// Three categories, and only the last two reach a human:
//   routine        work inside the task's own workspace: read, write, list,
//                  verify, register, and the validation commands that check
//                  a result. No card.
//   elevated       something that changes the machine or reaches the network:
//                  installing packages, unknown shell commands, browser and
//                  phone control. A card, with the reason named.
//   consequential  something that leaves the device or cannot be undone:
//                  external services (Composio/Drive/mail), git push, deploy,
//                  publish, purchases. A card that names the destination.
//
// An approval for one category never implies another: a notebook written
// locally says nothing about uploading it anywhere.
import { redactSecretsInText } from "../shared/redact.js";
import { assessShellCommand } from "./shell-policy.js";
/** `mcp__android_computer__workspace_write` → `workspace_write`. The generic
 * `mcp__<server>__` strip can't handle a server name with an underscore, which
 * is exactly the Android host's name. */
export function baseToolName(tool) {
    return tool
        .trim()
        .replace(/^mcp__(?:android_computer|android_browser|openmausbot-phone)__/i, "")
        .replace(/^mcp__[^_]+__/i, "")
        .replace(/^android_(?:computer|browser)_/i, "")
        .toLowerCase();
}
// Work inside the task's own workspace, and the bookkeeping that records it.
// This list is the whole of what the Android host's tools can do without a
// card, so it is deliberately explicit rather than prefix-matched: a new tool
// lands here only when someone decides it belongs here.
const ROUTINE_TOOLS = new Set([
    // workspace files
    "workspace_read",
    "workspace_list",
    "workspace_stat",
    "workspace_exists",
    "workspace_write",
    "workspace_append",
    "workspace_mkdir",
    "workspace_move",
    "workspace_copy",
    "workspace_delete",
    "workspace_grep",
    "workspace_read_file",
    "read_file",
    "write_file",
    "edit_file",
    "list_files",
    "glob",
    "grep",
    // the deliverable: check it, then attach it to this conversation
    "verify_file",
    "verify_image",
    "verify_artifact",
    "verify_service",
    "artifact_register",
    "artifact_list",
    "artifact_info",
    "artifact_read",
    "read_document_pages",
    // attached resources (already downloaded; inspecting them is local)
    "resource_list",
    "resource_inspect",
    "resource_artifact_info",
    "resource_extract_pdf",
    "resource_extract_pdf_text",
    "resource_extract_links",
    // the environment and the processes already running in it
    "environment_discover",
    "process_inspect",
    "process_logs",
    "process_list",
    "terminal_read",
    "terminal_resize",
    "terminal_list",
    // the project lifecycle the person asked for, and its own bookkeeping
    "project_create",
    "project_start",
    "project_list",
    "project_open",
    "project_read",
    "project_write",
    "project_patch",
    "project_delete",
    "project_rename",
    "project_run",
    "project_build",
    "project_lifecycle_status",
    "project_step_complete",
    "project_criterion_verify",
    "project_finish",
    "build_run",
    "build_status",
    "build_logs",
    "test_run",
    "test_status",
    "test_logs",
    "preview_start",
    "preview_status",
    "preview_logs",
    "preview_stop",
    "preview_restart",
    "repair_analyze_failure",
    "repair_run_cycle",
    "repair_status",
    "plan_create",
    "plan_status",
    "plan_step_start",
    "plan_step_complete",
    "plan_step_fail",
    "plan_replan",
    "plan_approval_checkpoint",
    "plan_approval_respond",
    "plan_verify_completion",
    "task_create",
    "task_status",
    "task_progress",
    "task_wait",
    "task_cancel",
    "task_complete",
    "task_resume",
    "task_approval_request",
    "task_approval_decide",
    // project configuration that is read, and its own git history (never a push)
    "environment_list",
    "project_git_status",
    "project_git_diff",
    "project_git_init",
    "project_git_commit",
    // describing the device's capabilities without touching them
    "device_capability_list",
    "device_capability_describe",
    "device_capability_health",
    "device_capability_risk",
]);
/** Device state, network, and anything that changes the machine. */
const ELEVATED_TOOLS = new Set([
    "browser_open",
    "browser_navigate",
    "browser_get_text",
    "browser_dom",
    "browser_click",
    "browser_type",
    "browser_eval",
    "browser_evaluate",
    "browser_screenshot",
    "browser_cookies",
    "browser_fill",
    "browser_press",
    "browser_hover",
    "browser_scroll",
    "browser_tabs",
    "browser_back",
    "browser_forward",
    "browser_close",
    "browser_persist",
    "browser_clear",
    "http_fetch",
    "web_search",
    "fetch",
    "websearch",
    "open_app",
    "tap",
    "tap_text",
    "swipe",
    "type_text",
    "clear_text",
    "press",
    "read_screen",
    "screenshot",
    "status",
    "list_apps",
    "phone_launch_app",
    "phone_tap",
    "phone_swipe",
    "phone_type_text",
    "phone_press_key",
    "phone_read_screen",
    "phone_take_screenshot",
    "phone_list_apps",
    "phone_restore_host",
    "device_capability_invoke",
    "environment_set",
    "environment_remove",
    "process_start",
    "process_stop",
    "process_restart",
    "open_interactive",
    "terminal_start",
    "terminal_write",
    "terminal_close",
    // Downloading fetches bytes from a network this task does not own; a local
    // inspect of what was already fetched stays routine above.
    "resource_fetch",
    "resource_download",
]);
/** Names that mean data leaves this device, whichever casing or namespace. */
const CONSEQUENTIAL_PATTERN = /composio|connector|integration|\bdrive\b|googledrive|gmail|calendar|sheets|slack|notion|jira|linear|\bdeploy|publish|release|purchase|payment|checkout|subscribe|upload|email_send|send_email|git_push|push_repo/i;
/** Shell commands that reach outside the workspace without being a plain
 * validation run. Ordered by severity: the first match wins. */
const CONSEQUENTIAL_COMMAND = [
    /\bgit\s+push\b/i,
    /\bgh\s+(?:release|repo\s+create|pr\s+create|api)\b/i,
    /\b(?:npm|pnpm|yarn)\s+publish\b/i,
    /\b(?:docker|podman)\s+push\b/i,
    /\b(?:vercel|netlify|flyctl|wrangler|firebase|surge)\s+(?:deploy|publish)\b/i,
    /\b(?:aws|gcloud|az|heroku)\s+\S+/i,
    /\b(?:curl|wget)\b[^|]*\|\s*(?:sh|bash|zsh)\b/i,
    /\bscp\b|\brsync\b.*@/i,
];
const ELEVATED_COMMAND = [
    /\b(?:sudo|doas|su\s+-)\b/i,
    /\b(?:apt|apt-get|dnf|yum|apk|brew|pacman)\s+(?:install|add|upgrade)\b/i,
    /\b(?:npm|pnpm|yarn|bun)\s+(?:install|add|i|ci)\b/i,
    /\b(?:pip|pip3|python3?\s+-m\s+pip)\s+install\b/i,
    /\b(?:gem|go|cargo|dotnet)\s+(?:install|add|get)\b/i,
    /\bgit\s+clone\b/i,
    /\b(?:chmod|chown|chgrp)\b/i,
    /\brm\s+-[a-z]*r[a-z]*\b/i,
    /\b(?:shutdown|reboot|mount|umount|systemctl)\b/i,
    /\b(?:curl|wget)\b/i,
    /\s\/(?:etc|usr|bin|sbin|system)\//,
];
/** Commands that only read or validate inside the workspace. */
const ROUTINE_BINARIES = new Set([
    "node", "npm", "pnpm", "npx", "yarn", "bun", "deno",
    "python", "python3", "pytest", "pip", "pip3", "uv",
    "cat", "ls", "head", "tail", "grep", "rg", "sed", "awk", "wc", "sort",
    "uniq", "tr", "cut", "tee", "touch", "mkdir", "cp", "mv", "diff", "file",
    "sha256sum", "md5sum", "jq", "echo", "printf", "test", "true", "false",
    "find", "stat", "pwd", "cd", "env", "which", "date", "zip", "unzip",
    "git", "tsc", "vitest", "eslint", "prettier",
    // shell builtins a validation run uses to ask about itself. `command -v x`
    // and `[ -f x ]` start a command line without running a program, and the
    // old allowlist treated that probe as an unknown binary.
    "command", "type", "hash", "basename", "dirname", "realpath", "readlink",
    "export", "set", "unset", "seq", "timeout", "id", "uname", "[", "[[",
]);
function normalizeCommand(value) {
    return typeof value === "string" ? value.trim().replace(/\s+/g, " ") : "";
}
function commandOf(args) {
    if (!args)
        return "";
    for (const key of ["command", "cmd", "script", "shell", "commandLine"]) {
        const value = normalizeCommand(args[key]);
        if (value)
            return value;
    }
    return "";
}
function pathOf(args) {
    if (!args)
        return undefined;
    for (const key of ["path", "filePath", "file", "target", "name", "outputPath"]) {
        const value = args[key];
        if (typeof value === "string" && value.trim())
            return value.trim();
    }
    return undefined;
}
/** Does this path escape every workspace root the task was given? */
function outsideWorkspaces(path, roots) {
    if (!path || path.startsWith("/") === false)
        return false;
    if (!roots || roots.length === 0)
        return false;
    return !roots.some((root) => path === root || path.startsWith(`${root}/`));
}
/** First token of a command, skipping env assignments and `cd x &&`. */
export function commandBinary(command) {
    let cleaned = command.replace(/^(?:[A-Za-z_][A-Za-z0-9_]*=\S*\s+)*/, "").trim();
    for (;;) {
        const cd = /^cd\s+\S+\s*(?:&&|;)\s*/i.exec(cleaned);
        if (!cd)
            break;
        cleaned = cleaned.slice(cd[0].length);
    }
    const firstSegment = cleaned.split(/&&|\|\||;|\|/)[0]?.trim() ?? "";
    const parts = firstSegment.split(/\s+/).filter(Boolean);
    return (parts[0] ?? "").replace(/^\.\//, "");
}
/** `cd` destinations that leave the task's own workspace are a change of
 * scope, so the command is judged on where it actually runs. */
function cdLeavesWorkspace(command, roots) {
    if (!roots || roots.length === 0)
        return false;
    const pattern = /(?:^|&&|;|\|\|)\s*cd\s+("[^"]*"|'[^']*'|\S+)/g;
    for (const match of command.matchAll(pattern)) {
        const dest = match[1].replace(/^["']|["']$/g, "");
        if (dest === "-" || dest.startsWith("~"))
            return true;
        if (dest.startsWith("/") && !roots.some((root) => dest === root || dest.startsWith(`${root}/`)))
            return true;
    }
    return false;
}
/** A path that a task may write: relative, or inside one of its workspaces. */
function isTaskPath(path, roots) {
    if (!path)
        return true;
    if (!path.startsWith("/"))
        return true;
    return !outsideWorkspaces(path, roots);
}
function cleanWorkspacePath(p, roots) {
    if (!p)
        return undefined;
    let clean = p;
    if (roots) {
        for (const root of roots) {
            if (clean === root)
                return "workspace";
            if (clean.startsWith(`${root}/`)) {
                clean = clean.slice(root.length + 1);
            }
        }
    }
    clean = clean.replace(/^\/data\/(?:user\/\d+|data)\/[^/]+\/files\/host\/(?:data\/)?(?:task-workspaces|workspaces)\/[^/]+\/?(?:data\/)?/, "");
    clean = clean.replace(/^\/data\/(?:user\/\d+|data)\/[^/]+\//, "");
    return clean || "workspace";
}
function sanitizePathString(s) {
    return s
        .replace(/\/data\/(?:user\/\d+|data)\/[^/\s'"]+\/files\/host\/(?:data\/)?(?:task-workspaces|workspaces)\/[^/\s'"]+\/?(?:data\/)?/gi, "")
        .replace(/\/data\/(?:user\/\d+|data)\/[^/\s'"]+\/?/gi, "");
}
/** Check whether arguments disclose credentials, private keys, or sensitive secrets. */
export function containsSensitiveData(input, depth = 0) {
    if (depth > 8 || input === null || input === undefined)
        return false;
    if (typeof input === "string") {
        if (redactSecretsInText(input) !== input)
            return true;
        if (/\b(?:password|passwd|private_key|id_rsa|secret_key|api_key)\s*[:=]/i.test(input))
            return true;
        if (/(?:~\/|\/root\/|\/home\/[^/]+\/)\.(?:ssh|gnupg|aws|config\/gcloud)/i.test(input))
            return true;
        return false;
    }
    if (Array.isArray(input)) {
        return input.some((item) => containsSensitiveData(item, depth + 1));
    }
    if (typeof input === "object") {
        for (const [key, value] of Object.entries(input)) {
            if (/password|passwd|secret|credential|token|api_?key/i.test(key)) {
                if (value && typeof value === "string" && value.length > 0)
                    return true;
            }
            if (containsSensitiveData(value, depth + 1))
                return true;
        }
    }
    return false;
}
export function assessToolCall(tool, args, context = {}) {
    const base = baseToolName(tool);
    const path = pathOf(args);
    const command = commandOf(args);
    if (base === "chief_of_staff_execute" || tool === "chief_of_staff_execute") {
        const taskId = String(args?.task_id || args?.taskId || "");
        return {
            risk: "consequential",
            action: `Execute Chief of Staff action${taskId ? ` for task ${taskId}` : ""}`,
            target: taskId || "Chief of Staff Action",
            leavesDevice: true,
            reversible: false,
            why: "This executes an external delegated action on connected personal services outside this device.",
        };
    }
    if (base === "chief_of_staff_email_send" || tool === "chief_of_staff_email_send") {
        const composerId = String(args?.composer_id || args?.composerId || "");
        return {
            risk: "consequential",
            action: `Send email${composerId ? ` for composer ${composerId}` : ""}`,
            target: composerId || "Chief of Staff Email Send",
            leavesDevice: true,
            reversible: false,
            why: "Sending an email delivers communication externally via Gmail and cannot be undone.",
        };
    }
    if (base === "chief_of_staff_email_save_draft" || tool === "chief_of_staff_email_save_draft") {
        const composerId = String(args?.composer_id || args?.composerId || "");
        return {
            risk: "consequential",
            action: `Save email draft${composerId ? ` for composer ${composerId}` : ""}`,
            target: composerId || "Chief of Staff Email Draft",
            leavesDevice: true,
            reversible: true,
            why: "This creates or updates an email draft on your connected Gmail account.",
        };
    }
    // Composio read-only metadata discovery: searching tools, fetching schemas,
    // or searching skills without sensitive parameters are routine operations.
    // They retrieve catalog definitions and do not modify external state or upload user files.
    const isComposioDiscovery = /composio.*search_tools$/i.test(tool) || /composio.*search_tools$/i.test(base) ||
        /composio.*get_tool_schemas$/i.test(tool) || /composio.*get_tool_schemas$/i.test(base) ||
        /composio.*search_skills$/i.test(tool) || /composio.*search_skills$/i.test(base);
    if (isComposioDiscovery) {
        const hasSensitive = containsSensitiveData(args);
        if (/get_tool_schemas/i.test(tool) || /get_tool_schemas/i.test(base)) {
            const slugs = Array.isArray(args?.tool_slugs) ? args.tool_slugs.join(", ") : undefined;
            return {
                risk: "routine",
                action: `Retrieve tool schemas from connected service${slugs ? ` (${slugs.slice(0, 100)})` : ""}`,
                target: slugs,
                leavesDevice: true,
                reversible: true,
                why: "This retrieves schema definitions for available tools without modifying any data.",
            };
        }
        if (hasSensitive) {
            return {
                risk: "consequential",
                action: "Search connected tools with sensitive parameters",
                target: "Connected service tool search",
                leavesDevice: true,
                reversible: false,
                why: "This tool search contains sensitive parameters or credentials that would leave this device.",
            };
        }
        const isSkills = /search_skills/i.test(tool) || /search_skills/i.test(base);
        return {
            risk: "routine",
            action: isSkills ? "Search skills catalog in connected service" : "Search available tools in connected service",
            target: "Connected service catalog search",
            leavesDevice: true,
            reversible: true,
            why: "This queries the connected service catalog for matching capabilities without modifying any data.",
        };
    }
    // External services first: a name that mentions Drive, Composio, a mailer or
    // a deploy target sends data off the device whatever else it does.
    if (CONSEQUENTIAL_PATTERN.test(tool) || CONSEQUENTIAL_PATTERN.test(base) || CONSEQUENTIAL_PATTERN.test(command)) {
        const service = /googledrive|\bdrive\b/i.test(`${tool} ${command}`)
            ? "Google Drive"
            : /composio|connector|integration/i.test(tool)
                ? "a connected service"
                : "an external service";
        return {
            risk: "consequential",
            action: `Send data to ${service}`,
            target: path ?? undefined,
            leavesDevice: true,
            reversible: false,
            why: `${service} is outside this device, and an upload cannot be taken back.`,
        };
    }
    if (/\b(?:git\s+push|publish|deploy|release|purchase)\b/i.test(command)) {
        return {
            risk: "consequential",
            action: `Run \`${command.slice(0, 120)}\``,
            target: command,
            leavesDevice: true,
            reversible: false,
            why: "This publishes work or spends money outside the workspace.",
        };
    }
    if (command) {
        const consequential = CONSEQUENTIAL_COMMAND.find((pattern) => pattern.test(command));
        if (consequential) {
            return {
                risk: "consequential",
                action: `Run \`${command.slice(0, 120)}\``,
                target: command,
                leavesDevice: true,
                reversible: false,
                why: "The command publishes or fetches from outside this device.",
            };
        }
        const elevated = ELEVATED_COMMAND.find((pattern) => pattern.test(command));
        if (elevated) {
            return {
                risk: "elevated",
                action: `Run \`${command.slice(0, 120)}\``,
                target: command,
                leavesDevice: false,
                reversible: true,
                why: "The command installs software or changes the machine beyond this task's files.",
            };
        }
        // What the command can reach, not what it starts with: `cat`, `ls` and
        // `node` are all routine words, and all three can name the app's credential
        // store or another project's files. Only paths decide that, so this runs
        // before the binary allow-list and can only raise the risk.
        const shell = assessShellCommand(command, {
            workspaceRoots: context.workspaceRoots,
            credentialExemptRoots: context.credentialExemptRoots,
        });
        if (shell.risk === "consequential") {
            return {
                risk: "consequential",
                action: `Read this app's private state with \`${command.slice(0, 120)}\``,
                target: shell.sensitivePaths[0],
                leavesDevice: false,
                reversible: false,
                why: shell.why ?? "The command reads the app's own credential store.",
            };
        }
        if (shell.risk === "elevated") {
            return {
                risk: "elevated",
                action: `Run \`${command.slice(0, 120)}\``,
                target: shell.escapingPaths[0] ?? command,
                leavesDevice: false,
                reversible: true,
                why: shell.why ?? "The command reaches outside this task's workspace.",
            };
        }
        if (cdLeavesWorkspace(command, context.workspaceRoots)) {
            return {
                risk: "elevated",
                action: `Run \`${command.slice(0, 120)}\``,
                target: command,
                leavesDevice: false,
                reversible: true,
                why: "The command changes directory outside this task's workspace.",
            };
        }
        const binary = commandBinary(command);
        if (!binary || !ROUTINE_BINARIES.has(binary)) {
            return {
                risk: "elevated",
                action: `Run \`${command.slice(0, 120)}\``,
                target: command,
                leavesDevice: false,
                reversible: true,
                why: `\`${binary || "that command"}\` is not one of the validation commands this app runs unattended.`,
            };
        }
        return {
            risk: "routine",
            action: `Run \`${command.slice(0, 120)}\` in this task's workspace`,
            target: command,
            leavesDevice: false,
            reversible: true,
        };
    }
    if (ROUTINE_TOOLS.has(base)) {
        const verb = base.startsWith("verify")
            ? "Check"
            : base === "artifact_register"
                ? "Attach"
                : /delete|remove/.test(base)
                    ? "Delete"
                    : /write|append|edit|mkdir|move|copy/.test(base)
                        ? "Write"
                        : "Read";
        const asset = base.startsWith("artifact") ? " in this conversation" : " in this task's workspace";
        const outside = !isTaskPath(path, context.workspaceRoots);
        const cleanP = cleanWorkspacePath(path, context.workspaceRoots);
        return {
            risk: outside ? "elevated" : "routine",
            action: `${verb} ${cleanP ? `\`${cleanP}\`` : "files"}${asset}`,
            target: cleanP,
            leavesDevice: false,
            reversible: !/delete|remove/.test(base),
            ...(outside
                ? { why: "The path is outside this task's workspace." }
                : {}),
        };
    }
    if (ELEVATED_TOOLS.has(base)) {
        return {
            risk: "elevated",
            action: base.startsWith("browser")
                ? "Use the browser on this device"
                : base.includes("screen") || base === "screenshot"
                    ? "Look at this phone's screen"
                    : `Use ${base.replace(/_/g, " ")} on this device`,
            target: path,
            leavesDevice: false,
            reversible: true,
            why: "This changes the phone's own state rather than the task's files.",
        };
    }
    // Unknown tools fail closed to a card rather than running unattended.
    return {
        risk: "elevated",
        action: `Use \`${tool}\``,
        target: path,
        leavesDevice: false,
        reversible: true,
        why: "This tool is not classified as workspace work.",
    };
}
/** Should this call stop for a person? Full access is the person's standing
 * grant, and a mass deletion stops even there — which auto-approve.ts already
 * enforces for the provider path, repeated here for the chat path. */
export function needsApproval(mode, assessment, options = {}) {
    if (options.massDeletion)
        return true;
    if (mode === "full")
        return false;
    return assessment.risk !== "routine";
}
/** What the card says. The first line is the action in plain words; the raw
 * argument follows, dimmed to a detail, because it is evidence rather than an
 * explanation. */
export function approvalSummary(assessment, rawPreview) {
    const lines = [sanitizePathString(assessment.action)];
    const facts = [];
    if (assessment.target && assessment.target !== assessment.action) {
        facts.push(`Target: ${sanitizePathString(assessment.target).slice(0, 200)}`);
    }
    facts.push(assessment.leavesDevice ? "Leaves this device: yes" : "Leaves this device: no");
    facts.push(assessment.reversible ? "Can be undone: yes" : "Can be undone: no");
    lines.push(facts.join(" · "));
    if (assessment.why)
        lines.push(sanitizePathString(assessment.why));
    const raw = (rawPreview ?? "").trim();
    if (raw && raw !== assessment.target) {
        const cleanRaw = sanitizePathString(raw);
        lines.push(`Arguments: ${cleanRaw.length > 1200 ? `${cleanRaw.slice(0, 1200)}…` : cleanRaw}`);
    }
    return lines.join("\n\n");
}
