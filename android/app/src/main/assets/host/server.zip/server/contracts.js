// Canonical harness contracts — ported from upstream
// (apps/server/src/provider/ProviderDriver.ts, Services/ProviderAdapter.ts,
// packages/contracts/src/{provider,providerInstance,providerRuntime}.ts),
// de-Effect-ed: Promises instead of Effect, listener callbacks instead of
// Stream. The shapes and names are kept so the two codebases stay mutually
// readable.
export class ProviderError extends Error {
    code;
    constructor(code, message, options) {
        super(message, options);
        this.name = "ProviderError";
        this.code = code;
    }
}
/** Variants are opaque provider IDs, not the cross-engine effort enum. */
export function isModelVariant(value) {
    return typeof value === "string" && value.length > 0 && value.length <= 256 &&
        value.trim() === value && !/\p{Cc}/u.test(value);
}
let eventCounter = 0;
export const newEventId = () => `ev-${Date.now().toString(36)}-${(eventCounter++).toString(36)}`;
export const newId = () => crypto.randomUUID();
