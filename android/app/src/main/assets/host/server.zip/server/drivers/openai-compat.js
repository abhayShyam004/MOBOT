import { createOpenAIChatRuntime } from "./openai-chat.js";
const DRIVER_KIND = "openai-compat";
const DEFAULT_IDLE_TIMEOUT_MS = 180_000;
const idleTimeoutMs = () => {
    const raw = process.env.OPENMAUS_OPENAI_COMPAT_IDLE_TIMEOUT_MS;
    if (!raw)
        return DEFAULT_IDLE_TIMEOUT_MS;
    const value = Number(raw);
    return Number.isSafeInteger(value) && value >= 1_000 && value <= 2_147_483_647 ? value : DEFAULT_IDLE_TIMEOUT_MS;
};
const DEFAULT_MODELS = {
    default: "meta-llama/llama-3.3-70b-instruct",
    options: [
        { id: "meta-llama/llama-3.3-70b-instruct", label: "Llama 3.3 70B (OpenRouter)", custom: true },
        { id: "llama-3.3-70b-versatile", label: "Llama 3.3 70B (Groq)", custom: true },
    ],
};
function isOpenRouterUrl(url) {
    try {
        const host = new URL(url).hostname.toLowerCase();
        return host === "openrouter.ai" || host.endsWith(".openrouter.ai");
    }
    catch {
        return false;
    }
}
function decodeConfig(raw) {
    const config = (raw ?? {});
    if (config.tools !== undefined && typeof config.tools !== "boolean")
        throw new Error("tools must be a boolean");
    const envUrl = process.env.OPENAI_COMPAT_URL;
    return {
        ...(config.tools !== undefined ? { tools: config.tools } : {}),
        url: (typeof config.url === "string" && config.url ? config.url : envUrl || "https://openrouter.ai/api/v1")
            .replace(/\/+$/, ""),
        apiKeyEnv: typeof config.apiKeyEnv === "string" && config.apiKeyEnv
            ? config.apiKeyEnv
            : "OPENAI_COMPAT_API_KEY",
        key: typeof config.key === "string" && config.key ? config.key : undefined,
        model: typeof config.model === "string" && config.model
            ? config.model
            : process.env.OPENAI_COMPAT_MODEL || undefined,
        // An explicit empty override disables inherited routing for an isolated
        // connection (CLI setup uses this). Absent still inherits the global pin.
        provider: typeof config.provider === "string"
            ? config.provider || undefined
            : process.env.OPENAI_COMPAT_PROVIDER || undefined,
    };
}
export const OpenAICompatDriver = {
    driverKind: DRIVER_KIND,
    metadata: {
        displayName: "OpenAI-compatible (OpenRouter / Groq)",
        supportsMultipleInstances: true,
        access: "custom",
    },
    models: DEFAULT_MODELS,
    install: {
        docsUrl: "https://openrouter.ai/keys",
        signInCommand: "add {\"openaiCompat\":{\"key\":\"sk-or-v1-…\"}} to ~/.openmausbot/config.json (or set OPENAI_COMPAT_API_KEY)",
        command: {
            darwin: "Get a free key at https://openrouter.ai/keys (or https://console.groq.com) then add it to ~/.openmausbot/config.json under openaiCompat.key",
            linux: "Get a free key at https://openrouter.ai/keys (or https://console.groq.com) then add it to ~/.openmausbot/config.json under openaiCompat.key",
            win32: "Get a free key at https://openrouter.ai/keys (or https://console.groq.com) then add it to %USERPROFILE%\\.openmausbot\\config.json under openaiCompat.key",
        },
    },
    decodeConfig,
    defaultConfig: () => decodeConfig({}),
    async create(input) {
        const { config } = input;
        const apiKey = config.key ??
            input.environment[config.apiKeyEnv] ??
            input.environment.OPENAI_COMPAT_API_KEY ??
            process.env[config.apiKeyEnv] ??
            process.env.OPENAI_COMPAT_API_KEY ??
            "";
        let catalog = config.model
            ? {
                default: config.model,
                options: DEFAULT_MODELS.options.some((model) => model.id === config.model)
                    ? DEFAULT_MODELS.options
                    : [{ id: config.model, label: config.model, custom: true }, ...DEFAULT_MODELS.options],
            }
            : DEFAULT_MODELS;
        const fetchModels = async () => {
            if (!apiKey)
                return;
            try {
                const response = await fetch(`${config.url}/models`, {
                    headers: { authorization: `Bearer ${apiKey}` },
                    signal: AbortSignal.timeout(8_000),
                });
                if (!response.ok)
                    return;
                const json = await response.json();
                const rows = Array.isArray(json) ? json : Array.isArray(json.data) ? json.data : [];
                const seen = new Set();
                const options = [];
                for (const row of rows) {
                    const id = typeof row.id === "string" ? row.id : "";
                    if (!id || seen.has(id))
                        continue;
                    seen.add(id);
                    options.push({
                        id,
                        label: typeof row.name === "string" && row.name.trim() ? row.name : id,
                        custom: true,
                    });
                }
                if (!options.length)
                    return;
                if (config.model && !options.some((model) => model.id === config.model)) {
                    options.unshift({ id: config.model, label: config.model, custom: true });
                }
                catalog = { default: config.model ?? options[0].id, options };
            }
            catch {
                // Catalog refresh is opportunistic; keep the seeded options.
            }
        };
        if (apiKey)
            void fetchModels();
        return createOpenAIChatRuntime({
            input,
            driverKind: DRIVER_KIND,
            apiKey,
            apiUrl: config.url,
            tools: config.tools,
            models: () => catalog,
            refreshModels: fetchModels,
            requestBody: (model, messages, stream) => ({
                model,
                messages,
                stream,
                stream_options: stream ? { include_usage: true } : undefined,
                ...(config.provider && isOpenRouterUrl(config.url)
                    ? { provider: { order: [config.provider], allow_fallbacks: false } }
                    : {}),
            }),
            httpErrorLabel: "upstream",
            missingKeyError: `no API key — set ${config.apiKeyEnv} or add it to the instance config`,
            unavailableReason: `no API key — set ${config.apiKeyEnv} or add it to the instance config`,
            timeoutMs: idleTimeoutMs(),
            // The runtime only retries at all once a scale is supplied, and this
            // endpoint was the one driver left without: Grok passed it, MiniMax and
            // this driver did not, so a single 429 from a router — the ordinary way
            // a shared or free model says "not this second" — ended the turn as
            // `upstream HTTP 429: {"error":…}` in the conversation, with no wait
            // and no second try. Rate limiting is not an exotic failure for a
            // gateway onto someone else's quota; it is the expected one.
            retryScale: Number(process.env.FAKE_OPENAI_COMPAT_RETRY_SCALE ?? "1"),
            reasoning: true,
            billing: "metered",
            includeUsageInCompleted: true,
            nativeLog: {
                source: "openai-compat.chat.completions",
                outgoing: (_turn, messages, model) => ({ model, messageCount: messages.length }),
                incoming: ({ text, reasoning, usage }) => ({
                    textLength: text.length,
                    reasoningLength: reasoning.length,
                    usage,
                }),
            },
        });
    },
};
