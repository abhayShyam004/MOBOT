// One deadline for a whole retry sequence.
//
// The per-attempt deadlines in `provider-deadline.ts` bound one request. The
// retry loop bounds how many of those a person can be made to wait through: a
// provider that never answers used to cost three connect budgets (3 x 30s plus
// backoff ≈ 94s), and a provider that never starts its answer cost three
// first-token budgets (≈ 229s). Bounded, but not predictable, and long enough
// that the person has already decided the app is broken.
//
// So the sequence gets one clock. It starts with the first attempt, it is
// spent by attempts and backoff alike, and it never restarts between them.
//
// What it does *not* do is shorten a working answer. The budget is spent only
// while nothing is arriving: waiting for a connection, waiting for a first
// token, and the pause between retries. Those phases are clamped to whatever
// budget is left, and no new attempt starts when the budget is gone. An
// attempt that starts streaming keeps the ordinary idle and call budgets — a
// response that is working, just slowly, is never cut off because retries used
// up the sequence's clock (`OMB_PROVIDER_RETRY_BUDGET_MS`).
import { humanDuration, ProviderTimeoutError, } from "./provider-deadline.js";
/** Three connect budgets plus backoff, which is what the old loop could cost. */
export const DEFAULT_PROVIDER_RETRY_BUDGET_MS = 120_000;
export const PROVIDER_RETRY_BUDGET_ENV = "OMB_PROVIDER_RETRY_BUDGET_MS";
/** Below this there is no time to learn anything from another attempt, so a
 *  sequence ends instead of starting one it cannot watch. */
export const MIN_RETRY_ATTEMPT_MS = 1_000;
export function resolveProviderRetryBudget(environment = process.env) {
    const raw = environment[PROVIDER_RETRY_BUDGET_ENV];
    if (!raw)
        return DEFAULT_PROVIDER_RETRY_BUDGET_MS;
    const value = Number(raw);
    if (!Number.isFinite(value) || value <= 0)
        return DEFAULT_PROVIDER_RETRY_BUDGET_MS;
    return Math.round(value);
}
/**
 * Start the clock. `now` is injectable so tests can spend the budget without
 * sleeping, and it must be monotonic in production — a phone whose clock is
 * corrected mid-turn must not gain or lose retry time.
 */
export function createProviderRetryBudget(limitMs = DEFAULT_PROVIDER_RETRY_BUDGET_MS, now = () => performance.now()) {
    const startedAt = now();
    const remainingMs = () => Math.max(0, limitMs - (now() - startedAt));
    return {
        limitMs,
        usedMs: () => Math.max(0, now() - startedAt),
        remainingMs,
        allowsAnotherAttempt: () => remainingMs() >= MIN_RETRY_ATTEMPT_MS,
        policyForAttempt(policy) {
            const left = remainingMs();
            if (left <= 0)
                return policy;
            return {
                ...policy,
                connectTimeoutMs: Math.min(policy.connectTimeoutMs, left),
                firstTokenTimeoutMs: Math.min(policy.firstTokenTimeoutMs, left),
            };
        },
    };
}
/**
 * The failure a sequence ends with when the budget runs out.
 *
 * It keeps the last phase's own sentence — that is what the person can act on —
 * and says plainly that retrying stopped because the total was used up. A
 * timeout keeps its `timeout` classification, so the card does not change kind;
 * the extra sentence is what says "MOBOT stopped retrying", rather than
 * pretending the last attempt was the whole story.
 */
export class ProviderRetryBudgetError extends Error {
    budgetMs;
    attempts;
    lastError;
    constructor(lastError, budgetMs, attempts) {
        const budget = humanDuration(budgetMs);
        const timedOut = lastError instanceof ProviderTimeoutError;
        const phaseSentence = timedOut ? `${lastError.message} ` : "";
        // A timeout's own sentence already says what went wrong, so repeating the
        // error at the end would duplicate it. Any other last error comes along so
        // the classification stays truthful (a rate limit is not a timeout) — the
        // card still shows its own copy, never this text.
        const detail = timedOut ? "" : ` Last attempt: ${lastError.message}`;
        super(`${phaseSentence}Retrying stopped after ${budget}: the retry budget for this request was used up.${detail}`);
        this.name = "ProviderRetryBudgetError";
        this.budgetMs = budgetMs;
        this.attempts = attempts;
        this.lastError = lastError;
    }
}
/** Whether this error means "the sequence stopped retrying", for logging and
 *  for the card's phrase. */
export function isRetryBudgetExhausted(error) {
    return error instanceof ProviderRetryBudgetError;
}
