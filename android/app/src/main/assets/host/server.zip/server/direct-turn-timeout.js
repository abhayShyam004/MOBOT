// Direct turn active-work budget and deadline enforcement.
//
// NOT WIRED. Nothing imports this module: no absolute per-turn budget runs in
// the direct chat path today, and the audit that reviewed it recommended
// against wiring one at the ten-minute default — it would cut legitimate
// installs and builds on a phone. The provider call itself is bounded
// (server/provider-deadline.ts), and the 1:1 stall watchdog already stops a
// turn that has been silent for 20 minutes while exempting turns parked on a
// person. See provider_timeout_audit_report.md before integrating this.
//
// Like room turns, counts active work time rather than wall-clock time:
// the clock holds while the turn is waiting on a human decision
// (approval cards or ask_user question cards).
// When the budget expires, the turn is cleanly interrupted, resources
// cleaned up, and the durable journal settles to "failed".
export const DEFAULT_DIRECT_TURN_TIMEOUT_MINUTES = 10;
export const MIN_DIRECT_TURN_TIMEOUT_MINUTES = 1;
export const MAX_DIRECT_TURN_TIMEOUT_MINUTES = 60;
export function directTurnTimeoutMs(minutes) {
    return Math.max(MIN_DIRECT_TURN_TIMEOUT_MINUTES, Math.min(MAX_DIRECT_TURN_TIMEOUT_MINUTES, minutes)) * 60_000;
}
export function directTurnTimeoutMinutesFromEnv() {
    const envVal = process.env.OMB_DIRECT_TURN_TIMEOUT_MINUTES;
    if (!envVal)
        return DEFAULT_DIRECT_TURN_TIMEOUT_MINUTES;
    const num = Number(envVal);
    if (!Number.isFinite(num) || num <= 0)
        return DEFAULT_DIRECT_TURN_TIMEOUT_MINUTES;
    return Math.max(MIN_DIRECT_TURN_TIMEOUT_MINUTES, Math.min(MAX_DIRECT_TURN_TIMEOUT_MINUTES, Math.round(num)));
}
export class DirectTurnDeadline {
    remainingMs;
    timer = null;
    openRequests = 0;
    stopped = false;
    fired = false;
    armedAt = 0;
    fire;
    constructor(minutes, fire) {
        this.remainingMs = directTurnTimeoutMs(minutes);
        this.fire = fire;
    }
    /** Begin counting down the work budget. */
    start() {
        this.arm();
    }
    /**
     * Hold the clock while waiting on human action (approval cards, ask_user choices).
     * Request pairings clamp at zero.
     */
    setWaitingOnHuman(waiting) {
        if (this.stopped || this.fired)
            return;
        if (waiting) {
            const wasIdle = this.openRequests === 0;
            this.openRequests += 1;
            if (wasIdle)
                this.hold();
        }
        else if (this.openRequests > 0) {
            this.openRequests -= 1;
            if (this.openRequests === 0)
                this.arm();
        }
    }
    /** The turn settled or was stopped — cancel timer. Idempotent. */
    stop() {
        this.stopped = true;
        if (this.timer !== null) {
            clearTimeout(this.timer);
            this.timer = null;
        }
    }
    hold() {
        if (this.timer === null)
            return;
        this.remainingMs -= Date.now() - this.armedAt;
        clearTimeout(this.timer);
        this.timer = null;
        if (this.remainingMs <= 0)
            this.expired();
    }
    arm() {
        if (this.stopped || this.fired || this.openRequests > 0)
            return;
        if (this.remainingMs <= 0) {
            this.expired();
            return;
        }
        this.armedAt = Date.now();
        this.timer = setTimeout(() => {
            this.timer = null;
            this.expired();
        }, this.remainingMs);
        this.timer.unref?.();
    }
    expired() {
        if (this.stopped || this.fired)
            return;
        this.fired = true;
        this.fire();
    }
}
export function directTurnTimeoutMessage(minutes) {
    const unit = minutes === 1 ? "minute" : "minutes";
    return `This turn exceeded its ${minutes} ${unit} active execution deadline and was stopped. Ask for the change in smaller pieces, then retry.`;
}
