import { loadConfig } from "../config.js";
import { connectMcpEndpoint } from "../composio.js";
export class ComposioTransportClient {
    consumerKey;
    endpoint;
    constructor(consumerKey, endpoint) {
        this.consumerKey = consumerKey;
        this.endpoint = endpoint ?? connectMcpEndpoint();
    }
    async callTool(name, args) {
        try {
            const res = await fetch(this.endpoint, {
                method: "POST",
                headers: {
                    "content-type": "application/json",
                    accept: "application/json, text/event-stream",
                    "x-consumer-api-key": this.consumerKey,
                },
                body: JSON.stringify({
                    jsonrpc: "2.0",
                    id: Date.now(),
                    method: "tools/call",
                    params: {
                        name: "COMPOSIO_MULTI_EXECUTE_TOOL",
                        arguments: {
                            tools: [{ tool_slug: name, arguments: args }],
                        },
                    },
                }),
                signal: AbortSignal.timeout(20_000),
            });
            if (!res.ok) {
                return { ok: false, error: `Composio HTTP ${res.status}` };
            }
            const text = await res.text();
            const frames = text
                .split(/\r?\n/)
                .filter((line) => line.startsWith("data:"))
                .map((line) => line.slice(5).trim())
                .filter((line) => line && line !== "[DONE]")
                .map((line) => {
                try {
                    return JSON.parse(line);
                }
                catch {
                    return null;
                }
            })
                .filter(Boolean);
            const lastFrame = frames.at(-1);
            const contentText = lastFrame?.result?.content?.[0]?.text;
            if (!contentText) {
                return { ok: false, error: "Empty or unrecognized response from Composio transport" };
            }
            const parsed = JSON.parse(contentText);
            const toolResult = parsed?.data?.results?.[0];
            if (!toolResult) {
                return { ok: false, error: parsed?.error ?? "No tool result in response" };
            }
            if (toolResult.error) {
                return { ok: false, error: toolResult.error };
            }
            return { ok: true, data: toolResult.response?.data ?? toolResult.response };
        }
        catch (err) {
            return { ok: false, error: err instanceof Error ? err.message : String(err) };
        }
    }
    async queryConnectionStatuses(slugs) {
        try {
            const res = await fetch(this.endpoint, {
                method: "POST",
                headers: {
                    "content-type": "application/json",
                    accept: "application/json, text/event-stream",
                    "x-consumer-api-key": this.consumerKey,
                },
                body: JSON.stringify({
                    jsonrpc: "2.0",
                    id: Date.now(),
                    method: "tools/call",
                    params: {
                        name: "COMPOSIO_MANAGE_CONNECTIONS",
                        arguments: {
                            toolkits: slugs.map((name) => ({ name, action: "list" })),
                        },
                    },
                }),
                signal: AbortSignal.timeout(15_000),
            });
            if (!res.ok)
                return {};
            const text = await res.text();
            const lines = text
                .split(/\r?\n/)
                .filter((l) => l.startsWith("data:"))
                .map((l) => l.slice(5).trim());
            const last = lines.at(-1);
            if (!last)
                return {};
            const parsed = JSON.parse(last);
            const content = parsed?.result?.content?.[0]?.text;
            if (!content)
                return {};
            const inner = JSON.parse(content);
            const results = inner?.data?.results ?? {};
            const out = {};
            for (const slug of slugs) {
                const item = results[slug];
                if (!item)
                    continue;
                const accounts = Array.isArray(item.accounts) ? item.accounts : [];
                const activeAcc = accounts.find((a) => /^active$/i.test(a.status));
                const status = String(item.status || "UNKNOWN").toUpperCase();
                out[slug] = {
                    status,
                    active: Boolean(activeAcc) || /^active$/i.test(status),
                    account: activeAcc?.id,
                };
            }
            return out;
        }
        catch {
            return {};
        }
    }
}
export class PersonalContextAggregator {
    transport;
    cfg;
    constructor(opts) {
        this.transport = opts?.transport;
        this.cfg = opts?.config;
    }
    resolveTransport() {
        if (this.transport)
            return this.transport;
        const cfg = this.cfg ?? loadConfig();
        const apiKey = cfg.composio?.apiKey;
        if (apiKey && apiKey.startsWith("ck_")) {
            this.transport = new ComposioTransportClient(apiKey, cfg.composio?.mcpUrl);
            return this.transport;
        }
        return undefined;
    }
    async aggregate() {
        const items = [];
        const sourcesSummary = {
            googlecalendar: { status: "empty", count: 0 },
            gmail: { status: "disconnected", count: 0 },
            googledrive: { status: "empty", count: 0 },
            github: { status: "empty", count: 0 },
            workspace: { status: "empty", count: 0 },
        };
        const client = this.resolveTransport();
        if (!client) {
            sourcesSummary.googlecalendar = { status: "disconnected", count: 0, details: "No Composio Connect configuration found" };
            sourcesSummary.gmail = { status: "disconnected", count: 0, details: "No Composio Connect configuration found" };
            return { items, sourcesSummary };
        }
        // 1. Google Calendar
        try {
            const calRes = await client.callTool("GOOGLECALENDAR_EVENTS_LIST", {
                calendarId: "primary",
                maxResults: 10,
                singleEvents: true,
                orderBy: "startTime",
                timeMin: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
            });
            if (calRes.ok && calRes.data) {
                const events = Array.isArray(calRes.data.items) ? calRes.data.items : [];
                sourcesSummary.googlecalendar = {
                    status: "active",
                    count: events.length,
                    account: calRes.data.summary,
                };
                for (const ev of events) {
                    const start = ev.start?.dateTime || ev.start?.date || "";
                    const end = ev.end?.dateTime || ev.end?.date || "";
                    const attendees = Array.isArray(ev.attendees) ? ev.attendees : [];
                    const selfAttendee = attendees.find((a) => a.self === true);
                    const organizer = ev.organizer?.email || ev.creator?.email || "Unknown";
                    items.push({
                        id: `gcal_${ev.id}`,
                        source: "googlecalendar",
                        timestamp: start || ev.updated || new Date().toISOString(),
                        title: ev.summary || "(No Title)",
                        content: ev.description || "",
                        metadata: {
                            eventId: ev.id,
                            htmlLink: ev.htmlLink,
                            location: ev.location,
                            start,
                            end,
                            status: ev.status,
                            responseStatus: selfAttendee?.responseStatus || "accepted",
                            organizer,
                            attendees,
                            conferenceData: ev.conferenceData,
                            attachments: ev.attachments,
                        },
                        verified: true,
                    });
                }
            }
            else {
                sourcesSummary.googlecalendar = {
                    status: "error",
                    count: 0,
                    details: calRes.error || "Failed to query Google Calendar",
                };
            }
        }
        catch (err) {
            sourcesSummary.googlecalendar = {
                status: "error",
                count: 0,
                details: err instanceof Error ? err.message : String(err),
            };
        }
        // 2. Gmail
        // Notice: Gmail requires active connection.
        try {
            const gmailRes = await client.callTool("GMAIL_LIST_THREADS", {
                user_id: "me",
                max_results: 5,
            });
            if (gmailRes.ok && gmailRes.data) {
                const threads = Array.isArray(gmailRes.data.threads) ? gmailRes.data.threads : [];
                sourcesSummary.gmail = {
                    status: "active",
                    count: threads.length,
                };
                for (let i = 0; i < threads.length; i++) {
                    const th = threads[i];
                    let sender;
                    let subject;
                    let timestamp;
                    // For top threads, enrich with message details (sender, subject, timestamp)
                    if (i < 2) {
                        try {
                            const msgRes = await client.callTool("GMAIL_FETCH_MESSAGE_BY_MESSAGE_ID", {
                                user_id: "me",
                                message_id: th.id,
                            });
                            if (msgRes.ok && msgRes.data) {
                                sender = msgRes.data.sender;
                                subject = msgRes.data.subject;
                                timestamp = msgRes.data.messageTimestamp;
                            }
                        }
                        catch {
                            // fallback to snippet
                        }
                    }
                    items.push({
                        id: `gmail_${th.id}`,
                        source: "gmail",
                        timestamp: timestamp || th.snippetDate || new Date().toISOString(),
                        title: subject || th.subject || th.snippet?.slice(0, 50) || "Email Thread",
                        content: th.snippet || "",
                        metadata: {
                            threadId: th.id,
                            historyId: th.historyId,
                            sender,
                            subject,
                        },
                        verified: true,
                    });
                }
            }
            else {
                const errMsg = gmailRes.error || "";
                const isAuthError = /No active connection|not connected|unauthorized|initiat/i.test(errMsg);
                sourcesSummary.gmail = {
                    status: isAuthError ? "disconnected" : "error",
                    count: 0,
                    details: errMsg || "Gmail not connected",
                };
            }
        }
        catch (err) {
            sourcesSummary.gmail = {
                status: "disconnected",
                count: 0,
                details: err instanceof Error ? err.message : String(err),
            };
        }
        // 3. Google Drive
        try {
            const driveRes = await client.callTool("GOOGLEDRIVE_FIND_FILE", {
                page_size: 10,
            });
            if (driveRes.ok && driveRes.data) {
                const files = Array.isArray(driveRes.data.files) ? driveRes.data.files : [];
                sourcesSummary.googledrive = {
                    status: "active",
                    count: files.length,
                };
                for (const file of files) {
                    items.push({
                        id: `gdrive_${file.id}`,
                        source: "googledrive",
                        timestamp: file.modifiedTime || new Date().toISOString(),
                        title: file.name || "Untitled Document",
                        content: `Drive file: ${file.name} (MIME: ${file.mimeType || "unknown"})`,
                        metadata: {
                            fileId: file.id,
                            name: file.name,
                            mimeType: file.mimeType,
                            modifiedTime: file.modifiedTime,
                            webViewLink: file.webViewLink || file.display_url,
                            webContentLink: file.webContentLink,
                            size: file.size ? Number(file.size) : undefined,
                        },
                        verified: true,
                    });
                }
            }
            else {
                const errMsg = driveRes.error || "";
                const isAuthError = /No active connection|not connected|unauthorized|initiat/i.test(errMsg);
                sourcesSummary.googledrive = {
                    status: isAuthError ? "disconnected" : "empty",
                    count: 0,
                    details: errMsg,
                };
            }
        }
        catch (err) {
            sourcesSummary.googledrive = {
                status: "disconnected",
                count: 0,
                details: err instanceof Error ? err.message : String(err),
            };
        }
        return { items, sourcesSummary };
    }
}
