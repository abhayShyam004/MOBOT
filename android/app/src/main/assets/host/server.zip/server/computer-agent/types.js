// Types and contracts for General-Purpose Computer Agent (master_prompt_02.md)
export {};
