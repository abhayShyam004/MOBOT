export { resolveBotIdentity, compileBotIdentityPrompt, } from "../shared/bot-identity.js";
