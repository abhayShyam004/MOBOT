/**
 * Authoritative Specialization System for MOBOT (Phase 31).
 *
 * Defines the core SpecializationProfile data contract, role defaults,
 * tool affinity, boundary enforcement, and heuristic validation engines.
 */
import { z } from "zod";
export const ROLE_HEURISTIC_DEFAULTS = {
    researcher: {
        defaultSearchDepth: "deep",
        minimumSourceCitations: 2,
        requireAutomatedTestRun: false,
        requireDependencyOrdering: false,
    },
    coder: {
        defaultSearchDepth: "shallow",
        minimumSourceCitations: undefined,
        requireAutomatedTestRun: true,
        requireDependencyOrdering: false,
    },
    planner: {
        defaultSearchDepth: "shallow",
        minimumSourceCitations: undefined,
        requireAutomatedTestRun: false,
        requireDependencyOrdering: true,
    },
    generalist: {
        defaultSearchDepth: "shallow",
        minimumSourceCitations: undefined,
        requireAutomatedTestRun: false,
        requireDependencyOrdering: false,
    },
};
export const specializationProfileSchema = z.object({
    roleId: z.enum(["researcher", "coder", "planner", "generalist"]),
    heuristics: z.object({
        minimumSourceCitations: z.number().int().min(0).optional(),
        requireAutomatedTestRun: z.boolean().optional(),
        requireDependencyOrdering: z.boolean().optional(),
        defaultSearchDepth: z.enum(["shallow", "deep", "exhaustive"]),
    }),
    customPromptInjections: z.array(z.string()),
});
export const specializationDiagnostics = [];
/**
 * Resolves a default SpecializationProfile for a canonical role identifier.
 */
export function defaultSpecializationProfile(roleId) {
    return {
        roleId,
        heuristics: { ...ROLE_HEURISTIC_DEFAULTS[roleId] },
        customPromptInjections: [],
    };
}
/**
 * Normalizes and validates a role identifier safely.
 * Unknown or malformed roles fall back to "generalist" with an observable diagnostic entry.
 */
export function normalizeRoleId(raw) {
    if (typeof raw !== "string" || !raw.trim()) {
        return { roleId: "generalist", valid: false };
    }
    const clean = raw.trim().toLowerCase();
    if (clean === "researcher" || clean === "coder" || clean === "planner" || clean === "generalist") {
        return { roleId: clean, valid: true };
    }
    // Record diagnostic
    specializationDiagnostics.push({
        invalidRoleId: raw,
        reason: `Unknown role identifier "${raw}" is not supported; falling back to "generalist".`,
        fallback: "generalist",
        timestamp: Date.now(),
    });
    return { roleId: "generalist", valid: false };
}
/**
 * Resolves the final specialization profile by combining:
 * 1. Role defaults
 * 2. Explicit per-bot heuristic configuration
 * 3. Task-specific execution requirements (which can strengthen verification, but never weaken safety)
 */
export function resolveSpecializationProfile(input, taskRequirements) {
    const normalizedInput = typeof input === "string" ? { roleId: input } : input;
    if (!normalizedInput || typeof normalizedInput !== "object") {
        const base = defaultSpecializationProfile("generalist");
        if (taskRequirements) {
            overlayTaskRequirements(base.heuristics, taskRequirements);
        }
        return base;
    }
    const raw = normalizedInput;
    const { roleId } = normalizeRoleId(raw.roleId);
    const defaults = ROLE_HEURISTIC_DEFAULTS[roleId];
    const resolvedHeuristics = {
        defaultSearchDepth: defaults.defaultSearchDepth,
        minimumSourceCitations: defaults.minimumSourceCitations,
        requireAutomatedTestRun: defaults.requireAutomatedTestRun,
        requireDependencyOrdering: defaults.requireDependencyOrdering,
    };
    // Overlay explicit per-bot heuristic overrides
    if (raw.heuristics && typeof raw.heuristics === "object") {
        const h = raw.heuristics;
        if (h.defaultSearchDepth === "shallow" || h.defaultSearchDepth === "deep" || h.defaultSearchDepth === "exhaustive") {
            resolvedHeuristics.defaultSearchDepth = h.defaultSearchDepth;
        }
        if (typeof h.minimumSourceCitations === "number" && Number.isFinite(h.minimumSourceCitations) && h.minimumSourceCitations >= 0) {
            resolvedHeuristics.minimumSourceCitations = Math.floor(h.minimumSourceCitations);
        }
        if (typeof h.requireAutomatedTestRun === "boolean") {
            resolvedHeuristics.requireAutomatedTestRun = h.requireAutomatedTestRun;
        }
        if (typeof h.requireDependencyOrdering === "boolean") {
            resolvedHeuristics.requireDependencyOrdering = h.requireDependencyOrdering;
        }
    }
    // Overlay task-specific requirements
    if (taskRequirements) {
        overlayTaskRequirements(resolvedHeuristics, taskRequirements);
    }
    // Preserve custom prompt injections in exact order
    const customPromptInjections = [];
    if (Array.isArray(raw.customPromptInjections)) {
        for (const injection of raw.customPromptInjections) {
            if (typeof injection === "string" && injection.trim()) {
                customPromptInjections.push(injection.trim());
            }
        }
    }
    return {
        roleId,
        heuristics: resolvedHeuristics,
        customPromptInjections,
    };
}
function overlayTaskRequirements(target, req) {
    if (req.requireAutomatedTestRun === true) {
        target.requireAutomatedTestRun = true;
    }
    if (req.requireDependencyOrdering === true) {
        target.requireDependencyOrdering = true;
    }
    if (typeof req.minimumSourceCitations === "number" && req.minimumSourceCitations >= 0) {
        target.minimumSourceCitations = Math.max(target.minimumSourceCitations ?? 0, req.minimumSourceCitations);
    }
    if (req.defaultSearchDepth) {
        const priority = { shallow: 1, deep: 2, exhaustive: 3 };
        if (priority[req.defaultSearchDepth] > priority[target.defaultSearchDepth]) {
            target.defaultSearchDepth = req.defaultSearchDepth;
        }
    }
}
// ---------------------------------------------------------------------------
// Tool Boundaries & ERR_SPECIALIST_BOUNDARY_OVERSTEP
// ---------------------------------------------------------------------------
export const ERR_SPECIALIST_BOUNDARY_OVERSTEP = "ERR_SPECIALIST_BOUNDARY_OVERSTEP";
export class SpecialistBoundaryOverstepError extends Error {
    code = ERR_SPECIALIST_BOUNDARY_OVERSTEP;
    roleId;
    attemptedCapability;
    toolName;
    recoverySuggestion;
    constructor(roleId, toolName, attemptedCapability, recoverySuggestion) {
        const suggestion = recoverySuggestion ??
            (roleId === "researcher"
                ? "Researcher specialization cannot modify files or execute shell code; delegate this implementation task to a Coder specialist."
                : roleId === "planner"
                    ? "Planner specialization can formulate plans and dependency trees but cannot directly execute code; delegate code execution to a Coder specialist."
                    : `Operation "${toolName}" is prohibited under ${roleId} specialization.`);
        super(`${ERR_SPECIALIST_BOUNDARY_OVERSTEP}: Specialist "${roleId}" is prohibited from invoking "${toolName}" (${attemptedCapability}). ${suggestion}`);
        this.name = "SpecialistBoundaryOverstepError";
        this.roleId = roleId;
        this.toolName = toolName;
        this.attemptedCapability = attemptedCapability;
        this.recoverySuggestion = suggestion;
    }
    toJSON() {
        return {
            code: this.code,
            roleId: this.roleId,
            attemptedCapability: this.attemptedCapability,
            toolName: this.toolName,
            reason: this.message,
            recoverySuggestion: this.recoverySuggestion,
        };
    }
}
export function classifyToolCapability(toolName, args) {
    const norm = toolName.toLowerCase().replace(/^mcp__.*?__/, "").replace(/^(android_computer|android_browser)_/, "");
    // 1. Shell & Terminal command execution
    const shellPattern = /^(bash|sh|terminal|shell|exec|run_command|pty|process|cmd|spawn|terminal_exec|terminal_write|run_shell|project_run|dweb_opencode_run|nushell)/i;
    let isShellOrTerminal = shellPattern.test(norm) ||
        norm.includes("exec_command") ||
        norm.includes("run_shell") ||
        norm.includes("terminal_exec") ||
        norm.includes("shell_exec") ||
        norm === "execute" ||
        norm === "runner";
    // Check if arguments contain wrapped shell execution payloads
    if (args && typeof args === "object") {
        if ((args.command && typeof args.command === "string") ||
            (args.cmd && typeof args.cmd === "string") ||
            (args.script && typeof args.script === "string")) {
            const cmdStr = String(args.command || args.cmd || args.script).trim().toLowerCase();
            if (/^(bash|sh|zsh|git|rm|mv|cp|cat|node|npm|pnpm|python|python3|pip|vitest|curl|wget)\b/.test(cmdStr) ||
                cmdStr.includes("&&") ||
                cmdStr.includes("||") ||
                cmdStr.includes("|") ||
                cmdStr.includes(">")) {
                isShellOrTerminal = true;
            }
        }
    }
    // 2. Read-only filesystem operations (Allowed for Researcher/Planner)
    const isReadOnlyFilesystem = /^(read_file|file_read|cat_file|get_file|view_image|project_read|workspace_read|artifact_read|list_directory|list_files|inspect_file|read_document_pages|read_page|read_screen|fx_read|session_read|readfile|read_notes)/i.test(norm) ||
        norm.includes("read_file") ||
        norm.includes("project_read") ||
        norm.includes("list_directory") ||
        norm.includes("workspace_read") ||
        norm.includes("read_document");
    // 3. Code editing, file modification, file deletion, and patching (MUTATION - Prohibited for Researcher/Planner)
    const isCodeEditingOrMutation = !isReadOnlyFilesystem &&
        (/^(file_write|file_edit|edit_file|write_file|patch|code_refactor|refactor|modify_code|apply_diff|project_write|project_patch|project_create|project_delete|workspace_write|artifact_write|file_delete|patch_file|remote_write|audit_write|write|edit)/i.test(norm) ||
            norm.includes("write_file") ||
            norm.includes("edit_file") ||
            norm.includes("patch_file") ||
            norm.includes("refactor_code") ||
            norm.includes("modify_code") ||
            norm.includes("apply_diff") ||
            norm.includes("project_write") ||
            norm.includes("project_patch") ||
            norm.includes("project_create") ||
            norm.includes("project_delete") ||
            norm.includes("workspace_write") ||
            norm.includes("file_delete"));
    // 4. Git inspection (read-only)
    const isGitInspection = /^(git_status|git_diff|git_log|git_show|git_branch|project_git_status|project_git_diff)/i.test(norm) ||
        norm.includes("git_status") ||
        norm.includes("git_diff") ||
        norm.includes("git_log") ||
        norm.includes("git_show") ||
        norm.includes("git_branch");
    // 5. Git mutation (modifying version control state)
    const isGitMutation = /^(git_commit|git_push|git_stage|git_add|git_checkout|git_reset|project_git_commit|project_git_init)/i.test(norm) ||
        norm.includes("git_commit") ||
        norm.includes("git_push") ||
        norm.includes("git_stage") ||
        norm.includes("git_reset") ||
        norm.includes("project_git_commit") ||
        norm.includes("project_git_init");
    // 6. Research & Documentation
    const isResearchOrDocument = /^(browser|web_search|resource_fetch|resource_download|read_pdf|extract_pdf|search|fetch|scrape|search_web|composio_search_tools)/i.test(norm) ||
        norm.includes("search") ||
        norm.includes("pdf") ||
        norm.includes("browser") ||
        norm.includes("fetch") ||
        norm.includes("scrape") ||
        isReadOnlyFilesystem;
    // 7. Planning & Tasks
    const isPlanningOrTask = /^(plan_|task_|routine_|goal_|milestone_|manage_task|create_milestone|schedule_routine|routine_run|project_lifecycle|project_step|project_criterion|list_threads|close_thread)/i.test(norm) ||
        norm.includes("plan_create") ||
        norm.includes("task_create") ||
        norm.includes("milestone") ||
        norm.includes("routine");
    return {
        isShellOrTerminal,
        isCodeEditingOrMutation,
        isReadOnlyFilesystem,
        isGitInspection,
        isGitMutation,
        isResearchOrDocument,
        isPlanningOrTask,
    };
}
/**
 * Authoritative specialist boundary check.
 * Strictly blocks forbidden modalities before execution side effects can occur.
 */
export function checkSpecialistToolBoundary(roleId, toolName, args) {
    if (roleId === "generalist") {
        return { allowed: true };
    }
    const { isShellOrTerminal, isCodeEditingOrMutation, isGitMutation } = classifyToolCapability(toolName, args);
    if (roleId === "researcher") {
        if (isShellOrTerminal) {
            return {
                allowed: false,
                error: new SpecialistBoundaryOverstepError("researcher", toolName, "Shell/Terminal Command Execution", "Researcher specialization cannot execute shell code; delegate execution tasks to a Coder specialist."),
            };
        }
        if (isCodeEditingOrMutation) {
            return {
                allowed: false,
                error: new SpecialistBoundaryOverstepError("researcher", toolName, "Code Editing & Filesystem Mutation", "Researcher specialization cannot modify files, patch code, or edit files; delegate implementation to a Coder specialist."),
            };
        }
        if (isGitMutation) {
            return {
                allowed: false,
                error: new SpecialistBoundaryOverstepError("researcher", toolName, "Git Repository Mutation", "Researcher specialization cannot mutate git repositories; delegate version control mutations to a Coder specialist."),
            };
        }
    }
    if (roleId === "planner") {
        if (isShellOrTerminal) {
            return {
                allowed: false,
                error: new SpecialistBoundaryOverstepError("planner", toolName, "Direct Code Execution", "Planner specialization can formulate plans and dependency trees but cannot directly execute code; delegate code execution to a Coder specialist."),
            };
        }
        if (isCodeEditingOrMutation) {
            return {
                allowed: false,
                error: new SpecialistBoundaryOverstepError("planner", toolName, "Direct Code Editing", "Planner specialization formulates task structures but cannot directly mutate codebase files; delegate code editing to a Coder specialist."),
            };
        }
        if (isGitMutation) {
            return {
                allowed: false,
                error: new SpecialistBoundaryOverstepError("planner", toolName, "Git Repository Mutation", "Planner specialization cannot commit or push git changes directly; delegate git mutations to a Coder specialist."),
            };
        }
    }
    return { allowed: true };
}
/**
 * Tool affinity ranking for specialization roles.
 */
export function rankSpecialistTools(roleId, availableTools, _context) {
    const prioritized = [];
    const standard = [];
    const deprioritized = [];
    const forbidden = [];
    for (const tool of availableTools) {
        const boundary = checkSpecialistToolBoundary(roleId, tool);
        if (!boundary.allowed) {
            forbidden.push(tool);
            continue;
        }
        const { isShellOrTerminal, isCodeEditingOrMutation, isReadOnlyFilesystem, isGitInspection, isGitMutation, isResearchOrDocument, isPlanningOrTask, } = classifyToolCapability(tool);
        if (roleId === "researcher") {
            // Researcher prioritizes research, web, documents, and read-only inspection
            if (isResearchOrDocument || isReadOnlyFilesystem || isGitInspection) {
                prioritized.push(tool);
            }
            else {
                standard.push(tool);
            }
        }
        else if (roleId === "coder") {
            // Coder prioritizes Terminal, Filesystem, and Git tools for engineering tasks
            if (isShellOrTerminal ||
                isCodeEditingOrMutation ||
                isReadOnlyFilesystem ||
                isGitInspection ||
                isGitMutation ||
                tool.includes("test") ||
                tool.includes("git")) {
                prioritized.push(tool);
            }
            else if (tool.includes("chat") || tool.includes("casual")) {
                deprioritized.push(tool);
            }
            else {
                standard.push(tool);
            }
        }
        else if (roleId === "planner") {
            if (isPlanningOrTask) {
                prioritized.push(tool);
            }
            else if (isReadOnlyFilesystem || isGitInspection) {
                standard.push(tool);
            }
            else {
                deprioritized.push(tool);
            }
        }
        else {
            // generalist
            standard.push(tool);
        }
    }
    return { prioritized, standard, deprioritized, forbidden };
}
/**
 * Filter and order candidate tools supplied to the model.
 * Strict architectural separation of selection from authorization:
 * Forbidden tools are completely filtered out of model candidate tools.
 */
export function filterSpecialistToolCandidates(roleId, availableTools, context) {
    const ranked = rankSpecialistTools(roleId, availableTools, context);
    return [...ranked.prioritized, ...ranked.standard, ...ranked.deprioritized];
}
/**
 * Validates that source citations in response text are:
 * 1. Non-empty, non-fabricated valid URLs.
 * 2. Deduplicated.
 * 3. Grounded in sources actually retrieved during the turn.
 * 4. Satisfy the configured minimum count.
 */
export function validateSourceCitations(content, retrievedSources, minimumRequired) {
    const urlRegex = /(?:https?|fixture):\/\/[^\s)\]>"',;]+/g;
    const rawMatches = content.match(urlRegex) ?? [];
    // Deduplicate and normalize
    const normalizedRetrieved = new Set(retrievedSources.map((s) => s.trim().toLowerCase().replace(/\/+$/, "")));
    const uniqueCitedUrls = [];
    const seenCited = new Set();
    for (const match of rawMatches) {
        const clean = match.trim().replace(/[.,;!?]+$/, "");
        try {
            const parsed = new URL(clean);
            if (!parsed.hostname || parsed.hostname.includes(" ") || parsed.hostname === "example.com/fake") {
                continue;
            }
            const norm = clean.toLowerCase().replace(/\/+$/, "");
            if (!seenCited.has(norm)) {
                seenCited.add(norm);
                uniqueCitedUrls.push(clean);
            }
        }
        catch {
            // Invalid URL syntax
        }
    }
    // Cross-reference against retrieved sources
    const groundedCitations = [];
    const ungroundedCitations = [];
    for (const url of uniqueCitedUrls) {
        const norm = url.toLowerCase().replace(/\/+$/, "");
        if (normalizedRetrieved.has(norm) || Array.from(normalizedRetrieved).some((r) => r.startsWith(norm) || norm.startsWith(r))) {
            groundedCitations.push(url);
        }
        else {
            ungroundedCitations.push(url);
        }
    }
    const min = minimumRequired ?? 0;
    const missingCount = Math.max(0, min - groundedCitations.length);
    if (min > 0 && groundedCitations.length < min) {
        return {
            valid: false,
            citations: groundedCitations,
            retrievedSources,
            missingCount,
            ungroundedCitations,
            reason: `Configured minimum citations (${min}) not satisfied: found ${groundedCitations.length} valid grounded citation(s), ${ungroundedCitations.length} ungrounded/unverified.`,
        };
    }
    return {
        valid: true,
        citations: groundedCitations,
        retrievedSources,
        missingCount: 0,
        ungroundedCitations,
    };
}
/**
 * Validates automated test execution for Coder specialist engineering tasks.
 */
export function validateAutomatedTestRun(actions, hasCodeChanges = false) {
    const testActions = actions.filter((a) => {
        const norm = a.toolName.toLowerCase();
        const cmd = String(a.args?.command || a.args?.cmd || "").toLowerCase();
        return (norm.includes("test") ||
            cmd.includes("test") ||
            cmd.includes("vitest") ||
            cmd.includes("pytest") ||
            cmd.includes("gradlew test") ||
            cmd.includes("npm test"));
    });
    const testsExecuted = testActions.length > 0;
    const executedTestTools = testActions.map((t) => t.toolName);
    const allTestsPassed = testsExecuted && testActions.every((t) => t.result?.ok !== false && !t.result?.text?.includes("FAIL"));
    if (hasCodeChanges && !testsExecuted) {
        return {
            valid: false,
            testsExecuted: false,
            executedTestTools: [],
            allTestsPassed: false,
            reason: "Executable code was modified, but no automated test execution was observed.",
        };
    }
    return {
        valid: true,
        testsExecuted,
        executedTestTools,
        allTestsPassed,
    };
}
/**
 * Validates that a plan's dependency structure is coherent:
 * 1. All dependency IDs reference real task IDs in the plan.
 * 2. Self-dependencies are rejected.
 * 3. Cycles are detected and rejected.
 * 4. A valid topological sort order exists.
 * 5. Parallel tasks are preserved without artificial serialization.
 */
export function validateDependencyGraph(tasks) {
    const errors = [];
    const taskMap = new Map();
    for (const task of tasks) {
        if (!task.id || typeof task.id !== "string") {
            errors.push("Task item is missing a valid 'id' identifier.");
            continue;
        }
        if (taskMap.has(task.id)) {
            errors.push(`Duplicate task identifier "${task.id}".`);
        }
        taskMap.set(task.id, task);
    }
    if (errors.length > 0) {
        return { valid: false, errors };
    }
    // Validate reference integrity and self-dependencies
    for (const task of tasks) {
        const deps = task.dependencies ?? [];
        for (const depId of deps) {
            if (depId === task.id) {
                errors.push(`Self-dependency detected in task "${task.id}".`);
            }
            else if (!taskMap.has(depId)) {
                errors.push(`Task "${task.id}" depends on unknown task "${depId}".`);
            }
        }
    }
    if (errors.length > 0) {
        return { valid: false, errors };
    }
    // Cycle detection and topological sorting using Kahn's algorithm
    const inDegree = new Map();
    const graph = new Map(); // dep -> tasks that depend on it
    for (const task of tasks) {
        inDegree.set(task.id, 0);
        graph.set(task.id, []);
    }
    for (const task of tasks) {
        const deps = task.dependencies ?? [];
        inDegree.set(task.id, deps.length);
        for (const depId of deps) {
            graph.get(depId)?.push(task.id);
        }
    }
    const queue = [];
    for (const [taskId, deg] of inDegree.entries()) {
        if (deg === 0) {
            queue.push(taskId);
        }
    }
    const executionOrder = [];
    const parallelBatches = [];
    while (queue.length > 0) {
        // Current queue represents a parallelizable batch
        const currentBatch = [...queue];
        parallelBatches.push(currentBatch);
        queue.length = 0;
        for (const taskId of currentBatch) {
            executionOrder.push(taskId);
            const dependents = graph.get(taskId) ?? [];
            for (const nextId of dependents) {
                const remaining = (inDegree.get(nextId) ?? 1) - 1;
                inDegree.set(nextId, remaining);
                if (remaining === 0) {
                    queue.push(nextId);
                }
            }
        }
    }
    if (executionOrder.length !== tasks.length) {
        // There is a cycle
        const unvisited = tasks.filter((t) => !executionOrder.includes(t.id)).map((t) => t.id);
        errors.push(`Circular dependency detected involving task(s): ${unvisited.join(", ")}`);
        return { valid: false, errors };
    }
    return {
        valid: true,
        executionOrder,
        parallelBatches,
    };
}
/**
 * Maps defaultSearchDepth to concrete operational search parameters.
 */
export function resolveSearchStrategy(depth) {
    switch (depth) {
        case "exhaustive":
            return {
                depth: "exhaustive",
                queryExpansionCount: 5,
                maxSourcesToFetch: 12,
                substantiveReadRequired: true,
                crossCorroborationRequired: true,
            };
        case "deep":
            return {
                depth: "deep",
                queryExpansionCount: 3,
                maxSourcesToFetch: 6,
                substantiveReadRequired: true,
                crossCorroborationRequired: true,
            };
        case "shallow":
        default:
            return {
                depth: "shallow",
                queryExpansionCount: 1,
                maxSourcesToFetch: 2,
                substantiveReadRequired: false,
                crossCorroborationRequired: false,
            };
    }
}
