// Bounded deadlines for model provider calls.
//
// Distinguishes:
// 1. Connection establishment (DNS + TCP + TLS handshake)
// 2. Time to first token (request sent to first SSE event / byte, allowing for reasoning models)
// 3. Streaming idle timeout (chunk-to-chunk silence once streaming has begun)
// 4. Single model-call total deadline (bounds a single completion round)
// Chosen against the two failure modes seen on the phone: a provider that
// accepts the request and never answers (bounded by connect and first-token),
// and one that goes quiet mid-stream (bounded by idle). The idle budget is the
// value the native runtime already shipped with before these phases existed
// (120s) — tightening it to 30s was not backed by any evidence and would cut
// turns that are working, just slowly. Reasoning models emit their summary
// between long thinking pauses; a phone link is not a datacentre.
export const DEFAULT_PROVIDER_TIMEOUTS = {
    connectTimeoutMs: 30_000, // no response headers within 30s
    firstTokenTimeoutMs: 75_000, // headers arrived, no first event within 75s
    idleTimeoutMs: 120_000, // 120s of silence mid-stream
    callTimeoutMs: 300_000, // 5 minutes for one completion round
};
export function resolveProviderTimeouts(overrides) {
    const envNum = (key) => {
        const v = process.env[key];
        if (!v)
            return undefined;
        const n = Number(v);
        return Number.isFinite(n) && n > 0 ? n : undefined;
    };
    return {
        connectTimeoutMs: overrides?.connectTimeoutMs ?? envNum("OMB_PROVIDER_CONNECT_TIMEOUT_MS") ?? DEFAULT_PROVIDER_TIMEOUTS.connectTimeoutMs,
        firstTokenTimeoutMs: overrides?.firstTokenTimeoutMs ?? envNum("OMB_PROVIDER_FIRST_TOKEN_TIMEOUT_MS") ?? DEFAULT_PROVIDER_TIMEOUTS.firstTokenTimeoutMs,
        idleTimeoutMs: overrides?.idleTimeoutMs ?? envNum("OMB_PROVIDER_IDLE_TIMEOUT_MS") ?? DEFAULT_PROVIDER_TIMEOUTS.idleTimeoutMs,
        callTimeoutMs: overrides?.callTimeoutMs ?? envNum("OMB_PROVIDER_CALL_TIMEOUT_MS") ?? DEFAULT_PROVIDER_TIMEOUTS.callTimeoutMs,
    };
}
/** A budget as the person reads it. `Math.round(150 / 1000)` used to print
 *  "0s", which is how a 150ms test budget appeared in a real message. */
export function humanDuration(ms) {
    // Seconds up to two minutes: "75.5s" is a budget someone can picture,
    // "1.3 min" is not.
    if (ms >= 120_000) {
        const minutes = ms / 60_000;
        return `${Number.isInteger(minutes) ? minutes : minutes.toFixed(1)} min`;
    }
    if (ms >= 1_000) {
        const seconds = ms / 1_000;
        return `${Number.isInteger(seconds) ? seconds : seconds.toFixed(1)}s`;
    }
    return `${Math.round(ms)}ms`;
}
export class ProviderTimeoutError extends Error {
    phase;
    timeoutMs;
    constructor(phase, timeoutMs, message) {
        const budget = humanDuration(timeoutMs);
        const defaultMessage = phase === "first_token"
            ? `The provider took too long to begin its response (${budget} first-token timeout elapsed).`
            : phase === "idle"
                ? `The provider connection stalled (${budget} streaming idle timeout elapsed).`
                : phase === "call_total"
                    ? `The model generation exceeded its deadline (${budget} call timeout elapsed).`
                    : `The provider did not answer within ${budget} (connect timeout).`;
        super(message ?? defaultMessage);
        this.name = "ProviderTimeoutError";
        this.phase = phase;
        this.timeoutMs = timeoutMs;
    }
}
/**
 * Settle with `work`, or fail with the signal's reason the moment it aborts.
 *
 * A deadline that only aborts a signal is a request, not a guarantee: the
 * transport has to be watching. Racing the operation is what makes the bound
 * real when it is not — a wedged fetch, a stream whose source never pulls, or
 * a custom transport that ignores its signal. The abandoned promise keeps a
 * rejection handler so a late failure never surfaces as unhandled.
 */
export function raceWithSignal(work, signal) {
    const reason = () => signal.reason ?? new Error("The operation was aborted.");
    if (signal.aborted) {
        void work.catch(() => { });
        return Promise.reject(reason());
    }
    return new Promise((resolve, reject) => {
        const onAbort = () => {
            void work.catch(() => { });
            reject(reason());
        };
        signal.addEventListener("abort", onAbort, { once: true });
        work.then((value) => {
            signal.removeEventListener("abort", onAbort);
            resolve(value);
        }, (error) => {
            signal.removeEventListener("abort", onAbort);
            reject(error);
        });
    });
}
/**
 * Establish bounded deadlines for a single provider request / stream.
 * Automatically cleans up timers when completed or aborted.
 */
export function createProviderCallDeadline(parentSignal, policy = DEFAULT_PROVIDER_TIMEOUTS) {
    const controller = new AbortController();
    let connectTimer = null;
    let firstTokenTimer = null;
    let idleTimer = null;
    let callTimer = null;
    let connected = false;
    let sawFirstToken = false;
    let cleanedUp = false;
    const cleanup = () => {
        cleanedUp = true;
        if (connectTimer !== null) {
            clearTimeout(connectTimer);
            connectTimer = null;
        }
        if (firstTokenTimer !== null) {
            clearTimeout(firstTokenTimer);
            firstTokenTimer = null;
        }
        if (idleTimer !== null) {
            clearTimeout(idleTimer);
            idleTimer = null;
        }
        if (callTimer !== null) {
            clearTimeout(callTimer);
            callTimer = null;
        }
        if (parentSignal) {
            parentSignal.removeEventListener("abort", onParentAbort);
        }
    };
    const onParentAbort = () => {
        cleanup();
        controller.abort(parentSignal?.reason);
    };
    if (parentSignal?.aborted) {
        controller.abort(parentSignal.reason);
        return {
            signal: controller.signal,
            onConnected: () => { },
            onChunkReceived: () => { },
            cleanup,
        };
    }
    if (parentSignal) {
        parentSignal.addEventListener("abort", onParentAbort, { once: true });
    }
    // 1. Connection establishment deadline
    if (policy.connectTimeoutMs > 0) {
        connectTimer = setTimeout(() => {
            if (!connected && !cleanedUp) {
                cleanup();
                controller.abort(new ProviderTimeoutError("connect", policy.connectTimeoutMs));
            }
        }, policy.connectTimeoutMs);
        connectTimer.unref?.();
    }
    // 2. First token deadline is armed when the response headers arrive (see
    // onConnected). Armed here it would start before the request was even sent,
    // so the shorter connect budget always won and this phase could never fire.
    // 3. Total call deadline
    if (policy.callTimeoutMs > 0) {
        callTimer = setTimeout(() => {
            if (!cleanedUp) {
                cleanup();
                controller.abort(new ProviderTimeoutError("call_total", policy.callTimeoutMs));
            }
        }, policy.callTimeoutMs);
        callTimer.unref?.();
    }
    const onConnected = () => {
        if (cleanedUp)
            return;
        connected = true;
        if (connectTimer !== null) {
            clearTimeout(connectTimer);
            connectTimer = null;
        }
        // Time spent reaching the provider is not time it had to start answering.
        if (!sawFirstToken && policy.firstTokenTimeoutMs > 0 && firstTokenTimer === null) {
            firstTokenTimer = setTimeout(() => {
                if (!sawFirstToken && !cleanedUp) {
                    cleanup();
                    controller.abort(new ProviderTimeoutError("first_token", policy.firstTokenTimeoutMs));
                }
            }, policy.firstTokenTimeoutMs);
            firstTokenTimer.unref?.();
        }
    };
    const onChunkReceived = () => {
        connected = true;
        if (connectTimer !== null) {
            clearTimeout(connectTimer);
            connectTimer = null;
        }
        if (!sawFirstToken) {
            sawFirstToken = true;
            if (firstTokenTimer !== null) {
                clearTimeout(firstTokenTimer);
                firstTokenTimer = null;
            }
        }
        if (idleTimer !== null) {
            clearTimeout(idleTimer);
            idleTimer = null;
        }
        if (!cleanedUp && policy.idleTimeoutMs > 0) {
            idleTimer = setTimeout(() => {
                if (!cleanedUp) {
                    cleanup();
                    controller.abort(new ProviderTimeoutError("idle", policy.idleTimeoutMs));
                }
            }, policy.idleTimeoutMs);
            idleTimer.unref?.();
        }
    };
    return {
        signal: controller.signal,
        onConnected,
        onChunkReceived,
        cleanup,
    };
}
