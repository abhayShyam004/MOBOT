import { request as httpRequest } from "node:http";
import { request as httpsRequest } from "node:https";
import { resolve4, resolve6 } from "node:dns/promises";
import { isIP } from "node:net";
export class AddressBlockedError extends Error {
    code = "SSRF_BLOCKED";
    constructor(message) {
        super(message);
        this.name = "AddressBlockedError";
    }
}
export class DnsResolutionError extends Error {
    code = "DNS_FAILURE";
    constructor(message) {
        super(message);
        this.name = "DnsResolutionError";
    }
}
/** Real resolver: A and AAAA records, no globalThis introspection. */
export const defaultResolver = async (hostname) => {
    const [a, aaaa] = await Promise.allSettled([resolve4(hostname), resolve6(hostname)]);
    const out = [];
    if (a.status === "fulfilled") {
        for (const address of a.value)
            out.push({ address, family: 4 });
    }
    if (aaaa.status === "fulfilled") {
        for (const address of aaaa.value)
            out.push({ address, family: 6 });
    }
    if (out.length === 0) {
        const detail = [a, aaaa]
            .filter((r) => r.status === "rejected")
            .map((r) => (r.reason instanceof Error ? r.reason.message : String(r.reason)))
            .join("; ");
        throw new DnsResolutionError(`No A/AAAA records for ${hostname}${detail ? ` (${detail})` : ""}`);
    }
    return out;
};
function parseIPv4Strict(input) {
    const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(input);
    if (!m)
        return null;
    let value = 0;
    for (let i = 1; i <= 4; i++) {
        const part = m[i];
        const n = Number(part);
        if (!Number.isInteger(n) || n > 255)
            return null;
        // Reject leading zeros: they are octal to some resolvers, decimal to others.
        if (part.length > 1 && part.startsWith("0"))
            return null;
        value = value * 256 + n;
    }
    return value >>> 0;
}
function parseIPv6Strict(input) {
    let s = input.trim().toLowerCase();
    if (s.startsWith("[") && s.endsWith("]"))
        s = s.slice(1, -1);
    const zoneIndex = s.indexOf("%");
    if (zoneIndex !== -1)
        s = s.slice(0, zoneIndex);
    if (s.length === 0)
        return null;
    const halves = s.split("::");
    if (halves.length > 2)
        return null;
    const expandGroups = (segment) => {
        if (segment === "")
            return [];
        const groups = segment.split(":");
        const out = [];
        for (let i = 0; i < groups.length; i++) {
            const group = groups[i];
            if (group === "")
                return null;
            if (group.includes(".")) {
                if (i !== groups.length - 1)
                    return null;
                const v4 = parseIPv4Strict(group);
                if (v4 === null)
                    return null;
                out.push((v4 >>> 16) & 0xffff, v4 & 0xffff);
                continue;
            }
            if (!/^[0-9a-f]{1,4}$/.test(group))
                return null;
            out.push(parseInt(group, 16));
        }
        return out;
    };
    const head = expandGroups(halves[0]);
    if (head === null)
        return null;
    const tail = halves.length === 2 ? expandGroups(halves[1]) : [];
    if (tail === null)
        return null;
    let groups;
    if (halves.length === 2) {
        const fill = 8 - head.length - tail.length;
        if (fill < 1)
            return null;
        groups = [...head, ...new Array(fill).fill(0), ...tail];
    }
    else {
        groups = head;
    }
    if (groups.length !== 8)
        return null;
    const bytes = new Uint8Array(16);
    for (let i = 0; i < 8; i++) {
        bytes[i * 2] = (groups[i] >>> 8) & 0xff;
        bytes[i * 2 + 1] = groups[i] & 0xff;
    }
    return bytes;
}
function isZeroRange(bytes, from, to) {
    for (let i = from; i < to; i++)
        if (bytes[i] !== 0)
            return false;
    return true;
}
function blockedIPv4(value) {
    const inRange = (base, bits) => {
        const baseInt = parseIPv4Strict(base);
        if (baseInt === null)
            return false;
        const mask = bits === 0 ? 0 : (0xffffffff << (32 - bits)) >>> 0;
        return (value & mask) >>> 0 === (baseInt & mask) >>> 0;
    };
    if (inRange("0.0.0.0", 8))
        return "0.0.0.0/8";
    if (inRange("10.0.0.0", 8))
        return "10.0.0.0/8 (private)";
    if (inRange("100.64.0.0", 10))
        return "100.64.0.0/10 (carrier-grade NAT)";
    if (inRange("127.0.0.0", 8))
        return "127.0.0.0/8 (loopback)";
    if (inRange("169.254.0.0", 16))
        return "169.254.0.0/16 (link-local / cloud metadata)";
    if (inRange("172.16.0.0", 12))
        return "172.16.0.0/12 (private)";
    if (inRange("192.0.0.0", 24))
        return "192.0.0.0/24 (IETF protocol assignment)";
    if (inRange("192.0.2.0", 24))
        return "192.0.2.0/24 (documentation)";
    if (inRange("192.168.0.0", 16))
        return "192.168.0.0/16 (private)";
    if (inRange("198.18.0.0", 15))
        return "198.18.0.0/15 (benchmarking)";
    if (inRange("198.51.100.0", 24))
        return "198.51.100.0/24 (documentation)";
    if (inRange("203.0.113.0", 24))
        return "203.0.113.0/24 (documentation)";
    if (inRange("224.0.0.0", 4))
        return "224.0.0.0/4 (multicast)";
    if (inRange("240.0.0.0", 4))
        return "240.0.0.0/4 (reserved)";
    return null;
}
function v4FromBytes(bytes, offset) {
    return (((bytes[offset] << 24) >>> 0) +
        (bytes[offset + 1] << 16) +
        (bytes[offset + 2] << 8) +
        bytes[offset + 3]) >>> 0;
}
/**
 * Classify a single IP address. Returns `allowed: false` with a human readable
 * reason for every non-global destination.
 */
export function classifyAddress(address) {
    const family = isIP(address);
    if (family === 4) {
        const value = parseIPv4Strict(address);
        if (value === null)
            return { allowed: false, reason: "unparseable IPv4 literal" };
        const blocked = blockedIPv4(value);
        return blocked ? { allowed: false, reason: blocked } : { allowed: true, family: 4 };
    }
    if (family === 6) {
        const bytes = parseIPv6Strict(address);
        if (bytes === null)
            return { allowed: false, reason: "unparseable IPv6 literal" };
        // :: and ::1
        if (isZeroRange(bytes, 0, 16))
            return { allowed: false, reason: ":: (unspecified)" };
        if (isZeroRange(bytes, 0, 15) && bytes[15] === 1) {
            return { allowed: false, reason: "::1 (loopback)" };
        }
        // fe80::/10 link-local, fec0::/10 deprecated site-local
        if (bytes[0] === 0xfe && (bytes[1] & 0xc0) === 0x80) {
            return { allowed: false, reason: "fe80::/10 (link-local)" };
        }
        if (bytes[0] === 0xfe && (bytes[1] & 0xc0) === 0xc0) {
            return { allowed: false, reason: "fec0::/10 (site-local)" };
        }
        // fc00::/7 unique local
        if ((bytes[0] & 0xfe) === 0xfc) {
            return { allowed: false, reason: "fc00::/7 (unique local)" };
        }
        // ff00::/8 multicast
        if (bytes[0] === 0xff)
            return { allowed: false, reason: "ff00::/8 (multicast)" };
        // 100::/64 discard-only
        if (bytes[0] === 0x01 && isZeroRange(bytes, 1, 8)) {
            return { allowed: false, reason: "100::/64 (discard-only)" };
        }
        // 2001:db8::/32 documentation
        if (bytes[0] === 0x20 && bytes[1] === 0x01 && bytes[2] === 0x0d && bytes[3] === 0xb8) {
            return { allowed: false, reason: "2001:db8::/32 (documentation)" };
        }
        // 2001::/32 Teredo
        if (bytes[0] === 0x20 && bytes[1] === 0x01 &&
            bytes[2] === 0x00 && bytes[3] === 0x00) {
            return { allowed: false, reason: "2001::/32 (Teredo tunnel)" };
        }
        // ::ffff:a.b.c.d IPv4-mapped
        if (isZeroRange(bytes, 0, 10) && bytes[10] === 0xff && bytes[11] === 0xff) {
            const v4 = v4FromBytes(bytes, 12);
            const blocked = blockedIPv4(v4);
            return blocked
                ? { allowed: false, reason: `IPv4-mapped ${describeV4(v4)}: ${blocked}` }
                : { allowed: true, family: 6 };
        }
        // ::a.b.c.d IPv4-compatible (deprecated)
        if (isZeroRange(bytes, 0, 12)) {
            const v4 = v4FromBytes(bytes, 12);
            const blocked = blockedIPv4(v4);
            return blocked
                ? { allowed: false, reason: `IPv4-compatible ${describeV4(v4)}: ${blocked}` }
                : { allowed: true, family: 6 };
        }
        // 64:ff9b::/96 NAT64
        if (bytes[0] === 0x00 && bytes[1] === 0x64 && bytes[2] === 0xff && bytes[3] === 0x9b &&
            isZeroRange(bytes, 4, 12)) {
            const v4 = v4FromBytes(bytes, 12);
            const blocked = blockedIPv4(v4);
            return blocked
                ? { allowed: false, reason: `NAT64 ${describeV4(v4)}: ${blocked}` }
                : { allowed: true, family: 6 };
        }
        // 2002::/16 6to4 embeds an IPv4 address
        if (bytes[0] === 0x20 && bytes[1] === 0x02) {
            const v4 = v4FromBytes(bytes, 2);
            const blocked = blockedIPv4(v4);
            return blocked
                ? { allowed: false, reason: `6to4 ${describeV4(v4)}: ${blocked}` }
                : { allowed: true, family: 6 };
        }
        // Only global unicast 2000::/3 is reachable from monitoring.
        if ((bytes[0] & 0xe0) === 0x20)
            return { allowed: true, family: 6 };
        return { allowed: false, reason: "not a global unicast address" };
    }
    return { allowed: false, reason: "not an IP address" };
}
function describeV4(value) {
    return [value >>> 24, (value >>> 16) & 0xff, (value >>> 8) & 0xff, value & 0xff].join(".");
}
/**
 * Resolve a host to exactly one validated address.
 *
 * - IP literals are classified directly, without DNS.
 * - A hostname is rejected if ANY A/AAAA answer is non-global, so a mixed
 *   answer set cannot be used to smuggle an internal destination.
 * - An empty answer set fails closed.
 * - An unroutable family is skipped only after every answer was validated.
 */
export async function resolveTargetAddress(hostname, options = {}) {
    const normalized = hostname.trim().replace(/^\[|\]$/g, "").replace(/\.$/, "");
    if (normalized.length === 0) {
        throw new DnsResolutionError("Hostname is empty");
    }
    const literalFamily = isIP(normalized);
    if (literalFamily !== 0) {
        const verdict = classifyAddress(normalized);
        if (!verdict.allowed && !options.allowInternal) {
            throw new AddressBlockedError(`Blocked destination ${normalized}: ${verdict.reason}`);
        }
        return { address: normalized, family: literalFamily === 6 ? 6 : 4 };
    }
    const resolver = options.resolver ?? defaultResolver;
    const answers = await resolver(normalized);
    if (answers.length === 0) {
        throw new DnsResolutionError(`No addresses returned for ${normalized}`);
    }
    for (const answer of answers) {
        const verdict = classifyAddress(answer.address);
        if (!verdict.allowed && !options.allowInternal) {
            throw new AddressBlockedError(`Blocked destination ${normalized} resolved to ${answer.address}: ${verdict.reason}`);
        }
    }
    return answers[0];
}
function isTimeoutError(err) {
    const code = err?.code;
    return code === "ETIMEDOUT" || code === "MOBOT_MONITOR_TIMEOUT";
}
/**
 * Issue a single request to a pre-validated address.
 *
 * `lookup` always returns the pinned address, so a DNS answer that changes
 * between validation and connect cannot redirect the socket. TLS keeps the
 * original hostname for SNI and certificate verification; there is no code
 * path that disables certificate validation.
 */
export function performPinnedRequest(rawUrl, options) {
    return new Promise((resolve, reject) => {
        const url = new URL(rawUrl);
        const isHttps = url.protocol === "https:";
        if (!isHttps && url.protocol !== "http:") {
            reject(new Error(`Unsupported protocol ${url.protocol}`));
            return;
        }
        const literalFamily = isIP(url.hostname);
        if (literalFamily !== 0 && url.hostname !== options.address) {
            reject(new AddressBlockedError(`URL host ${url.hostname} does not match pinned address ${options.address}`));
            return;
        }
        // Pinned resolver: the socket connects to the validated address, never to a
        // fresh DNS answer for the hostname.
        const lookup = (_host, lookupOptions, callback) => {
            if (Boolean(lookupOptions?.all)) {
                callback(null, [{ address: options.address, family: options.family }]);
                return;
            }
            callback(null, options.address, options.family);
        };
        const requestFn = isHttps ? httpsRequest : httpRequest;
        let settled = false;
        let tlsEstablished = !isHttps;
        const finish = (err, value) => {
            if (settled)
                return;
            settled = true;
            if (err)
                reject(err);
            else
                resolve(value);
        };
        let req;
        try {
            req = requestFn({
                protocol: url.protocol,
                hostname: url.hostname,
                port: url.port ? Number(url.port) : isHttps ? 443 : 80,
                path: `${url.pathname}${url.search}`,
                method: options.method ?? "GET",
                headers: options.headers,
                agent: false,
                lookup,
                servername: literalFamily === 0 ? url.hostname : undefined,
            });
        }
        catch (err) {
            finish(err instanceof Error ? err : new Error(String(err)));
            return;
        }
        req.setTimeout(options.timeoutMs, () => {
            const err = new Error(`Timed out after ${options.timeoutMs}ms`);
            err.code = "MOBOT_MONITOR_TIMEOUT";
            req.destroy(err);
        });
        req.on("socket", (socket) => {
            if (!isHttps)
                return;
            socket.once("secureConnect", () => {
                tlsEstablished = true;
            });
        });
        req.on("error", (err) => {
            const errCode = err.code;
            // A reset before the handshake completes is a certificate/handshake
            // rejection, not a flaky connection: report it as a TLS failure.
            if (isHttps &&
                !tlsEstablished &&
                !isTimeoutError(err) &&
                (errCode === "ECONNRESET" || errCode === "EPIPE" || /socket hang up/i.test(err.message))) {
                const wrapped = new Error(`TLS handshake failed: ${err.message}`);
                wrapped.code = "ERR_TLS_HANDSHAKE_FAILED";
                finish(wrapped);
                return;
            }
            if (isTimeoutError(err)) {
                const wrapped = new Error(`Timed out after ${options.timeoutMs}ms`);
                wrapped.code = "MOBOT_MONITOR_TIMEOUT";
                finish(wrapped);
                return;
            }
            finish(err);
        });
        req.on("response", (res) => {
            const chunks = [];
            let bytesRead = 0;
            let truncated = false;
            res.on("data", (chunk) => {
                if (truncated)
                    return;
                bytesRead += chunk.length;
                if (bytesRead > options.maxBytes) {
                    truncated = true;
                    const err = new Error("MOBOT_MONITOR_RESPONSE_TOO_LARGE");
                    err.code = "MOBOT_MONITOR_RESPONSE_TOO_LARGE";
                    res.destroy(err);
                    req.destroy();
                    return;
                }
                chunks.push(chunk);
            });
            const settle = () => {
                if (truncated) {
                    const err = new Error("Response body exceeded the configured limit");
                    err.code = "MOBOT_MONITOR_RESPONSE_TOO_LARGE";
                    finish(err);
                    return;
                }
                finish(null, {
                    statusCode: res.statusCode ?? 0,
                    headers: res.headers,
                    body: Buffer.concat(chunks).toString("utf8"),
                    truncated: false,
                    bytesRead,
                    address: options.address,
                    family: options.family,
                });
            };
            res.on("end", settle);
            res.on("error", (err) => {
                if (truncated) {
                    const tooLarge = new Error("Response body exceeded the configured limit");
                    tooLarge.code = "MOBOT_MONITOR_RESPONSE_TOO_LARGE";
                    finish(tooLarge);
                    return;
                }
                finish(err);
            });
        });
        req.end();
    });
}
export function isAddressBlockedError(err) {
    return err instanceof AddressBlockedError || err?.code === "SSRF_BLOCKED";
}
