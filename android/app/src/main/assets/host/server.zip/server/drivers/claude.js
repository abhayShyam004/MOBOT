// Claude driver — upstream ClaudeDriver skeleton over agentcal's
// drivers/claude.js runtime (stream-json both directions, prompt over
// stdin, completion from a real `result` event — verified against
// claude 2.1.211 by agentcal). Per-turn CLI process; the conversation
// continues across turns via --resume <sessionId> (the resumeCursor).
//
// Integrations become MCP servers on the CLI:
//   - Composio Sessions (connected apps → tools) over streamable HTTP
//   - the bot's cloud computer (box.ascii.dev) via server/computer-proxy.ts
//     — screenshot/exec/open_url, the CUA-on-the-box bridge
import { createHash, randomBytes } from "node:crypto";
import { chmodSync, mkdtempSync, readFileSync, rmSync, unlinkSync, writeFileSync } from "node:fs";
import { createServer as createNetServer } from "node:net";
import { homedir, tmpdir } from "node:os";
import { join, dirname, isAbsolute, normalize } from "node:path";
import { DATA_DIR, stripWorkspaceCredentialEnv } from "../config.js";
import { disallowedToolsForPermissions, loadDiskPermissions } from "../permission-policy.js";
import { augmentedPath } from "../env-path.js";
import { brokerSocketPath, describeSpawnFailure, execCli, killCliTree, spawnCli } from "../procs.js";
import { classifyResumeFailure, mayReplay, recoveryPromptFor } from "../resume-recovery.js";
import { ClaudeLoginController } from "./claude-login-auth.js";
import { gateServer, resultBudget } from "../mcp-gate-config.js";
import { newEventId, newId } from "../contracts.js";
import { askInputSummary, commandSummary, toolDetailPreview } from "../tool-summary.js";
import { classifyError, computeBackoff, interruptibleDelay, RETRY_MAX_ATTEMPTS } from "./retry.js";
import { applyClaudeInject, decodeInjectId, mergeLocalInject, probeLocalInjects, resolveInjectId, } from "./local-inject.js";
import { appendNative } from "./native.js";
import { SPAWNED_PROXIES } from "../proxy-paths.js";
import { ASK_USER_QUESTION_TOOL, askQuestionSummary, normalizeAskUserInput, parseAskQuestions, parseChoices, questionChoices, } from "../../shared/ask-question.js";
/** Whether `claude` has been signed in.
 *
 * Credential storage is deliberately not inspected here. Claude Code uses the
 * macOS Keychain for OAuth, a JSON file on some platforms, and may gain other
 * backends over time. Presence checks also accept stale credentials. The CLI's
 * own machine-readable auth command is the source of truth for every backend.
 */
function claudeAuthStatus(cli, env, run = execCli) {
    return new Promise((resolve) => {
        run(cli, ["auth", "status", "--json"], { timeout: 8000, maxBuffer: 65_536, env }, (_error, stdout) => {
            try {
                const status = JSON.parse(stdout);
                if (!status || typeof status !== "object" || !("loggedIn" in status) || status.loggedIn !== true) {
                    return resolve({ authenticated: false });
                }
                // Only display identity fields, never the CLI's full auth response.
                const identity = status;
                const boundedText = (value, max) => typeof value === "string" && value.trim().length > 0 && value.length <= max && !/[\p{Cc}\p{Cf}]/u.test(value)
                    ? value.trim() : undefined;
                const candidateEmail = boundedText(identity.email, 254);
                const email = candidateEmail && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(candidateEmail) ? candidateEmail : undefined;
                const organization = boundedText(identity.orgName, 160);
                // An API key is a workspace decision, not a person: say so instead
                // of showing an empty identity.
                const account = {
                    ...(email ? { email } : {}),
                    ...(organization ? { organization } : {}),
                    ...(identity.authMethod === "api_key" ? { method: "api-key" } : {}),
                };
                resolve({ authenticated: true, ...(Object.keys(account).length ? { account } : {}) });
            }
            catch {
                resolve({ authenticated: false });
            }
        });
    });
}
export async function claudeSignedIn(cli, env, run = execCli) {
    return (await claudeAuthStatus(cli, env, run)).authenticated;
}
/** Parent-session credentials/routing that a named account must not inherit.
 * Shared with terminal sign-in instructions so login and turns select alike. */
export const CLAUDE_ACCOUNT_ENV_KEYS = [
    "CLAUDE_CODE_OAUTH_TOKEN",
    "CLAUDE_CODE_OAUTH_REFRESH_TOKEN",
    "CLAUDE_CODE_OAUTH_SCOPES",
    "CLAUDE_CODE_OAUTH_TOKEN_FILE_DESCRIPTOR",
    "CLAUDE_CODE_API_KEY_FILE_DESCRIPTOR",
    "ANTHROPIC_API_KEY",
    "ANTHROPIC_AUTH_TOKEN",
    "ANTHROPIC_BASE_URL",
    "ANTHROPIC_CUSTOM_HEADERS",
    "CLAUDE_CODE_USE_BEDROCK",
    "CLAUDE_CODE_USE_VERTEX",
    "CLAUDE_CODE_USE_FOUNDRY",
];
/** Resolve the CLI's config location without changing HOME or Keychain. */
export function resolveClaudeConfigDir(configDir, env = process.env) {
    const home = env.HOME || env.USERPROFILE || homedir();
    const configured = configDir?.trim() || env.CLAUDE_CONFIG_DIR?.trim() || join(home, ".claude");
    const expanded = configured === "~" ? home : configured.startsWith("~/") ? join(home, configured.slice(2)) : configured;
    if (!isAbsolute(expanded) || /[\p{Cc}\p{Cf}]/u.test(expanded)) {
        throw new Error("claude: configDir must be an absolute path or start with ~/");
    }
    return normalize(expanded);
}
/** Whether a stream frame is the CLI reporting that it has no login.
 *
 * The CLI flags its own api-error frames (`error`, `is_api_error_message`);
 * a model reply never carries them. Requiring that flag first is what keeps
 * an answer that merely discusses being logged out from being read as a
 * failure — the text classifier runs only once the CLI has already called
 * the frame an error, and covers CLI builds that flag the frame without
 * naming the reason.
 */
export function claudeAuthFailure(frame, text) {
    if (frame.is_api_error_message !== true && typeof frame.error !== "string")
        return false;
    return frame.error === "authentication_failed" || classifyError({ text }).reason === "auth";
}
/** The CLI environment shared by auth probes and real turns.
 *
 * Subscription users can be billed pay-as-you-go if an inherited API key
 * leaks through, and a nested CLI must not inherit this session's identity.
 * Keeping the probe and turn environments identical prevents setup from
 * claiming an API-key login that the turn itself would deliberately remove.
 */
function claudeEnvironment(model, source = process.env, configDir, instanceEnvironment = {}) {
    const env = { ...source, PATH: augmentedPath(), NPM_CONFIG_LOGLEVEL: "error" };
    if (configDir?.trim()) {
        env.CLAUDE_CONFIG_DIR = resolveClaudeConfigDir(configDir, env);
        for (const key of CLAUDE_ACCOUNT_ENV_KEYS) {
            // Explicit custom endpoint settings still work; subscription OAuth
            // always belongs to this account's CLI-managed login, never its parent.
            if (key.startsWith("CLAUDE_CODE_OAUTH_") || key.endsWith("_FILE_DESCRIPTOR") || !Object.hasOwn(instanceEnvironment, key)) {
                delete env[key];
            }
        }
    }
    else if (env.CLAUDE_CONFIG_DIR) {
        env.CLAUDE_CONFIG_DIR = resolveClaudeConfigDir(undefined, env);
    }
    delete env.CLAUDECODE;
    delete env.CLAUDE_CODE_ENTRYPOINT;
    // The harness process may hold workspace credentials (xai/box/voice keys,
    // env-injected at boot); none of them are this CLI's to see.
    stripWorkspaceCredentialEnv(env);
    const applied = applyClaudeInject(env, model);
    // A key set on purpose for this workspace (Settings → Connections, carried
    // in the instance environment) stays. One riding along in the parent's
    // env never does: it would flip a subscription login to pay-as-you-go.
    if (!applied.injected && !instanceEnvironment.ANTHROPIC_API_KEY)
        delete env.ANTHROPIC_API_KEY;
    return env;
}
/** Escape hatch back to the pre-isolation launch, where a bot inherited this
 * machine's Claude Code setup: its MCP servers and connectors, skills,
 * agents, hooks and personal CLAUDE.md. Set it only to recover a bot that
 * genuinely depended on a user- or local-scope MCP server; the supported way
 * to give a bot a server is the app's own `mcpServers` config or the bot
 * project's `.mcp.json`. */
function inheritsUserConfig(env) {
    return env.OMB_CLAUDE_INHERIT_USER_CONFIG === "1";
}
/** The Engines-page warning while the escape hatch is set. The flag is a
 * footgun: it is invisible once exported, and what it costs — every Claude
 * bot re-reading this machine's own servers, skills, hooks and CLAUDE.md on
 * every model call — shows up only on the bill. Naming it where the person
 * looks when something is off is the whole point. */
export function claudeInheritWarning(env) {
    if (!inheritsUserConfig(env))
        return undefined;
    return {
        title: "Bots inherit this machine's Claude Code setup",
        message: "OMB_CLAUDE_INHERIT_USER_CONFIG=1 is set on the OpenMausBot process, so every Claude bot also loads this " +
            "computer's own MCP servers, connectors, skills, hooks and personal CLAUDE.md on every turn — often thousands " +
            "of extra tokens per model call, and tools nobody gave the bot. Unless a bot genuinely needs a server from " +
            "your user-scope Claude config, remove the variable and restart; add the server under Settings → MCP servers " +
            "or the bot project's .mcp.json instead.",
    };
}
/** Retain the selected CLI account's authentication without importing its
 * hooks, permissions, MCP servers or personal instructions. Explicit OMB
 * connections/local endpoints own their entire routing + credential pair. */
export function readClaudeAuthSettings(env, instanceEnvironment = {}) {
    if (CLAUDE_ACCOUNT_ENV_KEYS.some((key) => instanceEnvironment[key]))
        return {};
    try {
        const settings = JSON.parse(readFileSync(join(resolveClaudeConfigDir(undefined, env), "settings.json"), "utf8"));
        const authEnv = {};
        for (const key of CLAUDE_ACCOUNT_ENV_KEYS) {
            if (!key.endsWith("_FILE_DESCRIPTOR") && typeof settings?.env?.[key] === "string") {
                authEnv[key] = settings.env[key];
            }
        }
        return {
            ...(Object.keys(authEnv).length ? { env: authEnv } : {}),
            ...(typeof settings?.apiKeyHelper === "string" && settings.apiKeyHelper.trim()
                ? { apiKeyHelper: settings.apiKeyHelper } : {}),
        };
    }
    catch {
        return {};
    }
}
/** MCP servers the bot's own project declares in `<cwd>/.mcp.json`.
 *
 * The CLI would find this file itself, but the harness launches it with
 * --strict-mcp-config, which makes the harness's config the only source.
 * The project file IS part of the bot's definition (its cwd is chosen per
 * bot), so it is forwarded verbatim — including `type: "http"`/`"sse"`
 * entries the harness never mounts itself, because the CLI, not this code,
 * is what has to understand them. A malformed file is ignored rather than
 * failing the turn: an unreadable project config must not brick a bot. */
function projectMcpServers(cwd) {
    let parsed;
    try {
        parsed = JSON.parse(readFileSync(join(cwd, ".mcp.json"), "utf8"));
    }
    catch {
        return {};
    }
    const servers = parsed?.mcpServers;
    if (!servers || typeof servers !== "object" || Array.isArray(servers))
        return {};
    const out = {};
    for (const [name, server] of Object.entries(servers)) {
        if (server && typeof server === "object" && !Array.isArray(server))
            out[name] = server;
    }
    return out;
}
/** The CLI compacts its own session when it approaches a window. Left alone
 * that window is the model's, so a Sonnet 5 session runs to something near a
 * million tokens before anything happens — and every model call until then
 * re-reads the whole thing. The measured food-ordering thread sat at 330k
 * tokens per call and looked perfectly healthy to the CLI.
 *
 * So the harness picks the window instead. This delegates the actual
 * compaction to the CLI, which owns the session and already has a summarizer
 * for it; the harness only decides when it is worth paying for.
 *
 * OMB_CLAUDE_AUTOCOMPACT takes a token count, "auto" to hand the decision
 * back to the CLI, or "off" to pass nothing at all. The CLI rejects a window
 * outside 100k-1M as a hard argument error, so a configured value is clamped
 * rather than passed through: a mistyped setting must not fail every turn. */
export function autoCompactWindow(env) {
    const raw = (env.OMB_CLAUDE_AUTOCOMPACT ?? "").trim().toLowerCase();
    if (raw === "off")
        return null;
    if (raw === "auto")
        return "auto";
    const parsed = raw ? Number(raw) : DEFAULT_AUTOCOMPACT_TOKENS;
    if (!Number.isFinite(parsed) || parsed <= 0)
        return String(DEFAULT_AUTOCOMPACT_TOKENS);
    return String(Math.min(1_000_000, Math.max(100_000, Math.floor(parsed))));
}
/** Generous for real work, and still a third of where a 1M-window session
 * would otherwise get to. With bot tool results gated (mcp-gate.ts) most
 * threads never reach it; this is the backstop for the ones that do. */
const DEFAULT_AUTOCOMPACT_TOKENS = 200_000;
/** The Claude CLI version that first accepted each flag the harness passes
 * for context control. An unknown flag is a hard argument error, so passing
 * one to an older CLI would fail every turn rather than degrade; each flag
 * is therefore only passed to a CLI known to accept it.
 *
 * Verified against the published binaries, not the changelog (which never
 * records `--autocompact`): `--strict-mcp-config` is present in 1.0.60 and
 * absent from 1.0.0; `--setting-sources` first appears in 1.0.122 (1.0.120
 * lacks it); `--autocompact` first appears in 2.1.122 (2.1.121 lacks it). */
export const CLAUDE_FLAG_FLOORS = {
    "--strict-mcp-config": [1, 0, 60],
    "--setting-sources": [1, 0, 122],
    "--autocompact": [2, 1, 122],
    // 2.1.267 is the first CLI that accepts it; below that the recorded prompt
    // simply is not refreshed, which is the pre-existing behaviour.
    "--system-prompt-snapshot": [2, 1, 267],
};
/** The newest floor above: a CLI at or past it accepts everything the
 * harness sends. Below it the engine still works, minus the flags the CLI
 * predates, and the Engines page suggests an update. */
export const CLAUDE_CONTEXT_CONTROL_MIN_VERSION = CLAUDE_FLAG_FLOORS["--system-prompt-snapshot"];
/** `claude --version` prints "2.1.232 (Claude Code)"; the first dotted triple
 * is the version. Null when nothing parses, e.g. a wrapper that prints its
 * own banner first — see claudeCliSupports for how that is treated. */
export function parseClaudeCliVersion(stdout) {
    const match = /(\d+)\.(\d+)\.(\d+)/.exec(stdout ?? "");
    if (!match)
        return null;
    return [Number(match[1]), Number(match[2]), Number(match[3])];
}
function versionAtLeast(installed, floor) {
    for (let i = 0; i < 3; i += 1) {
        if (installed[i] !== floor[i])
            return installed[i] > floor[i];
    }
    return true;
}
/** Whether a CLI reporting `version` accepts `flag`. A version that could
 * not be parsed counts as current: every CLI that predates a floor prints a
 * plain "x.y.z (Claude Code)", so an unreadable version is far more likely
 * a newer wrapper than an old build, and withholding the flags from a modern
 * CLI would silently re-open the context leak this file exists to close. */
export function claudeCliSupports(version, flag) {
    return version === null || versionAtLeast(version, CLAUDE_FLAG_FLOORS[flag]);
}
/** The Engines-page notice for a CLI older than the newest floor. The engine
 * keeps working without the flags its CLI predates. */
export function claudeCliUpdate(version, cli) {
    const parsed = parseClaudeCliVersion(version);
    if (!parsed || versionAtLeast(parsed, CLAUDE_CONTEXT_CONTROL_MIN_VERSION))
        return undefined;
    const floor = CLAUDE_CONTEXT_CONTROL_MIN_VERSION.join(".");
    const missing = Object.keys(CLAUDE_FLAG_FLOORS)
        .filter((flag) => !claudeCliSupports(parsed, flag));
    const effects = [
        ...(missing.includes("--autocompact") ? ["no compaction window picked by OpenMausBot"] : []),
        ...(missing.includes("--setting-sources") ? ["bots still see this machine's own Claude Code setup"] : []),
        ...(missing.includes("--system-prompt-snapshot") ? ["coordinated resumed turns cannot refresh stale system prompts"] : []),
    ];
    return {
        title: "Update Claude Code for context controls",
        message: `Claude Code ${parsed.join(".")} predates ${floor}, so bots run without ${missing.join(", ")}: ` +
            `${effects.join("; ")}. Update it, then refresh Engines.`,
        command: cli === "claude" ? "claude update" : `${cli} update`,
    };
}
const DRIVER_KIND = "claudeAgent";
// model catalog ported from upstream packages/contracts/src/model.ts
export const STATIC_CLAUDE_MODELS = {
    default: "claude-sonnet-5",
    options: [
        { id: "claude-fable-5-1", label: "Claude Fable 5.1" },
        { id: "claude-fable-5", label: "Claude Fable 5" },
        { id: "claude-opus-5", label: "Claude Opus 5" },
        { id: "claude-sonnet-5", label: "Claude Sonnet 5" },
        { id: "claude-haiku-4-5", label: "Claude Haiku 4.5" },
    ],
};
const CLAUDE_MODEL_ID = /^[a-z0-9][a-z0-9._:/-]*$/i;
/** Rewrite a leftover API slug (`orcarouter/Qwen…`) to `host::model` when a
 *  local host is serving it, so the turn injects instead of asking for /login.
 *  Official cloud ids and already-encoded inject ids skip the probe. */
async function resolveClaudeTurnModel(model, env) {
    if (!model || decodeInjectId(model) || STATIC_CLAUDE_MODELS.options.some((option) => option.id === model)) {
        return model;
    }
    return resolveInjectId(model, await probeLocalInjects(env)) ?? model;
}
function extrasFromUnknown(value) {
    if (!Array.isArray(value))
        return [];
    return value.flatMap((item) => {
        if (typeof item === "string") {
            return CLAUDE_MODEL_ID.test(item) ? [{ id: item, label: item }] : [];
        }
        if (!item || typeof item !== "object")
            return [];
        const row = item;
        const id = [row.id, row.model, row.slug].find((candidate) => typeof candidate === "string");
        if (!id || !CLAUDE_MODEL_ID.test(id))
            return [];
        const label = [row.name, row.displayName, row.label].find((candidate) => typeof candidate === "string");
        return [{ id, label: label || id }];
    });
}
/** Extra ids from ~/.claude/settings.json. Official cloud rows stay untagged.
 *  `model` is Claude Code's last-used slug, not a catalog — listing it as
 *  Custom put a non-inject id in the picker and the turn then had no
 *  ANTHROPIC_API_KEY ("Not logged in · Please run /login"). Live injects
 *  come from mergeLocalInject. */
export function readClaudeModelCatalog(env = process.env) {
    // A missing or unreadable settings.json is not fatal: an instance whose
    // environment sets ANTHROPIC_MODEL (a Claude Code install pointed at an
    // Anthropic-compatible host) still lists that model as Custom.
    let settings = {};
    try {
        settings = JSON.parse(readFileSync(join(resolveClaudeConfigDir(undefined, env), "settings.json"), "utf8"));
    }
    catch {
        settings = {};
    }
    const extras = [
        ...extrasFromUnknown(settings.availableModels),
        ...extrasFromUnknown(settings.customModels),
        ...extrasFromUnknown(settings.extraModels),
    ];
    const nestedEnv = settings.env && typeof settings.env === "object" ? settings.env : {};
    const envModel = nestedEnv.ANTHROPIC_MODEL ?? env.ANTHROPIC_MODEL;
    if (typeof envModel === "string")
        extras.push(...extrasFromUnknown([envModel]));
    const options = STATIC_CLAUDE_MODELS.options.map((option) => ({ ...option }));
    const seen = new Set(options.map((option) => option.id));
    for (const extra of extras) {
        if (seen.has(extra.id))
            continue;
        seen.add(extra.id);
        options.push({ id: extra.id, label: extra.label, custom: true });
    }
    return { default: STATIC_CLAUDE_MODELS.default, options };
}
// Resolved from the server root, never relative to this file: bundling inlines
// this module into an entry one directory up, so a `".."` here would climb too
// far. See server/proxy-paths.ts.
const PERM_PROXY_PATH = SPAWNED_PROXIES.permission;
const DWEB_PROXY_PATH = SPAWNED_PROXIES.dweb;
// in the packaged app process.execPath is the Electron binary — this env
// makes it behave as plain node for the spawned MCP proxies (harmless in dev)
const NODE_ENV_FLAG = { ELECTRON_RUN_AS_NODE: "1" };
function removePrivateTempDir(filePath) {
    if (!filePath)
        return true;
    try {
        rmSync(dirname(filePath), { recursive: true, force: true, maxRetries: 3, retryDelay: 50 });
        return true;
    }
    catch {
        return false;
    }
}
const DENY_TIMEOUT_NOTE = "OpenMausBot: nobody answered this permission request in time. Skip this action and finish what you can without it.";
const QUESTION_TIMEOUT_NOTE = "OpenMausBot: nobody answered in time. Use your best judgment and continue.";
const DUPLICATE_ASK_ID_NOTE = "OpenMausBot: duplicate ask id — skipping this request.";
/** The system-source reply for an ask that outlives the turn — used both to
 * drain in-flight `pending` asks on close() and to answer one that arrives
 * on an already-closed broker (see the `closed` branch below). */
function systemEndedReply(kind) {
    return kind === "question"
        ? { behavior: "answer", message: "OpenMausBot: the turn is ending — wrap up." }
        : { behavior: "deny", message: "OpenMausBot: the turn ended" };
}
/** The structured questions behind an ask, when it is one. Claude's own
 * AskUserQuestion and the ask_user proxy tool both carry them (the proxy
 * normalizes flat and v2-typed inputs before they reach the broker);
 * everything else answers null and keeps the plain summary/choices card. */
function askQuestions(ask) {
    if (ask.tool === ASK_USER_QUESTION_TOOL)
        return parseAskQuestions(ask.input);
    if (ask.tool === "ask_user") {
        return parseAskQuestions(ask.input)
            ?? normalizeAskUserInput({ question: ask.input?.question, choices: ask.input?.choices, type: ask.input?.type });
    }
    return null;
}
/** One human-readable line for an ask — what the card subtitle shows. */
function askSummary(ask) {
    const questions = askQuestions(ask);
    if (questions)
        return askQuestionSummary(questions).slice(0, 300);
    return askInputSummary(ask.input) ?? ask.tool ?? "tool";
}
export function permissionSocketPath(threadId, botId) {
    // A readable prefix alone is not unique: ids that agree on their first
    // characters ("t-perm-dup-1", "t-perm-dup-2") would share a socket. POSIX
    // hides that — a new broker's listen replaces the socket FILE, so the name
    // always points at the fresh server — but Windows named pipes live in a
    // global namespace that is never unlinked, and a reused name races the
    // previous broker's async teardown. Half the tag is a digest of the FULL
    // id so distinct threads get distinct sockets; the tag stays at 8 chars
    // total because the POSIX path already brushes the 104-byte sun_path
    // limit under deep tmp home dirs.
    //
    // botId is folded into the digest too (#1017): the driver's session/broker
    // maps are a single process-wide table keyed on threadId alone, so a
    // delegated child turn whose threadId ever coincides with its still-open
    // parent's (or any other bot's) would otherwise collide on the exact same
    // socket. Namespacing by bot makes that collision structurally impossible
    // regardless of how two turns end up sharing a threadId.
    const key = botId ? `${botId}\0${threadId}` : threadId;
    const prefix = threadId.replace(/[^\w-]/g, "").slice(0, 4);
    const digest = createHash("sha256").update(key).digest("hex").slice(0, 4);
    return brokerSocketPath(DATA_DIR, `${prefix}${digest}`);
}
/** Paths the broker may bind, tried in order. Windows named pipes are never
 * unlinkable, and a hung CLI child from an earlier server process can hold a
 * name for minutes, so fresh suffixes let the new broker bind immediately.
 * POSIX gets a short temp fallback because macOS rejects Unix socket paths
 * longer than its small `sun_path` limit; a deep test HOME or long username
 * can otherwise make every approval silently unavailable. The proxy learns
 * the actual bound path from its argv, so either fallback is transparent. */
export function brokerSocketCandidates(threadId, botId) {
    const base = permissionSocketPath(threadId, botId);
    if (process.platform !== "win32") {
        const scope = createHash("sha256")
            .update(`${DATA_DIR}\0${process.pid}\0${botId ?? ""}\0${threadId}`)
            .digest("hex")
            .slice(0, 16);
        return [base, join(tmpdir(), `omb-perm-${scope}.sock`)];
    }
    return [
        base,
        `${base}-${randomBytes(3).toString("hex")}`,
        `${base}-${randomBytes(3).toString("hex")}`,
    ];
}
export async function createPermissionBroker(opts) {
    const timeoutMs = opts.timeoutMs ?? 15 * 60_000;
    const pending = new Map();
    // server.close() only stops accepting NEW connections — it does not touch
    // a connection that's already open. A still-alive child's MCP proxy can
    // keep sending asks on such a connection after the turn has ended, and
    // this handler stays fully wired to it. Without this flag those asks would
    // become new `pending` entries and `request.opened` cards for a turn the
    // driver already forgot (`active.delete(threadId)` already ran), which can
    // never be answered — the "zombie card" in issue #211.
    let closed = false;
    let boundPath = opts.socketPaths[0] ?? "";
    const connectionHandler = (conn) => {
        conn.on("error", () => { });
        let buf = "";
        conn.on("data", (chunk) => {
            buf += chunk;
            let nl;
            while ((nl = buf.indexOf("\n")) !== -1) {
                const line = buf.slice(0, nl);
                buf = buf.slice(nl + 1);
                let msg;
                try {
                    msg = JSON.parse(line);
                }
                catch {
                    continue;
                }
                if (msg.t !== "ask")
                    continue;
                const askId = String(msg.id ?? newId());
                const kind = msg.kind === "question" ? "question" : "permission";
                if (closed) {
                    // Closure is terminal and takes precedence over every active-turn
                    // rule, including duplicate-id rejection. Never register a pending
                    // entry or notify onAsk, but always answer an existing connection:
                    // permission-proxy.ts only resolves on an explicit answer (or a
                    // connection error/close), so a silent drop would hang the tool.
                    try {
                        conn.write(JSON.stringify({ t: "answer", id: askId, ...systemEndedReply(kind) }) + "\n");
                    }
                    catch { }
                    continue;
                }
                // A retained Claude process keeps its proxy connection between
                // turns. Late/background asks must still fail closed without opening
                // a card for a turn that has already settled.
                if (opts.isActive && !opts.isActive()) {
                    try {
                        conn.write(JSON.stringify({ t: "answer", id: askId, ...systemEndedReply(kind) }) + "\n");
                    }
                    catch { }
                    continue;
                }
                // `pending` is server-scoped, not per-connection: two asks with the
                // same id — a buggy/adversarial client, never a legitimate retry
                // (permission-proxy mints a fresh randomUUID per ask) — would
                // otherwise let the second `pending.set` silently overwrite the
                // first, orphaning it as an unanswerable card once the first
                // resolves and deletes the shared key. Reject before either ask
                // becomes visible to onAsk.
                if (pending.has(askId)) {
                    // askId is client-controlled; JSON.stringify escapes newlines and
                    // control characters so it can't corrupt the log line or terminal.
                    console.error(`permission broker on ${boundPath}: duplicate ask id ${JSON.stringify(askId)} — denying`);
                    try {
                        conn.write(JSON.stringify({ t: "answer", id: askId, behavior: "deny", message: DUPLICATE_ASK_ID_NOTE }) + "\n");
                    }
                    catch { }
                    continue;
                }
                const ask = { id: askId, kind, tool: msg.tool ?? "tool", input: msg.input ?? {}, at: Date.now() };
                const finish = (behavior, message, source, always) => {
                    if (!pending.delete(askId))
                        return;
                    clearTimeout(timer);
                    try {
                        // `always` rides to the proxy, which hands the CLI's own suggested
                        // permission rules back as updatedPermissions: Claude remembers
                        // the allow for the session, the harness remembers nothing.
                        // `source` travels with the answer too: a proxy that cannot tell
                        // the human's words from a timeout note would file the timeout
                        // note as the human's words.
                        conn.write(JSON.stringify({ t: "answer", id: askId, behavior, message, source, ...(always ? { always: true } : {}) }) + "\n");
                    }
                    catch { }
                    opts.onResolve({ ...ask, behavior, source });
                };
                const timer = setTimeout(() => kind === "question"
                    ? finish("answer", QUESTION_TIMEOUT_NOTE, "timeout")
                    : finish("deny", DENY_TIMEOUT_NOTE, "timeout"), timeoutMs);
                timer.unref?.();
                pending.set(askId, { ask, finish });
                opts.onAsk(ask);
            }
        });
    };
    // Bind the first candidate that will take a listener. A broker that
    // never came up used to be silent — every approval then timed out into a
    // deny nobody could explain. Keep the turn fail-closed on total failure,
    // but leave an actionable diagnostic either way.
    let server = null;
    for (const [index, candidate] of opts.socketPaths.entries()) {
        const attempt = createNetServer(connectionHandler);
        try {
            unlinkSync(candidate);
        }
        catch { }
        let outcome = await new Promise((resolve) => {
            attempt.once("listening", () => resolve("listening"));
            // SAFETY: net 'error' events carry syscall errors; the optional
            // `code` is only read defensively below.
            attempt.once("error", (error) => resolve(error));
            attempt.listen(candidate);
        });
        // A fallback under the shared OS temp root must not be connectable by
        // another local account. DATA_DIR is private already, but applying the
        // same mode to every POSIX socket keeps the rule simple and fail-closed.
        if (outcome === "listening" && process.platform !== "win32") {
            try {
                chmodSync(candidate, 0o600);
            }
            catch (error) {
                try {
                    attempt.close();
                }
                catch { }
                try {
                    unlinkSync(candidate);
                }
                catch { }
                outcome = error;
            }
        }
        if (outcome === "listening") {
            if (index > 0) {
                console.error(`permission broker: ${opts.socketPaths[0]} is still held — bound fallback ${candidate}`);
            }
            boundPath = candidate;
            server = attempt;
            attempt.on("error", (error) => {
                console.error(`permission broker error on ${candidate}: ${error.message}`);
            });
            break;
        }
        try {
            attempt.close();
        }
        catch { }
        if (index === opts.socketPaths.length - 1) {
            console.error(`permission broker unavailable on ${candidate}: ${outcome.message}`);
            break;
        }
    }
    // Never hand the proxy an occupied candidate when every bind failed. That
    // could connect it to a stale (or unrelated) listener instead of this
    // broker, defeating the fail-closed boundary.
    if (!server)
        throw new Error("claude: permission broker could not bind a local socket");
    const drain = () => {
        for (const p of Array.from(pending.values())) {
            const { behavior, message } = systemEndedReply(p.ask.kind);
            p.finish(behavior, message, "system");
        }
    };
    return {
        answer(askId, behavior, message, always) {
            const p = pending.get(askId);
            if (!p)
                return false;
            if (p.ask.kind === "question" ? behavior !== "answer" : behavior === "answer")
                return false;
            p.finish(behavior, message, "user", always && behavior === "allow");
            return true;
        },
        pause() {
            drain();
        },
        close() {
            closed = true;
            drain();
            try {
                server?.close();
            }
            catch { }
            try {
                unlinkSync(boundPath);
            }
            catch { }
        },
        /** Where the broker actually listens — argv for the proxy child must
         * use this, not the deterministic base, when a fallback was bound. */
        socketPath: boundPath,
    };
}
function decodeToolList(value, field) {
    if (value === undefined)
        return undefined;
    if (!Array.isArray(value))
        throw new Error(`claude: ${field} must be an array of non-empty strings`);
    const decoded = [];
    const seen = new Set();
    for (const entry of value) {
        if (typeof entry !== "string" || !entry.trim()) {
            throw new Error(`claude: ${field} must be an array of non-empty strings`);
        }
        const normalized = entry.trim();
        if (seen.has(normalized))
            continue;
        seen.add(normalized);
        decoded.push(normalized);
    }
    return decoded;
}
function decodeConfig(raw) {
    const o = (raw ?? {});
    const mode = o.permissionMode;
    if (mode !== undefined && mode !== "acceptEdits" && mode !== "auto" && mode !== "bypassPermissions") {
        throw new Error(`claude: invalid permissionMode ${JSON.stringify(mode)}`);
    }
    const tools = decodeToolList(o.tools, "tools");
    const disallowedTools = decodeToolList(o.disallowedTools, "disallowedTools");
    if (o.configDir !== undefined && typeof o.configDir !== "string")
        throw new Error("claude: configDir must be a string");
    const configDir = typeof o.configDir === "string" ? o.configDir.trim() : undefined;
    if (configDir)
        resolveClaudeConfigDir(configDir);
    return {
        cli: typeof o.cli === "string" ? o.cli : "claude",
        ...(configDir ? { configDir } : {}),
        ...(o.managed === true ? { managed: true } : {}),
        permissionMode: mode ?? "acceptEdits",
        ...(tools !== undefined ? { tools } : {}),
        ...(disallowedTools !== undefined ? { disallowedTools } : {}),
    };
}
function firstText(content) {
    if (typeof content === "string")
        return content;
    if (Array.isArray(content)) {
        return content
            .filter((b) => b?.type === "text" && b.text)
            .map((b) => b.text)
            .join("");
    }
    return "";
}
/** Claude's stream-json input accepts the same image source blocks as the
 * Anthropic Messages API. Keep the old string form for text-only turns so a
 * CLI update cannot disturb the overwhelmingly common path. */
/** How a mid-session change to the volatile half of the system prompt
 * reaches a model whose process was launched with the old copy. The CLI's
 * own out-of-band convention inside a user turn, and it costs one short
 * append rather than a relaunch that re-uploads the whole prompt cache. */
function withVolatileNote(text, volatile) {
    const body = volatile.trim()
        ? `This part of your instructions changed since this session started. It replaces the earlier copy:\n\n${volatile.trim()}`
        : "The notes that were in your instructions when this session started have been cleared.";
    const note = `<system-reminder>\n${body}\n</system-reminder>`;
    return text ? `${note}\n\n${text}` : note;
}
function claudeUserMessage(text, images) {
    if (!images?.length)
        return { type: "user", message: { role: "user", content: text } };
    const content = images.map((image) => ({
        type: "image",
        source: {
            type: "base64",
            media_type: image.mime,
            data: readFileSync(image.path).toString("base64"),
        },
    }));
    if (text)
        content.push({ type: "text", text });
    return { type: "user", message: { role: "user", content } };
}
/** Native traces are routinely attached to bug reports. Preserve the image
 * block's shape and size for debugging, but never persist its base64 bytes. */
function diagnosticClaudeUserMessage(message) {
    if (!Array.isArray(message.message.content))
        return message;
    return {
        ...message,
        message: {
            ...message.message,
            content: message.message.content.map((block) => block.type === "image"
                ? {
                    ...block,
                    source: {
                        ...block.source,
                        data: `[image data: ${block.source.data.length} base64 chars]`,
                    },
                }
                : block),
        },
    };
}
export const ClaudeDriver = {
    driverKind: DRIVER_KIND,
    metadata: { displayName: "Claude", supportsMultipleInstances: true },
    // npm on all three: the one recipe that is genuinely cross-platform. The
    // native installers differ per OS and would need verifying separately.
    install: {
        command: {
            darwin: "npm install -g @anthropic-ai/claude-code",
            linux: "npm install -g @anthropic-ai/claude-code",
            win32: "npm install -g @anthropic-ai/claude-code",
        },
        needsNode: true,
        docsUrl: "https://claude.com/claude-code",
        signInCommand: "claude",
    },
    models: STATIC_CLAUDE_MODELS,
    decodeConfig,
    defaultConfig: () => decodeConfig({}),
    async create(input) {
        const { instanceId, config } = input;
        const environment = (model) => claudeEnvironment(config.managed ? undefined : model, { ...process.env, ...input.environment }, config.configDir, input.environment);
        const catalogEnv = environment();
        // Say it once where a headless or source run reads its logs; the Engines
        // page carries the same warning for the desktop (claudeInheritWarning).
        if (inheritsUserConfig(catalogEnv)) {
            console.error(`claude (${instanceId}): OMB_CLAUDE_INHERIT_USER_CONFIG=1 — bots inherit this machine's Claude Code MCP servers, skills, hooks and CLAUDE.md on every turn; remove it unless a bot needs a user-scope server`);
        }
        let models = STATIC_CLAUDE_MODELS;
        const refreshModels = async () => {
            if (config.managed)
                return;
            try {
                const resolved = await mergeLocalInject(readClaudeModelCatalog(catalogEnv), catalogEnv);
                if (resolved.options.length)
                    models = resolved;
            }
            catch {
                // Keep the last usable catalog when settings.json is unreadable.
            }
        };
        await refreshModels();
        // The installed CLI's version as snapshot() last read it, so a flag the
        // CLI does not know is never passed to it (CLAUDE_FLAG_FLOORS). The
        // harness snapshots every instance whenever it describes them — app
        // load, the Engines page, and right after `claude update`, which is
        // exactly when the answer changes — so a turn normally finds it filled.
        // Most turns before any snapshot assume a current CLI. A coordinated
        // turn checks first because the snapshot-refresh flag is newer than the
        // other context controls and an unknown flag would reject that request.
        let cliVersion = null;
        let cliVersionChecked = false;
        const readCliVersion = (env) => new Promise((resolve) => {
            execCli(config.cli, ["--version"], { timeout: 8000, env }, (err, stdout) => resolve(err ? null : stdout.trim() || null));
        });
        const listeners = new Set();
        // one active turn per thread; a second send while busy is a caller bug
        const active = new Map();
        const sessions = new Map();
        const configuredIdleMinimum = Number(process.env.OMB_CLAUDE_SESSION_IDLE_MIN_MS);
        const sessionIdleMinimum = Number.isFinite(configuredIdleMinimum) && configuredIdleMinimum > 0
            ? configuredIdleMinimum
            : 10_000;
        const SESSION_IDLE_MS = Math.max(sessionIdleMinimum, Number(process.env.OMB_CLAUDE_SESSION_IDLE_MS) || 10 * 60_000);
        const stopSession = (session) => {
            void killCliTree(session.child).then((stopped) => {
                if (stopped)
                    void session.finishClose?.();
            });
        };
        const closeSession = (threadId, why) => {
            const s = sessions.get(threadId);
            if (!s || s.closing)
                return;
            s.closing = true;
            if (s.idleTimer)
                clearTimeout(s.idleTimer);
            // Broker ownership belongs to this session. Detach and close it now,
            // before a replacement can bind the same per-thread socket; the old
            // child's later close event must never unlink a new broker.
            const broker = s.broker;
            s.broker = undefined;
            broker?.close();
            appendNative(threadId, { dir: "out", source: "claude.session", msg: { close: why } });
            // stdin EOF is the CLI's exit signal; give it a moment, then insist
            try {
                s.child.stdin.end();
            }
            catch { }
            const kill = setTimeout(() => {
                stopSession(s);
            }, 5_000);
            kill.unref?.();
        };
        const armIdle = (threadId) => {
            const s = sessions.get(threadId);
            if (!s)
                return;
            if (s.idleTimer)
                clearTimeout(s.idleTimer);
            s.idleTimer = setTimeout(() => closeSession(threadId, "idle"), SESSION_IDLE_MS);
            s.idleTimer.unref?.();
        };
        const writeUser = (s, threadId, promptMsg) => {
            if (!s.child.stdin.writable || s.child.stdin.destroyed)
                return Promise.resolve(false);
            return new Promise((resolve) => {
                try {
                    s.child.stdin.write(JSON.stringify(promptMsg) + "\n", (error) => {
                        if (error)
                            return resolve(false);
                        appendNative(threadId, {
                            dir: "out",
                            source: "claude.sdk.message",
                            msg: diagnosticClaudeUserMessage(promptMsg),
                        });
                        resolve(true);
                    });
                }
                catch {
                    resolve(false);
                }
            });
        };
        const emit = (event) => {
            for (const l of Array.from(listeners))
                l(event);
        };
        const base = (threadId, turnId) => ({
            eventId: newEventId(),
            provider: DRIVER_KIND,
            threadId,
            turnId,
            createdAt: new Date().toISOString(),
        });
        // retry bookkeeping lives PER THREAD, not per sendTurn call: a relaunch
        // is a fresh sendTurn, and the attempt cap must survive across launches
        const retryState = new Map();
        const sendTurn = async (turn, logicalTurnId) => {
            if (config.managed && (!turn.model || turn.model.includes("::") || !config.configDir ||
                !input.environment.ANTHROPIC_API_KEY || !input.environment.ANTHROPIC_BASE_URL)) {
                throw new Error("Company model access is unavailable. Reconnect your organization; personal billing will not be used.");
            }
            const { threadId, botId } = turn;
            // An internal relaunch (transient failure, rejected resume) keeps the
            // logical turn's stop handle in `active` while it sets up, so Stop is
            // never a silent no-op between two CLI processes of the same turn.
            const relaunch = logicalTurnId !== undefined;
            if (active.has(threadId) && !relaunch)
                throw new Error("a turn is already running on this thread");
            // A bot-level mode is authoritative for this turn. In particular, an
            // old provider instance may still be configured with
            // `bypassPermissions`; Ask/Auto must restore Claude's interactive
            // broker instead of inheriting that silent bypass. Calls without a
            // per-turn mode keep the legacy adapter behavior.
            const permissionMode = turn.approvalMode === undefined
                ? config.permissionMode
                : turn.approvalMode === "full" ? "bypassPermissions"
                    : turn.approvalMode === "auto" ? "auto"
                        : turn.approvalMode === "edits" ? "acceptEdits" : "default";
            const controlsHost = turn.integrations?.localComputer?.scope === "local-computer";
            if (controlsHost && permissionMode === "bypassPermissions" && turn.approvalMode !== "full") {
                throw new Error("local computer control requires the interactive approval broker");
            }
            // Materialize before creating a broker or process. A missing/corrupt
            // attachment must fail this call without leaving a live session behind.
            const promptMsg = claudeUserMessage(turn.text, turn.images);
            // Internal relaunches are still the turn acknowledged to the harness.
            // A new user message gets a fresh id, but retry/recovery must not orphan
            // its capability, coordination result or queued continuation ownership.
            const turnId = logicalTurnId ?? newId();
            const retryAbort = new AbortController();
            const retry = retryState.get(threadId) ?? { attempt: 0, cancelled: false };
            // A fresh user turn starts un-cancelled. A relaunch must keep a Stop
            // that landed while it was being scheduled.
            if (!relaunch) {
                retry.cancelled = false;
                retry.rebuilt = false;
            }
            retryState.set(threadId, retry);
            // a retry relaunches the whole CLI; the backoff is scaled down in tests
            // so a fake's transient failures don't stall real seconds
            const retryScale = Number(process.env.FAKE_CLAUDE_RETRY_SCALE ?? "1");
            const sessionId = typeof turn.resumeCursor === "string" ? turn.resumeCursor : null;
            const newSessionId = sessionId ? null : newId();
            const args = [
                "-p",
                "--output-format", "stream-json",
                "--input-format", "stream-json",
                "--verbose", // required by stream-json output
                // token-level streaming: content_block_delta events between the
                // whole-message frames, so the bubble grows as the model writes
                "--include-partial-messages",
                "--permission-mode", permissionMode,
            ];
            if (config.tools !== undefined)
                args.push("--tools", config.tools.join(","));
            const disallowedTools = new Set(config.disallowedTools ?? []);
            const diskPerms = loadDiskPermissions();
            for (const t of disallowedToolsForPermissions(diskPerms)) {
                disallowedTools.add(t);
            }
            if (disallowedTools.size > 0) {
                args.push("--disallowedTools", Array.from(disallowedTools).join(","));
            }
            const turnEnvironment = environment();
            if (turn.refreshSystemPrompt && !cliVersionChecked) {
                const version = await readCliVersion(turnEnvironment);
                if (version) {
                    cliVersion = parseClaudeCliVersion(version);
                    cliVersionChecked = true;
                }
            }
            const isolated = !inheritsUserConfig(turnEnvironment);
            if (isolated) {
                // A bot gets the tools and instructions its owner gave it, not
                // whatever this machine's Claude Code happens to be set up with.
                // Without these the CLI silently adds, to EVERY turn of every bot:
                // the desktop's own MCP servers and claude.ai connectors (one
                // measured desktop mounted 407 extra tools, ~10k tokens), its skill
                // and agent listings, its hooks, and its personal CLAUDE.md. Every
                // model call in the session then re-reads all of it.
                // Each flag only on a CLI that accepts it: an unknown flag is an
                // argument error that would fail every turn (CLAUDE_FLAG_FLOORS).
                // The MCP half has a switch (Plugins → MCP servers → "Also use my
                // Claude Code MCP servers"): with it on, the CLI loads the servers
                // and connectors from the person's own Claude Code config — the way
                // Codex reads its own config.toml — while skills, hooks and the
                // personal CLAUDE.md stay out.
                if (!turn.mcpFromUserConfig && claudeCliSupports(cliVersion, "--strict-mcp-config"))
                    args.push("--strict-mcp-config");
                if (claudeCliSupports(cliVersion, "--setting-sources"))
                    args.push("--setting-sources", "project");
            }
            const compactWindow = autoCompactWindow(turnEnvironment);
            if (compactWindow && claudeCliSupports(cliVersion, "--autocompact")) {
                args.push("--autocompact", compactWindow);
            }
            // An old pair conversation can still carry its first assignment in
            // Claude's recorded system prompt. The current brief rides in the user
            // turn, so refresh the recorded prompt on --resume too. Gated by the
            // version floor like every other flag the CLI may predate: an unknown
            // flag is a hard argument error, not a graceful degrade.
            if (turn.refreshSystemPrompt && cliVersionChecked && claudeCliSupports(cliVersion, "--system-prompt-snapshot")) {
                args.push("--system-prompt-snapshot", "off");
            }
            const turnModel = config.managed ? turn.model : await resolveClaudeTurnModel(turn.model, turnEnvironment);
            const injected = config.managed ? { model: turnModel ?? null, injected: false } : applyClaudeInject({ ...turnEnvironment }, turnModel);
            if (injected.model)
                args.push("--model", injected.model);
            if (turn.effort)
                args.push("--effort", turn.effort);
            // A room prompt can contain section context, skills, memory, playbooks,
            // and browser/agent instructions. Passing that text directly on argv
            // exceeds Windows' CreateProcess command-line limit and surfaces as
            // `spawn ENAMETOOLONG`. Claude accepts the same prompt from a file, so
            // keep both the text and its potentially sensitive contents off argv.
            let systemPromptPath = null;
            // integrations → MCP servers; pre-allow their tools (a headless
            // acceptEdits run silently denies anything unlisted)
            const mcpServers = {};
            const allowed = [];
            if (turn.integrations?.composio) {
                mcpServers.composio = { ...turn.integrations.composio };
                allowed.push("mcp__composio");
            }
            if (turn.integrations?.localComputer) {
                const local = turn.integrations.localComputer;
                mcpServers.computer = {
                    command: local.command,
                    args: local.args,
                    env: local.env,
                };
                // The isolated Local VM preserves the established pre-allow behavior.
                // Host tools always route through OpenMausBot's permission broker.
                if (!controlsHost)
                    allowed.push("mcp__computer");
            }
            // peer-agent comms (list_bots/ask_bot) — the harness builds the whole
            // spawn contract (command/args/env incl. the boot token) in
            // agentsIntegration(); pre-allowing matters doubly here, or the CLI's
            // own ListAgents look-alike shadows it and "@Bot" asks go nowhere
            if (turn.integrations?.agents) {
                // Coordination is foundational, not an optional deferred lookup.
                // Claude waits for always-loaded tools before building the prompt.
                mcpServers.agents = { ...turn.integrations.agents, alwaysLoad: true };
                allowed.push("mcp__agents");
            }
            if (turn.integrations?.phone) {
                mcpServers.phone = { ...turn.integrations.phone };
                allowed.push("mcp__phone");
            }
            if (turn.integrations?.browser) {
                mcpServers.browser = { ...turn.integrations.browser };
                allowed.push("mcp__browser");
            }
            // dweb network daemon (status / repo / opencode model access) via
            // server/drivers/dweb-proxy.ts — points at the configured dweb instance
            if (turn.integrations?.dweb) {
                mcpServers.dweb = {
                    command: process.execPath,
                    args: [DWEB_PROXY_PATH],
                    env: {
                        ...NODE_ENV_FLAG,
                        DWEB_URL: turn.integrations.dweb.url,
                    },
                };
                allowed.push("mcp__dweb");
            }
            // user-configured servers mount like any integration but are NOT
            // pre-allowed: acceptEdits silently denies unlisted tools, which
            // routes every custom tool call through the ogb permission broker
            // into an Allow/Deny card. Reserved names were filtered upstream;
            // skip any residual collision instead of clobbering a built-in.
            // A remote entry ({type, url, headers}) is already in the CLI's own
            // shape and the CLI connects to it itself; header values ride in the
            // 0600 config file like every other credential here.
            // Bot-owned servers, gated below: they are the ones that answer for a
            // machine rather than for a context window.
            const botOwned = new Set();
            for (const [name, server] of Object.entries(turn.integrations?.custom ?? {})) {
                if (Object.hasOwn(mcpServers, name))
                    continue;
                mcpServers[name] = { ...server };
                botOwned.add(name);
            }
            // --strict-mcp-config (above) makes this config the CLI's only source
            // of MCP servers, so a server the bot's OWN project declares would
            // otherwise vanish with the machine's. Merge it last: a project file
            // can add servers but never shadow a harness-owned mount.
            if (isolated && turn.cwd) {
                for (const [name, server] of Object.entries(projectMcpServers(turn.cwd))) {
                    if (Object.hasOwn(mcpServers, name))
                        continue;
                    mcpServers[name] = server;
                    botOwned.add(name);
                }
            }
            // One tool call can put more into the conversation than the whole rest
            // of the session: a single product search measured 60-140 KB of JSON,
            // and the CLI re-reads it on every later model call. The harness never
            // sees these calls — the CLI runs the server itself — so the only place
            // to stand is between the two processes. Harness-owned mounts (the
            // permission broker, computer, browser, agents, dweb) are already
            // bounded and are deliberately left alone.
            const budget = resultBudget(turnEnvironment);
            for (const name of botOwned) {
                const gated = gateServer({ name, server: mcpServers[name], threadId, budget, nodeEnv: NODE_ENV_FLAG });
                if (gated)
                    mcpServers[name] = gated;
            }
            // Keep ask_user available even in Full access. Native bypass skips
            // permission prompts, not questions requiring a person's answer.
            let broker;
            const socketPath = permissionSocketPath(threadId, botId);
            if (permissionMode !== "bypassPermissions") {
                args.push("--permission-prompt-tool", "mcp__ogb__approve");
            }
            mcpServers.ogb = { command: process.execPath, args: [PERM_PROXY_PATH, socketPath], env: { ...NODE_ENV_FLAG }, alwaysLoad: true };
            allowed.push("mcp__ogb");
            // The MCP config carries credentials — a Composio consumer key in a
            // header, the box token in the computer proxy's env, the comms token in
            // the agents proxy's env. On argv every one of those is world-readable
            // through `ps` for the life of the turn, to any local process. The CLI
            // accepts a FILE for this flag, so the secrets go in a 0600 file that
            // is removed when the turn settles.
            let mcpConfigPath = null;
            if (Object.keys(mcpServers).length) {
                mcpConfigPath = join(mkdtempSync(join(tmpdir(), "omb-mcp-")), "mcp.json");
                args.push("--mcp-config", mcpConfigPath);
                args.push("--allowedTools", allowed.join(","));
            }
            const env = environment(turnModel);
            const authSettings = isolated && !injected.injected
                ? readClaudeAuthSettings(env, input.environment) : {};
            const authSettingsPath = mcpConfigPath && Object.keys(authSettings).length
                ? join(dirname(mcpConfigPath), "auth-settings.json") : null;
            if (authSettingsPath)
                args.push("--settings", authSettingsPath);
            // Our approvals and browser credentials expire at the user-turn
            // boundary. Native background workers cannot outlive that boundary;
            // parallel bot work must use the harness's durable delegate_bot path.
            env.CLAUDE_CODE_DISABLE_BACKGROUND_TASKS = "1";
            const cwd = turn.cwd ?? homedir();
            // Everything that shapes the process, minus session/turn-specific temp
            // paths. Their contents are represented directly in the key instead.
            const privateFileFlags = new Set(["--mcp-config", "--settings"]);
            const keyArgs = args.filter((a, i) => !privateFileFlags.has(a) && !privateFileFlags.has(args[i - 1] ?? ""));
            const argsKey = JSON.stringify({
                args: keyArgs,
                // the volatile half is deliberately absent: it must not respawn a
                // healthy session (see Session.volatile)
                system: turn.systemStable ?? turn.system ?? null,
                mcpServers,
                cwd,
                model: injected.model ?? null,
                base: env.ANTHROPIC_BASE_URL ?? null,
                configDir: env.CLAUDE_CONFIG_DIR ?? null,
                // Rotating an account's key/helper must not reuse the old process.
                auth: createHash("sha256").update(JSON.stringify({
                    settings: authSettings,
                    env: Object.fromEntries(CLAUDE_ACCOUNT_ENV_KEYS.map((key) => [key, env[key]])),
                })).digest("hex"),
            });
            // Reuse the live process when it is idle, unchanged, and is the session
            // the harness wants resumed. Anything else: close it and spawn fresh
            // (with --resume, so the conversation continues in the new process).
            const live = sessions.get(threadId);
            if (live && !live.turn && !live.closing && live.child.exitCode === null && live.argsKey === argsKey && (!sessionId || sessionId === live.sessionId)) {
                if (live.idleTimer)
                    clearTimeout(live.idleTimer);
                live.turn = { turnId, input: turn, retryAbort, settled: false, sawStreamDelta: false };
                active.set(threadId, { stop: () => {
                        closeSession(threadId, "interrupted");
                        retry.cancelled = true;
                        retryAbort.abort();
                        stopSession(live);
                    }, turnId, broker: live.broker });
                emit({ ...base(threadId, turnId), type: "turn.started" });
                const volatile = turn.systemVolatile ?? "";
                const message = volatile === live.volatile
                    ? promptMsg
                    : claudeUserMessage(withVolatileNote(turn.text, volatile), turn.images);
                live.volatile = volatile;
                const written = await writeUser(live, threadId, message);
                if (!written) {
                    active.delete(threadId);
                    live.turn = null;
                    closeSession(threadId, "stdin write failed");
                    retryState.delete(threadId);
                    if (mcpConfigPath) {
                        try {
                            rmSync(dirname(mcpConfigPath), { recursive: true, force: true });
                        }
                        catch { }
                    }
                    throw new Error("claude session stdin is not writable");
                }
                // the MCP config was for the first spawn; nothing to clean here
                if (mcpConfigPath) {
                    try {
                        rmSync(dirname(mcpConfigPath), { recursive: true, force: true });
                    }
                    catch { }
                }
                return { turnId };
            }
            if (live)
                closeSession(threadId, "spawn contract changed");
            // Until sessions.set() below, this turn owns every launch resource.
            // Any bind, private-config or synchronous spawn failure must release
            // them here rather than leave a live listener or credential temp file.
            const cleanupUnownedLaunch = () => {
                broker?.close();
                broker = undefined;
                if (mcpConfigPath) {
                    try {
                        rmSync(dirname(mcpConfigPath), { recursive: true, force: true });
                    }
                    catch { }
                    mcpConfigPath = null;
                }
                if (systemPromptPath) {
                    removePrivateTempDir(systemPromptPath);
                    systemPromptPath = null;
                }
                retryState.delete(threadId);
            };
            try {
                // Create the prompt file only for a new process. A compatible live
                // session has already consumed the same system prompt at launch.
                if (turn.system) {
                    systemPromptPath = join(mkdtempSync(join(tmpdir(), "omb-system-")), "prompt.txt");
                    writeFileSync(systemPromptPath, turn.system, { mode: 0o600 });
                    args.push("--append-system-prompt-file", systemPromptPath);
                }
                // Only create a broker for a new process. A compatible retained
                // process keeps its existing proxy connection and broker across turns.
                if (socketPath) {
                    // remembers which tool each pending ask came from, so the resolved
                    // event can scope approvals to real desktop-control tools only
                    const askTools = new Map();
                    broker = await createPermissionBroker({
                        socketPaths: brokerSocketCandidates(threadId, botId),
                        isActive: () => Boolean(sessions.get(threadId)?.turn),
                        onAsk: (ask) => {
                            const eventTurnId = sessions.get(threadId)?.turn?.turnId ?? turnId;
                            askTools.set(ask.id, typeof ask.tool === "string" ? ask.tool : undefined);
                            // Auto was requested: say whether the CLI's reviewer is actually
                            // running, from init, so the harness can tell a classifier's
                            // verdict from a Manual session asking about everything.
                            const nativeMode = sessions.get(threadId)?.nativePermissionMode ?? null;
                            const nativeReview = permissionMode === "auto" && nativeMode !== null
                                ? nativeMode === "auto" ? "active" : "inactive"
                                : undefined;
                            const questions = askQuestions(ask);
                            emit({
                                ...base(threadId, eventTurnId),
                                type: "request.opened",
                                requestId: ask.id,
                                requestType: ask.kind,
                                tool: ask.tool,
                                summary: askSummary(ask),
                                nativeReview,
                                // the proxy hands Claude its own suggested rules on `always`;
                                // host control stays one action at a time
                                allowSession: ask.kind === "permission" && !(controlsHost && typeof ask.tool === "string" && ask.tool.startsWith("mcp__computer")) ? true : undefined,
                                approvalScope: typeof ask.tool === "string" && controlsHost && ask.tool.startsWith("mcp__computer")
                                    ? "local-computer"
                                    : undefined,
                                questions: questions ?? undefined,
                                // A structured ask still offers flat labels, for the phone
                                // companions and any client that predates the question card.
                                choices: questions ? questionChoices(questions) : parseChoices(ask.input?.choices),
                            });
                        },
                        onResolve: (resolved) => {
                            const eventTurnId = sessions.get(threadId)?.turn?.turnId ?? turnId;
                            emit({
                                ...base(threadId, eventTurnId),
                                type: "request.resolved",
                                requestId: resolved.id,
                                behavior: resolved.behavior,
                                source: resolved.source,
                                approvalScope: controlsHost && typeof askTools.get(resolved.id) === "string" && askTools.get(resolved.id).startsWith("mcp__computer") ? "local-computer" : undefined,
                            });
                            askTools.delete(resolved.id);
                        },
                    });
                    // A fallback bind means the deterministic pipe is still held by an
                    // earlier process's child. The proxy learns its path from argv, so
                    // point it at the pipe we actually bound. argsKey deliberately keeps
                    // the base path: the nonce is not part of the spawn contract, and a
                    // retained session keeps its own broker object anyway.
                    if (broker.socketPath !== socketPath && mcpConfigPath) {
                        mcpServers.ogb = { command: process.execPath, args: [PERM_PROXY_PATH, broker.socketPath], env: { ...NODE_ENV_FLAG }, alwaysLoad: true };
                    }
                }
                // Write once, only after the broker has selected its real endpoint.
                if (mcpConfigPath) {
                    writeFileSync(mcpConfigPath, JSON.stringify({ mcpServers }), { mode: 0o600 });
                }
                if (authSettingsPath) {
                    writeFileSync(authSettingsPath, JSON.stringify(authSettings), { mode: 0o600 });
                }
                if (sessionId)
                    args.push("--resume", sessionId);
                else
                    args.push("--session-id", newSessionId);
            }
            catch (error) {
                cleanupUnownedLaunch();
                throw error;
            }
            // Stop reached the relaunch handle while this attempt was still setting
            // up (model probe, broker). Settle the logical turn as interrupted
            // instead of spawning a process nobody wants.
            if (relaunch && retry.cancelled) {
                cleanupUnownedLaunch();
                if (active.get(threadId)?.turnId === turnId)
                    active.delete(threadId);
                emit({ ...base(threadId, turnId), type: "turn.completed", ok: false, stopReason: "interrupted", cost: null });
                return { turnId };
            }
            let child;
            try {
                child = spawnCli(config.cli, args, {
                    cwd,
                    env,
                    stdio: ["pipe", "pipe", "pipe"],
                });
            }
            catch (error) {
                cleanupUnownedLaunch();
                throw error;
            }
            const session = {
                child,
                broker,
                mcpConfigPath,
                systemPromptPath,
                argsKey,
                volatile: turn.systemVolatile ?? "",
                sessionId: sessionId ?? newSessionId,
                sawInit: false,
                nativePermissionMode: null,
                turn: { turnId, input: turn, retryAbort, settled: false, sawStreamDelta: false },
                idleTimer: null,
                closing: false,
                stderr: "",
            };
            sessions.set(threadId, session);
            // settles the TURN, not the process: the CLI stays for the next
            // message until it has been quiet for SESSION_IDLE_MS
            const settle = (ok, stopReason, cost = null, usage) => {
                const t = session.turn;
                if (!t || t.settled)
                    return;
                t.settled = true;
                // Resolve any ask still open for this turn, but keep the broker
                // listening for the next turn on the retained process. Between turns
                // isActive() rejects late background asks without creating cards.
                session.broker?.pause();
                // the config file holds live credentials — the CLI read it at start;
                // it must not sit on disk for the life of the session
                if (session.mcpConfigPath) {
                    try {
                        rmSync(dirname(session.mcpConfigPath), { recursive: true, force: true });
                    }
                    catch { }
                    session.mcpConfigPath = null;
                }
                if (session.systemPromptPath) {
                    if (removePrivateTempDir(session.systemPromptPath))
                        session.systemPromptPath = null;
                }
                active.delete(threadId);
                session.turn = null;
                // A settled turn owns no retry budget. Retained CLI sessions may run
                // many later turns on this thread, and each must start fresh.
                retryState.delete(threadId);
                emit({ ...base(threadId, t.turnId), type: "turn.completed", ok, stopReason, cost, ...(usage ? { usage } : {}) });
                if (session.child.exitCode === null && !session.closing)
                    armIdle(threadId);
            };
            const currentTurnId = () => session.turn?.turnId ?? turnId;
            const handleLine = (line) => {
                if (session.closing)
                    return;
                let o;
                try {
                    o = JSON.parse(line);
                }
                catch {
                    return;
                }
                appendNative(threadId, { dir: "in", source: "claude.sdk.message", msg: o });
                switch (o.type) {
                    case "system":
                        if (o.subtype === "init") {
                            session.sawInit = true;
                            session.nativePermissionMode = typeof o.permissionMode === "string" ? o.permissionMode : null;
                            if (typeof o.session_id === "string")
                                session.sessionId = o.session_id;
                            emit({ ...base(threadId, currentTurnId()), type: "session.started", sessionId: o.session_id, model: o.model, ...(retry.rebuilt ? { rebuilt: true } : {}) });
                        }
                        else if (o.subtype === "thinking_tokens") {
                            emit({ ...base(threadId, currentTurnId()), type: "item.updated", itemType: "reasoning", tokens: o.estimated_tokens });
                        }
                        break;
                    case "stream_event": {
                        // subagent narration is dropped — N parallel Tasks would
                        // interleave their prose into one bubble (upstream-verified bug)
                        if (o.parent_tool_use_id)
                            break;
                        const ev = o.event ?? {};
                        if (ev.type !== "content_block_delta")
                            break;
                        const d = ev.delta ?? {};
                        if (d.type === "text_delta" && typeof d.text === "string" && d.text) {
                            if (session.turn)
                                session.turn.sawStreamDelta = true;
                            emit({ ...base(threadId, currentTurnId()), type: "content.delta", streamKind: "assistant_text", delta: d.text });
                        }
                        else if (d.type === "thinking_delta" && typeof d.thinking === "string" && d.thinking) {
                            emit({ ...base(threadId, currentTurnId()), type: "content.delta", streamKind: "reasoning_text", delta: d.thinking });
                        }
                        break;
                    }
                    case "assistant": {
                        const msg = o.message ?? {};
                        const text = firstText(msg.content);
                        // An unauthenticated turn comes back as an api-error frame whose
                        // only content is the CLI's own "run /login" instruction — a
                        // command this app has no terminal to run, so relaying it as a
                        // reply strands the user. Every other engine reports this as a
                        // setup error; that is what routes them to the sign-in card.
                        if (claudeAuthFailure(o, text)) {
                            if (session.turn)
                                session.turn.authFailed = true;
                            emit({ ...base(threadId, currentTurnId()), type: "runtime.error", message: text, setup: true });
                            break;
                        }
                        if (text.trim()) {
                            // The CLI's own report of any other API error is still shown,
                            // but marked: the model never produced it.
                            const synthetic = o.is_api_error_message === true || typeof o.error === "string" ? { synthetic: true } : {};
                            // fallback delta for CLIs/paths that never streamed the block
                            if (!session.turn?.sawStreamDelta) {
                                emit({ ...base(threadId, currentTurnId()), ...synthetic, type: "content.delta", streamKind: "assistant_text", delta: text });
                            }
                            if (session.turn)
                                session.turn.sawStreamDelta = false;
                            emit({ ...base(threadId, currentTurnId()), ...synthetic, type: "item.completed", itemType: "assistant_text", text });
                        }
                        for (const b of Array.isArray(msg.content) ? msg.content : []) {
                            if (b.type === "tool_use") {
                                emit({
                                    ...base(threadId, currentTurnId()),
                                    type: "item.started",
                                    itemType: "tool",
                                    itemId: b.id,
                                    title: b.name,
                                    summary: commandSummary(b.input),
                                    input: toolDetailPreview(b.input),
                                });
                            }
                        }
                        if (msg.usage) {
                            emit({
                                ...base(threadId, currentTurnId()),
                                type: "thread.token-usage.updated",
                                input: (msg.usage.input_tokens || 0) + (msg.usage.cache_read_input_tokens || 0),
                                output: msg.usage.output_tokens || 0,
                                ...(typeof msg.usage.cache_read_input_tokens === "number"
                                    ? { cachedInput: msg.usage.cache_read_input_tokens }
                                    : {}),
                                // one assistant message = one model call, and its prompt is
                                // everything in the window: fresh text, cache reads and writes
                                contextTokens: (msg.usage.input_tokens || 0) + (msg.usage.cache_read_input_tokens || 0) + (msg.usage.cache_creation_input_tokens || 0),
                            });
                        }
                        break;
                    }
                    case "user":
                        for (const b of Array.isArray(o.message?.content) ? o.message.content : []) {
                            if (b.type === "tool_result") {
                                emit({ ...base(threadId, currentTurnId()), type: "item.completed", itemType: "tool", itemId: b.tool_use_id, ok: !b.is_error, output: toolDetailPreview(b.content) });
                            }
                        }
                        break;
                    case "result":
                        // A synthetic background completion is not the result of the
                        // submitted user turn. Settling it would revoke browser access
                        // and deny approvals while that user turn is still running.
                        if (o.origin?.kind === "task-notification")
                            break;
                        // result.usage is this invocation's total — one process per turn,
                        // so it is the turn's figure. cache reads count as input: they
                        // are billed (at the cache rate) and they fill the window — but
                        // they are reported separately too, so the UI can show how much
                        // of the figure was context re-read rather than new text.
                        settle(o.is_error !== true, session.turn?.authFailed ? "auth_required" : o.stop_reason ?? o.terminal_reason ?? null, o.total_cost_usd ?? null, o.usage
                            ? {
                                input: (o.usage.input_tokens || 0) + (o.usage.cache_read_input_tokens || 0) + (o.usage.cache_creation_input_tokens || 0),
                                output: o.usage.output_tokens || 0,
                                ...(typeof o.usage.cache_read_input_tokens === "number"
                                    ? { cachedInput: o.usage.cache_read_input_tokens }
                                    : {}),
                            }
                            : undefined);
                        break;
                }
            };
            let buf = "";
            // decode as UTF-8 across chunk boundaries — a raw `buf += chunk` splits
            // multibyte characters that straddle two reads and corrupts the text
            child.stdout.setEncoding("utf8");
            child.stdout.on("data", (chunk) => {
                buf += chunk;
                let nl;
                while ((nl = buf.indexOf("\n")) !== -1) {
                    const line = buf.slice(0, nl);
                    buf = buf.slice(nl + 1);
                    if (line.trim())
                        handleLine(line);
                }
            });
            child.stderr.on("data", (c) => {
                session.stderr += c;
                if (session.stderr.length > 8192)
                    session.stderr = session.stderr.slice(-8192);
            });
            child.on("error", (e) => {
                emit({ ...base(threadId, currentTurnId()), type: "runtime.error", ...describeSpawnFailure(e, config.cli) });
                settle(false, "spawn_error");
            });
            let closeFinalized = false;
            const finalizeClose = async (code) => {
                if (closeFinalized)
                    return;
                // The root can close while its MCP helpers are still running. Join
                // an in-flight stop (or reap its remaining group) before releasing
                // the turn so a replacement cannot overlap the old helpers.
                if (!(await killCliTree(child, 0))) {
                    session.broker?.close();
                    session.broker = undefined;
                    emit({ ...base(threadId, currentTurnId()), type: "runtime.error", message: "Claude could not be confirmed stopped; its helper processes may still be running." });
                    return;
                }
                if (closeFinalized)
                    return;
                closeFinalized = true;
                // a turn still running when the process died is a failed turn; a
                // process that exited between turns (idle close, contract change)
                // is just a session ending
                if (session.turn && !session.turn.settled) {
                    // A retained process may be running a later user turn. Its close
                    // handler must retry that request, not the process's first prompt.
                    const { turnId, input: turn, retryAbort } = session.turn;
                    const retry = retryState.get(threadId) ?? { attempt: 0, cancelled: false };
                    const message = `claude exited ${code} before result${session.stderr ? `: ${session.stderr.trim().slice(-300)}` : ""}`;
                    const verdict = classifyError({ exitCode: code, stderr: message });
                    if (!retry.cancelled &&
                        code !== 0 &&
                        verdict.transient &&
                        !session.turn.sawStreamDelta &&
                        retry.attempt < RETRY_MAX_ATTEMPTS - 1) {
                        // the CLI is gone but the TURN continues: keep the thread busy,
                        // emit no terminal event, and relaunch after the backoff. The
                        // `active` entry STAYS — it is what makes an interrupt during
                        // the backoff reach this turn's stop() and cancel the retry.
                        const failedBroker = session.broker;
                        session.broker = undefined;
                        failedBroker?.pause();
                        failedBroker?.close();
                        if (session.mcpConfigPath) {
                            try {
                                rmSync(dirname(session.mcpConfigPath), { recursive: true, force: true });
                            }
                            catch { }
                            session.mcpConfigPath = null;
                        }
                        if (session.systemPromptPath) {
                            removePrivateTempDir(session.systemPromptPath);
                            session.systemPromptPath = null;
                        }
                        sessions.delete(threadId);
                        session.turn = null;
                        retry.attempt++;
                        const delayMs = computeBackoff(retry.attempt - 1);
                        emit({
                            ...base(threadId, turnId),
                            type: "turn.retrying",
                            attempt: retry.attempt,
                            delayMs,
                            reason: verdict.reason,
                        });
                        void (async () => {
                            const wait = interruptibleDelay(delayMs * retryScale, retryAbort.signal);
                            await wait.promise;
                            // an interrupt during the backoff landed here via stop(); the
                            // turn settles as interrupted and no zombie relaunch happens
                            if (retry.cancelled) {
                                active.delete(threadId);
                                retryState.delete(threadId);
                                emit({
                                    ...base(threadId, turnId),
                                    type: "turn.completed",
                                    ok: false,
                                    stopReason: "interrupted",
                                    cost: null,
                                });
                                return;
                            }
                            // Keep Stop reachable while the relaunch sets up: there is no
                            // process yet, so this handle only records the cancellation and
                            // the relaunched sendTurn honors it before spawning.
                            retryState.set(threadId, retry);
                            active.set(threadId, { stop: () => { retry.cancelled = true; retryAbort.abort(); }, turnId });
                            try {
                                const cursor = session.sessionId ?? sessionId ?? undefined;
                                await sendTurn({ ...turn, resumeCursor: cursor }, turnId);
                            }
                            catch (e) {
                                if (active.get(threadId)?.turnId === turnId)
                                    active.delete(threadId);
                                retryState.delete(threadId);
                                emit({
                                    ...base(threadId, turnId),
                                    type: "runtime.error",
                                    message: e instanceof Error ? e.message : String(e),
                                });
                                emit({
                                    ...base(threadId, turnId),
                                    type: "turn.completed",
                                    ok: false,
                                    stopReason: "exit_before_result",
                                    cost: null,
                                });
                            }
                        })();
                        return;
                    }
                    // A --resume that the CLI never acknowledged: it exited without
                    // an `init` frame, so it never read the prompt and this turn has
                    // caused nothing. Without this the thread is BRICKED — the dead
                    // cursor is never cleared, so every later turn resumes the same
                    // missing session and fails identically, and the user has no way
                    // back except switching engines. One fresh session, carrying the
                    // harness's rebuild of the conversation. Exactly one: the relaunch
                    // offers no cursor, so `attempted` is false there and a second
                    // failure is reported like any other.
                    const resumeFailure = classifyResumeFailure({
                        attempted: Boolean(sessionId),
                        rejected: !session.sawInit,
                        promptSubmitted: session.sawInit,
                        producedOutput: session.turn.sawStreamDelta,
                    });
                    if (mayReplay(resumeFailure) && !retry.cancelled) {
                        const recovery = recoveryPromptFor({
                            recoveryText: turn.recoveryText,
                            currentText: turn.text,
                            failure: resumeFailure,
                        });
                        session.broker?.close();
                        session.broker = undefined;
                        if (session.mcpConfigPath) {
                            try {
                                rmSync(dirname(session.mcpConfigPath), { recursive: true, force: true });
                            }
                            catch { }
                            session.mcpConfigPath = null;
                        }
                        if (session.systemPromptPath) {
                            removePrivateTempDir(session.systemPromptPath);
                            session.systemPromptPath = null;
                        }
                        sessions.delete(threadId);
                        session.turn = null;
                        // Same relaunch handle as the transient-retry path above. The new
                        // session is announced as rebuilt only when it is actually given
                        // the replay: with nothing to replay it gets the turn text alone.
                        retry.rebuilt = recovery.replayed;
                        retryState.set(threadId, retry);
                        active.set(threadId, { stop: () => { retry.cancelled = true; retryAbort.abort(); }, turnId });
                        emit({
                            ...base(threadId, turnId),
                            type: "turn.retrying",
                            attempt: retry.attempt + 1,
                            delayMs: 0,
                            reason: "resume_rejected",
                        });
                        void (async () => {
                            try {
                                // no cursor: a fresh session, carrying the rebuild
                                await sendTurn({ ...turn, resumeCursor: undefined, recoveryText: undefined, text: recovery.text }, turnId);
                            }
                            catch (e) {
                                if (active.get(threadId)?.turnId === turnId)
                                    active.delete(threadId);
                                retryState.delete(threadId);
                                emit({
                                    ...base(threadId, turnId),
                                    type: "runtime.error",
                                    message: e instanceof Error ? e.message : String(e),
                                });
                                emit({ ...base(threadId, turnId), type: "turn.completed", ok: false, stopReason: "exit_before_result", cost: null });
                            }
                        })();
                        return;
                    }
                    retryState.delete(threadId);
                    emit({
                        ...base(threadId, currentTurnId()),
                        type: "runtime.error",
                        message,
                    });
                    settle(false, "exit_before_result");
                }
                if (session.idleTimer)
                    clearTimeout(session.idleTimer);
                session.broker?.close();
                if (session.mcpConfigPath) {
                    try {
                        rmSync(dirname(session.mcpConfigPath), { recursive: true, force: true });
                    }
                    catch { }
                }
                removePrivateTempDir(session.systemPromptPath);
                if (sessions.get(threadId) === session)
                    sessions.delete(threadId);
            };
            child.on("close", (code) => {
                session.finishClose = () => finalizeClose(code);
                void session.finishClose();
            });
            const stop = () => {
                // taskkill is asynchronous on Windows. Retire steering and approvals
                // now, before a still-connected child can submit more work.
                closeSession(threadId, "interrupted");
                retry.cancelled = true;
                retryAbort.abort();
                stopSession(session);
            };
            active.set(threadId, { stop, turnId, broker });
            emit({ ...base(threadId, turnId), type: "turn.started" });
            // prompt over stdin as a stream-json message — never argv (ARG_MAX).
            // stdin stays OPEN: that is what keeps the session alive for a
            // mid-turn steer or the next turn; closeSession() ends it.
            if (!(await writeUser(session, threadId, promptMsg))) {
                settle(false, "stdin_write_failed");
                closeSession(threadId, "stdin write failed");
            }
            return { turnId };
        };
        /** A user message into the running turn: the CLI delivers it before its
         * next model call. "refused" when nothing is running here to steer or
         * the stdin write provably failed; the caller queues those words. */
        const steer = async (threadId, text) => {
            const s = sessions.get(threadId);
            if (!s || !s.turn || s.turn.settled || s.closing || s.child.exitCode !== null)
                return "refused";
            return (await writeUser(s, threadId, claudeUserMessage(text, undefined))) ? "steered" : "refused";
        };
        // Sign in from Settings: the unmodified CLI's own login, driven over pipes
        // (server/drivers/claude-login-auth.ts). Same environment as every turn.
        const login = new ClaudeLoginController({ cli: config.cli, environment, onAuthenticated: async () => { await refreshModels(); } });
        const snapshot = async () => {
            const env = environment();
            const version = await readCliVersion(env);
            if (!version)
                return { state: "unavailable", reason: `\`${config.cli}\` CLI not found` };
            cliVersion = parseClaudeCliVersion(version);
            cliVersionChecked = true;
            const auth = await claudeAuthStatus(config.cli, env);
            // claudeEnvironment strips ANTHROPIC_API_KEY, so turns run on the
            // CLI's own login (Pro/Max): the cost it reports is what the call
            // WOULD bill, not a charge
            const update = claudeCliUpdate(version, config.cli);
            const warning = claudeInheritWarning(env);
            return { state: "available", version, ...auth, ...(update ? { update } : {}), ...(warning ? { warning } : {}), billing: "subscription" };
        };
        /** One-shot Claude call with the prompt on stdin, never argv. Approval
         * summaries can contain paths, commands, or secrets, so the generic
         * `claude -p "prompt"` shape is not safe for review. No tools or MCP
         * servers are mounted in this isolated process. */
        const generateReview = (prompt, signal) => new Promise((resolve, reject) => {
            const child = spawnCli(config.cli, ["-p", "--model", "claude-haiku-4-5", "--output-format", "text"], {
                stdio: ["pipe", "pipe", "pipe"],
                env: environment("claude-haiku-4-5"),
            });
            let stdout = "";
            let stderr = "";
            let settled = false;
            const finish = (error) => {
                if (settled)
                    return;
                settled = true;
                clearTimeout(timer);
                signal?.removeEventListener("abort", onAbort);
                if (error)
                    reject(error);
                else
                    resolve(stdout.trim());
            };
            const onAbort = () => {
                killCliTree(child);
                finish(new Error("Claude review aborted"));
            };
            const timer = setTimeout(() => {
                killCliTree(child);
                finish(new Error("Claude review timed out"));
            }, 60_000);
            timer.unref?.();
            child.stdout.setEncoding("utf8");
            child.stderr.setEncoding("utf8");
            child.stdout.on("data", (chunk) => {
                stdout += chunk;
                if (stdout.length > 1_000_000) {
                    killCliTree(child);
                    finish(new Error("Claude review output exceeded 1 MB"));
                }
            });
            child.stderr.on("data", (chunk) => {
                stderr = (stderr + chunk).slice(-8_192);
            });
            child.on("error", (error) => finish(error));
            child.on("close", (code) => {
                if (code === 0)
                    finish();
                else
                    finish(new Error(stderr.trim() || `Claude review exited ${code}`));
            });
            if (signal?.aborted)
                onAbort();
            else {
                signal?.addEventListener("abort", onAbort, { once: true });
                child.stdin.end(prompt);
            }
        });
        return {
            instanceId,
            driverKind: DRIVER_KIND,
            displayName: input.displayName,
            enabled: input.enabled,
            get models() {
                return models;
            },
            refreshModels,
            snapshot,
            startAuthentication: () => login.start(),
            getAuthentication: (flowId) => login.get(flowId),
            completeAuthentication: (flowId, code) => login.complete(flowId, code),
            cancelAuthentication: () => login.cancel(),
            signOut: () => login.signOut(),
            // Claude's sign-in is the unmodified CLI's own login (see
            // claude-login-auth.ts) — there is deliberately no OAuth client of ours
            // to run instead. Sign-in therefore exists exactly while the runtime
            // does, and says so honestly instead of collecting a spawn failure.
            authCapability: async () => {
                const version = await readCliVersion(environment());
                return version
                    ? { available: true }
                    : {
                        available: false,
                        reason: "Account sign-in runs the Claude Code runtime's own login, and this host does not have it. Connect an Anthropic API provider instead.",
                    };
            },
            adapter: {
                provider: DRIVER_KIND,
                capabilities: {
                    sessionModelSwitch: "in-session",
                    agentsMcp: true,
                    customMcp: true,
                    computerMcp: true,
                    composioMcp: true,
                    phoneMcp: true,
                    browserMcp: true,
                    images: true,
                    nativeImageInput: true,
                    effortLevels: ["low", "medium", "high", "xhigh", "max"],
                    queueing: true,
                    // Only while this CLI can be told to refresh a resumed session's
                    // recorded system prompt (--system-prompt-snapshot). Keeping a
                    // session across an update from outside it means the harness keeps
                    // its prompt too; an older CLI would answer a delegated return with
                    // the instructions of the turn that started the session, where a
                    // fresh session rebuilt them. Unknown version: not yet.
                    get strictResume() {
                        return cliVersionChecked && cliVersion !== null && claudeCliSupports(cliVersion, "--system-prompt-snapshot");
                    },
                    // Harness turns reassert a per-bot mode and restore the broker even
                    // when an old instance was configured with bypassPermissions.
                    localComputerMcp: true,
                },
                sendTurn,
                steer,
                interruptTurn: async (threadId) => active.get(threadId)?.stop(),
                respondToRequest: async (threadId, requestId, decision) => {
                    // fail-closed by construction: no broker, or an ask that already
                    // timed out / settled, is `unavailable` — the caller denies
                    const broker = sessions.get(threadId)?.broker ?? active.get(threadId)?.broker;
                    if (!broker)
                        return "unavailable";
                    const behavior = decision.behavior === "answer" ? "answer" : decision.behavior;
                    if (!broker.answer(requestId, behavior, decision.message, decision.always))
                        return "unavailable";
                    return behavior === "allow" ? "allowed-once" : behavior === "answer" ? "answered" : "rejected";
                },
                hasSession: (threadId) => active.has(threadId),
                stopAll: async () => {
                    for (const { stop } of active.values())
                        stop();
                    for (const threadId of Array.from(sessions.keys()))
                        closeSession(threadId, "stopAll");
                },
                onEvent: (listener) => {
                    listeners.add(listener);
                    return () => listeners.delete(listener);
                },
            },
            generateText: (prompt, options) => generateReview(prompt, options?.signal),
            reviewPermission: generateReview,
            dispose: async () => {
                try {
                    await login.dispose();
                }
                finally {
                    for (const { stop } of active.values())
                        stop();
                    for (const threadId of Array.from(sessions.keys()))
                        closeSession(threadId, "dispose");
                    listeners.clear();
                }
            },
        };
    },
};
