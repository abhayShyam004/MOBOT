// What a shell command can actually reach, decided from the whole command
// rather than from the program it starts.
//
// `cat ../../host/home/.codex/auth.json` begins with a deliberately routine
// binary. Judging the head word calls that routine and hands over the app's
// provider credential, because on Android there is no kernel boundary behind
// the word: the server, its shell and every child process run as the same UID
// with the same reach. This module is the layer that replaces the guess with a
// statement about paths.
//
// What it is: a static reading of every path a command names — in arguments,
// in redirect targets, and inside quoted strings — classified against the
// task's own workspace. What it is not: a sandbox. A command can compute a
// path at runtime (`$(...)`, `sh -c`, `xargs`), and that is reported as
// unanalyzable rather than assumed safe. See docs/verification/shell-boundary.md
// for the device-measured limits.
import { realpathSync } from "node:fs";
import { resolve, sep } from "node:path";
/** Places a task has no reason to read, and an autonomous turn must not read
 *  on the person's behalf: provider credentials, session stores, keys. */
const SENSITIVE_PATH_PATTERNS = [
    /(?:^|\/)\.codex\//i,
    /(?:^|\/)\.claude\//i,
    /(?:^|\/)\.config\/(?:gh|gcloud|codex|claude|omb)\//i,
    /(?:^|\/)auth\.json$/i,
    /(?:^|\/)oauth[_-]?tokens?\.json$/i,
    /(?:^|\/)credentials?(?:\.json|\.ini)?$/i,
    /(?:^|\/)\.git-credentials$/i,
    /(?:^|\/)\.netrc$/i,
    /(?:^|\/)\.npmrc$/i,
    /(?:^|\/)\.ssh\//i,
    /(?:^|\/)id_(?:rsa|ed25519|ecdsa)(?:\.pub)?$/i,
    /(?:^|\/)(?:token|secret|apikey|api_key|keystore)(?:\.[a-z0-9]+)?$/i,
    /(?:^|\/)\.config\//i,
];
/** The app's own state lives under these on Android; nothing a task does needs
 *  them, and reading them is a credential disclosure even when the file is not
 *  obviously a credential. Note what is NOT here: `files/host/data` is the
 *  legitimate data directory (task workspaces, projects) and `files/host/home`
 *  is a directory whose credential entries the name patterns above already
 *  catch. Marking either one wholesale would block the work this app exists to
 *  do, which is how a boundary gets turned off by the person using it. */
const SENSITIVE_DIR_PATTERNS = [
    /^\/data\/(?:data|user\/\d+)\/[^/]+\/(?:shared_prefs|databases)/,
    /^\/data\/(?:data|user\/\d+)\/[^/]+\/files\/datastore/,
];
/** Shell constructs that compute what they run or where they read. */
const UNANALYZABLE_PATTERNS = [
    /`/,
    /\$\(/,
    /\$\{?[A-Za-z_][A-Za-z0-9_]*\}?\//, // $HOME/x, ${DIR}/x
    /\$\{?HOME\}?/,
    /(?:^|\s)~(?:\/|$|\s)/,
    /\b(?:sh|bash|ash|zsh|dash)\s+-c\b/,
    /\beval\b/,
    /\bxargs\b/,
    /\bfind\b[^;|&]*-exec(?:dir)?\b/,
    /\b(?:env)\s+-i\b/,
    /\bbase64\s+(?:-d|--decode)\b/,
    /(?:curl|wget)\b[^|]*\|\s*(?:sh|bash|zsh)\b/,
    /\b(?:source|\.)\s+\//,
    /\bfind\b[^;|&]*\s-\w*exec/,
];
/** Every absolute path shape in the command text, including paths inside
 *  quotes and inside `-e`/`-c` program strings. Trailing punctuation a path
 *  cannot end with is trimmed. */
const ABSOLUTE_PATH = /(?:^|[\s'"`=(,:])(\/[A-Za-z0-9._@%+\-][^\s'"`|;&<>(){}]*)/g;
function trimPath(raw) {
    let out = raw;
    // A path token can pick up shell punctuation on either side; none of these
    // characters can end a real path operand.
    while (out.length > 1 && /[.,;:?!\\]$/.test(out))
        out = out.slice(0, -1);
    return out;
}
/** Sinks a validation run legitimately writes to and reads from; they hold no
 *  data and reach nothing. `/dev/null` on the end of `> ` is the common one. */
const SAFE_DEVICE_PATHS = new Set([
    "/dev/null",
    "/dev/stdout",
    "/dev/stderr",
    "/dev/zero",
]);
function normalize(path) {
    const cleaned = path.replace(/\/{2,}/g, "/");
    const resolved = resolve(cleaned);
    return resolved.length > 1 && resolved.endsWith(sep) ? resolved.slice(0, -1) : resolved;
}
function inside(path, root) {
    return path === root || path.startsWith(root.endsWith(sep) ? root : `${root}${sep}`);
}
function isSensitive(path) {
    return SENSITIVE_DIR_PATTERNS.some((pattern) => pattern.test(path))
        || SENSITIVE_PATH_PATTERNS.some((pattern) => pattern.test(path));
}
/**
 * Paths the command names that exist and resolve, through symlinks, outside
 * every workspace root.
 *
 * The lexical analysis above reads the command text; it cannot see that a
 * workspace entry called `link-project` is a symlink to another project, or
 * that `link-cred` points at the provider's auth file. Measured on the phone:
 * `cat link-cred` returned the app's own credential store with no path, no
 * `..`, and no absolute spelling to notice. Resolving each named path is the
 * one check that closes that: the kernel follows the link, so the analysis
 * does too.
 *
 * Tokens that are flags, contain shell expansion, or do not exist are skipped;
 * a path that resolves inside the workspace costs nothing.
 */
function realEscapingPaths(command, roots) {
    if (roots.length === 0)
        return [];
    const found = new Set();
    for (const match of command.matchAll(/(?:^|[\s'"`=(,:;|&<>])([^\s'"`|;&<>(){}]+)/g)) {
        const token = trimPath(match[1]);
        if (!token || token.startsWith("-") || token.includes("$") || token.includes("`"))
            continue;
        const candidate = token.startsWith("/") ? token : resolve(roots[0], token);
        let real;
        try {
            real = normalize(realpathSync(candidate));
        }
        catch {
            continue;
        }
        if (roots.some((root) => inside(real, root)))
            continue;
        found.add(real);
    }
    return [...found];
}
/** Relative operands that climb out of the workspace (`../x`, `../../y`). The
 *  shell's own working directory is the workspace root, so a lexical resolve
 *  from there is what the process will actually open. */
function escapedRelativePaths(command, roots) {
    if (roots.length === 0)
        return [];
    const found = [];
    for (const match of command.matchAll(/(?:^|[\s'"`=(,:;|&])((?:\.\.\/|\.\.$|[^\s'"`]*\/\.\.\/)[^\s'"`|;&<>()]*)/g)) {
        const raw = trimPath(match[1]);
        if (!raw || raw.startsWith("/"))
            continue;
        for (const root of roots) {
            const resolved = normalize(resolve(root, raw));
            if (!roots.some((candidate) => inside(resolved, normalize(candidate)))) {
                found.push(resolved);
                break;
            }
        }
    }
    return found;
}
/**
 * Judge one shell command.
 *
 * Escalation only: a command is never called safer than the paths it names.
 * With no workspace roots the analysis cannot prove containment, so anything
 * naming an absolute path is treated as leaving the workspace.
 */
export function assessShellCommand(command, context = {}) {
    const roots = (context.workspaceRoots ?? []).filter(Boolean).map(normalize);
    const exempt = (context.credentialExemptRoots ?? []).filter(Boolean).map(normalize);
    const text = command.trim();
    const empty = { risk: "routine", escapingPaths: [], sensitivePaths: [], unanalyzable: false };
    if (!text)
        return empty;
    const absolute = new Set();
    for (const match of text.matchAll(ABSOLUTE_PATH)) {
        const candidate = trimPath(match[1]);
        if (candidate.length > 1)
            absolute.add(candidate);
    }
    for (const relative of escapedRelativePaths(text, roots))
        absolute.add(relative);
    for (const real of realEscapingPaths(text, roots))
        absolute.add(real);
    const sensitivePaths = [];
    const escapingPaths = [];
    for (const candidate of absolute) {
        const path = normalize(candidate);
        if (SAFE_DEVICE_PATHS.has(path))
            continue;
        const outside = roots.length === 0 || !roots.some((root) => inside(path, root));
        if (!outside)
            continue;
        escapingPaths.push(path);
        // A file called `auth.json` inside the workspace is the task's own file (a
        // fixture, a test tree). The same name in the app's private state is the
        // credential, so sensitivity is only ever judged on paths that already
        // left the workspace — and never on a project tree, which is fixtures.
        if (!exempt.some((root) => inside(path, root)) && isSensitive(path))
            sensitivePaths.push(path);
    }
    const unanalyzable = UNANALYZABLE_PATTERNS.some((pattern) => pattern.test(text));
    if (sensitivePaths.length > 0) {
        return {
            risk: "consequential",
            why: "The command reads this app's own private state, which holds credentials.",
            escapingPaths,
            sensitivePaths,
            unanalyzable,
        };
    }
    if (escapingPaths.length > 0) {
        return {
            risk: "elevated",
            why: "The command names paths outside this task's workspace.",
            escapingPaths,
            sensitivePaths,
            unanalyzable,
        };
    }
    if (unanalyzable) {
        return {
            risk: "elevated",
            why: "The command builds its paths or program at runtime, so what it reaches cannot be checked first.",
            escapingPaths,
            sensitivePaths,
            unanalyzable,
        };
    }
    return empty;
}
/** Paths a deletion in this command would remove outside the workspace.
 *  A turn never needs to delete someone else's files, and a deletion cannot be
 *  approved into existence after the fact, so this is a refusal rather than a
 *  card. Only the deletion's own operands are read, so `rm -rf dist && cat
 *  /tmp/log` is judged on `dist`.
 */
export function deletionsOutsideWorkspace(command, context = {}) {
    const roots = (context.workspaceRoots ?? []).filter(Boolean).map(normalize);
    const found = [];
    // `cd /sdcard && rm -rf Download` deletes by a relative name in a place the
    // workspace never covered, so the directory the deletion runs in is tracked
    // along the command rather than assumed to be the workspace.
    let cwd = roots[0] ?? "/";
    for (const segment of command.split(/\n|;|&&|\|\||\||&/)) {
        const words = segment.trim().split(/\s+/).filter(Boolean);
        const verb = words[0]?.replace(/^\(/, "");
        if (verb === "cd") {
            const destination = words[1]?.replace(/^['"]|['"]$/g, "");
            if (destination)
                cwd = normalize(destination.startsWith("/") ? destination : resolve(cwd, destination));
            // `cd` into a workspace symlink is how `rm -rf *` reaches another
            // project without ever naming it — the shell's cwd is the target.
            try {
                cwd = normalize(realpathSync(cwd));
            }
            catch {
                // A directory that does not exist cannot be entered.
            }
            continue;
        }
        if (!verb || !/^(?:rm|rmdir|unlink)$/.test(verb))
            continue;
        const operands = words.slice(1).filter((word) => !word.startsWith("-"));
        for (const raw of operands) {
            const operand = raw.replace(/^['"]|['"]$/g, "");
            if (!operand || operand === "." || operand === "./")
                continue;
            // A plain relative name is the workspace's own tree; one that climbs
            // (`..`, `rm -rf ..`) is resolved from the shell's cwd and judged like
            // an absolute path, because that is what it will empty.
            let path = normalize(operand.startsWith("/") ? operand : resolve(cwd, operand));
            // `rm -rf link/` follows a directory symlink and empties what it points
            // at, and `rm -rf link/*` is expanded by the shell into the target's own
            // children. Both name only a workspace entry, so the lexical path looks
            // contained; measured on the phone, the first emptied another project.
            // Judge what the kernel will actually remove.
            const followsLink = operand.endsWith("/") || operand.endsWith("/.") || /[*?]/.test(operand);
            if (followsLink) {
                const anchor = /[*?]/.test(operand)
                    ? operand.slice(0, operand.search(/[*?]/)).replace(/\/?[^/]*$/, "")
                    : operand.endsWith("/.") ? operand.slice(0, -2) : operand;
                const target = normalize(anchor.startsWith("/") ? anchor : resolve(cwd, anchor));
                try {
                    path = normalize(realpathSync(target));
                }
                catch {
                    // It does not exist, so it cannot be deleted through.
                }
            }
            if (roots.length === 0 || !roots.some((root) => inside(path, root)))
                found.push(path);
        }
    }
    return found;
}
/** Should this invocation be refused outright rather than offered to a person?
 *
 *  A credential is not a permission the model can be granted to read: no
 *  ordinary task needs the provider's own auth file, and the person cannot
 *  approve a disclosure that has already happened by the time they are asked.
 *  This runs in the tool, so it holds whether or not a card was shown. */
export function refusalForShellCommand(command, context = {}) {
    const deletions = deletionsOutsideWorkspace(command, context);
    if (deletions.length > 0) {
        return {
            refused: true,
            reason: `refused: the command deletes ${deletions.slice(0, 3).join(", ")}, which is outside this task's workspace. ` +
                "A turn may remove what it created inside its own workspace; it may not delete the person's other files.",
            paths: deletions,
        };
    }
    const verdict = assessShellCommand(command, context);
    if (verdict.sensitivePaths.length === 0)
        return null;
    const shown = verdict.sensitivePaths.slice(0, 3).join(", ");
    return {
        refused: true,
        reason: `refused: the command reads this app's private credential store (${shown}). ` +
            "No task needs it, and no approval can make reading it safe. Work inside the task's workspace instead; " +
            "if the task genuinely needs a credential, the person configures it in the app's settings.",
        paths: verdict.sensitivePaths,
    };
}
