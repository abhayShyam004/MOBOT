// Observability System for MOBOT (Phase U)
//
// Structured internal events for capabilities, structured UI, file operations,
// media generation, and model availability.
//
// Invariant:
// 1. Raw event streams stay strictly OUT of normal chat.
// 2. Maintained in a bounded ring-buffer for telemetry and diagnostic inspection.
export class ObservabilityBus {
    events = [];
    maxEvents;
    listeners = new Set();
    constructor(maxEvents = 1000) {
        this.maxEvents = maxEvents;
    }
    emit(type, payload = {}, context) {
        const event = {
            id: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
            type,
            timestamp: new Date().toISOString(),
            botId: context?.botId,
            threadId: context?.threadId,
            payload,
        };
        this.events.push(event);
        if (this.events.length > this.maxEvents) {
            this.events.shift();
        }
        for (const listener of this.listeners) {
            try {
                listener(event);
            }
            catch { }
        }
        return event;
    }
    subscribe(listener) {
        this.listeners.add(listener);
        return () => this.listeners.delete(listener);
    }
    getEvents(filter) {
        let result = this.events;
        if (filter?.type) {
            result = result.filter((e) => e.type === filter.type);
        }
        if (filter?.botId) {
            result = result.filter((e) => e.botId === filter.botId);
        }
        if (filter?.limit && filter.limit > 0) {
            result = result.slice(-filter.limit);
        }
        return result;
    }
    getMetricsSummary() {
        const counts = {};
        for (const e of this.events) {
            counts[e.type] = (counts[e.type] || 0) + 1;
        }
        return counts;
    }
    clear() {
        this.events.length = 0;
    }
}
export const sharedObservability = new ObservabilityBus();
