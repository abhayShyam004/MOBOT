// A project API key (ak_…) creates/reuses one Composio Session. That
// Session owns connection state, auth links and the MCP endpoint.
import { saveConfig } from "./config.js";
import { createHash, randomUUID } from "node:crypto";
import { z } from "zod";
import { SPAWNED_PROXIES } from "./proxy-paths.js";
import { managedConnectorUnavailableReason } from "../shared/connector-availability.js";
const DEFAULT_BACKEND_ORIGIN = "https://backend.composio.dev";
const DEFAULT_CONNECT_MCP_ENDPOINT = "https://connect.composio.dev/mcp";
function apiBase() {
    return (process.env.OMB_COMPOSIO_API ?? `${DEFAULT_BACKEND_ORIGIN}/api/v3.1`).replace(/\/$/, "");
}
function toolkitBase() {
    return (process.env.OMB_COMPOSIO_TOOLKITS_API ?? `${DEFAULT_BACKEND_ORIGIN}/api/v3`).replace(/\/$/, "");
}
export function connectMcpEndpoint(cfg) {
    return cfg?.composio?.mcpUrl ?? process.env.OMB_COMPOSIO_CONNECT_MCP ?? DEFAULT_CONNECT_MCP_ENDPOINT;
}
export function detectComposioKeyType(key) {
    const trimmed = key.trim();
    if (trimmed.startsWith("ak_"))
        return "platform";
    if (trimmed.startsWith("ck_"))
        return "connect";
    return "unknown";
}
export function composioSurface(cfg) {
    if (cfg.composio?.surface)
        return cfg.composio.surface;
    const key = projectApiKey(cfg);
    if (key?.startsWith("ck_"))
        return "connect";
    return "platform";
}
export function validatePlatformKey(key) {
    const trimmed = key.trim();
    if (!trimmed)
        throw new Error("Enter a Composio project API key");
    if (trimmed.startsWith("ck_")) {
        throw new Error("This Composio connection expects a Platform Project API key (ak_...). You provided a Connect consumer key (ck_...). Choose the appropriate Composio connection type.");
    }
    if (!trimmed.startsWith("ak_")) {
        throw new Error("Invalid Composio key format. Platform Project API keys must start with ak_.");
    }
    return trimmed;
}
export function validateConnectKey(key) {
    const trimmed = key.trim();
    if (!trimmed)
        throw new Error("Enter a Composio Connect consumer key");
    if (trimmed.startsWith("ak_")) {
        throw new Error("This Composio connection expects a Connect consumer key (ck_...). You provided a Platform Project API key (ak_...). Choose the appropriate Composio connection type.");
    }
    if (!trimmed.startsWith("ck_")) {
        throw new Error("Invalid Composio key format. Connect consumer keys must start with ck_.");
    }
    return trimmed;
}
export async function verifyConnectConsumerKey(consumerKey, endpoint) {
    const validKey = validateConnectKey(consumerKey);
    const mcpUrl = endpoint ?? connectMcpEndpoint();
    const res = await fetch(mcpUrl, {
        method: "POST",
        headers: {
            "content-type": "application/json",
            "x-consumer-api-key": validKey,
            accept: "application/json, text/event-stream",
        },
        body: JSON.stringify({
            jsonrpc: "2.0",
            id: 1,
            method: "tools/list",
            params: {},
        }),
        signal: AbortSignal.timeout(15_000),
    });
    if (res.status === 401 || res.status === 403) {
        throw new Error("Composio rejected this consumer key (invalid or unauthorized)");
    }
    if (!res.ok) {
        throw new Error(await responseError(res, `Composio Connect error: HTTP ${res.status}`));
    }
    return { ok: true };
}
const sessionResponseSchema = z.object({
    session_id: z.string().min(1),
    mcp: z.object({ type: z.enum(["http", "sse"]), url: z.string().min(1) }),
    config: z.object({
        user_id: z.string().optional(),
        multi_account: z.object({
            enable: z.boolean().optional(),
            max_accounts_per_toolkit: z.number().optional(),
            require_explicit_selection: z.boolean().optional(),
        }).optional(),
        /** toolkit slug → the project's own auth config the Session uses for it */
        auth_configs: z.record(z.string(), z.string()).optional(),
    }).optional(),
});
// A project's own auth configs (bring-your-own OAuth app, API-key toolkits
// such as twitter that Composio does not manage). A Session only uses one
// when it was created with the config's id under `auth_configs`.
const authConfigItemSchema = z.object({
    id: z.string().optional(),
    status: z.string().nullable().optional(),
    is_composio_managed: z.boolean().optional(),
    is_enabled_for_tool_router: z.boolean().nullable().optional(),
    last_updated_at: z.string().nullable().optional(),
    toolkit: z.object({ slug: z.string().optional() }).optional(),
});
const authConfigsPageSchema = z.object({
    items: z.array(authConfigItemSchema).optional(),
    next_cursor: z.string().nullable().optional(),
});
const MAX_AUTH_CONFIG_PAGES = 20;
const connectedAccountResponseSchema = z.object({
    id: z.string().optional(),
    alias: z.string().nullable().optional(),
    status: z.string().optional(),
    updated_at: z.string().optional(),
    toolkit: z.object({ slug: z.string().optional() }).optional(),
});
const connectedAccountsPageSchema = z.object({
    items: z.array(connectedAccountResponseSchema),
    next_cursor: z.string().nullable().optional(),
});
const toolkitItemSchema = z.object({
    slug: z.string().optional(),
    is_no_auth: z.boolean().optional(),
    connected_account: z.object({ id: z.string().optional(), status: z.string().optional() }).nullable().optional(),
});
const toolkitPageSchema = z.object({
    items: z.array(toolkitItemSchema).optional(),
    next_cursor: z.string().nullable().optional(),
});
const connectorServiceSchema = z.object({
    connected: z.boolean(),
    pending: z.boolean().optional(),
    status: z.string().optional(),
    accounts: z.array(z.object({ id: z.string(), alias: z.string().optional(), status: z.string() })).optional(),
});
const connectorServicesResponseSchema = z.object({ services: z.record(z.string(), connectorServiceSchema).optional() });
const removalResponseSchema = z.object({ removed: z.number() });
const authUrlResponseSchema = z.object({ url: z.string().optional() });
const linkResponseSchema = z.object({ redirect_url: z.string().optional() });
const MULTI_ACCOUNT_CONFIG = {
    enable: true,
    max_accounts_per_toolkit: 5,
    require_explicit_selection: true,
};
const MAX_CONNECTED_ACCOUNT_PAGES = 100;
const ACCOUNT_ID = /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/;
const printableAliasSchema = z.string().min(1).max(64).refine((value) => {
    for (const character of value) {
        const codePoint = character.codePointAt(0);
        if (codePoint === undefined || codePoint < 32 || codePoint === 127)
            return false;
    }
    return true;
});
let managedBrokerAccess;
const managedBrokerMessageSchema = z.record(z.string(), z.unknown());
const managedBrokerToken = /^[0-9a-f]{64}$/;
function normalizeManagedBrokerUrl(value) {
    const url = new URL(value);
    if (url.username || url.password || url.search || url.hash) {
        throw new Error("The connected-apps service URL must not include credentials, a query, or a fragment");
    }
    const loopback = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
    if (url.protocol !== "https:" && !(url.protocol === "http:" && loopback)) {
        throw new Error("The connected-apps service must use HTTPS");
    }
    return `${url.origin}${url.pathname.replace(/\/+$/, "")}`;
}
export function applyManagedBrokerMessage(message) {
    const parsed = managedBrokerMessageSchema.safeParse(message);
    if (!parsed.success ||
        parsed.data.type !== "openmausbot:managed-composio" ||
        !Object.hasOwn(parsed.data, "access")) {
        return false;
    }
    setManagedBrokerAccess(parsed.data.access);
    return true;
}
export function setManagedBrokerAccess(access) {
    if (access === null) {
        managedBrokerAccess = null;
        return;
    }
    const parsed = z.object({ url: z.string().url(), token: z.string().regex(managedBrokerToken) }).strict().parse(access);
    managedBrokerAccess = { url: normalizeManagedBrokerUrl(parsed.url), token: parsed.token };
}
function brokerAccess() {
    if (managedBrokerAccess !== undefined)
        return managedBrokerAccess;
    const url = process.env.OMB_COMPOSIO_BROKER_URL?.trim();
    const token = process.env.OMB_COMPOSIO_BROKER_TOKEN?.trim();
    if (!url || !token)
        return null;
    if (!managedBrokerToken.test(token))
        throw new Error("The connected-apps service token is invalid");
    return { url: normalizeManagedBrokerUrl(url), token };
}
/** A user-owned project is an explicit choice and must win over the packaged
 * app's managed broker. An empty key means that choice was cleared, so the
 * managed service may take over again without a restart. */
function projectApiKey(cfg) {
    const apiKey = cfg.composio?.apiKey?.trim();
    return apiKey || null;
}
/** Composio's toolkit slug is `twitter`. Keep accepting the old `x` alias at
 * every local boundary so saved connector cards and model calls keep working. */
function canonicalToolkitSlug(slug) {
    const normalized = slug.trim().toLowerCase();
    return normalized === "x" ? "twitter" : normalized;
}
/** Keep credential-backed caches and transport sessions separated without
 * retaining another plaintext copy of the credential as their identity. */
function backendFingerprint(kind, endpoint, credential) {
    return createHash("sha256")
        .update(kind)
        .update("\0")
        .update(endpoint)
        .update("\0")
        .update(credential)
        .digest("hex");
}
const MAX_TRACKED_TRANSPORT_SESSIONS = 512;
const transportSessionBackends = new Map();
function rememberTransportSession(sessionId, identity) {
    transportSessionBackends.delete(sessionId);
    transportSessionBackends.set(sessionId, identity);
    while (transportSessionBackends.size > MAX_TRACKED_TRANSPORT_SESSIONS) {
        const oldest = transportSessionBackends.keys().next().value;
        if (oldest === undefined)
            break;
        transportSessionBackends.delete(oldest);
    }
}
function canonicalServiceRecord(services) {
    return Object.fromEntries(Object.entries(services).map(([slug, state]) => [canonicalToolkitSlug(slug), state]));
}
/** Preserve the caller's key (`x` included) while speaking canonical toolkit
 * slugs upstream. Old connector cards index status with their saved slug. */
function requestedServiceRecord(services, requested) {
    const canonical = canonicalServiceRecord(services);
    return Object.fromEntries(requested.flatMap((slug) => {
        const state = canonical[canonicalToolkitSlug(slug)];
        return state === undefined ? [] : [[slug, state]];
    }));
}
export function connectionMode(cfg) {
    if (projectApiKey(cfg))
        return "self-hosted";
    if (brokerAccess())
        return "managed";
    return "unavailable";
}
export function configured(cfg) {
    return connectionMode(cfg) !== "unavailable";
}
export function connectorAvailability(cfg, storeState = process.env.OMB_CREDENTIAL_STORE) {
    if (configured(cfg))
        return "configured";
    return storeState === "unavailable" ? "unreadable" : "unconfigured";
}
async function brokerRequest(path, init) {
    const broker = brokerAccess();
    if (!broker)
        throw new Error("The connected-apps service is unavailable");
    const headers = new Headers(init?.headers);
    headers.set("authorization", `Bearer ${broker.token}`);
    if (init?.body)
        headers.set("content-type", "application/json");
    return fetch(`${broker.url}${path}`, {
        ...init,
        headers,
        signal: init?.signal ?? AbortSignal.timeout(30_000),
    });
}
function projectHeaders(apiKey, json = false) {
    const headers = new Headers({ "x-api-key": apiKey });
    if (json)
        headers.set("content-type", "application/json");
    return headers;
}
async function responseError(res, fallback) {
    const raw = await res.text().catch(() => "");
    try {
        const body = JSON.parse(raw);
        return String(body?.message ?? body?.error?.message ?? body?.error ?? fallback);
    }
    catch {
        return raw.trim().slice(0, 300) || fallback;
    }
}
async function throwBrokerError(res, fallback) {
    const status = res.status >= 400 && res.status < 500 ? res.status : 502;
    throw Object.assign(new Error(await responseError(res, fallback)), { status });
}
function trustedAuthUrl(value, slug) {
    if (!value)
        throw new Error(`Connected-apps service returned no authorization link for ${slug}`);
    const url = new URL(value);
    if (url.protocol !== "https:" || (url.hostname !== "composio.dev" && !url.hostname.endsWith(".composio.dev"))) {
        throw new Error("Connected-apps service returned an untrusted authorization link");
    }
    return url.toString();
}
function parseSessionResponse(session) {
    const mcp = new URL(session.mcp.url);
    if (mcp.protocol !== "https:" || (mcp.hostname !== "composio.dev" && !mcp.hostname.endsWith(".composio.dev"))) {
        throw new Error("Composio returned an untrusted Session MCP URL");
    }
    return { ...session, mcp: { ...session.mcp, url: mcp.toString() } };
}
function supportsMultiAccount(session) {
    // Only `enable` gates reuse. The cap and selection flags are what we ASK
    // for at creation; if Composio clamps or omits them in the echo, recreating
    // the Session would post the same config and get the same echo back — a
    // strict equality check here can only manufacture a recreate-per-request
    // loop, never fix anything.
    return session.config?.multi_account?.enable === true;
}
/** Session ids this boot already tried to upgrade once. If the fresh Session
 *  STILL doesn't echo multi-account, Composio isn't granting it — run with
 *  what we have (single-account behavior) instead of recreating a Session and
 *  rewriting config.json on every request. */
const multiAccountUpgradeAttempted = new Set();
/** Session id + auth-config map pairs this boot already created a Session
 *  for. Same idea: if Composio does not echo `auth_configs`, recreating the
 *  Session on every check would loop without changing anything. */
const authConfigUpgradeAttempted = new Set();
function inputError(message, status = 400) {
    return Object.assign(new Error(message), { status });
}
export function normalizeAccountAlias(value) {
    if (value === undefined || value === null || value === "")
        return undefined;
    const parsed = z.string().safeParse(value);
    if (!parsed.success)
        throw inputError("Account alias must be text");
    const alias = parsed.data.trim();
    if (!printableAliasSchema.safeParse(alias).success) {
        throw inputError("Account alias must be 1-64 printable characters");
    }
    return alias;
}
function validAccountId(value) {
    return Boolean(value && ACCOUNT_ID.test(value));
}
async function getProjectSession(apiKey, sessionId) {
    const res = await fetch(`${apiBase()}/tool_router/session/${encodeURIComponent(sessionId)}`, {
        headers: projectHeaders(apiKey),
        signal: AbortSignal.timeout(15_000),
    });
    if (res.status === 404)
        return null;
    if (!res.ok)
        throw new Error(await responseError(res, `Composio session: HTTP ${res.status}`));
    return parseSessionResponse(sessionResponseSchema.parse(await res.json()));
}
/** The project's own (non-Composio-managed) auth configs, one per toolkit.
 *  Disabled configs and ones switched off for Sessions are skipped; when a
 *  toolkit has several, the most recently updated wins. Ordinary Session
 *  preparation treats a denied list as "none"; an explicit auth retry surfaces
 *  the denial so it cannot replace a usable Session with an incomplete one. */
export async function listCustomAuthConfigs(apiKey) {
    const chosen = new Map();
    let cursor;
    for (let page = 0; page < MAX_AUTH_CONFIG_PAGES; page++) {
        const params = new URLSearchParams({ is_composio_managed: "false", limit: "100" });
        if (cursor)
            params.set("cursor", cursor);
        const res = await fetch(`${apiBase()}/auth_configs?${params}`, {
            headers: projectHeaders(apiKey),
            signal: AbortSignal.timeout(15_000),
        });
        if (!res.ok)
            throw new Error(await responseError(res, `Composio auth configs: HTTP ${res.status}`));
        const body = authConfigsPageSchema.parse(await res.json());
        for (const item of body.items ?? []) {
            const slug = item.toolkit?.slug ? canonicalToolkitSlug(item.toolkit.slug) : "";
            if (!slug || !item.id || item.is_composio_managed === true)
                continue;
            if (item.is_enabled_for_tool_router === false)
                continue;
            if (item.status && /^(disabled|inactive|expired|deleted)$/i.test(item.status))
                continue;
            const updated = item.last_updated_at ?? "";
            const current = chosen.get(slug);
            if (!current || updated > current.updated)
                chosen.set(slug, { id: item.id, updated });
        }
        const next = body.next_cursor ?? undefined;
        if (!next || next === cursor)
            break;
        cursor = next;
    }
    return Object.fromEntries([...chosen].sort(([a], [b]) => a.localeCompare(b)).map(([slug, { id }]) => [slug, id]));
}
/** True when the Session already routes every wanted toolkit through the
 *  project's own auth config. Extra configs on the Session are fine; a
 *  missing or different one means the Session predates the config. */
function sessionCoversAuthConfigs(session, wanted) {
    const have = session.config?.auth_configs ?? {};
    const haveLower = Object.fromEntries(Object.entries(have).map(([slug, id]) => [canonicalToolkitSlug(slug), id]));
    return Object.entries(wanted).every(([slug, id]) => haveLower[slug] === id);
}
function authConfigsKey(sessionId, wanted) {
    return `${sessionId}:${JSON.stringify(wanted)}`;
}
/** Validate a project key and return one reusable Session for this install.
 *
 *  Identity model (multi-device compatibility — do not casually change):
 *  each install mints its own Composio user (`openmausbot_<uuid>`) and
 *  connections belong to that Composio user, NOT to the project key. A
 *  second device sharing the same project key therefore starts with zero
 *  connections until it adopts the first device's user via
 *  `PUT /api/config {"composio":{"userId":"openmausbot_…","sessionId":""}}`
 *  — clearing sessionId forces a Session rebuild under the adopted user and
 *  every existing connection becomes visible. Replacing the random-user
 *  minting here with, say, a shared constant would silently change which
 *  accounts every existing install sees. */
export async function prepareProjectSession(apiKey, current, knownAuthConfigs) {
    const trimmed = validatePlatformKey(apiKey);
    // The project's own auth configs must be named at creation — a Session
    // cannot be edited later — so they are read before deciding whether the
    // current Session is still the right one (issue #509: a twitter auth
    // config created after the Session existed was never used).
    const authConfigs = knownAuthConfigs
        ?? await listCustomAuthConfigs(trimmed).catch(() => ({}));
    let priorUserId = current?.userId;
    if (trimmed === current?.apiKey && current.sessionId) {
        const existing = await getProjectSession(trimmed, current.sessionId);
        if (existing
            && supportsMultiAccount(existing)
            && (sessionCoversAuthConfigs(existing, authConfigs)
                || authConfigUpgradeAttempted.has(authConfigsKey(existing.session_id, authConfigs)))) {
            return {
                apiKey: trimmed,
                userId: existing.config?.user_id ?? current.userId ?? `openmausbot_${randomUUID()}`,
                sessionId: existing.session_id,
            };
        }
        // Connections belong to the Composio user, not the Session. Recreate old
        // single-account Sessions with the same user ID so every existing grant is
        // retained while the new Session opts into explicit multi-account routing.
        priorUserId = existing?.config?.user_id ?? priorUserId;
    }
    const userId = priorUserId ?? `openmausbot_${randomUUID()}`;
    const sessionRequest = {
        user_id: userId,
        manage_connections: {
            enable: true,
            enable_wait_for_connections: true,
            enable_connection_removal: true,
        },
        multi_account: MULTI_ACCOUNT_CONFIG,
    };
    if (Object.keys(authConfigs).length)
        sessionRequest.auth_configs = authConfigs;
    const res = await fetch(`${apiBase()}/tool_router/session`, {
        method: "POST",
        headers: projectHeaders(trimmed, true),
        body: JSON.stringify(sessionRequest),
        signal: AbortSignal.timeout(30_000),
    });
    if (!res.ok)
        throw new Error(await responseError(res, `Composio rejected this key (HTTP ${res.status})`));
    const session = parseSessionResponse(sessionResponseSchema.parse(await res.json()));
    // If Composio does not echo the configs back, a later check would ask for
    // the same creation again — remember this attempt so it happens once.
    authConfigUpgradeAttempted.add(authConfigsKey(session.session_id, authConfigs));
    return { apiKey: trimmed, userId, sessionId: session.session_id };
}
export async function prepareComposioCredential(apiKey, options) {
    const trimmed = apiKey.trim();
    if (!trimmed)
        throw new Error("Enter a Composio key");
    const surface = options?.requestedSurface ??
        (trimmed.startsWith("ck_") ? "connect" : trimmed.startsWith("ak_") ? "platform" : undefined);
    if (!surface) {
        throw new Error("Invalid Composio key format. Keys must start with ak_ (Platform Project API key) or ck_ (Connect / For You consumer key).");
    }
    if (surface === "platform") {
        const validKey = validatePlatformKey(trimmed);
        const session = await prepareProjectSession(validKey, options?.current, options?.knownAuthConfigs);
        return {
            apiKey: session.apiKey,
            surface: "platform",
            userId: session.userId,
            sessionId: session.sessionId,
        };
    }
    if (surface === "connect") {
        const validKey = validateConnectKey(trimmed);
        await verifyConnectConsumerKey(validKey, options?.endpoint);
        return {
            apiKey: validKey,
            surface: "connect",
            mcpUrl: options?.endpoint ?? connectMcpEndpoint(),
        };
    }
    throw new Error(`Unknown Composio surface: ${surface}`);
}
async function ensureProjectSession(cfg) {
    const composio = cfg.composio;
    const apiKey = projectApiKey(cfg);
    if (!composio || !apiKey)
        throw new Error("No Composio project key configured");
    if (composio.sessionId) {
        const existing = await getProjectSession(apiKey, composio.sessionId);
        if (existing && (supportsMultiAccount(existing) || multiAccountUpgradeAttempted.has(existing.session_id))) {
            return existing;
        }
    }
    // A missing/deleted session is recreated and its non-secret identifiers are
    // persisted so an edited config/env setup does not recreate it every launch.
    const prepared = await prepareProjectSession(apiKey, composio);
    multiAccountUpgradeAttempted.add(prepared.sessionId);
    composio.userId = prepared.userId;
    composio.sessionId = prepared.sessionId;
    saveConfig({ composio: { userId: prepared.userId, sessionId: prepared.sessionId } });
    const created = await getProjectSession(apiKey, prepared.sessionId);
    if (!created)
        throw new Error("Composio Session disappeared after creation");
    return created;
}
/** Replace the current Session with a freshly created one — the only way to
 *  pick up an auth config the user added after the Session was made. The
 *  Composio user id is kept, so every existing connection survives. */
async function recreateProjectSession(cfg, userId, authConfigs) {
    const composio = cfg.composio;
    const apiKey = projectApiKey(cfg);
    if (!composio || !apiKey)
        throw new Error("No Composio project key configured");
    const prepared = await prepareProjectSession(apiKey, { apiKey, userId }, authConfigs);
    multiAccountUpgradeAttempted.add(prepared.sessionId);
    composio.userId = prepared.userId;
    composio.sessionId = prepared.sessionId;
    saveConfig({ composio: { userId: prepared.userId, sessionId: prepared.sessionId } });
    const created = await getProjectSession(apiKey, prepared.sessionId);
    if (!created)
        throw new Error("Composio Session disappeared after creation");
    return created;
}
/** Composio's wording when a toolkit has no managed auth and the Session was
 *  not told which of the project's own auth configs to use. */
const NEEDS_AUTH_CONFIG = /does not manage auth|auth[_ ]?config/i;
export async function mcpIntegration(cfg, context) {
    if (!configured(cfg))
        return null;
    return {
        command: process.execPath,
        args: [SPAWNED_PROXIES.connectors],
        env: {
            ELECTRON_RUN_AS_NODE: "1",
            // The provider-facing bridge receives only this boot's loopback token.
            // Project/broker credentials stay in the harness process, so a coding
            // agent that prints its environment cannot export a durable secret.
            OMB_CONNECTOR_UPSTREAM_URL: `${context.harnessUrl}/api/internal/connectors/mcp`,
            OMB_CONNECTOR_UPSTREAM_HEADERS: JSON.stringify({ authorization: `Bearer ${context.commsToken}` }),
            OMB_HARNESS_URL: context.harnessUrl,
            // Distinct from the agents proxy token: Codex flattens mounted MCP env
            // variables into one process environment, so a shared name would let
            // the later agents mount overwrite this connector-scoped capability.
            OMB_CONNECTOR_TOKEN: context.commsToken,
            OMB_BOT_ID: context.botId,
            OMB_THREAD_ID: context.threadId,
        },
    };
}
export async function relayMcp(cfg, payload, transportSessionId) {
    const apiKey = projectApiKey(cfg);
    let url;
    let identity;
    const headers = new Headers({
        "content-type": "application/json",
        accept: "application/json, text/event-stream",
    });
    const surface = composioSurface(cfg);
    if (apiKey) {
        if (surface === "connect") {
            url = connectMcpEndpoint(cfg);
            headers.set("x-consumer-api-key", apiKey);
            identity = backendFingerprint("connect-mcp", url, apiKey);
        }
        else {
            const session = await ensureProjectSession(cfg);
            url = session.mcp.url;
            headers.set("x-api-key", apiKey);
            identity = backendFingerprint("project-mcp", url, apiKey);
        }
    }
    else {
        const broker = brokerAccess();
        if (!broker)
            throw new Error("Connected apps are unavailable");
        url = `${broker.url}/v1/mcp`;
        headers.set("authorization", `Bearer ${broker.token}`);
        identity = backendFingerprint("managed-mcp", url, broker.token);
    }
    const knownIdentity = transportSessionId
        ? transportSessionBackends.get(transportSessionId)
        : undefined;
    const forwardedTransportSessionId = transportSessionId
        && knownIdentity === identity
        ? transportSessionId
        : undefined;
    if (forwardedTransportSessionId) {
        headers.set("mcp-session-id", forwardedTransportSessionId);
    }
    const response = await fetch(url, {
        method: "POST",
        headers,
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(10 * 60_000),
    });
    const declared = Number(response.headers.get("content-length") ?? "0");
    if (declared > 20 * 1024 * 1024)
        throw new Error("Connected-app response exceeded 20 MB");
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (bytes.byteLength > 20 * 1024 * 1024)
        throw new Error("Connected-app response exceeded 20 MB");
    if (forwardedTransportSessionId)
        rememberTransportSession(forwardedTransportSessionId, identity);
    const nextTransportSessionId = response.headers.get("mcp-session-id") ?? undefined;
    if (nextTransportSessionId)
        rememberTransportSession(nextTransportSessionId, identity);
    return {
        status: response.status,
        bytes,
        contentType: response.headers.get("content-type") ?? "application/json",
        transportSessionId: nextTransportSessionId,
    };
}
async function listConnectedAccounts(apiKey, userId, slugs) {
    const accounts = [];
    const seenCursors = new Set();
    let cursor;
    // Five accounts per toolkit can exceed one provider page when a user has
    // many apps. Follow Composio's cursor instead of silently dropping entries.
    for (let page = 0; page < MAX_CONNECTED_ACCOUNT_PAGES; page += 1) {
        const params = new URLSearchParams({
            limit: "50",
            user_ids: userId,
            order_by: "updated_at",
            order_direction: "desc",
        });
        if (slugs.length)
            params.set("toolkit_slugs", slugs.join(","));
        if (cursor)
            params.set("cursor", cursor);
        const response = await fetch(`${apiBase()}/connected_accounts?${params}`, {
            headers: projectHeaders(apiKey),
            signal: AbortSignal.timeout(15_000),
        });
        if (!response.ok)
            throw new Error(await responseError(response, `Composio accounts: HTTP ${response.status}`));
        const body = connectedAccountsPageSchema.parse(await response.json());
        accounts.push(...body.items);
        const next = body.next_cursor || undefined;
        if (!next || seenCursors.has(next))
            return accounts;
        seenCursors.add(next);
        cursor = next;
    }
    throw new Error("Composio account inventory exceeded the pagination safety limit");
}
async function listSessionToolkits(apiKey, sessionId) {
    const toolkits = [];
    const seenCursors = new Set();
    let cursor;
    for (let page = 0; page < MAX_CONNECTED_ACCOUNT_PAGES; page += 1) {
        // The unfiltered endpoint contains the entire Composio marketplace and is
        // cursor-paginated in 50-item pages. The Connected tab only needs the
        // user's connected toolkits, so avoid scanning hundreds of unrelated apps.
        const params = new URLSearchParams({ limit: "50", is_connected: "true" });
        if (cursor)
            params.set("cursor", cursor);
        const response = await fetch(`${apiBase()}/tool_router/session/${encodeURIComponent(sessionId)}/toolkits?${params}`, { headers: projectHeaders(apiKey), signal: AbortSignal.timeout(15_000) });
        if (!response.ok)
            throw new Error(await responseError(response, `Composio toolkits: HTTP ${response.status}`));
        const body = toolkitPageSchema.parse(await response.json());
        toolkits.push(...(body.items ?? []));
        const next = body.next_cursor || undefined;
        if (!next || seenCursors.has(next))
            return toolkits;
        seenCursors.add(next);
        cursor = next;
    }
    throw new Error("Composio toolkit inventory exceeded the pagination safety limit");
}
function summarizeAccounts(accounts, slugs) {
    const requested = new Set(slugs.map(canonicalToolkitSlug));
    const bySlug = new Map();
    for (const account of accounts) {
        const slug = account.toolkit?.slug ? canonicalToolkitSlug(account.toolkit.slug) : "";
        if (!slug || (requested.size && !requested.has(slug)) || !validAccountId(account.id))
            continue;
        const alias = account.alias?.trim() ?? "";
        const summary = {
            id: account.id,
            status: account.status || "UNKNOWN",
            updatedAt: account.updated_at ?? "",
        };
        if (printableAliasSchema.safeParse(alias).success)
            summary.alias = alias;
        const list = bySlug.get(slug) ?? [];
        list.push(summary);
        bySlug.set(slug, list);
    }
    for (const list of bySlug.values())
        list.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
    return bySlug;
}
function publicAccount({ id, alias, status }) {
    const account = { id, status };
    if (alias)
        account.alias = alias;
    return account;
}
function serviceStateFromAccounts(accounts) {
    const active = accounts.find((account) => /^active$/i.test(account.status));
    const pending = accounts.find((account) => /^(initiated|initializing|pending)$/i.test(account.status));
    const expired = accounts.find((account) => /^expired/i.test(account.status));
    const failed = accounts.find((account) => /^(failed|error)/i.test(account.status));
    const cancelled = accounts.find((account) => /^cancel/i.test(account.status));
    const disconnected = accounts.find((account) => /^disconnect/i.test(account.status));
    if (active) {
        return {
            connected: true,
            pending: false,
            status: active.status || "ACTIVE",
            accounts: accounts.map(publicAccount),
        };
    }
    if (pending) {
        return {
            connected: false,
            pending: true,
            status: pending.status || "PENDING",
            accounts: accounts.map(publicAccount),
        };
    }
    if (expired) {
        return {
            connected: false,
            pending: false,
            status: expired.status || "EXPIRED",
            accounts: accounts.map(publicAccount),
        };
    }
    if (failed) {
        return {
            connected: false,
            pending: false,
            status: failed.status || "FAILED",
            accounts: accounts.map(publicAccount),
        };
    }
    if (cancelled) {
        return {
            connected: false,
            pending: false,
            status: cancelled.status || "CANCELLED",
            accounts: accounts.map(publicAccount),
        };
    }
    if (disconnected) {
        return {
            connected: false,
            pending: false,
            status: disconnected.status || "DISCONNECTED",
            accounts: accounts.map(publicAccount),
        };
    }
    const selected = accounts[0];
    return {
        connected: false,
        pending: false,
        status: selected?.status ?? "not_connected",
        accounts: accounts.map(publicAccount),
    };
}
function allServiceStates(accountsBySlug, toolkits) {
    const services = new Map([...accountsBySlug].map(([slug, accounts]) => [slug, serviceStateFromAccounts(accounts)]));
    for (const toolkit of toolkits) {
        const slug = toolkit.slug ? canonicalToolkitSlug(toolkit.slug) : "";
        const selected = toolkit.connected_account;
        const selectedId = validAccountId(selected?.id) ? selected.id : undefined;
        if (!slug || (!toolkit.is_no_auth && !selectedId))
            continue;
        const existingAccounts = accountsBySlug.get(slug) ?? [];
        const accounts = [...existingAccounts];
        if (selectedId && !accounts.some((account) => account.id === selectedId)) {
            accounts.push({ id: selectedId, status: selected?.status ?? "ACTIVE" });
        }
        const accountState = serviceStateFromAccounts(accounts);
        const isNoAuth = toolkit.is_no_auth === true;
        const rawStatus = isNoAuth ? "ACTIVE" : (selected?.status ?? accountState.status);
        const isConnected = isNoAuth || accountState.connected || /^active$/i.test(rawStatus);
        const isPending = !isConnected && (accountState.pending || /^(initiated|initializing|pending)$/i.test(rawStatus));
        const finalStatus = isConnected
            ? (isNoAuth ? "ACTIVE" : (accountState.connected ? accountState.status : rawStatus))
            : (isPending ? (accountState.pending ? accountState.status : rawStatus) : rawStatus);
        services.set(slug, {
            connected: isConnected,
            pending: isPending,
            status: finalStatus,
            accounts: accountState.accounts,
        });
    }
    return Object.fromEntries(services);
}
async function queryConnectMcpTools(apiKey, endpoint) {
    const res = await fetch(endpoint, {
        method: "POST",
        headers: {
            "content-type": "application/json",
            "x-consumer-api-key": apiKey,
            accept: "application/json, text/event-stream",
        },
        body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "tools/list", params: {} }),
        signal: AbortSignal.timeout(10_000),
    });
    if (!res.ok)
        return [];
    const json = await res.json().catch(() => ({}));
    const tools = json?.result?.tools ?? json?.tools ?? [];
    if (!Array.isArray(tools))
        return [];
    return tools.map((t) => String(t.name ?? "")).filter(Boolean);
}
function toolkitSlugsFromTools(toolNames) {
    const slugs = new Set();
    for (const name of toolNames) {
        const parts = name.split(/[-_]/);
        if (parts[0])
            slugs.add(canonicalToolkitSlug(parts[0]));
    }
    return slugs;
}
async function connectServicesFromMcp(apiKey, endpoint) {
    const tools = await queryConnectMcpTools(apiKey, endpoint);
    const slugs = toolkitSlugsFromTools(tools);
    return Object.fromEntries([...slugs].map((slug) => [
        slug,
        {
            connected: true,
            pending: false,
            status: "ACTIVE",
            accounts: [{ id: `connect_${slug}`, status: "ACTIVE" }],
        },
    ]));
}
async function connectStatusFromMcp(apiKey, slugs, endpoint) {
    const tools = await queryConnectMcpTools(apiKey, endpoint);
    const connected = toolkitSlugsFromTools(tools);
    return Object.fromEntries(slugs.map((slug) => {
        const canonical = canonicalToolkitSlug(slug);
        const isConnected = connected.has(canonical);
        return [
            slug,
            {
                connected: isConnected,
                pending: false,
                status: isConnected ? "ACTIVE" : "not_connected",
                accounts: isConnected ? [{ id: `connect_${canonical}`, status: "ACTIVE" }] : [],
            },
        ];
    }));
}
/**
 * Enumerate the user's complete connected-account inventory without depending
 * on marketplace ordering or catalog pagination.
 */
export async function connectedServices(cfg) {
    const apiKey = projectApiKey(cfg);
    if (!apiKey) {
        const response = await brokerRequest("/v1/connectors/connected");
        if (!response.ok)
            await throwBrokerError(response, `Connected apps: HTTP ${response.status}`);
        const body = connectorServicesResponseSchema.parse(await response.json());
        const services = canonicalServiceRecord(body.services ?? {});
        return Object.fromEntries(Object.entries(services).map(([slug, state]) => [slug, {
                connected: state.connected,
                pending: state.pending ?? false,
                status: state.status ?? (state.connected ? "ACTIVE" : "not_connected"),
                accounts: state.accounts ?? [],
            }]));
    }
    const surface = composioSurface(cfg);
    if (surface === "connect") {
        return connectServicesFromMcp(apiKey, connectMcpEndpoint(cfg)).catch(() => ({}));
    }
    const session = await ensureProjectSession(cfg);
    const userId = session.config?.user_id ?? cfg.composio?.userId;
    if (!userId)
        throw new Error("Composio Session returned no user ID");
    const [toolkits, accounts] = await Promise.all([
        listSessionToolkits(apiKey, session.session_id),
        // Scoped project keys can grant Session reads without granting the raw
        // connected-account list. The Session still proves which selected/no-auth
        // toolkits belong to this installation, so retain that safe fallback.
        listConnectedAccounts(apiKey, userId, []).catch(() => []),
    ]);
    return allServiceStates(summarizeAccounts(accounts, []), toolkits);
}
export async function connectionStatus(cfg, slugs) {
    const canonicalSlugs = [...new Set(slugs.map(canonicalToolkitSlug))];
    const apiKey = projectApiKey(cfg);
    if (!apiKey) {
        const response = await brokerRequest(`/v1/connectors?${new URLSearchParams({ services: canonicalSlugs.join(",") })}`);
        if (!response.ok)
            await throwBrokerError(response, `Connected apps: HTTP ${response.status}`);
        const body = connectorServicesResponseSchema.parse(await response.json());
        return requestedServiceRecord(body.services ?? {}, slugs);
    }
    const surface = composioSurface(cfg);
    if (surface === "connect") {
        return connectStatusFromMcp(apiKey, slugs, connectMcpEndpoint(cfg)).catch(() => {
            return Object.fromEntries(slugs.map((slug) => [slug, { connected: false, pending: false, status: "not_connected", accounts: [] }]));
        });
    }
    const session = await ensureProjectSession(cfg);
    const params = new URLSearchParams({ limit: "50" });
    if (canonicalSlugs.length)
        params.set("toolkits", canonicalSlugs.join(","));
    const userId = session.config?.user_id ?? cfg.composio?.userId;
    const [res, accounts] = await Promise.all([
        fetch(`${apiBase()}/tool_router/session/${encodeURIComponent(session.session_id)}/toolkits?${params}`, {
            headers: projectHeaders(apiKey),
            signal: AbortSignal.timeout(15_000),
        }),
        // Session toolkits only include an account once it is usable. Read the
        // account lifecycle too so the UI can distinguish an OAuth flow that is
        // still waiting in the browser from one that expired or failed. Scoped
        // keys may omit connected-account read permission, so this is additive:
        // the normal session result remains the fallback.
        userId
            ? listConnectedAccounts(apiKey, userId, canonicalSlugs).catch(() => [])
            : Promise.resolve([]),
    ]);
    if (!res.ok)
        throw new Error(await responseError(res, `Composio toolkits: HTTP ${res.status}`));
    const body = toolkitPageSchema.parse(await res.json());
    const bySlug = new Map((body.items ?? []).flatMap((item) => item.slug ? [[canonicalToolkitSlug(item.slug), item]] : []));
    const accountsBySlug = summarizeAccounts(accounts, canonicalSlugs);
    return Object.fromEntries(slugs.map((slug) => {
        const canonicalSlug = canonicalToolkitSlug(slug);
        const item = bySlug.get(canonicalSlug);
        const serviceAccounts = accountsBySlug.get(canonicalSlug) ?? [];
        // Mirror allServiceStates: a scoped key can be denied the raw account
        // list while the Session still names its selected account. Synthesize
        // that account here too, so a status poll never wipes the row the
        // inventory paths render (merge replaces a slug's state wholesale).
        const selected = item?.connected_account;
        const selectedId = validAccountId(selected?.id) ? selected.id : undefined;
        const withSelected = selectedId && !serviceAccounts.some((account) => account.id === selectedId)
            ? [...serviceAccounts, { id: selectedId, status: selected?.status ?? "ACTIVE" }]
            : serviceAccounts;
        const accountState = serviceStateFromAccounts(withSelected);
        const isNoAuth = item?.is_no_auth === true;
        const rawState = item?.connected_account?.status
            ?? (isNoAuth ? "ACTIVE" : accountState.status);
        const isConnected = isNoAuth || accountState.connected || /^active$/i.test(rawState);
        const isPending = !isConnected && (accountState.pending || /^(initiated|initializing|pending)$/i.test(rawState));
        const finalStatus = isConnected
            ? (isNoAuth ? "ACTIVE" : (accountState.connected ? accountState.status : rawState))
            : (isPending ? (accountState.pending ? accountState.status : rawState) : rawState);
        return [slug, {
                connected: isConnected,
                pending: isPending,
                status: finalStatus,
                accounts: accountState.accounts,
            }];
    }));
}
/** Backward-compatible service disconnect: removes all accounts associated with the toolkit. */
export async function removeService(cfg, slug) {
    const toolkit = canonicalToolkitSlug(slug);
    const apiKey = projectApiKey(cfg);
    if (!apiKey) {
        const response = await brokerRequest(`/v1/connectors/${encodeURIComponent(toolkit)}`, { method: "DELETE" });
        if (!response.ok)
            await throwBrokerError(response, `Connected apps: HTTP ${response.status}`);
        transportSessionBackends.clear();
        return removalResponseSchema.parse(await response.json());
    }
    const surface = composioSurface(cfg);
    if (surface === "connect") {
        transportSessionBackends.clear();
        return { removed: 1 };
    }
    const session = await ensureProjectSession(cfg).catch(() => null);
    const userId = session?.config?.user_id ?? cfg.composio?.userId;
    const targetIds = new Set();
    if (session) {
        const params = new URLSearchParams({ limit: "50", toolkits: toolkit });
        const list = await fetch(`${apiBase()}/tool_router/session/${encodeURIComponent(session.session_id)}/toolkits?${params}`, { headers: projectHeaders(apiKey), signal: AbortSignal.timeout(15_000) }).catch(() => null);
        if (list?.ok) {
            const body = toolkitPageSchema.safeParse(await list.json().catch(() => null));
            if (body.success) {
                const item = body.data.items?.find((i) => i.slug && canonicalToolkitSlug(i.slug) === toolkit);
                if (validAccountId(item?.connected_account?.id)) {
                    targetIds.add(item.connected_account.id);
                }
            }
        }
    }
    if (userId) {
        const accounts = await listConnectedAccounts(apiKey, userId, [toolkit]).catch(() => []);
        for (const a of accounts) {
            if (a.toolkit?.slug && canonicalToolkitSlug(a.toolkit.slug) === toolkit && validAccountId(a.id)) {
                targetIds.add(a.id);
            }
        }
    }
    if (targetIds.size === 0)
        return { removed: 0 };
    for (const id of targetIds) {
        const removed = await fetch(`${apiBase()}/connected_accounts/${encodeURIComponent(id)}?revoke_on_delete=true`, { method: "DELETE", headers: projectHeaders(apiKey), signal: AbortSignal.timeout(30_000) });
        if (!removed.ok && removed.status !== 404) {
            throw new Error(await responseError(removed, `Composio disconnect: HTTP ${removed.status}`));
        }
    }
    transportSessionBackends.clear();
    return { removed: 1 };
}
/** Disconnect exactly one account after proving it belongs to this user/toolkit. */
export async function removeAccount(cfg, slug, accountId) {
    if (!validAccountId(accountId))
        throw inputError("Invalid connected-account ID");
    const toolkit = canonicalToolkitSlug(slug);
    const apiKey = projectApiKey(cfg);
    if (!apiKey) {
        const response = await brokerRequest(`/v1/connectors/${encodeURIComponent(toolkit)}/accounts/${encodeURIComponent(accountId)}`, { method: "DELETE" });
        if (!response.ok)
            await throwBrokerError(response, `Connected apps: HTTP ${response.status}`);
        transportSessionBackends.clear();
        return removalResponseSchema.parse(await response.json());
    }
    const session = await ensureProjectSession(cfg).catch(() => null);
    const userId = session?.config?.user_id ?? cfg.composio?.userId;
    if (userId) {
        const accounts = await listConnectedAccounts(apiKey, userId, [toolkit]).catch(() => []);
        const owned = accounts.some((account) => account.id === accountId
            && account.toolkit?.slug !== undefined
            && canonicalToolkitSlug(account.toolkit.slug) === toolkit);
        if (!owned && accounts.length > 0)
            return { removed: 0 };
    }
    const removed = await fetch(`${apiBase()}/connected_accounts/${encodeURIComponent(accountId)}?revoke_on_delete=true`, { method: "DELETE", headers: projectHeaders(apiKey), signal: AbortSignal.timeout(30_000) });
    if (!removed.ok && removed.status !== 404) {
        throw new Error(await responseError(removed, `Composio disconnect: HTTP ${removed.status}`));
    }
    transportSessionBackends.clear();
    return { removed: 1 };
}
/** Mint a browser auth link for one service. Returns { url } or throws. */
export async function authorizeService(cfg, slug, requestedAlias) {
    const alias = normalizeAccountAlias(requestedAlias);
    const toolkit = canonicalToolkitSlug(slug);
    const mode = connectionMode(cfg);
    const unavailable = managedConnectorUnavailableReason(mode, toolkit);
    if (unavailable)
        throw inputError(unavailable, 409);
    const apiKey = projectApiKey(cfg);
    if (!apiKey) {
        const request = { method: "POST" };
        if (alias)
            request.body = JSON.stringify({ alias });
        const response = await brokerRequest(`/v1/connectors/${encodeURIComponent(toolkit)}/authorize`, request);
        if (!response.ok)
            await throwBrokerError(response, `Connected apps: HTTP ${response.status}`);
        const body = authUrlResponseSchema.parse(await response.json());
        return { url: trustedAuthUrl(body.url, toolkit) };
    }
    const surface = composioSurface(cfg);
    if (surface === "connect") {
        return { url: "https://dashboard.composio.dev" };
    }
    const session = await ensureProjectSession(cfg);
    const userId = session.config?.user_id ?? cfg.composio?.userId;
    if (!userId)
        throw new Error("Composio Session has no user ID");
    // A scoped key may be denied account listing — authorization must still
    // work (it always did pre-multi-account), so the alias guardrails degrade
    // to first-account behavior, the same fallback every inventory path takes.
    const accounts = await listConnectedAccounts(apiKey, userId, [toolkit]).catch(() => []);
    const serviceAccounts = accounts.filter((account) => account.toolkit?.slug !== undefined && canonicalToolkitSlug(account.toolkit.slug) === toolkit);
    const usableAccounts = serviceAccounts.filter((account) => /^(active|initiated|initializing|pending)$/i.test(account.status ?? ""));
    if (usableAccounts.length >= MULTI_ACCOUNT_CONFIG.max_accounts_per_toolkit) {
        throw inputError(`${toolkit} already has the maximum of ${MULTI_ACCOUNT_CONFIG.max_accounts_per_toolkit} accounts`, 409);
    }
    if (usableAccounts.length > 0 && !alias) {
        throw inputError("Add an account alias so the existing connection is not replaced");
    }
    if (alias && serviceAccounts.some((account) => account.alias?.trim().toLowerCase() === alias.toLowerCase())) {
        throw inputError(`Account alias "${alias}" is already in use for ${toolkit}`, 409);
    }
    const linkRequest = { toolkit };
    if (alias)
        linkRequest.alias = alias;
    const link = (sessionId) => fetch(`${apiBase()}/tool_router/session/${encodeURIComponent(sessionId)}/link`, {
        method: "POST",
        headers: projectHeaders(apiKey, true),
        body: JSON.stringify(linkRequest),
        signal: AbortSignal.timeout(30_000),
    });
    let res = await link(session.session_id);
    if (!res.ok) {
        const message = await responseError(res, `Composio authorization: HTTP ${res.status}`);
        if (!NEEDS_AUTH_CONFIG.test(message))
            throw new Error(message);
        // The toolkit needs one of the project's own auth configs. The Session
        // names those only at creation, so an auth config the user created after
        // the Session existed is invisible to it: rebuild the Session once and
        // retry. If the project has no config for this toolkit, say what to do
        // instead of echoing Composio's "auth_config_override" hint.
        const authConfigs = await listCustomAuthConfigs(apiKey);
        const covered = Object.keys(authConfigs).some((key) => canonicalToolkitSlug(key) === toolkit);
        if (!covered) {
            throw inputError(`${toolkit} has no Composio-managed sign-in. In your Composio project, create an auth config for "${toolkit}" `
                + "(Auth Configs → Create) with your own app credentials, then click Connect again.");
        }
        const fresh = await recreateProjectSession(cfg, userId, authConfigs);
        res = await link(fresh.session_id);
        if (!res.ok)
            throw new Error(await responseError(res, `Composio authorization: HTTP ${res.status}`));
    }
    const body = linkResponseSchema.parse(await res.json());
    return { url: trustedAuthUrl(body.redirect_url, toolkit) };
}
// Curated fallback — the services agentcal's connectors page ships plus the
// long marketplace tail. Logos resolve client-side:
// logo → favicon(domain) → monogram.
const CURATED = [
    { slug: "slack", label: "Slack", blurb: "Post updates and read channels", domain: "slack.com", logo: null },
    { slug: "github", label: "GitHub", blurb: "Issues, pull requests, and code", domain: "github.com", logo: null },
    { slug: "gmail", label: "Gmail", blurb: "Read and send email", domain: "gmail.com", logo: null },
    { slug: "googlecalendar", label: "Google Calendar", blurb: "Read and create events", domain: "calendar.google.com", logo: null },
    { slug: "googlesheets", label: "Google Sheets", blurb: "Read and update spreadsheets", domain: "sheets.google.com", logo: null },
    { slug: "googledocs", label: "Google Docs", blurb: "Read and write documents", domain: "docs.google.com", logo: null },
    { slug: "googledrive", label: "Google Drive", blurb: "Browse and manage files", domain: "drive.google.com", logo: null },
    { slug: "notion", label: "Notion", blurb: "Pages and databases", domain: "notion.so", logo: null },
    { slug: "linear", label: "Linear", blurb: "Issues and project tracking", domain: "linear.app", logo: null },
    { slug: "sentry", label: "Sentry", blurb: "Errors and alerts", domain: "sentry.io", logo: null },
    { slug: "posthog", label: "PostHog", blurb: "Analytics, feature flags, experiments", domain: "posthog.com", logo: null },
    { slug: "discord", label: "Discord", blurb: "Messages and channels", domain: "discord.com", logo: null },
    { slug: "twitter", label: "X (Twitter)", blurb: "Post and read on X", domain: "x.com", logo: null },
    { slug: "reddit", label: "Reddit", blurb: "Browse and post", domain: "reddit.com", logo: null },
    { slug: "zapier", label: "Zapier", blurb: "Connect 9,000+ apps", domain: "zapier.com", logo: null },
    { slug: "hubspot", label: "HubSpot", blurb: "CRM search & updates", domain: "hubspot.com", logo: null },
    { slug: "salesforce", label: "Salesforce", blurb: "CRM records and reports", domain: "salesforce.com", logo: null },
    { slug: "jira", label: "Jira", blurb: "Issues and sprints", domain: "atlassian.com", logo: null },
    { slug: "asana", label: "Asana", blurb: "Tasks and projects", domain: "asana.com", logo: null },
    { slug: "trello", label: "Trello", blurb: "Boards and cards", domain: "trello.com", logo: null },
    { slug: "dropbox", label: "Dropbox", blurb: "Files and folders", domain: "dropbox.com", logo: null },
    { slug: "airtable", label: "Airtable", blurb: "Bases and records", domain: "airtable.com", logo: null },
    { slug: "figma", label: "Figma", blurb: "Files and comments", domain: "figma.com", logo: null },
    { slug: "stripe", label: "Stripe", blurb: "Payments and customers", domain: "stripe.com", logo: null },
];
let toolkitCache = null;
/**
 * Marketplace catalog. Tries the v3 toolkits API (official names,
 * descriptions, logos — cached 10 min); falls back to the curated list.
 */
export async function listToolkits(cfg) {
    const backendKey = projectApiKey(cfg);
    const broker = backendKey ? null : brokerAccess();
    const identity = backendKey
        ? backendFingerprint("project-catalog", toolkitBase(), backendKey)
        : broker
            ? backendFingerprint("managed-catalog", broker.url, broker.token)
            : null;
    if (identity && toolkitCache?.identity === identity && Date.now() - toolkitCache.at < 10 * 60_000) {
        return { cards: toolkitCache.cards, source: "api" };
    }
    if (backendKey || broker) {
        try {
            // The marketplace runs to well over a thousand toolkits and the endpoint
            // is cursor-paginated, so one page stops partway through the alphabet.
            // Follow next_cursor, and keep the pages already collected if a later
            // one fails — a partial catalog still beats the curated two dozen.
            const items = [];
            const seenCursors = new Set();
            let cursor;
            let lastReportedPage;
            for (let page = 0; page < MAX_CONNECTED_ACCOUNT_PAGES; page += 1) {
                const params = new URLSearchParams({ limit: "500", sort_by: "usage" });
                if (cursor)
                    params.set("cursor", cursor);
                const res = backendKey
                    ? await fetch(`${toolkitBase()}/toolkits?${params}`, {
                        headers: { "x-api-key": backendKey },
                        signal: AbortSignal.timeout(15_000),
                    })
                    : await brokerRequest(cursor ? `/v1/catalog?cursor=${encodeURIComponent(cursor)}` : "/v1/catalog", {
                        signal: AbortSignal.timeout(15_000),
                    });
                if (!res.ok)
                    break;
                const json = await res.json();
                const pageItems = json.items ?? json.data ?? [];
                if (!Array.isArray(pageItems))
                    break;
                items.push(...pageItems);
                // Composio reports current_page and total_pages beside next_cursor.
                // A broker that drops the cursor (or an upstream regression) can replay
                // a page while minting fresh cursors, so trust page movement: once it
                // stops advancing, the catalog is stuck and paging stops cleanly.
                const reportedPage = Number(json.current_page);
                if (Number.isFinite(reportedPage)) {
                    if (lastReportedPage !== undefined && reportedPage <= lastReportedPage)
                        break;
                    lastReportedPage = reportedPage;
                }
                const reportedTotalPages = Number(json.total_pages);
                if (lastReportedPage !== undefined &&
                    Number.isFinite(reportedTotalPages) &&
                    reportedTotalPages > 0 &&
                    lastReportedPage >= reportedTotalPages) {
                    break;
                }
                const next = typeof json.next_cursor === "string" ? json.next_cursor.trim() : "";
                if (!next || seenCursors.has(next))
                    break;
                seenCursors.add(next);
                cursor = next;
            }
            if (items.length) {
                const cards = items.map((t) => ({
                    slug: canonicalToolkitSlug(String(t.slug ?? t.key ?? t.name ?? "")),
                    label: t.name ?? t.slug ?? "",
                    blurb: (t.meta?.description ?? t.description ?? "").slice(0, 90),
                    logo: t.meta?.logo ?? t.logo ?? null,
                    noAuth: t.no_auth === true,
                    domain: null,
                }));
                const uniqueCards = cards.filter((card, index) => card.slug && cards.findIndex((candidate) => candidate.slug === card.slug) === index);
                toolkitCache = { at: Date.now(), cards: uniqueCards, identity: identity };
                return { cards: uniqueCards, source: "api" };
            }
        }
        catch {
            /* fall through to curated */
        }
    }
    return { cards: CURATED, source: "curated" };
}
export async function toolkitCard(cfg, slug) {
    const normalized = canonicalToolkitSlug(slug);
    const { cards } = await listToolkits(cfg);
    return cards.find((card) => card.slug.toLowerCase() === normalized)
        ?? CURATED.find((card) => card.slug === normalized)
        ?? {
            slug: normalized,
            label: normalized.replace(/[-_]+/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase()),
            blurb: "Connect this app so your bot can continue",
            logo: null,
            domain: null,
        };
}
export const CURATED_SLUGS = CURATED.map((c) => c.slug);
