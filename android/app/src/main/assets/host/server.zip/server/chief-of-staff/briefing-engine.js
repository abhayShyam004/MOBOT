import { randomUUID } from "node:crypto";
import { defaultChiefStore } from "./chief-store.js";
import { isSameDayInTimezone } from "./task-extractor.js";
export class BriefingEngine {
    store;
    clock;
    constructor(store = defaultChiefStore, opts) {
        this.store = store;
        this.clock = opts?.clock ?? (() => new Date());
    }
    generateBriefing(tasks, sourcesSummary) {
        const briefingId = `briefing_${randomUUID()}`;
        const now = this.clock();
        const needsAttention = [];
        const scheduleToday = [];
        const pendingActionItems = [];
        for (const task of tasks) {
            if (task.status === "completed" || task.status === "dismissed") {
                continue;
            }
            // Expired appointments never belong in Needs Attention or Today's Schedule
            if (task.temporalStatus === "expired") {
                pendingActionItems.push(task);
                continue;
            }
            // Today's schedule: strictly happening now or upcoming today
            const isToday = task.dueDate ? isSameDayInTimezone(now, new Date(task.dueDate), "Asia/Kolkata") : false;
            if (isToday && (task.temporalStatus === "happening_now" || task.temporalStatus === "upcoming")) {
                scheduleToday.push(task);
                // If RSVP is also required, cross-list in needsAttention
                if (task.title.startsWith("RSVP Required") || task.priority === "urgent") {
                    needsAttention.push(task);
                }
                continue;
            }
            // Needs Attention: Urgent, happening now, upcoming unconfirmed RSVPs, or past actionable items
            if (task.priority === "urgent" ||
                task.temporalStatus === "happening_now" ||
                (task.temporalStatus === "upcoming" && task.title.startsWith("RSVP Required")) ||
                task.temporalStatus === "past_actionable" ||
                (task.action && task.priority === "high")) {
                needsAttention.push(task);
            }
            else {
                pendingActionItems.push(task);
            }
        }
        // Build stable display order across all visible sections
        const displayOrder = [];
        const addOrder = (list) => {
            for (const t of list) {
                if (!displayOrder.includes(t.id)) {
                    displayOrder.push(t.id);
                }
            }
        };
        addOrder(needsAttention);
        addOrder(scheduleToday);
        addOrder(pendingActionItems);
        // Save tasks to store
        this.store.saveTasks(tasks);
        // Format markdown representation
        const formattedMarkdown = this.renderMarkdown(briefingId, now, needsAttention, scheduleToday, pendingActionItems, displayOrder, sourcesSummary);
        const briefing = {
            id: briefingId,
            generatedAt: now.toISOString(),
            needsAttention,
            scheduleToday,
            pendingActionItems,
            displayOrder,
            sourcesSummary,
            formattedMarkdown,
        };
        this.store.setActiveBriefing(briefing);
        return briefing;
    }
    renderMarkdown(_briefingId, generatedAt, needsAttention, scheduleToday, pendingActionItems, displayOrder, sourcesSummary) {
        const getIndex = (taskId) => displayOrder.indexOf(taskId) + 1;
        const lines = [];
        lines.push(`# MOBOT Chief of Staff — Personal Briefing`);
        lines.push(`*Generated on ${generatedAt.toLocaleString("en-US", { timeZone: "Asia/Kolkata" })} (Asia/Kolkata)*\n`);
        // Sources summary banner
        lines.push(`### 🔌 Connected Integrations`);
        for (const [slug, summary] of Object.entries(sourcesSummary)) {
            const badge = summary.status === "active"
                ? "🟢 Active"
                : summary.status === "disconnected"
                    ? "⚪ Not Connected"
                    : summary.status === "empty"
                        ? "⚪ No Data"
                        : "🔴 Error";
            const countInfo = summary.count > 0 ? ` (${summary.count} items)` : "";
            const accountInfo = summary.account ? ` — ${summary.account}` : "";
            const details = summary.details ? ` *(${summary.details})*` : "";
            lines.push(`- **${slug}**: ${badge}${countInfo}${accountInfo}${details}`);
        }
        lines.push("");
        // Section 1: Needs Attention
        lines.push(`## ⚠️ Needs Attention`);
        if (needsAttention.length === 0) {
            lines.push(`*No urgent items requiring immediate intervention.*\n`);
        }
        else {
            for (const t of needsAttention) {
                const idx = getIndex(t.id);
                const prioTag = t.priority === "urgent"
                    ? "🔥 `URGENT`"
                    : t.temporalStatus === "past_actionable"
                        ? "🕒 `OVERDUE`"
                        : "⚡ `HIGH`";
                lines.push(`### [${idx}] ${t.title} ${prioTag}`);
                lines.push(`${t.description}`);
                if (t.temporalNote) {
                    lines.push(`- **Timing:** 🕒 ${t.temporalNote}`);
                }
                else if (t.dueDate) {
                    lines.push(`- **Due / Starts:** ${t.dueDate}`);
                }
                if (t.action) {
                    lines.push(`- **Suggested Action:** ${t.action.title} *(reply "do ${idx}" to delegate)*`);
                }
                lines.push("");
            }
        }
        // Section 2: Today's Schedule
        lines.push(`## 📅 Today's Schedule`);
        if (scheduleToday.length === 0) {
            lines.push(`*No scheduled meetings or calendar events for today.*\n`);
        }
        else {
            for (const t of scheduleToday) {
                const idx = getIndex(t.id);
                lines.push(`- **[${idx}] ${t.title}**`);
                lines.push(`  ${t.description}`);
                if (t.temporalNote) {
                    lines.push(`  *Timing:* ${t.temporalNote}`);
                }
                else if (t.dueDate) {
                    lines.push(`  *Time:* ${t.dueDate}`);
                }
            }
            lines.push("");
        }
        // Section 3: Pending Action Items
        lines.push(`## 📋 Pending Action Items`);
        if (pendingActionItems.length === 0) {
            lines.push(`*No other pending action items.*\n`);
        }
        else {
            for (const t of pendingActionItems) {
                const idx = getIndex(t.id);
                const statusBadge = t.temporalStatus === "expired"
                    ? " `EXPIRED / PAST`"
                    : t.priority === "low"
                        ? " `LOW`"
                        : "";
                lines.push(`- **[${idx}] ${t.title}**${statusBadge}`);
                lines.push(`  ${t.description}`);
                if (t.temporalNote) {
                    lines.push(`  *Status:* ${t.temporalNote}`);
                }
                if (t.action) {
                    lines.push(`  *Action:* ${t.action.title} *(reply "do ${idx}")*`);
                }
            }
            lines.push("");
        }
        // Delegation footer
        lines.push(`---`);
        lines.push(`💡 *To delegate any action, reply with "do [number]" (e.g. "do 1") or describe the action you want executed.*`);
        return lines.join("\n");
    }
}
