import { createOpenAIChatRuntime } from "./openai-chat.js";
const DRIVER_KIND = "grok";
const DEFAULT_URL = "https://api.x.ai/v1";
const MODELS = {
    default: "grok-4",
    options: [
        { id: "grok-4", label: "Grok 4" },
        { id: "grok-4-fast", label: "Grok 4 Fast" },
        { id: "grok-3-mini", label: "Grok 3 Mini" },
    ],
};
function decodeConfig(raw) {
    const config = (raw ?? {});
    if (config.tools !== undefined && typeof config.tools !== "boolean")
        throw new Error("tools must be a boolean");
    return {
        ...(config.tools !== undefined ? { tools: config.tools } : {}),
        url: typeof config.url === "string" ? config.url : DEFAULT_URL,
        apiKeyEnv: typeof config.apiKeyEnv === "string" ? config.apiKeyEnv : "XAI_API_KEY",
    };
}
export const GrokDriver = {
    driverKind: DRIVER_KIND,
    metadata: { displayName: "Grok (API)", supportsMultipleInstances: true },
    models: MODELS,
    decodeConfig,
    defaultConfig: () => decodeConfig({}),
    async create(input) {
        const { config } = input;
        const apiKey = input.environment[config.apiKeyEnv] ?? process.env[config.apiKeyEnv] ?? "";
        return createOpenAIChatRuntime({
            input,
            driverKind: DRIVER_KIND,
            apiKey,
            apiUrl: config.url,
            tools: config.tools,
            models: () => MODELS,
            requestBody: (model, messages, stream) => ({ model, messages, stream }),
            httpErrorLabel: "xAI",
            missingKeyError: `no xAI key — set ${config.apiKeyEnv} or config.json xai.key`,
            unavailableReason: `no xAI API key — add {"xai":{"key":"xai-…"}} to ~/.openmausbot/config.json or set ${config.apiKeyEnv}`,
            timeoutMs: 120_000,
            retryScale: Number(process.env.FAKE_GROK_RETRY_SCALE ?? "1"),
            generateModel: () => "grok-3-mini",
            nativeLog: {
                source: "xai.chat.completions",
                outgoing: (_turn, messages, model) => ({ model, messages }),
                incoming: ({ text, usage }) => ({ text, usage }),
            },
        });
    },
};
