import { newEventId, newId } from "../contracts.js";
import { appendNative } from "./native.js";
const DRIVER_KIND = "boxAgent";
// overridable so tests and a dev backend can be pointed at instead of the live provider
const BOX_API = process.env.OMB_BOX_API || "https://ascii.dev/api/box/v1";
const MODELS = {
    default: "claude-fable-5",
    options: [
        { id: "claude-fable-5", label: "Claude Fable 5 · on the box" },
        { id: "sonnet", label: "Claude Sonnet · on the box" },
        { id: "gpt-5.4", label: "GPT-5.4 (Codex) · on the box" },
    ],
};
/** The box runs every harness ascii.dev ships (claude-code, codex, pi, opencode,
 * prime-agent, kimi). Which one a model id belongs to comes from the public
 * catalog, `GET /api/provider-models` at the API root: an object keyed by
 * harness, each with its `models`. A bot that arrives here from another engine
 * carries that engine's model id, so this is what lets it keep its model. */
let catalog = null;
async function loadCatalog() {
    const root = BOX_API.replace(/\/api\/box\/v1\/?$/, "");
    catalog = await fetch(`${root}/api/provider-models`, { signal: AbortSignal.timeout(15_000) })
        .then((res) => (res.ok ? res.json() : null))
        .catch(() => null);
}
const providerFor = (model) => {
    const slash = model.indexOf("/");
    if (slash > 0 && catalog?.[model.slice(0, slash)])
        return { provider: model.slice(0, slash), model: model.slice(slash + 1) };
    for (const [provider, harness] of Object.entries(catalog ?? {})) {
        if (harness.models?.some((m) => m?.id === model))
            return { provider, model };
    }
    return { provider: model.startsWith("gpt") ? "codex" : "claude-code", model };
};
function decodeConfig(raw) {
    const o = (raw ?? {});
    return { pollMs: typeof o.pollMs === "number" ? o.pollMs : 2500 };
}
export const BoxAgentDriver = {
    driverKind: DRIVER_KIND,
    metadata: { displayName: "Computer", supportsMultipleInstances: false },
    models: MODELS,
    decodeConfig,
    defaultConfig: () => decodeConfig({}),
    async create(input) {
        const { instanceId, config } = input;
        const token = input.environment.BOX_TOKEN ?? process.env.BOX_TOKEN ?? "";
        const listeners = new Set();
        const active = new Map();
        const emit = (event) => {
            for (const l of Array.from(listeners))
                l(event);
        };
        const base = (threadId, turnId) => ({
            eventId: newEventId(),
            provider: DRIVER_KIND,
            threadId,
            turnId,
            createdAt: new Date().toISOString(),
        });
        const api = async (path, opts = {}) => {
            const res = await fetch(`${BOX_API}${path}`, {
                ...opts,
                headers: { authorization: `Bearer ${token}`, "content-type": "application/json", ...opts.headers },
                signal: opts.signal ?? AbortSignal.timeout(30_000),
            });
            const body = await res.json().catch(() => null);
            if (!res.ok || body?.ok === false) {
                throw new Error(body?.code ?? body?.error ?? `box HTTP ${res.status}`);
            }
            return body;
        };
        const sendTurn = async (turn) => {
            const { threadId } = turn;
            const computer = turn.integrations?.computer;
            const boxId = computer && (!computer.kind || computer.kind === "box") ? computer.boxId : undefined;
            if (!token)
                throw new Error('box not configured — add {"box":{"token":"…"}} to ~/.openmausbot/config.json');
            if (!boxId) {
                throw new Error("this bot has no computer yet — open the Computer panel and provision one");
            }
            if (active.has(threadId))
                throw new Error("a turn is already running on this thread");
            const turnId = newId();
            const model = turn.model || MODELS.default;
            const prompt = [
                turn.system,
                "You are working on the assigned cloud computer — use its desktop, Chrome, and shell within the access described above.",
                "",
                turn.text,
            ]
                .filter((s) => s !== undefined)
                .join("\n");
            if (!catalog)
                await loadCatalog();
            const started = await api(`/boxes/${boxId}/prompt`, {
                method: "POST",
                body: JSON.stringify({ ...providerFor(model), prompt }),
            });
            appendNative(threadId, { dir: "out", source: "box.prompt", msg: { model, prompt, response: started } });
            // real shape (2026-08): {type:"prompt.queued", promptId, promptRun:{id,…},
            // id:<box id>} — never fall back to the bare id, it's the box's
            const promptId = started?.promptRun?.id ?? started?.prompt?.id ?? started?.promptId ?? null;
            let cancelled = false;
            active.set(threadId, {
                turnId,
                boxId,
                cancel: () => {
                    cancelled = true;
                    void api(`/boxes/${boxId}/interrupt`, { method: "POST" }).catch(() => { });
                },
            });
            emit({ ...base(threadId, turnId), type: "turn.started" });
            emit({ ...base(threadId, turnId), type: "session.started", sessionId: promptId, model });
            // poll events + run status until the prompt settles
            (async () => {
                const seen = new Set();
                const startedAt = Date.now();
                let lastText = "";
                let pendingText = "";
                /** Why the box could not answer (login expired, model refused, …). */
                let problem = null;
                /** Emit unflushed deltas as assistant_text and reset pendingText. */
                const flushAssistantText = () => {
                    const text = pendingText;
                    pendingText = "";
                    if (!text.trim())
                        return;
                    emit({ ...base(threadId, turnId), type: "item.completed", itemType: "assistant_text", text });
                };
                /** Stream a full-text snapshot as a delta and accumulate it for flush. */
                const ingest = (text) => {
                    const delta = text.startsWith(lastText) ? text.slice(lastText.length) : text;
                    lastText = text;
                    if (!delta)
                        return;
                    pendingText += delta;
                    emit({ ...base(threadId, turnId), type: "content.delta", streamKind: "assistant_text", delta });
                };
                try {
                    for (;;) {
                        if (cancelled)
                            break;
                        await new Promise((r) => setTimeout(r, config.pollMs));
                        const events = await api(`/boxes/${boxId}/events`).catch(() => null);
                        const list = events?.events ?? events?.items ?? [];
                        for (const ev of list) {
                            // The stream is the whole conversation from its start; `taskId`
                            // names the prompt run an event belongs to. Earlier turns are
                            // history, not this answer.
                            if (promptId && ev.taskId && String(ev.taskId) !== promptId)
                                continue;
                            const id = String(ev.id ?? ev.eventId ?? JSON.stringify(ev).slice(0, 120));
                            if (seen.has(id))
                                continue;
                            seen.add(id);
                            appendNative(threadId, { dir: "in", source: "box.events", msg: ev });
                            const kind = String(ev.type ?? ev.kind ?? "");
                            // "response" events carry the agent's text at data.content —
                            // the FULL text so far, not a chunk. Clients accumulate
                            // deltas, so forward only the growth; a drifted (non-prefix)
                            // event re-sends whole and the settled message replaces the
                            // stream anyway.
                            const text = ev.text ?? ev.message ?? ev.data?.text ?? ev.data?.content ?? null;
                            if (/assistant|message|output|response/i.test(kind) && typeof text === "string" && text.trim()) {
                                ingest(text);
                            }
                            else if (/usage_limit|error|fail/i.test(kind)) {
                                const why = ev.data?.summary ?? ev.data?.message ?? ev.data?.error ?? ev.message;
                                if (typeof why === "string" && why.trim())
                                    problem = why.trim();
                            }
                            else if (/tool|command|exec|browse/i.test(kind)) {
                                flushAssistantText();
                                emit({
                                    ...base(threadId, turnId),
                                    type: "item.started",
                                    itemType: "tool",
                                    itemId: id,
                                    title: String(ev.title ?? ev.command ?? kind).slice(0, 80),
                                });
                            }
                            // shape-drift backstop: without a promptId the status poll
                            // below can never see a terminal state, so settle off the
                            // events themselves instead of hanging to the 30-min ceiling
                            if (!promptId && /complete|finish|done|success|fail|error/i.test(kind)) {
                                active.delete(threadId);
                                flushAssistantText();
                                const failed = /fail|error/i.test(kind);
                                emit({ ...base(threadId, turnId), type: "turn.completed", ok: !failed, stopReason: failed ? kind : null, cost: null });
                                return;
                            }
                        }
                        if (promptId) {
                            const status = await api(`/boxes/${boxId}/prompts/${promptId}`).catch(() => null);
                            appendNative(threadId, { dir: "in", source: "box.prompt.status", msg: status });
                            // real shape (2026-08): {promptRun:{status:"finished",…}} —
                            // flat fallbacks kept for drift
                            const run = status?.promptRun ?? status?.prompt ?? status ?? {};
                            const state = String(run?.status ?? "");
                            if (/completed|succeeded|done|finished/i.test(state)) {
                                const result = run?.result ?? run?.output ?? lastText;
                                if (typeof result === "string" && result.trim() && result !== lastText) {
                                    ingest(result);
                                }
                                if (!pendingText.trim() && !lastText.trim()) {
                                    // a run that ends with nothing said and a recorded problem
                                    // (login expired, …) is a failure the person must see
                                    if (problem)
                                        throw new Error(problem);
                                    pendingText = "(finished)";
                                }
                                flushAssistantText();
                                active.delete(threadId);
                                emit({ ...base(threadId, turnId), type: "turn.completed", ok: true, stopReason: null, cost: null });
                                return;
                            }
                            if (/failed|error|cancelled|interrupted/i.test(state)) {
                                const runError = [run?.error, run?.failureReason, run?.message].find((v) => typeof v === "string" && v.trim());
                                if (problem || runError || /failed|error/i.test(state))
                                    throw new Error(problem ?? runError ?? `the box run ${state}`);
                                flushAssistantText();
                                active.delete(threadId);
                                emit({ ...base(threadId, turnId), type: "turn.completed", ok: false, stopReason: state, cost: null });
                                return;
                            }
                        }
                        if (Date.now() - startedAt > 30 * 60_000) {
                            throw new Error("box run exceeded 30 minutes — interrupted");
                        }
                    }
                    // cancelled
                    flushAssistantText();
                    active.delete(threadId);
                    emit({ ...base(threadId, turnId), type: "turn.completed", ok: false, stopReason: "interrupted", cost: null });
                }
                catch (e) {
                    flushAssistantText();
                    active.delete(threadId);
                    emit({ ...base(threadId, turnId), type: "runtime.error", message: e.message });
                    emit({ ...base(threadId, turnId), type: "turn.completed", ok: false, stopReason: "error", cost: null });
                }
            })();
            return { turnId };
        };
        const snapshot = async () => {
            if (!token) {
                return { state: "unavailable", reason: 'no Box token — add {"box":{"token":"…"}} to ~/.openmausbot/config.json' };
            }
            try {
                await api("/me");
                return { state: "available", authenticated: true, version: null };
            }
            catch (e) {
                return { state: "unavailable", reason: `box API unreachable: ${e.message}` };
            }
        };
        return {
            instanceId,
            driverKind: DRIVER_KIND,
            displayName: input.displayName,
            enabled: input.enabled,
            models: MODELS,
            snapshot,
            adapter: {
                provider: DRIVER_KIND,
                capabilities: { sessionModelSwitch: "in-session" },
                sendTurn,
                interruptTurn: async (threadId) => active.get(threadId)?.cancel(),
                respondToRequest: async () => "unavailable", // this engine has no asks to answer
                hasSession: (threadId) => active.has(threadId),
                stopAll: async () => {
                    for (const { cancel } of active.values())
                        cancel();
                },
                onEvent: (listener) => {
                    listeners.add(listener);
                    return () => listeners.delete(listener);
                },
            },
            dispose: async () => {
                for (const { cancel } of active.values())
                    cancel();
                listeners.clear();
            },
        };
    },
};
