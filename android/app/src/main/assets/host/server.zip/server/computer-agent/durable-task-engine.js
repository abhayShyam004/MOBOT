// Durable Task Execution Engine (Phase 3: Long-Running Autonomous Tasks)
//
// Provides persistent task lifecycle management independent of a single
// model turn or chat session:
// - Explicit states: CREATED, PLANNING, RUNNING, WAITING, RECOVERING,
//   AWAITING_APPROVAL, COMPLETED, FAILED, CANCELLED, PAUSED
// - Durable disk persistence in .mobot/tasks/ and .mobot/durable_tasks.json
// - Background supervision, process monitoring, crash detection, timeouts
// - Interruption recovery, milestone preservation, clean cancellation
// - Empirical completion verification gate
import { existsSync, mkdirSync, readFileSync, readdirSync, statSync } from "node:fs";
import { join, isAbsolute, resolve } from "node:path";
import { writeFileAtomic } from "../atomic.js";
import { defaultProcessManager } from "./process-manager.js";
import { defaultArtifactManager } from "./artifact-manager.js";
import { sharedPersistentJobManager } from "../tasks.js";
import { evaluateTaskCompletion } from "../completion-contract.js";
const TASK_ID_REGEX = /^task_\d+_[a-z0-9]+$/i;
function defaultWorkspace() {
    if (process.env.AC_WORKSPACE)
        return process.env.AC_WORKSPACE;
    const androidWs = "/data/user/0/com.openmausbot.companion/files/host/workspace";
    if (existsSync(androidWs))
        return androidWs;
    return process.cwd();
}
export class DurableTaskEngine {
    tasks = new Map();
    persistedTaskState = new Map();
    baseWorkspace;
    processManager;
    supervisorInterval = null;
    notificationSink;
    constructor(workspacePath, processManager) {
        this.baseWorkspace = workspacePath || defaultWorkspace();
        this.processManager = processManager || defaultProcessManager;
        this.ensureDirs(this.baseWorkspace);
        this.loadAllTasksFromDisk(this.baseWorkspace);
    }
    setNotificationSink(sink) {
        this.notificationSink = sink;
    }
    resolveWorkspace(wsPath) {
        return wsPath || this.baseWorkspace;
    }
    ensureDirs(ws) {
        const tasksDir = join(ws, ".mobot", "tasks");
        mkdirSync(tasksDir, { recursive: true, mode: 0o700 });
    }
    getRegistryPath(ws) {
        return join(ws, ".mobot", "durable_tasks.json");
    }
    getTaskFilePath(taskId, ws) {
        if (!TASK_ID_REGEX.test(taskId))
            throw new Error("Invalid durable task ID.");
        return join(ws, ".mobot", "tasks", `${taskId}.json`);
    }
    saveTaskToDisk(task, ws) {
        const taskPath = this.getTaskFilePath(task.id, ws);
        try {
            this.ensureDirs(ws);
            writeFileAtomic(taskPath, JSON.stringify(task, null, 2), { mode: 0o600 });
            this.persistedTaskState.set(task.id, structuredClone(task));
        }
        catch (error) {
            const previous = this.persistedTaskState.get(task.id);
            if (previous) {
                for (const key of Object.keys(task))
                    delete task[key];
                Object.assign(task, structuredClone(previous));
            }
            else {
                this.tasks.delete(task.id);
            }
            throw new Error(`Failed to persist durable task ${task.id} in ${ws}: ${error instanceof Error ? error.message : String(error)}`, { cause: error });
        }
        // The per-task file is authoritative. The registry is a rebuildable index
        // and the loader scans task files, so an index failure cannot make a
        // successfully persisted task transition look like a failed task write.
        const registryPath = this.getRegistryPath(ws);
        const allTasks = Array.from(this.tasks.values()).filter((t) => t.workspacePath === ws);
        try {
            writeFileAtomic(registryPath, JSON.stringify(allTasks, null, 2), { mode: 0o600 });
        }
        catch (error) {
            console.error(`[DurableTaskEngine] Task ${task.id} was saved, but registry index refresh failed: ${error instanceof Error ? error.message : String(error)}`);
        }
        // Consolidated persistence into authoritative PersistentJobManager
        try {
            const existingJob = sharedPersistentJobManager.getJob(task.id);
            if (!existingJob) {
                sharedPersistentJobManager.createJob({
                    jobId: task.id,
                    botId: task.botId,
                    threadId: task.threadId,
                    title: (task.goal || task.id).slice(0, 50),
                    objective: task.goal || task.id,
                    initialData: { durableTask: task },
                });
            }
        }
        catch { }
    }
    loadAllTasksFromDisk(ws) {
        this.ensureDirs(ws);
        const tasksDir = join(ws, ".mobot", "tasks");
        try {
            if (existsSync(tasksDir)) {
                const files = readdirSync(tasksDir).filter((f) => f.endsWith(".json"));
                for (const f of files) {
                    try {
                        const raw = readFileSync(join(tasksDir, f), "utf8");
                        const task = JSON.parse(raw);
                        if (task && task.id && task.workspacePath === ws) {
                            this.tasks.set(task.id, task);
                            this.persistedTaskState.set(task.id, structuredClone(task));
                        }
                    }
                    catch (error) {
                        console.error(`[DurableTaskEngine] Could not load task file ${join(tasksDir, f)}: ${error instanceof Error ? error.message : String(error)}`);
                    }
                }
            }
        }
        catch (error) {
            console.error(`[DurableTaskEngine] Could not scan durable tasks in ${tasksDir}: ${error instanceof Error ? error.message : String(error)}`);
        }
    }
    /**
     * Create a new durable task.
     */
    createTask(params) {
        const ws = this.resolveWorkspace(params.workspacePath);
        const id = `task_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        const now = new Date().toISOString();
        const task = {
            id,
            botId: params.botId || "default_bot",
            threadId: params.threadId || "default_thread",
            goal: params.goal,
            status: "CREATED",
            createdAt: now,
            updatedAt: now,
            revision: 1,
            currentStepId: null,
            completedMilestones: [],
            pendingWork: params.initialMilestones || [],
            observations: [
                {
                    timestamp: now,
                    source: "engine",
                    summary: `Task created with goal: "${params.goal}"`,
                },
            ],
            failures: [],
            processIds: [],
            artifactIds: [],
            approvals: [],
            progressPercent: 0,
            progressMessage: "Task initialized, ready for planning.",
            workspacePath: ws,
        };
        this.tasks.set(id, task);
        this.saveTaskToDisk(task, ws);
        return task;
    }
    /**
     * Get task by ID.
     */
    getTask(taskId, wsPath) {
        if (!TASK_ID_REGEX.test(taskId))
            return null;
        const requestedWorkspace = wsPath ? this.resolveWorkspace(wsPath) : undefined;
        const task = this.tasks.get(taskId);
        if (task)
            return !requestedWorkspace || task.workspacePath === requestedWorkspace ? task : null;
        // Fallback load from the explicitly requested workspace or the engine's default workspace.
        const ws = requestedWorkspace || this.baseWorkspace;
        const taskPath = this.getTaskFilePath(taskId, ws);
        if (existsSync(taskPath)) {
            try {
                const loaded = JSON.parse(readFileSync(taskPath, "utf8"));
                if (loaded.id !== taskId || loaded.workspacePath !== ws)
                    return null;
                this.tasks.set(loaded.id, loaded);
                this.persistedTaskState.set(loaded.id, structuredClone(loaded));
                return loaded;
            }
            catch (error) {
                console.error(`[DurableTaskEngine] Could not load task ${taskId}: ${error instanceof Error ? error.message : String(error)}`);
            }
        }
        return null;
    }
    /**
     * Persists a monitoring target (URL, system, or process) with its cadence,
     * active status, and verified condition.
     */
    registerMonitoringTarget(taskId, target, wsPath) {
        const effectiveWs = wsPath ? this.resolveWorkspace(wsPath) : this.baseWorkspace;
        const task = this.getTask(taskId, effectiveWs);
        if (!task)
            throw new Error(`Task ${taskId} not found`);
        task.monitoringTarget = target;
        task.updatedAt = new Date().toISOString();
        this.saveTaskToDisk(task, effectiveWs);
        return task;
    }
    /**
     * Transition to PLANNING state.
     */
    startPlanning(taskId, planId) {
        const task = this.requireTask(taskId);
        task.status = "PLANNING";
        task.planId = planId || task.planId;
        task.updatedAt = new Date().toISOString();
        task.progressMessage = "Constructing structured execution plan.";
        this.saveTaskToDisk(task, task.workspacePath);
        return task;
    }
    /**
     * Transition to RUNNING state.
     */
    startRunning(taskId, stepId) {
        const task = this.requireTask(taskId);
        task.status = "RUNNING";
        if (!task.startedAt)
            task.startedAt = new Date().toISOString();
        if (stepId)
            task.currentStepId = stepId;
        task.updatedAt = new Date().toISOString();
        task.progressMessage = stepId ? `Executing step ${stepId}.` : "Task running in background.";
        task.waitState = undefined;
        this.saveTaskToDisk(task, task.workspacePath);
        return task;
    }
    /**
     * Transition to WAITING state (autonomous pause until timer or condition).
     */
    setWaiting(taskId, options) {
        const task = this.requireTask(taskId);
        task.status = "WAITING";
        const until = Date.now() + Math.max(1, options.durationSeconds) * 1000;
        task.waitState = {
            untilTimestamp: until,
            reason: options.reason,
            nextAction: options.nextAction,
        };
        task.updatedAt = new Date().toISOString();
        task.progressMessage = `Waiting ${options.durationSeconds}s (${options.reason}). Next: ${options.nextAction}`;
        task.observations.push({
            timestamp: task.updatedAt,
            source: "engine",
            summary: `Entered WAITING state: ${options.reason}`,
            details: { untilTimestamp: until, nextAction: options.nextAction },
        });
        this.saveTaskToDisk(task, task.workspacePath);
        return task;
    }
    /**
     * Transition to RECOVERING state upon failure.
     */
    setRecovering(taskId, failure) {
        const task = this.requireTask(taskId);
        task.status = "RECOVERING";
        task.updatedAt = new Date().toISOString();
        task.progressMessage = `Recovering from failure: ${failure.error}${failure.diagnosis ? ` (${failure.diagnosis})` : ""}`;
        task.failures.push({
            timestamp: task.updatedAt,
            stepId: failure.stepId || task.currentStepId || undefined,
            error: failure.error,
            diagnosis: failure.diagnosis,
            recovered: false,
            recoveryAction: failure.recoveryAction,
        });
        this.saveTaskToDisk(task, task.workspacePath);
        if (this.notificationSink) {
            this.notificationSink({
                kind: "turn-failed",
                botId: task.botId,
                threadId: task.threadId,
                title: "Task Recovery In Progress",
                body: `Task "${task.goal}" encountered an error and is recovering: ${failure.error}`,
            });
        }
        return task;
    }
    /**
     * Request human approval checkpoint. Transitions to AWAITING_APPROVAL.
     */
    requestApproval(taskId, params) {
        const task = this.requireTask(taskId);
        task.status = "AWAITING_APPROVAL";
        task.updatedAt = new Date().toISOString();
        const approvalId = `appr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
        const request = {
            id: approvalId,
            stepId: params.stepId || task.currentStepId || undefined,
            action: params.action,
            reason: params.reason,
            impact: params.impact,
            requestedAt: task.updatedAt,
            status: "pending",
        };
        task.approvals.push(request);
        task.progressMessage = `Paused for approval: ${params.action} (${params.reason})`;
        this.saveTaskToDisk(task, task.workspacePath);
        if (this.notificationSink) {
            this.notificationSink({
                kind: "approval",
                botId: task.botId,
                threadId: task.threadId,
                title: "Approval Required",
                body: `Task "${task.goal}" requires decision for: ${params.action}`,
            });
        }
        return request;
    }
    /**
     * Record human decision on approval request.
     */
    decideApproval(taskId, approvalId, approved, reason) {
        const task = this.requireTask(taskId);
        const approval = task.approvals.find((a) => a.id === approvalId);
        if (!approval) {
            throw new Error(`Approval request '${approvalId}' not found on task '${taskId}'.`);
        }
        const now = new Date().toISOString();
        approval.status = approved ? "approved" : "rejected";
        approval.decisionAt = now;
        approval.decisionReason = reason;
        task.updatedAt = now;
        if (approved) {
            task.status = "RUNNING";
            task.progressMessage = `Approval granted for ${approval.action}. Resuming execution.`;
            task.observations.push({
                timestamp: now,
                source: "user",
                summary: `User approved: ${approval.action}${reason ? ` (${reason})` : ""}`,
            });
        }
        else {
            task.status = "FAILED";
            task.progressMessage = `Approval rejected for ${approval.action}: ${reason || "User rejected action"}`;
            task.failures.push({
                timestamp: now,
                stepId: approval.stepId,
                error: reason || "Action rejected by user at approval checkpoint",
                recovered: false,
            });
        }
        this.saveTaskToDisk(task, task.workspacePath);
        return task;
    }
    /**
     * Update task progress, observations, and milestones.
     */
    updateProgress(taskId, update) {
        const task = this.requireTask(taskId);
        const now = new Date().toISOString();
        task.updatedAt = now;
        if (update.progressPercent !== undefined) {
            task.progressPercent = Math.min(100, Math.max(0, update.progressPercent));
        }
        if (update.progressMessage) {
            task.progressMessage = update.progressMessage;
        }
        if (update.currentStepId) {
            task.currentStepId = update.currentStepId;
        }
        if (update.addedProcessId && !task.processIds.includes(update.addedProcessId)) {
            task.processIds.push(update.addedProcessId);
        }
        if (update.addedArtifactId && !task.artifactIds.includes(update.addedArtifactId)) {
            task.artifactIds.push(update.addedArtifactId);
        }
        if (update.observation) {
            task.observations.push({
                timestamp: now,
                source: "agent",
                summary: update.observation,
            });
        }
        if (update.milestoneCompleted) {
            const ms = update.milestoneCompleted;
            const milestone = {
                id: ms.id,
                title: ms.title,
                description: ms.description,
                completedAt: now,
                evidence: ms.evidence,
            };
            task.completedMilestones.push(milestone);
            task.pendingWork = task.pendingWork.filter((item) => item !== ms.title && item !== ms.id);
        }
        this.saveTaskToDisk(task, task.workspacePath);
        return task;
    }
    /**
     * Finalize task to COMPLETED with empirical verification evidence.
     */
    completeTask(taskId, verificationItems, summary, deliveredArtifacts) {
        const task = this.requireTask(taskId);
        const now = new Date().toISOString();
        if (!verificationItems || verificationItems.length === 0) {
            return {
                ok: false,
                task,
                error: "Cannot complete task without explicit empirical verification criteria.",
            };
        }
        const unverified = verificationItems.filter((item) => !item.verified);
        if (unverified.length > 0) {
            return {
                ok: false,
                task,
                error: `Cannot complete task: ${unverified.length} verification criteria failed (${unverified.map((u) => u.description).join(", ")}).`,
            };
        }
        // Verify deliverable existence and non-emptiness before marking task complete
        const artifactsToCheck = deliveredArtifacts && deliveredArtifacts.length > 0
            ? deliveredArtifacts
            : task.artifactIds;
        if (artifactsToCheck && artifactsToCheck.length > 0) {
            for (const item of artifactsToCheck) {
                let exists = false;
                let isNonEmpty = false;
                const reg = defaultArtifactManager.getArtifact(item);
                if (reg) {
                    if (existsSync(reg.localPath)) {
                        exists = true;
                        try {
                            isNonEmpty = statSync(reg.localPath).size > 0;
                        }
                        catch { }
                    }
                }
                else {
                    const fullPath = isAbsolute(item) ? item : resolve(task.workspacePath, item);
                    if (existsSync(fullPath)) {
                        exists = true;
                        try {
                            isNonEmpty = statSync(fullPath).size > 0;
                        }
                        catch { }
                    }
                }
                if (!exists) {
                    return {
                        ok: false,
                        task,
                        error: `Cannot complete task: deliverable "${item}" does not exist on disk.`,
                    };
                }
                if (!isNonEmpty) {
                    return {
                        ok: false,
                        task,
                        error: `Cannot complete task: deliverable "${item}" is empty (0 bytes).`,
                    };
                }
            }
        }
        // Authoritative completion evaluation via completion-contract
        const resolvedArtifacts = artifactsToCheck?.map((item) => {
            const reg = defaultArtifactManager.getArtifact(item);
            if (reg)
                return reg.localPath;
            return isAbsolute(item) ? item : resolve(task.workspacePath, item);
        });
        const evaluation = evaluateTaskCompletion({
            taskId: task.id,
            title: task.goal,
            objective: task.goal,
            threadId: task.threadId,
            execution: {
                status: "SUCCEEDED",
                operationsCompleted: (task.completedMilestones || []).map((m) => m.title),
            },
            requirements: verificationItems.map((v, i) => ({
                id: `v-${i}`,
                requirement: v.description,
                status: v.verified ? "SATISFIED" : "VIOLATED",
                evidence: v.evidence,
            })),
            artifacts: resolvedArtifacts,
            summary,
        });
        if (evaluation.overallStatus !== "COMPLETED") {
            task.status = evaluation.overallStatus === "PARTIALLY_COMPLETED" ? "RECOVERING" : "FAILED";
            task.updatedAt = now;
            task.progressMessage = `Task did not satisfy full completion contract: ${evaluation.blockingErrors.join("; ")}`;
            this.saveTaskToDisk(task, task.workspacePath);
            return {
                ok: false,
                task,
                error: `Cannot complete task: ${evaluation.blockingErrors.join("; ")}`,
            };
        }
        task.status = "COMPLETED";
        task.completedAt = now;
        task.updatedAt = now;
        task.progressPercent = 100;
        task.progressMessage = `Task completed successfully: ${summary}`;
        task.finalVerification = {
            verified: true,
            timestamp: now,
            criteria: verificationItems,
            summary,
        };
        task.finalResult = {
            success: true,
            summary,
            deliveredArtifacts: deliveredArtifacts || task.artifactIds,
        };
        this.saveTaskToDisk(task, task.workspacePath);
        if (this.notificationSink) {
            this.notificationSink({
                kind: "done",
                botId: task.botId,
                threadId: task.threadId,
                title: "Task Complete",
                body: `Task "${task.goal}" has completed successfully. All verification criteria confirmed.`,
            });
        }
        return { ok: true, task };
    }
    /**
     * Mark task as FAILED.
     */
    failTask(taskId, error, diagnosis) {
        const task = this.requireTask(taskId);
        const now = new Date().toISOString();
        task.status = "FAILED";
        task.completedAt = now;
        task.updatedAt = now;
        task.progressMessage = `Task failed: ${error}`;
        task.failures.push({
            timestamp: now,
            error,
            diagnosis,
            recovered: false,
        });
        task.finalResult = {
            success: false,
            summary: `Task failed: ${error}${diagnosis ? ` (${diagnosis})` : ""}`,
            deliveredArtifacts: task.artifactIds,
        };
        this.saveTaskToDisk(task, task.workspacePath);
        if (this.notificationSink) {
            this.notificationSink({
                kind: "turn-failed",
                botId: task.botId,
                threadId: task.threadId,
                title: "Task Failed",
                body: `Task "${task.goal}" failed: ${error}`,
            });
        }
        return task;
    }
    /**
     * Explicitly cancel task. Stops associated managed processes.
     */
    async cancelTask(taskId, reason = "Cancelled by user") {
        const task = this.requireTask(taskId);
        const now = new Date().toISOString();
        task.status = "CANCELLED";
        task.completedAt = now;
        task.updatedAt = now;
        task.progressMessage = `Task cancelled: ${reason}`;
        task.finalResult = {
            success: false,
            summary: `Task was cancelled before completion: ${reason}. Preserved ${task.completedMilestones.length} milestones.`,
            deliveredArtifacts: task.artifactIds,
        };
        // Cleanly stop all associated background processes
        for (const procId of task.processIds) {
            try {
                await this.processManager.stopProcess(procId, true);
            }
            catch { }
        }
        this.saveTaskToDisk(task, task.workspacePath);
        return task;
    }
    /**
     * Pause task execution.
     */
    pauseTask(taskId) {
        const task = this.requireTask(taskId);
        task.status = "PAUSED";
        task.updatedAt = new Date().toISOString();
        task.progressMessage = "Task paused by user.";
        this.saveTaskToDisk(task, task.workspacePath);
        return task;
    }
    /**
     * Resume a paused or recovering task.
     */
    resumeTask(taskId) {
        const task = this.requireTask(taskId);
        task.status = "RUNNING";
        task.updatedAt = new Date().toISOString();
        task.progressMessage = "Task resumed from persistent state.";
        task.waitState = undefined;
        this.saveTaskToDisk(task, task.workspacePath);
        return task;
    }
    /**
     * Interruption recovery on server startup:
     * Inspects all active tasks and running processes, reconciles crashed states,
     * and prepares tasks for resumption without restarting completed work.
     */
    async reconcileTasksOnStartup(wsPath) {
        const ws = this.resolveWorkspace(wsPath);
        this.loadAllTasksFromDisk(ws);
        const activeTasks = [];
        let reconciledCount = 0;
        for (const task of this.tasks.values()) {
            if (wsPath && task.workspacePath !== ws)
                continue;
            if (task.status === "RUNNING" || task.status === "WAITING" || task.status === "RECOVERING") {
                reconciledCount++;
                // Check managed processes
                for (const procId of task.processIds) {
                    const inspected = await this.processManager.inspectProcess(procId);
                    if (inspected && (inspected.state === "CRASHED" || inspected.state === "STOPPED")) {
                        task.observations.push({
                            timestamp: new Date().toISOString(),
                            source: "reconciler",
                            summary: `Process ${procId} found in ${inspected.state} state during startup reconciliation.`,
                        });
                    }
                }
                task.observations.push({
                    timestamp: new Date().toISOString(),
                    source: "reconciler",
                    summary: `Task recovered from disk after host startup. Retaining ${task.completedMilestones.length} completed milestones.`,
                });
                task.updatedAt = new Date().toISOString();
                this.saveTaskToDisk(task, task.workspacePath);
                activeTasks.push(task);
            }
        }
        return { reconciledCount, activeTasks };
    }
    /**
     * Start the background supervisor tick.
     */
    startSupervisor(intervalMs = 2000) {
        if (this.supervisorInterval)
            return;
        this.supervisorInterval = setInterval(async () => {
            await this.supervisorTick();
        }, intervalMs);
        if (this.supervisorInterval.unref) {
            this.supervisorInterval.unref();
        }
    }
    /**
     * Stop background supervisor.
     */
    stopSupervisor() {
        if (this.supervisorInterval) {
            clearInterval(this.supervisorInterval);
            this.supervisorInterval = null;
        }
    }
    /**
     * Single supervisor tick examining active tasks.
     */
    async supervisorTick() {
        const now = Date.now();
        for (const task of this.tasks.values()) {
            if (task.status === "WAITING" && task.waitState) {
                if (now >= task.waitState.untilTimestamp) {
                    const action = task.waitState.nextAction;
                    task.status = "RUNNING";
                    task.waitState = undefined;
                    task.updatedAt = new Date().toISOString();
                    task.progressMessage = `Wait timer expired. Ready to execute: ${action}`;
                    task.observations.push({
                        timestamp: task.updatedAt,
                        source: "supervisor",
                        summary: `Wait timer expired. Resumed to RUNNING state for action: ${action}`,
                    });
                    this.saveTaskToDisk(task, task.workspacePath);
                }
            }
            else if (task.status === "RUNNING") {
                // Monitor running processes
                for (const procId of task.processIds) {
                    const proc = await this.processManager.inspectProcess(procId);
                    if (proc && proc.state === "CRASHED") {
                        const alreadyRecorded = task.failures.some((f) => f.error.includes(procId) && !f.recovered);
                        if (!alreadyRecorded) {
                            task.status = "RECOVERING";
                            task.updatedAt = new Date().toISOString();
                            task.progressMessage = `Background process ${procId} crashed. Entering RECOVERING state.`;
                            task.failures.push({
                                timestamp: task.updatedAt,
                                stepId: task.currentStepId || undefined,
                                error: `Process ${procId} exited unexpectedly (state: CRASHED).`,
                                diagnosis: proc.lastError || `Exit code ${proc.exitCode}`,
                                recovered: false,
                                recoveryAction: "Restart process or replan step",
                            });
                            this.saveTaskToDisk(task, task.workspacePath);
                        }
                    }
                }
            }
        }
    }
    /**
     * List all tasks in engine.
     */
    listTasks(wsPath) {
        if (!wsPath) {
            return Array.from(this.tasks.values());
        }
        const ws = this.resolveWorkspace(wsPath);
        return Array.from(this.tasks.values()).filter((t) => t.workspacePath === ws);
    }
    requireTask(taskId) {
        const task = this.getTask(taskId);
        if (!task) {
            throw new Error(`Durable task with id '${taskId}' not found.`);
        }
        return task;
    }
}
export const defaultTaskEngine = new DurableTaskEngine();
/**
 * Checks whether persistent monitoring has actually been established for a task.
 * Prevents claiming that notifications will arrive unless monitoring target,
 * schedule, active status, and condition have been durably persisted.
 */
export function hasEstablishedMonitoring(task) {
    return Boolean(task &&
        task.monitoringTarget &&
        task.monitoringTarget.target &&
        task.monitoringTarget.cadenceSeconds > 0 &&
        task.monitoringTarget.status === "active");
}
