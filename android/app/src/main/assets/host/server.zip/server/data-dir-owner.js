// One server, one DATA_DIR.
//
// The room-post journal is durable, but durability is not mutual exclusion: two
// harness processes pointed at the same directory would each read the journal,
// each decide an identity was unclaimed, and each commit a message. The store
// is SQLite, so the smallest reliable answer is SQLite's own cross-process
// write lock, held for the lifetime of the process:
//
//   BEGIN IMMEDIATE writes a RESERVED lock into server-owner.db. A second
//   process cannot begin the same transaction, and SQLite releases the lock
//   when the process dies — including SIGKILL — because the kernel closes the
//   file descriptors. There is no PID to trust, so there is no PID to be
//   reused, no stale file to reason about and no unlock race to lose.
//
// The transaction is deliberately never committed: the lock is the ownership.
// For the same reason the owner row is not a cross-process diagnostic — an
// uncommitted write is invisible to every other connection — so the refusal
// says only what it can prove: the directory is already owned.
import { chmodSync, closeSync, mkdirSync, openSync } from "node:fs";
import { join } from "node:path";
import { DatabaseSync } from "node:sqlite";
export class DataDirInUseError extends Error {
    code = "data_dir_in_use";
    dataDir;
    constructor(dataDir) {
        super(`OpenMausBot is already using this data directory (${dataDir}). Close the other instance first.`);
        this.name = "DataDirInUseError";
        this.dataDir = dataDir;
    }
}
/**
 * Claim exclusive ownership of a data directory, or throw DataDirInUseError.
 *
 * Call this before serving any mutation. It is synchronous on purpose: a
 * server that is about to accept requests must not have a startup window where
 * ownership is still undecided.
 */
export function acquireDataDirOwnership(dataDir, options = {}) {
    mkdirSync(dataDir, { recursive: true, mode: 0o700 });
    const file = join(dataDir, "server-owner.db");
    const now = options.now ?? (() => Date.now());
    // Ownership metadata is not message content, but the file sits in DATA_DIR
    // and must not be readable by other accounts. Create it owner-only before
    // SQLite opens it, so there is no permissive window between create and chmod.
    closeSync(openSync(file, "a", 0o600));
    const db = new DatabaseSync(file, { timeout: 0 });
    try {
        try {
            chmodSync(file, 0o600);
        }
        catch {
            /* best effort on platforms that ignore POSIX modes */
        }
        db.exec("CREATE TABLE IF NOT EXISTS owner (id INTEGER PRIMARY KEY CHECK (id = 1), pid INTEGER NOT NULL, acquired_at INTEGER NOT NULL)");
        db.exec("BEGIN IMMEDIATE");
        db.prepare("INSERT INTO owner (id, pid, acquired_at) VALUES (1, ?, ?) ON CONFLICT(id) DO UPDATE SET pid = excluded.pid, acquired_at = excluded.acquired_at").run(process.pid, now());
    }
    catch (error) {
        try {
            db.close();
        }
        catch {
            /* the lock was never taken */
        }
        if (/locked|busy/i.test(error instanceof Error ? error.message : String(error))) {
            throw new DataDirInUseError(dataDir);
        }
        throw error;
    }
    let released = false;
    return {
        release() {
            if (released)
                return;
            released = true;
            try {
                db.exec("ROLLBACK");
            }
            catch {
                /* the transaction may already be gone */
            }
            try {
                db.close();
            }
            catch {
                /* already closed */
            }
        },
    };
}
