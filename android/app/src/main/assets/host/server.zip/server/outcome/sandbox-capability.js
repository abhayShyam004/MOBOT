import { execFileSync, spawn } from "node:child_process";
import { existsSync, readlinkSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { UnsupportedSandboxEnvironmentError } from "../tasks.js";
let cachedReport = null;
let mockReport = null;
export function setMockSandboxCapability(mock) {
    mockReport = mock;
}
export function resetSandboxCapabilityCache() {
    cachedReport = null;
}
export function findCuratedPackagesPath() {
    const candidates = [
        process.env.MOBOT_SANDBOX_PACKAGES,
        "/usr/local/lib/python3.14/site-packages",
        "/usr/lib/python3.14/site-packages",
        join(process.env.HOME || "", ".local/lib/python3.14/site-packages"),
        "/opt/mobot/site-packages",
    ].filter(Boolean);
    for (const c of candidates) {
        if (existsSync(c) && (existsSync(join(c, "numpy")) || existsSync(join(c, "pypdf")))) {
            return c;
        }
    }
    return null;
}
export async function checkSandboxCapability(options = {}) {
    if (mockReport)
        return mockReport;
    if (cachedReport && !options.forceRecheck)
        return cachedReport;
    // 1. Host Operating System check
    if (process.platform !== "linux") {
        cachedReport = {
            supported: false,
            status: "UNSUPPORTED",
            reason: `Platform '${process.platform}' does not support Linux kernel namespaces (bwrap).`,
            details: { failureStage: "platform_check" },
        };
        return cachedReport;
    }
    // 2. Discover bwrap binary
    let bwrapPath = options.bwrapBin;
    if (!bwrapPath) {
        const candidates = ["/usr/bin/bwrap", "/usr/local/bin/bwrap", "/bin/bwrap"];
        for (const c of candidates) {
            if (existsSync(c)) {
                bwrapPath = c;
                break;
            }
        }
    }
    if (!bwrapPath || !existsSync(bwrapPath)) {
        cachedReport = {
            supported: false,
            status: "UNSUPPORTED",
            reason: "Bubblewrap (bwrap) executable was not found on host.",
            details: { failureStage: "bwrap_binary_discovery" },
        };
        return cachedReport;
    }
    // 3. Check bwrap version and options
    let bwrapVersion = "unknown";
    try {
        const versionOut = execFileSync(bwrapPath, ["--version"], { encoding: "utf8" }).trim();
        bwrapVersion = versionOut;
    }
    catch (err) {
        cachedReport = {
            supported: false,
            status: "UNSUPPORTED",
            reason: `Failed to execute bwrap --version: ${err.message}`,
            details: { bwrapPath, failureStage: "bwrap_version_check" },
        };
        return cachedReport;
    }
    // 4. Check cgroup v2 presence and controllers
    const cgroupMount = "/sys/fs/cgroup";
    const cgroupControllersFile = join(cgroupMount, "cgroup.controllers");
    const cgroupV2Available = existsSync(cgroupControllersFile);
    let cgroupControllers = [];
    if (cgroupV2Available) {
        try {
            cgroupControllers = readFileSync(cgroupControllersFile, "utf8").trim().split(/\s+/);
        }
        catch {
            cgroupControllers = [];
        }
    }
    // Check required controllers: memory, pids, cpu
    const requiredControllers = ["memory", "pids", "cpu"];
    const missingControllers = requiredControllers.filter((ctrl) => !cgroupControllers.includes(ctrl));
    if (!cgroupV2Available || missingControllers.length > 0) {
        cachedReport = {
            supported: false,
            status: "UNSUPPORTED",
            reason: `Host cgroup v2 controllers missing required controllers: [${missingControllers.join(", ")}]. Aggregate resource limits cannot be enforced.`,
            details: {
                bwrapPath,
                bwrapVersion,
                cgroupV2Available,
                cgroupControllers,
                failureStage: "cgroup_controllers_check",
            },
        };
        return cachedReport;
    }
    // 5. Check systemd-run user scope delegation
    let userSliceDelegated = false;
    try {
        execFileSync("systemd-run", ["--user", "--scope", "--quiet", "/usr/bin/true"], { stdio: "ignore" });
        userSliceDelegated = true;
    }
    catch {
        userSliceDelegated = false;
    }
    if (!userSliceDelegated) {
        cachedReport = {
            supported: false,
            status: "UNSUPPORTED",
            reason: "User cgroup delegation is unavailable. 'systemd-run --user --scope' failed. Refusing unconfined execution.",
            details: {
                bwrapPath,
                bwrapVersion,
                cgroupV2Available,
                cgroupControllers,
                userSliceDelegated: false,
                failureStage: "user_slice_delegation_check",
            },
        };
        return cachedReport;
    }
    // 6. Check fuse2fs availability for quota staging filesystem
    const fuse2fsCandidates = ["/usr/bin/fuse2fs", "/bin/fuse2fs", "/usr/sbin/fuse2fs"];
    const fuse2fsAvailable = fuse2fsCandidates.some((c) => existsSync(c));
    if (!fuse2fsAvailable) {
        cachedReport = {
            supported: false,
            status: "UNSUPPORTED",
            reason: "fuse2fs is missing. Bounded ext4 staging filesystem cannot be mounted.",
            details: {
                bwrapPath,
                bwrapVersion,
                fuse2fsAvailable: false,
                failureStage: "fuse2fs_discovery",
            },
        };
        return cachedReport;
    }
    if (options.skipCanary) {
        cachedReport = {
            supported: true,
            status: "AVAILABLE",
            details: {
                bwrapPath,
                bwrapVersion,
                cgroupV2Available,
                cgroupControllers,
                userSliceDelegated,
                fuse2fsAvailable,
            },
        };
        return cachedReport;
    }
    // 7. Execute comprehensive Canary Probe inside Bubblewrap
    const curatedPackages = findCuratedPackagesPath();
    const hostNamespaces = {};
    for (const ns of ["user", "net", "pid", "ipc", "uts"]) {
        try {
            hostNamespaces[ns] = readlinkSync(`/proc/self/ns/${ns}`);
        }
        catch {
            hostNamespaces[ns] = "error";
        }
    }
    try {
        const canaryResult = await runCanaryProbe({
            bwrapPath,
            curatedPackages: curatedPackages ?? undefined,
        });
        // Verify all 5 namespaces are separated from host
        for (const ns of ["user", "net", "pid", "ipc", "uts"]) {
            const guestVal = canaryResult.guest_ns?.[ns];
            const hostVal = hostNamespaces[ns];
            if (!guestVal || guestVal === hostVal) {
                cachedReport = {
                    supported: false,
                    status: "UNSUPPORTED",
                    reason: `Canary probe failed: '${ns}' namespace was not isolated (guest: ${guestVal}, host: ${hostVal}).`,
                    details: {
                        bwrapPath,
                        bwrapVersion,
                        hostNamespaces,
                        guestNamespaces: canaryResult.guest_ns,
                        failureStage: "namespace_isolation_verification",
                    },
                };
                return cachedReport;
            }
        }
        // Verify nested userns disallowance
        if (!canaryResult.nested_prevented) {
            cachedReport = {
                supported: false,
                status: "UNSUPPORTED",
                reason: "Nested user namespace creation was permitted inside sandbox. Disallowance failed.",
                details: { failureStage: "nested_userns_check" },
            };
            return cachedReport;
        }
        // Verify zero capabilities
        const caps = canaryResult.caps || {};
        const capInhZero = !caps.CapInh || caps.CapInh.replace(/^0+/, "") === "";
        const capPrmZero = !caps.CapPrm || caps.CapPrm.replace(/^0+/, "") === "";
        const capEffZero = !caps.CapEff || caps.CapEff.replace(/^0+/, "") === "";
        const noNewPrivsOne = caps.NoNewPrivs === "1";
        if (!capInhZero || !capPrmZero || !capEffZero || !noNewPrivsOne) {
            cachedReport = {
                supported: false,
                status: "UNSUPPORTED",
                reason: `Canary probe failed: process retained Linux capabilities (${JSON.stringify(caps)}) or NoNewPrivs!=1.`,
                details: { failureStage: "capabilities_check", rawError: JSON.stringify(caps) },
            };
            return cachedReport;
        }
        cachedReport = {
            supported: true,
            status: "AVAILABLE",
            details: {
                bwrapPath,
                bwrapVersion,
                cgroupV2Available,
                cgroupControllers,
                userSliceDelegated,
                fuse2fsAvailable,
                hostNamespaces,
                guestNamespaces: canaryResult.guest_ns,
                nestedUsernsPrevented: true,
                zeroCapabilitiesVerified: true,
                packagesVerified: canaryResult.packages,
            },
        };
        return cachedReport;
    }
    catch (err) {
        cachedReport = {
            supported: false,
            status: "UNSUPPORTED",
            reason: `Sandbox canary execution failed: ${err.message}`,
            details: {
                bwrapPath,
                bwrapVersion,
                failureStage: "canary_execution",
                rawError: err.stack || String(err),
            },
        };
        return cachedReport;
    }
}
async function runCanaryProbe(config) {
    const guestScript = `
import os, json, sys, ctypes

ns_names = ["user", "net", "pid", "ipc", "uts"]
guest_ns = {}
for name in ns_names:
    try:
        guest_ns[name] = os.readlink(f"/proc/self/ns/{name}")
    except Exception as e:
        guest_ns[name] = f"error:{e}"

libc = ctypes.CDLL(None)
CLONE_NEWUSER = 0x10000000
res = libc.unshare(CLONE_NEWUSER)
nested_prevented = (res == -1)

status = open("/proc/self/status").read()
caps = {}
for line in status.splitlines():
    parts = line.split(":", 1)
    if len(parts) == 2:
        k, v = parts[0].strip(), parts[1].strip()
        if k in ("CapInh", "CapPrm", "CapEff", "NoNewPrivs"):
            caps[k] = v

packages = {}
for pkg in ["pypdf", "numpy"]:
    try:
        __import__(pkg)
        packages[pkg] = True
    except Exception:
        packages[pkg] = False

print(json.dumps({
    "guest_ns": guest_ns,
    "nested_prevented": nested_prevented,
    "caps": caps,
    "packages": packages
}))
`;
    return new Promise((resolve, reject) => {
        const args = [
            "--unshare-user",
            "--unshare-net",
            "--unshare-pid",
            "--unshare-ipc",
            "--unshare-uts",
            "--disable-userns",
            "--assert-userns-disabled",
            "--cap-drop",
            "ALL",
            "--die-with-parent",
            "--ro-bind",
            "/usr",
            "/usr",
            "--symlink",
            "usr/lib64",
            "/lib64",
            "--symlink",
            "usr/lib",
            "/lib",
            "--symlink",
            "usr/bin",
            "/bin",
            "--proc",
            "/proc",
            "--dev",
            "/dev",
            "--size",
            "67108864",
            "--tmpfs",
            "/tmp",
        ];
        if (config.curatedPackages && existsSync(config.curatedPackages)) {
            args.push("--ro-bind", config.curatedPackages, "/opt/packages", "--setenv", "PYTHONPATH", "/opt/packages");
        }
        args.push("/usr/bin/python3", "-c", guestScript);
        const child = spawn(config.bwrapPath, args, {
            stdio: ["ignore", "pipe", "pipe"],
        });
        let stdout = "";
        let stderr = "";
        child.stdout.on("data", (chunk) => {
            stdout += chunk.toString("utf8");
        });
        child.stderr.on("data", (chunk) => {
            stderr += chunk.toString("utf8");
        });
        const timer = setTimeout(() => {
            try {
                child.kill("SIGKILL");
            }
            catch { }
            reject(new Error("Sandbox canary probe timed out after 5000ms"));
        }, 5000);
        child.on("close", (code) => {
            clearTimeout(timer);
            if (code !== 0) {
                return reject(new Error(`Canary bwrap exited with code ${code}. Stderr: ${stderr.trim()}`));
            }
            try {
                const parsed = JSON.parse(stdout.trim());
                resolve(parsed);
            }
            catch (err) {
                reject(new Error(`Failed to parse canary JSON: ${err.message}. Raw: ${stdout}`));
            }
        });
        child.on("error", (err) => {
            clearTimeout(timer);
            reject(err);
        });
    });
}
export async function assertSandboxSupported() {
    const report = await checkSandboxCapability();
    if (!report.supported || report.status !== "AVAILABLE") {
        throw new UnsupportedSandboxEnvironmentError(`ERR_UNSUPPORTED_SANDBOX_ENVIRONMENT: Kernel-level execution sandbox is unavailable on this host (${report.reason || "unknown reason"}). Refusing to execute untrusted code on host.`, report.reason);
    }
    return report;
}
