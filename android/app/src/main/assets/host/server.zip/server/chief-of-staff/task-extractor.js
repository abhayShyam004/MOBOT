import { createHash } from "node:crypto";
export function isSameDayInTimezone(dateA, dateB, timeZone) {
    try {
        const fmt = new Intl.DateTimeFormat("en-CA", {
            timeZone,
            year: "numeric",
            month: "2-digit",
            day: "2-digit",
        });
        return fmt.format(dateA) === fmt.format(dateB);
    }
    catch {
        return dateA.toISOString().slice(0, 10) === dateB.toISOString().slice(0, 10);
    }
}
export class TaskExtractor {
    clock;
    constructor(opts) {
        this.clock = opts?.clock ?? (() => new Date());
    }
    extractTasks(items, existingTasks = {}) {
        const tasks = [];
        const now = this.clock();
        const nowMs = now.getTime();
        for (const item of items) {
            if (item.source === "googlecalendar") {
                const metadata = item.metadata ?? {};
                const responseStatus = String(metadata.responseStatus || "accepted");
                const eventStatus = String(metadata.status || metadata.eventStatus || "confirmed").toLowerCase();
                const eventId = String(metadata.eventId || item.id);
                const start = String(metadata.start || "");
                const end = String(metadata.end || "");
                const organizer = String(metadata.organizer || "the organizer");
                const timeZone = String(metadata.timeZone || "Asia/Kolkata");
                // Temporal classification
                let temporalStatus = "unknown";
                let temporalNote = "No scheduled time provided";
                let startMs = 0;
                let endMs = 0;
                if (start) {
                    startMs = new Date(start).getTime();
                    endMs = end ? new Date(end).getTime() : startMs + 3600_000;
                    if (Number.isNaN(startMs)) {
                        temporalStatus = "unknown";
                        temporalNote = "Unparseable start time";
                    }
                    else if (eventStatus === "cancelled") {
                        temporalStatus = "expired";
                        temporalNote = "Event was cancelled by organizer";
                    }
                    else if (nowMs >= startMs && nowMs <= endMs) {
                        temporalStatus = "happening_now";
                        temporalNote = `Currently in progress (scheduled until ${end || "completion"})`;
                    }
                    else if (nowMs < startMs) {
                        temporalStatus = "upcoming";
                        const hoursUntil = (startMs - nowMs) / (3600 * 1000);
                        if (hoursUntil <= 24) {
                            temporalNote = `Upcoming soon (${Math.max(1, Math.round(hoursUntil))}h remaining)`;
                        }
                        else {
                            const daysUntil = Math.round(hoursUntil / 24);
                            temporalNote = `Upcoming in ${daysUntil} day${daysUntil === 1 ? "" : "s"}`;
                        }
                    }
                    else {
                        // nowMs > endMs: Meeting is in the past
                        const hoursSinceStart = (nowMs - startMs) / (3600 * 1000);
                        const daysSinceStart = Math.floor(hoursSinceStart / 24);
                        const hoursSinceEnd = (nowMs - endMs) / (3600 * 1000);
                        if (responseStatus === "needsAction") {
                            if (hoursSinceEnd <= 48) {
                                temporalStatus = "past_actionable";
                                temporalNote = `Past meeting ended ${Math.round(hoursSinceEnd)}h ago; RSVP was not submitted`;
                            }
                            else {
                                temporalStatus = "expired";
                                temporalNote = `Past appointment elapsed ${daysSinceStart > 0 ? `${daysSinceStart} days ago` : `${Math.round(hoursSinceStart)}h ago`}; scheduled time has passed`;
                            }
                        }
                        else {
                            temporalStatus = "expired";
                            temporalNote = `Concluded on ${end || start}`;
                        }
                    }
                }
                // 1. Check for Pending RSVP (needsAction)
                if (responseStatus === "needsAction") {
                    const dedupKey = `gcal_rsvp::${eventId}`;
                    const existing = Object.values(existingTasks).find((t) => t.dedupKey === dedupKey);
                    let priority = "normal";
                    let taskTitle = `RSVP Required: ${item.title}`;
                    let taskDesc = `You have an unconfirmed invitation from ${organizer} scheduled for ${start || "upcoming"}.`;
                    let actionTitle = `Draft RSVP response to ${organizer}`;
                    let actionDesc = `Prepare an email draft to ${organizer} regarding attendance for "${item.title}".`;
                    let actionBody = `Hi,\n\nI am writing to confirm my attendance for "${item.title}" scheduled at ${start}.\n\nBest regards,\nAbhay`;
                    if (temporalStatus === "happening_now") {
                        priority = "urgent";
                        taskTitle = `RSVP Required (Happening Now): ${item.title}`;
                        taskDesc = `Meeting with ${organizer} is currently in progress (${start} to ${end}). Your attendance is unconfirmed.`;
                    }
                    else if (temporalStatus === "upcoming") {
                        const hoursUntil = (startMs - nowMs) / (3600 * 1000);
                        priority = hoursUntil <= 24 ? "urgent" : "high";
                        taskTitle = `RSVP Required: ${item.title}`;
                        taskDesc = `Upcoming invitation from ${organizer} scheduled for ${start}.`;
                    }
                    else if (temporalStatus === "past_actionable") {
                        priority = "normal";
                        taskTitle = `Overdue RSVP: ${item.title}`;
                        taskDesc = `You had an unconfirmed invitation from ${organizer} for a meeting scheduled at ${start} (${temporalNote}).`;
                        actionTitle = `Draft follow-up / apology to ${organizer}`;
                        actionDesc = `Send a follow-up email to ${organizer} regarding missed invitation for "${item.title}".`;
                        actionBody = `Hi,\n\nI apologize for missing the invitation for "${item.title}" scheduled for ${start}.\n\nBest regards,\nAbhay`;
                    }
                    else if (temporalStatus === "expired") {
                        priority = "low";
                        taskTitle = `Expired Invitation: ${item.title}`;
                        taskDesc = `Past meeting scheduled for ${start} (${temporalNote}). The scheduled appointment time has passed.`;
                        actionTitle = `Acknowledge missed meeting to ${organizer}`;
                        actionDesc = `Send a post-meeting acknowledgement note to ${organizer} for "${item.title}".`;
                        actionBody = `Hi,\n\nI am following up regarding the past meeting "${item.title}" scheduled for ${start}.\n\nBest regards,\nAbhay`;
                    }
                    const action = {
                        id: `act_${createHash("sha256").update(dedupKey).digest("hex").slice(0, 12)}`,
                        type: "create_email_draft",
                        title: actionTitle,
                        description: actionDesc,
                        payload: {
                            recipient_email: organizer,
                            subject: `Re: ${item.title} - Confirmation`,
                            body: actionBody,
                            eventId,
                        },
                        requiresApproval: true,
                        status: existing?.action?.status ?? "proposed",
                    };
                    const task = {
                        id: existing?.id ?? `task_${createHash("sha256").update(dedupKey).digest("hex").slice(0, 12)}`,
                        title: taskTitle,
                        description: taskDesc,
                        source: "googlecalendar",
                        sourceRef: eventId,
                        dueDate: start || undefined,
                        priority,
                        status: existing?.status ?? "pending",
                        confidence: 1.0,
                        action,
                        dedupKey,
                        createdAt: existing?.createdAt ?? now.toISOString(),
                        updatedAt: now.toISOString(),
                        temporalStatus,
                        temporalNote,
                    };
                    tasks.push(task);
                    continue;
                }
                // 2. Confirmed schedule item
                const isToday = start ? isSameDayInTimezone(now, new Date(start), timeZone) : false;
                const dedupKey = `gcal_schedule::${eventId}`;
                const existing = Object.values(existingTasks).find((t) => t.dedupKey === dedupKey);
                let priority = "normal";
                let taskTitle = item.title;
                if (temporalStatus === "happening_now") {
                    priority = "urgent";
                    taskTitle = `[Happening Now] ${item.title}`;
                }
                else if (temporalStatus === "upcoming") {
                    priority = isToday ? "high" : "normal";
                }
                else if (temporalStatus === "expired") {
                    priority = "low";
                    taskTitle = `[Past] ${item.title}`;
                }
                const location = metadata.location ? ` Location: ${metadata.location}` : "";
                const task = {
                    id: existing?.id ?? `task_${createHash("sha256").update(dedupKey).digest("hex").slice(0, 12)}`,
                    title: taskTitle,
                    description: `Scheduled meeting: ${start} to ${end}.${location} (${temporalNote})`,
                    source: "googlecalendar",
                    sourceRef: eventId,
                    dueDate: start || undefined,
                    priority,
                    status: existing?.status ?? "pending",
                    confidence: 1.0,
                    dedupKey,
                    createdAt: existing?.createdAt ?? now.toISOString(),
                    updatedAt: now.toISOString(),
                    temporalStatus,
                    temporalNote,
                };
                tasks.push(task);
            }
            else if (item.source === "gmail") {
                // Email action items
                const threadId = String(item.metadata?.threadId || item.id);
                const dedupKey = `gmail_thread::${threadId}`;
                const existing = Object.values(existingTasks).find((t) => t.dedupKey === dedupKey);
                const rawSender = String(item.metadata?.sender || "");
                const emailMatch = rawSender.match(/<([^>]+)>/);
                const recipientEmail = emailMatch ? emailMatch[1] : (rawSender.includes("@") ? rawSender : "");
                const task = {
                    id: existing?.id ?? `task_${createHash("sha256").update(dedupKey).digest("hex").slice(0, 12)}`,
                    title: `Follow up on email: ${item.title}`,
                    description: item.content ? item.content.slice(0, 200) : "Review and respond to email thread.",
                    source: "gmail",
                    sourceRef: threadId,
                    priority: "normal",
                    status: existing?.status ?? "pending",
                    confidence: 0.9,
                    action: {
                        id: `act_${createHash("sha256").update(dedupKey).digest("hex").slice(0, 12)}`,
                        type: "create_email_draft",
                        title: `Draft reply for "${item.title}"`,
                        description: `Prepare reply draft in thread ${threadId}.`,
                        payload: {
                            thread_id: threadId,
                            recipient_email: recipientEmail || undefined,
                            subject: `Re: ${item.title}`,
                            body: "Thank you for the update. I will review and follow up shortly.",
                        },
                        requiresApproval: true,
                        status: existing?.action?.status ?? "proposed",
                    },
                    dedupKey,
                    createdAt: existing?.createdAt ?? now.toISOString(),
                    updatedAt: now.toISOString(),
                    temporalStatus: "unknown",
                    temporalNote: "Email thread follow-up",
                };
                tasks.push(task);
            }
        }
        return tasks;
    }
}
