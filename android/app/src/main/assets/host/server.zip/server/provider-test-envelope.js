// A preview-build-only envelope for proving provider deadlines on a device.
//
// The shipped provider endpoint cannot be redirected, and that is correct: an
// app that lets its configuration point model traffic somewhere else is an app
// that can send a signed-in account's token somewhere else. But the deadline
// work can only be accepted if a *stalled* provider is observed through the
// real chat path, and a real provider cannot be stalled on demand.
//
// So the envelope is deliberately narrow:
//
// - It is supplied by the Android app, and the app reads it from an adb-only
//   global setting in a preview build (same pattern as `omb_crash_point`).
//   The agent's own shell shares the app UID but cannot write global settings,
//   so a bot cannot redirect its provider by writing a file.
// - The endpoint must be loopback or private (RFC 1918 / ULA / link-local).
//   A public host is refused, so this can never become "send the token to
//   somebody's server".
// - Budgets can only be shortened. A value above the production default is
//   clamped, so no build can be made to wait longer than the shipped one.
//
// Absent the variable (every production build), this module returns nothing and
// the runtime behaves exactly as shipped.
import { DEFAULT_PROVIDER_TIMEOUTS, } from "./provider-deadline.js";
import { DEFAULT_PROVIDER_RETRY_BUDGET_MS } from "./provider-retry-budget.js";
export const PROVIDER_TEST_ENVELOPE_ENV = "OMB_PROVIDER_TEST_ENVELOPE";
/** Short enough to observe on a device, long enough that a real request is
 *  not cut off by scheduling jitter. */
export const MIN_ENVELOPE_TIMEOUT_MS = 250;
const PRIVATE_V4 = [
    [/^10\./, "10/8"],
    [/^192\.168\./, "192.168/16"],
    [/^172\.(1[6-9]|2\d|3[01])\./, "172.16/12"],
    [/^169\.254\./, "169.254/16"],
    [/^127\./, "loopback"],
];
/** A dotted quad, so `192.168.1.1.example.com` is a name and not an address:
 *  a prefix match alone would accept it. */
function isIpv4Literal(host) {
    const parts = host.split(".");
    return parts.length === 4 && parts.every((part) => /^\d{1,3}$/.test(part) && Number(part) <= 255);
}
/** Whether a host is somewhere on this machine or this LAN. `localhost` is
 *  accepted because a device-side relay (`adb reverse`) presents it that way. */
export function isPrivateEndpointHost(hostname) {
    const host = hostname.trim().toLowerCase().replace(/^\[|\]$/g, "");
    if (host === "localhost" || host === "::1")
        return true;
    if (isIpv4Literal(host) && PRIVATE_V4.some(([pattern]) => pattern.test(host)))
        return true;
    if (!host.includes(":"))
        return false;
    // IPv6 unique-local (fc00::/7) and link-local (fe80::/10).
    if (/^f[cd][0-9a-f]{2}:/.test(host))
        return true;
    if (/^fe[89ab][0-9a-f]:/.test(host))
        return true;
    return false;
}
function clampBudget(value, ceiling) {
    if (typeof value !== "number" || !Number.isFinite(value))
        return undefined;
    return Math.max(MIN_ENVELOPE_TIMEOUT_MS, Math.min(ceiling, Math.round(value)));
}
/**
 * Read the envelope from the environment. Never throws: a malformed value is
 * reported and ignored, because a broken test aid must not break the app.
 */
export function resolveProviderTestEnvelope(environment = process.env, log = (line) => console.log(line)) {
    const raw = environment[PROVIDER_TEST_ENVELOPE_ENV]?.trim();
    if (!raw)
        return {};
    let parsed;
    try {
        parsed = JSON.parse(raw);
    }
    catch {
        log("provider-test: envelope is not valid JSON — ignored");
        return {};
    }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
        log("provider-test: envelope is not an object — ignored");
        return {};
    }
    const record = parsed;
    let responsesUrl;
    if (record.responsesUrl !== undefined) {
        if (typeof record.responsesUrl !== "string") {
            log("provider-test: responsesUrl is not a string — ignored");
        }
        else {
            try {
                const url = new URL(record.responsesUrl);
                if (url.protocol !== "http:" && url.protocol !== "https:") {
                    log(`provider-test: responsesUrl scheme '${url.protocol}' refused`);
                }
                else if (!isPrivateEndpointHost(url.hostname)) {
                    log(`provider-test: responsesUrl host '${url.hostname}' is not loopback or private — refused`);
                }
                else {
                    responsesUrl = url.toString();
                }
            }
            catch {
                log("provider-test: responsesUrl is not a URL — ignored");
            }
        }
    }
    const budgetSource = record.timeouts && typeof record.timeouts === "object" && !Array.isArray(record.timeouts)
        ? record.timeouts
        : {};
    const timeoutPolicy = {
        ...(clampBudget(budgetSource.connectTimeoutMs, DEFAULT_PROVIDER_TIMEOUTS.connectTimeoutMs) !== undefined
            ? { connectTimeoutMs: clampBudget(budgetSource.connectTimeoutMs, DEFAULT_PROVIDER_TIMEOUTS.connectTimeoutMs) }
            : {}),
        ...(clampBudget(budgetSource.firstTokenTimeoutMs, DEFAULT_PROVIDER_TIMEOUTS.firstTokenTimeoutMs) !== undefined
            ? { firstTokenTimeoutMs: clampBudget(budgetSource.firstTokenTimeoutMs, DEFAULT_PROVIDER_TIMEOUTS.firstTokenTimeoutMs) }
            : {}),
        ...(clampBudget(budgetSource.idleTimeoutMs, DEFAULT_PROVIDER_TIMEOUTS.idleTimeoutMs) !== undefined
            ? { idleTimeoutMs: clampBudget(budgetSource.idleTimeoutMs, DEFAULT_PROVIDER_TIMEOUTS.idleTimeoutMs) }
            : {}),
        ...(clampBudget(budgetSource.callTimeoutMs, DEFAULT_PROVIDER_TIMEOUTS.callTimeoutMs) !== undefined
            ? { callTimeoutMs: clampBudget(budgetSource.callTimeoutMs, DEFAULT_PROVIDER_TIMEOUTS.callTimeoutMs) }
            : {}),
    };
    // Same rule as the phases: a test may make the sequence shorter than the
    // shipped one, never longer.
    const retryBudgetMs = clampBudget(record.retryBudgetMs, DEFAULT_PROVIDER_RETRY_BUDGET_MS);
    if (!responsesUrl && Object.keys(timeoutPolicy).length === 0 && retryBudgetMs === undefined) {
        log("provider-test: envelope carried nothing usable — ignored");
        return {};
    }
    const host = responsesUrl ? new URL(responsesUrl).host : "(shipped endpoint)";
    const budgets = ["connectTimeoutMs", "firstTokenTimeoutMs", "idleTimeoutMs", "callTimeoutMs"]
        .map((key) => `${key.replace("TimeoutMs", "")}=${timeoutPolicy[key] ?? DEFAULT_PROVIDER_TIMEOUTS[key]}ms`)
        .join(" ");
    const summary = `provider-test: endpoint host=${host} ${budgets} retryBudget=${retryBudgetMs ?? DEFAULT_PROVIDER_RETRY_BUDGET_MS}ms`;
    log(summary);
    return {
        ...(responsesUrl ? { responsesUrl } : {}),
        ...(Object.keys(timeoutPolicy).length ? { timeoutPolicy } : {}),
        ...(retryBudgetMs !== undefined ? { retryBudgetMs } : {}),
        summary,
    };
}
