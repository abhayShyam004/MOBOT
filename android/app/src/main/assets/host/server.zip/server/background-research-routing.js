// Screen-off bounded background research routing.
//
// This decision must read the person's own words and nothing else. It used to
// read `effectiveObjective`, which by that point carries the whole provider
// prompt — including the boilerplate injected for an attached document
// ("…skills, roles, experience, background…", "Inspect and extract…",
// "remote/in-person"). On a phone, attaching a PDF whose context included those
// words turned an ordinary "make a notebook answering this PDF" request into a
// canned research job for a repository named `remote/in-person`, and the user
// never saw the model at all.
/** Anything shaped like `owner/name`, which is what the person would type. */
const REPO_TOKEN = /\b([a-zA-Z0-9_.-]+\/[a-zA-Z0-9_.-]+)\b/;
const URL_TOKEN = /\b(https?:\/\/[^\s]+)\b/;
/**
 * The person's own message, with attachment transport tags removed: what they
 * typed, never the prompt the provider receives. `originalQuestion` in
 * server/index.ts is built the same way for the browser fallback.
 */
export function personWords(message) {
    let words = message ?? "";
    // An attached document's extracted text and the rules around it are appended
    // after the person's words (see buildTurnFileContext). Cutting there keeps
    // this honest even when the caller hands over the composed prompt.
    const injected = words.search(/\[attached document |\[PREVIOUSLY ATTACHED DOCUMENT |---BEGIN DOCUMENT/);
    if (injected >= 0)
        words = words.slice(0, injected);
    return words
        .replace(/<attached-(?:image|file)[^>]*\/>/g, " ")
        .replace(/\s+/g, " ")
        .trim();
}
/**
 * The research job a message asks for, or null when it asks for something else.
 * A message that only *mentions* a document is not a research request.
 */
export function backgroundResearchTarget(words) {
    if (!words)
        return null;
    const lower = words.toLowerCase();
    const asksForBackground = /\b(?:background|screen-off|screen\s+off|unattended|while\s+(?:the\s+)?screen\s+is\s+off)\b/i.test(words);
    const asksForResearch = /\b(?:research|investigate|analyze|audit|inspect|check|explore|eval(?:uate)?)\b/i.test(words);
    const repoMatch = words.match(REPO_TOKEN);
    const liveUrl = words.match(URL_TOKEN)?.[1];
    const eligible = asksForBackground &&
        (asksForResearch || Boolean(repoMatch)) &&
        (Boolean(repoMatch) || lower.includes("repo") || lower.includes("github") || lower.includes("mobot-website"));
    if (!eligible)
        return null;
    if (repoMatch)
        return { targetRepo: repoMatch[1], liveUrl };
    // No explicit owner/name: only a word the person actually used may pick one.
    let targetRepo;
    if (lower.includes("mobot-website"))
        targetRepo = "abhayShyam004/mobot-website";
    else if (lower.includes("express"))
        targetRepo = "expressjs/express";
    else if (lower.includes("react"))
        targetRepo = "facebook/react";
    else if (lower.includes("vite"))
        targetRepo = "vitejs/vite";
    return { targetRepo: targetRepo ?? "abhayShyam004/mobot-website", liveUrl };
}
