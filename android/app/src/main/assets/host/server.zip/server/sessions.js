// Pairing codes, sessions and stream tickets for clients that are not on
// this machine. The shape the iOS companion already proved (short-lived
// pairing → durable per-device credential, hashed at rest), generalized.
//
// A pairing code is 12 characters from a 32-symbol alphabet with no 0/O/1/I
// (60 bits), single use, five minutes. Exchanging it yields an opaque
// session token (`omb_sess_…`, 256 bits) that lives 30 days, renewed on use
// up to 180 days from pairing (`renew`); only its sha256 is stored. A stream ticket is a 5-minute single-use credential for the SSE
// endpoint, because EventSource cannot set headers. Failed exchanges are
// counted per source: five in a minute lock that source out for ten.
import { createHash, randomBytes, randomUUID, timingSafeEqual } from "node:crypto";
import { closeSync, existsSync, fsyncSync, mkdirSync, openSync, readFileSync, unlinkSync } from "node:fs";
import { dirname } from "node:path";
import { z } from "zod";
import { writeFileAtomic } from "./atomic.js";
export const SCOPES = ["admin", "client"];
export const PAIRING_CODE_ALPHABET = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ";
export const PAIRING_CODE_LENGTH = 12;
export const PAIRING_CODE_TTL_MS = 5 * 60_000;
/** A whole number of days from an environment variable, as milliseconds.
 * Anything that is not a whole number of days between 1 and 3650 falls back
 * to the default rather than being clamped, so a typo is not silently
 * turned into a policy. */
export function daysMs(value, fallbackDays) {
    const days = Number(value);
    const ok = Number.isInteger(days) && days >= 1 && days <= 3650;
    return (ok ? days : fallbackDays) * 24 * 60 * 60_000;
}
/** How long a session lives after its last renewal. A session used with half
 * the term or less left is renewed for the full term again (see `renew`), so
 * a device in regular use keeps working; one that goes quiet lapses.
 * OMB_SESSION_TTL_DAYS overrides the 30-day default. */
export const SESSION_TTL_MS = daysMs(process.env.OMB_SESSION_TTL_DAYS, 30);
/** The most a session may live from the day it was paired, however often it
 * is used. Renewal never pushes a session past this, so a stolen cookie has a
 * bounded life and every device re-pairs occasionally. OMB_SESSION_MAX_DAYS
 * overrides the 180-day default. */
export const SESSION_MAX_AGE_MS = daysMs(process.env.OMB_SESSION_MAX_DAYS, 180);
/** Renewal is due once half the term or less is left. */
export const SESSION_RENEW_WHEN_LEFT_MS = SESSION_TTL_MS / 2;
/** Max-Age for a cookie that should die with its session: whole seconds, at least one. */
export function cookieMaxAgeSeconds(session, now = Date.now()) {
    return Math.max(1, Math.floor((session.expiresAt - now) / 1000));
}
export const STREAM_TICKET_TTL_MS = 5 * 60_000;
/** Per-source slow-down only. A 60-bit code cannot be guessed online in
 * five minutes whatever the rate, so the lock exists to make noise visible,
 * not to protect the secret; it is kept short because sources are shared
 * (an office NAT, a proxy) and a long lock would let one bad neighbour keep
 * everyone else from pairing. */
export const LOCKOUT = { failures: 10, windowMs: 60_000, lockMs: 60_000 };
/** A consumed code presented again with the SAME attempt id within this
 * window gets the same answer, so a lost response does not strand the
 * device. The attempt id is a random value the client made up for that one
 * attempt: without it there is no replay, and sharing an address with the
 * device is not enough to obtain its token. */
export const EXCHANGE_REPLAY_MS = 60_000;
/** Outstanding stream tickets per session; issuing more retires the oldest. */
export const MAX_STREAM_TICKETS_PER_SESSION = 5;
const LAST_SEEN_WRITE_INTERVAL_MS = 60_000;
const scopeSchema = z.enum(["admin", "client"]);
const sessionSchema = z.object({
    id: z.string().min(1),
    tokenHash: z.string().length(64),
    label: z.string().max(80),
    scopes: z.array(scopeSchema).min(1),
    createdAt: z.number(),
    lastSeenAt: z.number(),
    expiresAt: z.number(),
    /** Set when the session came from an account sign-in rather than a code. */
    userId: z.string().max(256).optional(),
    email: z.string().max(320).optional(),
    /** Set only by the internal verified-portal issuance path, never by email or pairing input. */
    membershipAuthority: z.literal("portal").optional(),
});
const fileSchema = z.object({ version: z.literal(1), sessions: z.array(sessionSchema) });
const sha256 = (value) => createHash("sha256").update(value).digest("hex");
function sameDigest(a, b) {
    const left = Buffer.from(a, "hex");
    const right = Buffer.from(b, "hex");
    return left.length === right.length && timingSafeEqual(left, right);
}
/** 12 symbols, rejection-sampled so every symbol is equally likely. */
export function generatePairingCode() {
    const limit = Math.floor(256 / PAIRING_CODE_ALPHABET.length) * PAIRING_CODE_ALPHABET.length;
    let code = "";
    while (code.length < PAIRING_CODE_LENGTH) {
        for (const byte of randomBytes(PAIRING_CODE_LENGTH)) {
            if (byte >= limit)
                continue;
            code += PAIRING_CODE_ALPHABET[byte % PAIRING_CODE_ALPHABET.length];
            if (code.length === PAIRING_CODE_LENGTH)
                break;
        }
    }
    return code;
}
/** The prefix that tells the two encodings apart on the wire. A credential is
 * matched byte for byte; only a typed code is normalized. */
export const PAIRING_CREDENTIAL_PREFIX = "omb_pair_";
/** The same pairing window as a 256-bit secret, for a QR a native app scans
 * rather than a code a person reads out. 9 + 43 characters: the Android
 * companion checks that length exactly (android/core Connection.kt). */
export function generatePairingCredential() {
    return `${PAIRING_CREDENTIAL_PREFIX}${randomBytes(32).toString("base64url")}`;
}
export function isPairingCredential(value) {
    return value.startsWith(PAIRING_CREDENTIAL_PREFIX);
}
/** Accept what a human typed: dashes, spaces, lowercase, lookalikes. */
export function normalizePairingCode(input) {
    return input
        .toUpperCase()
        .replace(/[^A-Z0-9]/g, "")
        .replace(/0/g, "O")
        .replace(/1/g, "I");
}
/** XXXX-XXXX-XXXX, easier to read out loud. */
export function formatPairingCode(code) {
    return code.match(/.{1,4}/g)?.join("-") ?? code;
}
function publicSession(record) {
    const view = {
        id: record.id,
        label: record.label,
        scopes: [...record.scopes],
        createdAt: record.createdAt,
        lastSeenAt: record.lastSeenAt,
        expiresAt: record.expiresAt,
    };
    if (record.email)
        view.email = record.email;
    return view;
}
export class SessionRegistry {
    sessions = [];
    pairings = [];
    tickets = new Map();
    failures = new Map();
    replays = [];
    onRevoked = new Set();
    lastSeenWrites = new Map();
    now;
    options;
    openMarker;
    closed = false;
    // No parameter properties: the server runs this file under Node's
    // strip-only TypeScript mode, which only erases types.
    constructor(options) {
        this.options = options;
        this.now = options.now ?? Date.now;
        this.openMarker = `${options.file}.open`;
        const unclean = existsSync(this.openMarker);
        try {
            mkdirSync(dirname(options.file), { recursive: true, mode: 0o700 });
            // Establish the guard before accepting any persisted bearer. Even if
            // every subsequent write fails, an unclean restart will see this marker.
            writeFileAtomic(this.openMarker, "Session registry is open.\n", { mode: 0o600 });
            this.syncDirectory();
        }
        catch {
            throw new Error("Could not establish safe session storage.");
        }
        this.load(!unclean);
        this.revalidateEmailSessions();
    }
    load(restoreAccounts) {
        if (!existsSync(this.options.file))
            return;
        let raw;
        try {
            raw = JSON.parse(readFileSync(this.options.file, "utf8"));
        }
        catch {
            return; // unreadable: start empty rather than refuse to boot; pairing again is cheap
        }
        const parsed = fileSchema.safeParse(raw);
        if (parsed.success)
            this.sessions = parsed.data.sessions.filter(session => restoreAccounts || (session.email === undefined && session.userId === undefined));
    }
    syncDirectory() {
        // Windows does not expose directory fsync. The open marker still guards
        // normal process crashes; no stronger power-loss guarantee is claimed.
        if (process.platform === "win32")
            return;
        const fd = openSync(dirname(this.options.file), "r");
        try {
            fsyncSync(fd);
        }
        finally {
            closeSync(fd);
        }
    }
    /** Atomic write, owner-only, directory owner-only. */
    persist() {
        if (this.closed)
            throw new Error("Session registry is closed.");
        const dir = dirname(this.options.file);
        mkdirSync(dir, { recursive: true, mode: 0o700 });
        writeFileAtomic(this.options.file, JSON.stringify({ version: 1, sessions: this.sessions }, null, 2) + "\n", { mode: 0o600 });
        this.syncDirectory();
    }
    /** Call after HTTP/stream shutdown. A failed close leaves the open marker,
     * so account sessions require fresh sign-in after restart. Paired devices
     * remain durable. Never remove the marker before the reduced set is saved. */
    close() {
        if (this.closed)
            return;
        try {
            this.revalidateEmailSessions();
            this.persist();
            unlinkSync(this.openMarker);
            this.closed = true;
            // A marker deletion lost on power failure causes extra sign-in only;
            // the session file and its rename were fsynced before removal.
        }
        catch {
            throw new Error("Could not safely close session storage.");
        }
    }
    prune() {
        this.revalidateEmailSessions();
        const now = this.now();
        this.pairings = this.pairings.filter((p) => p.expiresAt > now);
        this.replays = this.replays.filter((r) => r.expiresAt > now);
        for (const [hash, ticket] of this.tickets)
            if (ticket.expiresAt <= now)
                this.tickets.delete(hash);
        for (const [source, entry] of this.failures) {
            if (entry.lockedUntil <= now && now - entry.windowStart > LOCKOUT.windowMs)
                this.failures.delete(source);
        }
        const expired = this.sessions.filter((s) => s.expiresAt <= now);
        if (expired.length) {
            this.sessions = this.sessions.filter((s) => s.expiresAt > now);
            for (const s of expired)
                this.forget(s.id);
            this.persist();
        }
    }
    /** Called with a session id whenever it stops being valid (revoked,
     * logged out, expired), so open streams can be closed. */
    onSessionRevoked(listener) {
        this.onRevoked.add(listener);
        return () => this.onRevoked.delete(listener);
    }
    forget(sessionId) {
        this.lastSeenWrites.delete(sessionId);
        for (const [hash, ticket] of this.tickets)
            if (ticket.sessionId === sessionId)
                this.tickets.delete(hash);
        for (const listener of this.onRevoked)
            listener(sessionId);
    }
    // ── pairing ────────────────────────────────────────────────────────────
    openPairing(input = {}) {
        this.prune();
        const now = this.now();
        const code = generatePairingCode();
        const credential = generatePairingCredential();
        const scopes = input.scopes?.length ? [...new Set(input.scopes)] : [...SCOPES];
        const pairing = {
            id: randomUUID(),
            codeHash: sha256(code),
            credentialHash: sha256(credential),
            scopes,
            label: (input.label ?? "").trim().slice(0, 80),
            createdAt: now,
            expiresAt: now + (input.ttlMs ?? PAIRING_CODE_TTL_MS),
        };
        this.pairings.push(pairing);
        return { id: pairing.id, code, credential, expiresAt: pairing.expiresAt };
    }
    openPairings() {
        this.prune();
        return this.pairings.map((p) => ({ id: p.id, label: p.label, scopes: [...p.scopes], createdAt: p.createdAt, expiresAt: p.expiresAt }));
    }
    cancelPairing(id) {
        const before = this.pairings.length;
        this.pairings = this.pairings.filter((p) => p.id !== id);
        return this.pairings.length !== before;
    }
    /** Sources with recent failures (for tests and diagnostics; never the codes). */
    failureSources() {
        this.prune();
        return [...this.failures.keys()];
    }
    lockState(source) {
        const entry = this.failures.get(source);
        if (!entry)
            return { locked: false, retryAfterMs: 0 };
        const now = this.now();
        if (entry.lockedUntil > now)
            return { locked: true, retryAfterMs: entry.lockedUntil - now };
        return { locked: false, retryAfterMs: 0 };
    }
    recordFailure(source) {
        const now = this.now();
        const entry = this.failures.get(source) ?? { count: 0, windowStart: now, lockedUntil: 0 };
        if (now - entry.windowStart > LOCKOUT.windowMs) {
            entry.count = 0;
            entry.windowStart = now;
        }
        entry.count += 1;
        if (entry.count >= LOCKOUT.failures) {
            entry.lockedUntil = now + LOCKOUT.lockMs;
            entry.count = 0;
            entry.windowStart = now;
        }
        this.failures.set(source, entry);
    }
    /** Turn a pairing code into a session. `source` identifies the caller for
     * the lockout (an IP); `label` names the device in the sessions list. */
    /** `label` is what the client asked to be called; the code's own label
     * (set by whoever minted it) comes next; `fallbackLabel` (derived from the
     * user agent) last. */
    exchange(input) {
        this.prune();
        const now = this.now();
        // A credential is hashed as presented. Normalizing it would be actively
        // unsafe: normalizePairingCode folds 0 to O and 1 to I, which both
        // destroys a base64url secret and maps distinct secrets onto one digest.
        const presented = isPairingCredential(input.code)
            ? sha256(input.code)
            : sha256(normalizePairingCode(input.code));
        const attemptId = typeof input.attemptId === "string" && /^[\w-]{8,64}$/.test(input.attemptId) ? input.attemptId : null;
        const replay = attemptId ? this.replays.find((r) => r.attemptId === attemptId && sameDigest(r.codeHash, presented)) : undefined;
        if (replay)
            return replay.result;
        const lock = this.lockState(input.source);
        if (lock.locked) {
            const seconds = Math.ceil(lock.retryAfterMs / 1000);
            return { ok: false, status: 429, error: `too many failed pairing attempts from your address; try again in ${seconds}s` };
        }
        const index = this.pairings.findIndex((p) => sameDigest(p.codeHash, presented) || sameDigest(p.credentialHash, presented));
        if (index < 0) {
            this.recordFailure(input.source);
            return { ok: false, status: 401, error: "pairing code is wrong or has expired; create a new one on the server" };
        }
        const [pairing] = this.pairings.splice(index, 1); // single use
        this.failures.delete(input.source);
        const token = `omb_sess_${randomBytes(32).toString("base64url")}`;
        const record = {
            id: randomUUID(),
            tokenHash: sha256(token),
            label: (input.label.trim() || pairing.label || input.fallbackLabel?.trim() || "Unnamed device").slice(0, 80),
            scopes: [...pairing.scopes],
            createdAt: now,
            lastSeenAt: now,
            // The absolute cap applies from the first term, so a TTL configured
            // longer than the cap does not hand out a session the cap forbids.
            expiresAt: now + Math.min(SESSION_TTL_MS, SESSION_MAX_AGE_MS),
        };
        this.sessions.push(record);
        this.lastSeenWrites.set(record.id, now); // the exchange itself was the first sighting
        this.persist();
        const result = { ok: true, token, session: publicSession(record) };
        if (attemptId)
            this.replays.push({ codeHash: presented, attemptId, result, expiresAt: now + EXCHANGE_REPLAY_MS });
        return result;
    }
    /** A session from a verified account sign-in (server/account-signin.ts)
     * rather than a pairing code: same token, same term, same gates. */
    issue(input) {
        return this.issueAccount(input);
    }
    /** Internal hosted-bridge seam: call only after consuming a verified,
     * workspace-bound PKCE grant. No HTTP route accepts this marker as input. */
    issuePortal(input) {
        if (!/^[A-Za-z0-9_-]{43}$/.test(input.grant) || !input.email)
            throw new Error("A verified portal identity is required");
        return this.issueAccount({ label: "Hosted workspace", email: input.email, userId: `portal:${input.grant}`, scopes: input.scopes }, "portal");
    }
    issueAccount(input, membershipAuthority) {
        this.prune();
        const now = this.now();
        const token = `omb_sess_${randomBytes(32).toString("base64url")}`;
        const record = {
            id: randomUUID(),
            tokenHash: sha256(token),
            label: (input.label.trim() || "Unnamed device").slice(0, 80),
            scopes: [...new Set(input.scopes)],
            createdAt: now,
            lastSeenAt: now,
            expiresAt: now + Math.min(SESSION_TTL_MS, SESSION_MAX_AGE_MS),
        };
        if (input.userId)
            record.userId = input.userId;
        if (input.email)
            record.email = input.email;
        if (membershipAuthority)
            record.membershipAuthority = membershipAuthority;
        this.sessions.push(record);
        this.lastSeenWrites.set(record.id, now);
        this.persist();
        return { token, session: publicSession(record) };
    }
    /** The pairing lockout, for other code-like exchanges on the same source. */
    attemptAllowed(source) {
        const lock = this.lockState(source);
        return lock.locked ? { ok: false, retryAfterMs: lock.retryAfterMs } : { ok: true };
    }
    noteFailure(source) {
        this.recordFailure(source);
    }
    clearFailures(source) {
        this.failures.delete(source);
    }
    // ── sessions ───────────────────────────────────────────────────────────
    /** Email membership is live, not a thirty-day grant. Losing any issued
     * scope revokes the token and its streams; signing in again obtains the
     * new role. Promotions never widen existing credentials. Pairing sessions
     * have no email and remain independent of the hosted sign-in list. */
    revalidateEmailSessions() {
        if (this.closed)
            throw new Error("Session registry is closed.");
        const eligible = this.sessions.filter(session => session.email !== undefined && !(this.options.portalMembership && session.membershipAuthority === "portal"));
        if (!eligible.length)
            return;
        let resolveScopes = this.options.emailScopes;
        try {
            if (this.options.emailScopesSnapshot)
                resolveScopes = this.options.emailScopesSnapshot();
        }
        catch {
            resolveScopes = undefined; // Never fall back to stale membership after a failed snapshot.
        }
        const revoked = eligible.filter((session) => {
            try {
                const allowed = resolveScopes?.(session.email);
                return !allowed || session.scopes.some((scope) => !allowed.includes(scope));
            }
            catch {
                return true; // missing or unreadable membership must fail closed
            }
        });
        if (!revoked.length)
            return;
        const ids = new Set(revoked.map((session) => session.id));
        this.sessions = this.sessions.filter((session) => !ids.has(session.id));
        for (const session of revoked)
            this.forget(session.id);
        try {
            this.persist();
        }
        catch {
            // Revocation stays effective in memory and streams close. The boot
            // marker prevents old account bearers from reviving after an unclean
            // restart, even if membership is later restored and all writes failed.
            console.error("Could not persist email session revocation.");
        }
    }
    authenticate(token) {
        if (!token)
            return null;
        this.revalidateEmailSessions();
        const hash = sha256(token);
        const now = this.now();
        const record = this.sessions.find((s) => sameDigest(s.tokenHash, hash));
        if (!record || record.expiresAt <= now)
            return null;
        const lastWrite = this.lastSeenWrites.get(record.id) ?? 0;
        if (now - lastWrite >= LAST_SEEN_WRITE_INTERVAL_MS) {
            record.lastSeenAt = now;
            this.lastSeenWrites.set(record.id, now);
            this.persist();
        }
        return record;
    }
    /** Sliding expiry. Called by the request gate once a request has passed
     * the origin and scope checks (so a rejected request never extends
     * anything): a still-valid session with half its term or less left is
     * renewed for the full term, capped at SESSION_MAX_AGE_MS from pairing.
     * Nothing expired is revived. Writes at most once per half-term, so it
     * adds nothing to the last-seen traffic. Returns whether it renewed. */
    renew(sessionId) {
        this.revalidateEmailSessions();
        const record = this.sessions.find((s) => s.id === sessionId);
        const now = this.now();
        if (!record || record.expiresAt <= now)
            return false;
        if (record.expiresAt - now > SESSION_RENEW_WHEN_LEFT_MS)
            return false;
        const next = Math.min(now + SESSION_TTL_MS, record.createdAt + SESSION_MAX_AGE_MS);
        if (next <= record.expiresAt)
            return false; // already at the absolute cap
        record.expiresAt = next;
        record.lastSeenAt = now;
        this.lastSeenWrites.set(record.id, now);
        this.persist();
        return true;
    }
    /** Still valid right now (prunes expiry first). */
    isLive(sessionId) {
        this.prune();
        return this.sessions.some((s) => s.id === sessionId);
    }
    list() {
        this.prune();
        return this.sessions.map(publicSession);
    }
    revoke(id) {
        const before = this.sessions.length;
        this.sessions = this.sessions.filter((s) => s.id !== id);
        if (this.sessions.length === before)
            return false;
        this.forget(id);
        this.persist();
        return true;
    }
    // ── stream tickets ─────────────────────────────────────────────────────
    issueStreamTicket(sessionId) {
        this.prune();
        const mine = [...this.tickets].filter(([, t]) => t.sessionId === sessionId).sort((a, b) => a[1].expiresAt - b[1].expiresAt);
        for (const [hash] of mine.slice(0, Math.max(0, mine.length - (MAX_STREAM_TICKETS_PER_SESSION - 1))))
            this.tickets.delete(hash);
        const ticket = `omb_tick_${randomBytes(24).toString("base64url")}`;
        const expiresAt = this.now() + STREAM_TICKET_TTL_MS;
        this.tickets.set(sha256(ticket), { sessionId, expiresAt });
        return { ticket, expiresAt };
    }
    /** Single use: a reconnecting client asks for a fresh ticket first. */
    redeemStreamTicket(ticket) {
        this.prune();
        const hash = sha256(ticket);
        const entry = this.tickets.get(hash);
        if (!entry)
            return null;
        this.tickets.delete(hash);
        const now = this.now();
        const record = this.sessions.find((s) => s.id === entry.sessionId);
        return record && record.expiresAt > now ? record : null;
    }
}
