import { randomUUID } from "node:crypto";
import { defaultChiefStore } from "./chief-store.js";
import { defaultActionAuthorizationManager, } from "../capabilities/safety-policy.js";
import { ComposioTransportClient, } from "./context-aggregator.js";
import { loadConfig } from "../config.js";
export class EmailComposerService {
    store;
    authManager;
    transport;
    cfg;
    constructor(opts) {
        this.store = opts?.store ?? defaultChiefStore;
        this.authManager = opts?.authManager ?? defaultActionAuthorizationManager;
        this.transport = opts?.transport;
        this.cfg = opts?.config;
    }
    resolveTransport() {
        if (this.transport)
            return this.transport;
        const cfg = this.cfg ?? loadConfig();
        const apiKey = cfg.composio?.apiKey;
        if (apiKey && apiKey.startsWith("ck_")) {
            this.transport = new ComposioTransportClient(apiKey, cfg.composio?.mcpUrl);
            return this.transport;
        }
        return undefined;
    }
    /**
     * Create an initial email proposal and present it in chat.
     */
    propose(input) {
        const id = `comp_${randomUUID().slice(0, 12)}`;
        const now = new Date().toISOString();
        const recipient = (input.recipientEmail || (input.to && input.to[0]) || "").trim();
        const extra = input.extraRecipients || (input.to && input.to.length > 1 ? input.to.slice(1) : undefined);
        const payload = {
            recipientEmail: recipient,
            extraRecipients: extra,
            cc: input.cc,
            bcc: input.bcc,
            subject: input.subject.trim(),
            body: input.body.trim(),
            isHtml: input.isHtml ?? false,
            attachments: input.attachments ?? [],
            relatedMeeting: input.relatedMeeting,
            commitmentSource: input.commitmentSource,
            userEdited: false,
        };
        const composer = {
            id,
            taskId: input.taskId || `task_${id}`,
            status: "proposed",
            payload,
            createdAt: now,
            updatedAt: now,
        };
        this.store.saveComposer(composer);
        return this.renderComposerResult(composer, "Email proposal created and ready for review.");
    }
    /**
     * Edit an existing email proposal.
     * STRICT SECURITY INVARIANT: Any edit immediately invalidates previous authorization grants.
     */
    edit(composerId, edits) {
        const composer = this.store.getComposer(composerId);
        if (!composer) {
            return {
                ok: false,
                error: `Composer ${composerId} not found`,
                userFacingMessage: `Error: Email composer "${composerId}" does not exist.`,
                formattedMarkdown: "",
            };
        }
        if (composer.status === "sent") {
            return {
                ok: false,
                error: "Cannot edit an email that has already been sent",
                userFacingMessage: "Error: This email was already sent and cannot be edited.",
                formattedMarkdown: "",
            };
        }
        // Invalidate existing authorization grant on edit
        if (composer.currentGrantId) {
            this.authManager.revokeGrant(composer.currentGrantId);
            composer.currentGrantId = undefined;
        }
        // Apply edits
        if (edits.to && edits.to.length > 0) {
            composer.payload.recipientEmail = edits.to[0].trim();
            if (edits.to.length > 1) {
                composer.payload.extraRecipients = edits.to.slice(1);
            }
        }
        else if (edits.recipientEmail !== undefined) {
            composer.payload.recipientEmail = edits.recipientEmail.trim();
        }
        if (edits.extraRecipients !== undefined) {
            composer.payload.extraRecipients = edits.extraRecipients;
        }
        if (edits.cc !== undefined) {
            composer.payload.cc = edits.cc;
        }
        if (edits.bcc !== undefined) {
            composer.payload.bcc = edits.bcc;
        }
        if (edits.subject !== undefined) {
            composer.payload.subject = edits.subject.trim();
        }
        if (edits.body !== undefined) {
            composer.payload.body = edits.body.trim();
        }
        // Attachment modifications
        const currentAttachments = [...(composer.payload.attachments ?? [])];
        const removeIds = [
            ...(edits.removeAttachmentFileIds || []),
            ...(edits.removeAttachmentIds || []),
        ];
        if (removeIds.length > 0) {
            const toRemove = new Set(removeIds);
            composer.payload.attachments = currentAttachments.filter((a) => !toRemove.has(a.fileId) && !toRemove.has(a.name));
        }
        if (edits.addAttachments && edits.addAttachments.length > 0) {
            const existingIds = new Set((composer.payload.attachments ?? []).map((a) => a.fileId));
            for (const att of edits.addAttachments) {
                if (!existingIds.has(att.fileId)) {
                    composer.payload.attachments?.push(att);
                }
            }
        }
        // Apply natural language edit instruction if provided
        if (edits.instruction) {
            const lower = edits.instruction.toLowerCase();
            if (lower.includes("shorter") || lower.includes("concise") || lower.includes("brief")) {
                composer.payload.body = this.shortenText(composer.payload.body);
            }
        }
        composer.payload.userEdited = true;
        composer.payload.lastEditedAt = new Date().toISOString();
        composer.status = "editing";
        composer.updatedAt = new Date().toISOString();
        this.store.saveComposer(composer);
        return this.renderComposerResult(composer, "Email content updated. Existing authorizations have been invalidated. Please review and confirm the new details.");
    }
    /**
     * Request authoritative grant for saving draft or sending.
     */
    grantApproval(composerId, operation, opts) {
        const composer = this.store.getComposer(composerId);
        if (!composer) {
            return { ok: false, error: `Composer ${composerId} not found` };
        }
        // Validate email integrity before issuing approval
        if (!composer.payload.recipientEmail || !composer.payload.recipientEmail.includes("@")) {
            return { ok: false, error: "Valid recipient email address is required before approval" };
        }
        if (!composer.payload.subject) {
            return { ok: false, error: "Email subject is required before approval" };
        }
        if (!composer.payload.body) {
            return { ok: false, error: "Email body is required before approval" };
        }
        const grant = this.authManager.createGrant({
            capabilityId: `chief_of_staff:${composer.id}`,
            operation,
            parameters: {
                recipient_email: composer.payload.recipientEmail,
                subject: composer.payload.subject,
                body: composer.payload.body,
                draft_id: composer.payload.draftId,
                attachments: (composer.payload.attachments ?? []).map((a) => a.fileId),
            },
            threadId: opts?.threadId,
            botId: opts?.botId,
            ttlMs: 300_000, // 5 minute TTL
        });
        composer.currentGrantId = grant.grantId;
        composer.status = "approved";
        this.store.saveComposer(composer);
        return { ok: true, grantId: grant.grantId };
    }
    async resolveFileAttachments(transport, attachments) {
        if (!attachments || attachments.length === 0)
            return [];
        const uploadables = [];
        for (const att of attachments) {
            if (!att.fileId)
                continue;
            try {
                const dlRes = await transport.callTool("GOOGLEDRIVE_DOWNLOAD_FILE", { fileId: att.fileId });
                if (dlRes.ok && dlRes.data) {
                    const content = dlRes.data.downloaded_file_content || dlRes.data;
                    const s3url = content.s3url || content.s3Url || "";
                    let s3key = content.s3key || "";
                    if (!s3key && s3url) {
                        try {
                            const parsedUrl = new URL(s3url);
                            s3key = parsedUrl.pathname.replace(/^\/+/, "");
                        }
                        catch {
                            s3key = s3url;
                        }
                    }
                    if (s3key) {
                        uploadables.push({
                            name: content.name || att.name,
                            mimetype: content.mimetype || att.mimeType || "application/octet-stream",
                            s3key,
                        });
                    }
                }
            }
            catch (err) {
                if (process.env.NODE_ENV !== "test") {
                    console.warn(`Failed to retrieve file bytes for attachment ${att.name} (${att.fileId}):`, err);
                }
            }
        }
        return uploadables;
    }
    /**
     * Save draft to Gmail (create or update).
     */
    async saveDraft(composerId, opts) {
        const composer = this.store.getComposer(composerId);
        if (!composer) {
            return {
                ok: false,
                error: `Composer ${composerId} not found`,
                userFacingMessage: "Error: Email composer not found.",
                formattedMarkdown: "",
            };
        }
        // Validate and consume grant
        const targetGrantId = opts?.grantId || composer.currentGrantId;
        const authCheck = this.authManager.validateAndConsumeGrant({
            grantId: targetGrantId,
            capabilityId: `chief_of_staff:${composer.id}`,
            operation: composer.payload.draftId ? "update_email_draft" : "create_email_draft",
            parameters: {
                recipient_email: composer.payload.recipientEmail,
                subject: composer.payload.subject,
                body: composer.payload.body,
                draft_id: composer.payload.draftId,
                attachments: (composer.payload.attachments ?? []).map((a) => a.fileId),
            },
            threadId: opts?.threadId,
        });
        if (!authCheck.valid) {
            return {
                ok: false,
                error: authCheck.reason,
                userFacingMessage: `Authorization required: Cannot save draft. ${authCheck.reason}`,
                formattedMarkdown: "",
            };
        }
        const transport = this.resolveTransport();
        if (!transport) {
            return {
                ok: false,
                error: "No transport available",
                userFacingMessage: "Error: No connected apps transport available.",
                formattedMarkdown: "",
            };
        }
        this.store.updateComposerStatus(composer.id, "executing");
        const executedAt = new Date().toISOString();
        // Retrieve genuine file bytes for actual MIME attachments
        const fileUploadables = await this.resolveFileAttachments(transport, composer.payload.attachments);
        const finalBody = composer.payload.body;
        let res;
        let toolName = "GMAIL_CREATE_EMAIL_DRAFT";
        if (composer.payload.draftId) {
            toolName = "GMAIL_UPDATE_DRAFT";
            const updateArgs = {
                draft_id: composer.payload.draftId,
                recipient_email: composer.payload.recipientEmail,
                subject: composer.payload.subject,
                body: finalBody,
                is_html: composer.payload.isHtml ?? false,
            };
            if (fileUploadables.length > 0) {
                updateArgs.attachment = fileUploadables;
            }
            res = await transport.callTool("GMAIL_UPDATE_DRAFT", updateArgs);
        }
        else {
            const draftArgs = {
                recipient_email: composer.payload.recipientEmail,
                subject: composer.payload.subject,
                body: finalBody,
                thread_id: composer.payload.threadId,
                is_html: composer.payload.isHtml ?? false,
            };
            if (fileUploadables.length > 0) {
                draftArgs.attachment = fileUploadables;
            }
            res = await transport.callTool("GMAIL_CREATE_EMAIL_DRAFT", draftArgs);
        }
        if (!res.ok) {
            const receipt = {
                actionId: composer.id,
                transport: "composio_mcp",
                toolName,
                executedAt,
                success: false,
                error: res.error,
            };
            this.store.updateComposerStatus(composer.id, "failed", receipt);
            return {
                ok: false,
                error: res.error,
                receipt,
                userFacingMessage: `Failed to save draft: ${res.error}`,
                formattedMarkdown: "",
            };
        }
        const draftData = res.data ?? {};
        const externalDraftId = String(draftData.id || draftData.draft_id || composer.payload.draftId || "").trim();
        const receipt = {
            actionId: composer.id,
            transport: "composio_mcp",
            toolName,
            executedAt,
            success: true,
            externalId: externalDraftId,
            responseData: draftData,
        };
        composer.payload.draftId = externalDraftId;
        composer.status = "saved_draft";
        this.store.updateComposerStatus(composer.id, "saved_draft", receipt);
        return this.renderComposerResult(composer, `✅ Draft successfully saved to Gmail (Draft ID: ${externalDraftId}). It is available in your Gmail account for further review.`);
    }
    /**
     * Send approved email.
     * STRICT SECURITY BOUNDARY: Sending requires explicit human authorization and grant consumption.
     */
    async sendEmail(composerId, opts) {
        const composer = this.store.getComposer(composerId);
        if (!composer) {
            return {
                ok: false,
                error: `Composer ${composerId} not found`,
                userFacingMessage: "Error: Email composer not found.",
                formattedMarkdown: "",
            };
        }
        // 1. Authoritative grant verification
        const targetGrantId = opts?.grantId || composer.currentGrantId;
        const authCheck = this.authManager.validateAndConsumeGrant({
            grantId: targetGrantId,
            capabilityId: `chief_of_staff:${composer.id}`,
            operation: "send_email",
            parameters: {
                recipient_email: composer.payload.recipientEmail,
                subject: composer.payload.subject,
                body: composer.payload.body,
                draft_id: composer.payload.draftId,
                attachments: (composer.payload.attachments ?? []).map((a) => a.fileId),
            },
            threadId: opts?.threadId,
        });
        if (!authCheck.valid) {
            return {
                ok: false,
                error: authCheck.reason,
                userFacingMessage: `Authorization required: Sending email cannot proceed without explicit user confirmation. ${authCheck.reason}`,
                formattedMarkdown: "",
            };
        }
        const transport = this.resolveTransport();
        if (!transport) {
            return {
                ok: false,
                error: "No transport available",
                userFacingMessage: "Error: No connected apps transport available.",
                formattedMarkdown: "",
            };
        }
        this.store.updateComposerStatus(composer.id, "executing");
        const executedAt = new Date().toISOString();
        // Retrieve genuine file bytes for actual MIME attachments
        const fileUploadables = await this.resolveFileAttachments(transport, composer.payload.attachments);
        const finalBody = composer.payload.body;
        // If draft already exists, use GMAIL_SEND_DRAFT
        let res;
        let toolName = "GMAIL_SEND_DRAFT";
        if (composer.payload.draftId) {
            // First ensure draft content and attachments are up to date
            const updateArgs = {
                draft_id: composer.payload.draftId,
                recipient_email: composer.payload.recipientEmail,
                subject: composer.payload.subject,
                body: finalBody,
            };
            if (fileUploadables.length > 0) {
                updateArgs.attachment = fileUploadables;
            }
            await transport.callTool("GMAIL_UPDATE_DRAFT", updateArgs);
            res = await transport.callTool("GMAIL_SEND_DRAFT", {
                draft_id: composer.payload.draftId,
            });
        }
        else {
            // Create draft first with genuine attachments, then send
            const draftArgs = {
                recipient_email: composer.payload.recipientEmail,
                subject: composer.payload.subject,
                body: finalBody,
            };
            if (fileUploadables.length > 0) {
                draftArgs.attachment = fileUploadables;
            }
            const draftRes = await transport.callTool("GMAIL_CREATE_EMAIL_DRAFT", draftArgs);
            if (!draftRes.ok || !draftRes.data?.id) {
                return {
                    ok: false,
                    error: `Failed to prepare draft before sending: ${draftRes.error}`,
                    userFacingMessage: `Error preparing email for sending: ${draftRes.error}`,
                    formattedMarkdown: "",
                };
            }
            const draftId = draftRes.data.id;
            composer.payload.draftId = draftId;
            res = await transport.callTool("GMAIL_SEND_DRAFT", {
                draft_id: draftId,
            });
        }
        if (!res.ok) {
            const receipt = {
                actionId: composer.id,
                transport: "composio_mcp",
                toolName,
                executedAt,
                success: false,
                error: res.error,
            };
            this.store.updateComposerStatus(composer.id, "failed", receipt);
            return {
                ok: false,
                error: res.error,
                receipt,
                userFacingMessage: `Failed to send email: ${res.error}`,
                formattedMarkdown: "",
            };
        }
        const sendData = res.data ?? {};
        const messageId = String(sendData.id || sendData.message_id || composer.payload.draftId || "").trim();
        const receipt = {
            actionId: composer.id,
            transport: "composio_mcp",
            toolName,
            executedAt,
            success: true,
            externalId: messageId,
            responseData: sendData,
        };
        composer.payload.messageId = messageId;
        composer.status = "sent";
        this.store.updateComposerStatus(composer.id, "sent", receipt);
        return this.renderComposerResult(composer, `🚀 Email sent successfully to ${composer.payload.recipientEmail}! Message ID: ${messageId}.`);
    }
    /**
     * Cancel and discard composer.
     */
    cancel(composerId) {
        const composer = this.store.getComposer(composerId);
        if (!composer) {
            return {
                ok: false,
                error: "Composer not found",
                userFacingMessage: "Composer not found.",
                formattedMarkdown: "",
            };
        }
        if (composer.currentGrantId) {
            this.authManager.revokeGrant(composer.currentGrantId);
            composer.currentGrantId = undefined;
        }
        composer.status = "cancelled";
        this.store.updateComposerStatus(composer.id, "cancelled");
        return this.renderComposerResult(composer, "Email draft proposal cancelled and discarded.");
    }
    shortenText(text) {
        const lines = text.split("\n").filter((l) => l.trim().length > 0);
        if (lines.length <= 3)
            return text;
        // Condense into a concise 3-line format
        const greeting = lines[0] || "Hi,";
        const closing = lines[lines.length - 1]?.startsWith("Best") || lines[lines.length - 1]?.startsWith("Thanks")
            ? lines.slice(lines.length - 2).join("\n")
            : "Best regards,\nAbhay";
        const bodyLines = lines.slice(1, lines.length - 2).join(" ");
        const condensedBody = bodyLines.length > 120 ? bodyLines.slice(0, 115) + "..." : bodyLines;
        return `${greeting}\n\n${condensedBody}\n\n${closing}`;
    }
    renderComposerResult(composer, message) {
        const p = composer.payload;
        const attList = (p.attachments ?? [])
            .map((a) => `📎 **${a.name}** (${a.mimeType || "application/octet-stream"}${a.size ? ` · ${typeof a.size === "number" ? Math.round(a.size / 1024) : a.size} KB` : ""})`)
            .join("\n");
        const statusBadge = {
            proposed: "🟡 PROPOSED",
            editing: "✏️ EDITING",
            awaiting_approval: "⏳ AWAITING APPROVAL",
            approved: "🟢 APPROVED",
            executing: "⚙️ EXECUTING",
            saved_draft: "💾 DRAFT SAVED",
            sent: "🚀 SENT",
            failed: "❌ FAILED",
            cancelled: "🚫 CANCELLED",
        }[composer.status];
        const formattedMarkdown = [
            `### ✉️ Email Composer — ${statusBadge}`,
            p.relatedMeeting ? `*Related Meeting:* **${p.relatedMeeting.title}** (${p.relatedMeeting.start})` : undefined,
            p.commitmentSource ? `*Source:* ${p.commitmentSource.sourceTitle} — *"${p.commitmentSource.snippet}"*` : undefined,
            `**To:** \`${p.recipientEmail}\`${p.cc?.length ? ` · **Cc:** \`${p.cc.join(", ")}\`` : ""}`,
            `**Subject:** ${p.subject}`,
            attList ? `\n**Attachments:**\n${attList}` : undefined,
            "\n**Message Body:**",
            "```text",
            p.body,
            "```",
            p.draftId ? `*Gmail Draft ID:* \`${p.draftId}\`` : undefined,
            p.userEdited ? "*(User modified content)*" : undefined,
            "\n---",
            "💡 *Actions: reply with **\"Save Draft\"**, **\"Send\"**, **\"Edit [instructions]\"**, **\"Cancel\"**, or **\"Manage Rules\"**.*",
        ]
            .filter(Boolean)
            .join("\n");
        return {
            ok: true,
            composer,
            formattedCard: {
                title: `Email: ${p.subject}`,
                subtitle: `To: ${p.recipientEmail} · Status: ${composer.status}`,
                options: ["Save Draft", "Send", "Edit", "Cancel", "Manage Rules"],
                composerId: composer.id,
                status: composer.status,
            },
            optionCard: composerToOptionCard(composer),
            formattedMarkdown,
            userFacingMessage: message,
        };
    }
}
export function composerToOptionCard(composer, requestId) {
    const p = composer.payload;
    const isSent = composer.status === "sent";
    return {
        title: `Email: ${p.subject || "Follow-up"}`,
        subtitle: `To: ${p.recipientEmail} · Status: ${composer.status}`,
        options: isSent ? [] : ["Save Draft", "Send", "Edit", "Cancel"],
        requestId: requestId || `email:preview:${composer.id}`,
        tool: "chief_of_staff_email",
        answered: isSent ? "Sent" : undefined,
        emailComposer: {
            composerId: composer.id,
            status: composer.status,
            from: "abhay315204@gmail.com",
            to: p.recipientEmail,
            cc: p.cc?.join(", "),
            subject: p.subject,
            body: p.body,
            attachments: p.attachments?.map((a) => ({
                name: a.name,
                fileId: a.fileId,
                mimeType: a.mimeType,
                size: a.size ? (typeof a.size === "number" ? `${Math.round(a.size / 1024)} KB` : String(a.size)) : undefined,
                driveUrl: a.driveUrl,
                verified: a.verifiedAccessible,
            })),
            relatedMeetingTitle: p.relatedMeeting?.title,
            relatedMeetingTime: p.relatedMeeting?.start,
            draftId: p.draftId,
            messageId: p.messageId,
        },
    };
}
export const defaultEmailComposerService = new EmailComposerService();
