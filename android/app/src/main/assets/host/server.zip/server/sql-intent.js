/**
 * What a SQL comparison question is actually asking for.
 *
 * A question that mentions "different columns and rows" can mean at least four
 * different operations, and only one of them uses window functions. Recommending
 * `LAG()`/`LEAD()` merely because several rows were mentioned is wrong: that is
 * the tool for stepping through an *explicit order*, not the tool for comparing
 * two columns of one row or for finding records that match other records.
 *
 * This layer classifies the operation, says whether a window function is
 * justified, and — when the wording genuinely admits more than one reading —
 * returns the one clarification worth asking. It reads the question's own
 * structure rather than a list of SQL keywords, and it does not special-case
 * any one question.
 */
const ORDER_SIGNALS = [
    { pattern: /\bprevious\s+(?:row|record|entry|month|day|year|period|value)\b/i, weight: 3, label: "previous row" },
    { pattern: /\bnext\s+(?:row|record|entry|month|day|year|period|value)\b/i, weight: 3, label: "next row" },
    { pattern: /\b(?:adjacent|consecutive|neighbou?ring)\s+(?:rows?|records?|entries)\b/i, weight: 3, label: "adjacent rows" },
    { pattern: /\border(?:ed)?\s+by\b/i, weight: 3, label: "ordered by" },
    { pattern: /\b(?:lag|lead)\s*\(/i, weight: 2, label: "lag/lead" },
    { pattern: /\b(?:sequence|series|over\s+time|month\s+over\s+month|day\s+over\s+day|year\s+over\s+year)\b/i, weight: 2, label: "sequence" },
    { pattern: /\b(?:before|after)\s+(?:the\s+)?(?:current|previous|next)\b/i, weight: 1, label: "before/after current" },
];
const SAME_ROW_SIGNALS = [
    { pattern: /\b(?:two|2|both|multiple)\s+columns?\b/i, weight: 3, label: "two columns" },
    { pattern: /\bcolumns?\s+(?:in|of|within)\s+(?:the\s+)?same\s+row\b/i, weight: 3, label: "columns in the same row" },
    { pattern: /\bsame\s+row\b/i, weight: 3, label: "same row" },
    { pattern: /\bin\s+each\s+row\b/i, weight: 2, label: "in each row" },
    { pattern: /\brow[\s-]wise\b/i, weight: 2, label: "row-wise" },
    { pattern: /\b(?:column\s+[a-z0-9_]+\s+(?:and|versus|vs\.?|to|with)\s+column\s+[a-z0-9_]+)/i, weight: 3, label: "column A vs column B" },
    { pattern: /\bcompare\s+[a-z_][a-z0-9_]*\s+(?:and|with|to|versus|vs\.?)\s+[a-z_][a-z0-9_]*\b/i, weight: 2, label: "compare X and Y" },
];
const CROSS_ROW_SIGNALS = [
    { pattern: /\b(?:another|other|different|separate)\s+(?:row|record|entry)\b/i, weight: 3, label: "another row" },
    { pattern: /\b(?:same|one)\s+column\b[\s\S]{0,80}\b(?:different|other|another)\s+rows?\b/i, weight: 4, label: "same column across rows" },
    { pattern: /\b(?:values?|data)\s+(?:in|from|across)\s+(?:different|multiple|other)\s+rows?\b/i, weight: 3, label: "values across rows" },
    { pattern: /\b(?:compare|contrast)\b[\s\S]{0,60}\b(?:rows?|records?)\b/i, weight: 2, label: "compare rows" },
    { pattern: /\b(?:row|record)\s+(?:against|with)\s+(?:another|other)\s+(?:row|record)\b/i, weight: 3, label: "row against another" },
];
const MATCH_SIGNALS = [
    { pattern: /\b(?:find|list|select|get|show)\b[\s\S]{0,50}\b(?:records?|rows?)\b[\s\S]{0,40}\b(?:that\s+)?match/i, weight: 3, label: "records that match" },
    { pattern: /\bmatch(?:es|ing)?\s+(?:the\s+)?(?:values?|records?|another|other)\b/i, weight: 3, label: "matching values" },
    { pattern: /\b(?:same|equal)\s+(?:value|amount|number)\s+as\b/i, weight: 3, label: "same value as" },
    { pattern: /\b(?:duplicates?|duplicated)\b/i, weight: 3, label: "duplicates" },
    { pattern: /\bexist(?:s|ing)?\b/i, weight: 2, label: "exists" },
    { pattern: /\b(?:which|whose)\b[\s\S]{0,80}\b(?:also\s+)?(?:appears?|occur(?:s|ring)?)\b/i, weight: 2, label: "appears elsewhere" },
];
const RANKING_SIGNALS = [
    { pattern: /\b(?:rank|ranking|dense_rank|row_number)\b/i, weight: 3, label: "rank" },
    { pattern: /\b(?:running|rolling|cumulative)\s+(?:total|sum|average|count)\b/i, weight: 3, label: "running total" },
    { pattern: /\btop\s+\d+\b/i, weight: 2, label: "top N" },
    { pattern: /\bpercentile|ntile\b/i, weight: 3, label: "percentile" },
];
function score(text, table) {
    let total = 0;
    const signals = [];
    for (const entry of table) {
        if (entry.pattern.test(text)) {
            total += entry.weight;
            signals.push(entry.label);
        }
    }
    return { total, signals };
}
/**
 * Classifies a SQL comparison question.
 *
 * Order matters: an explicit ordering is the only thing that makes a window
 * function the right answer, so it wins when the question states one. Otherwise
 * the highest-scoring structural signal wins, and a genuine tie yields `unknown`
 * with a clarification instead of a guess.
 */
export function classifySqlComparison(question) {
    const text = (question ?? "").trim();
    if (!text) {
        return { intent: "unknown", confidence: 0, signals: [], windowFunctionJustified: false };
    }
    const order = score(text, ORDER_SIGNALS);
    const sameRow = score(text, SAME_ROW_SIGNALS);
    const crossRow = score(text, CROSS_ROW_SIGNALS);
    const match = score(text, MATCH_SIGNALS);
    const ranking = score(text, RANKING_SIGNALS);
    // An ordered sequence with an explicit direction is unambiguous.
    if (order.total >= 3 && ![sameRow.total, match.total].some((value) => value > order.total)) {
        return {
            intent: "adjacent_ordered_rows",
            confidence: Math.min(1, order.total / 6),
            signals: order.signals,
            windowFunctionJustified: true,
        };
    }
    if (ranking.total >= 3) {
        return {
            intent: "ranking_or_aggregate",
            confidence: Math.min(1, ranking.total / 6),
            signals: ranking.signals,
            windowFunctionJustified: true,
        };
    }
    const scored = [
        { intent: "same_row_columns", total: sameRow.total, signals: sameRow.signals },
        { intent: "cross_row_same_column", total: crossRow.total, signals: crossRow.signals },
        { intent: "match_other_records", total: match.total, signals: match.signals },
    ];
    const candidates = scored.filter((candidate) => candidate.total > 0);
    candidates.sort((a, b) => b.total - a.total);
    if (candidates.length === 0) {
        return {
            intent: "unknown",
            confidence: 0,
            signals: [],
            windowFunctionJustified: false,
            clarification: "Are you comparing values within one row, comparing one row's value with another row's, or finding rows whose value matches another row?",
        };
    }
    const best = candidates[0];
    const runnerUp = candidates[1];
    if (runnerUp && runnerUp.total === best.total) {
        // Two readings fit equally: ask rather than pick one and build a tutorial
        // around the wrong operation.
        return {
            intent: "unknown",
            confidence: 0.3,
            signals: [...best.signals, ...runnerUp.signals],
            windowFunctionJustified: false,
            clarification: best.intent === "same_row_columns"
                ? "Do you want a comparison within each row (two columns of the same record), or a comparison between different rows?"
                : "Do you want records that match a value in another row, or a row-by-row comparison?",
        };
    }
    const confidence = runnerUp ? Math.min(1, (best.total - runnerUp.total) / (best.total + runnerUp.total)) : 1;
    // A window function only makes sense when the question established a
    // sequence; a bare mention of "rows" never does.
    return {
        intent: best.intent,
        confidence: Math.max(0.4, confidence),
        signals: best.signals,
        windowFunctionJustified: false,
        ...(confidence < 0.35
            ? { clarification: "Should the comparison happen within each row, or between different rows?" }
            : {}),
    };
}
const APPROACHES = {
    same_row_columns: {
        intent: "same_row_columns",
        approach: "Compare the two columns directly in the same SELECT, or in a WHERE clause on that row.",
        explanation: "Both values live in the same row, so they are already side by side: a plain expression such as `a - b` or `WHERE a <> b` answers it. A self-join would match the row to itself and a window function would add an ordering the question never asked for.",
        avoid: ["LAG()/LEAD()", "self-join"],
    },
    cross_row_same_column: {
        intent: "cross_row_same_column",
        approach: "Use a self-join: join the table to itself on the record key and compare the same column from both sides.",
        explanation: "The values come from the same column in two different records, so the rows must be aligned explicitly — a self-join (or a correlated subquery) pairs them on a key you choose, and the comparison is between the two aliases.",
        avoid: ["LAG()/LEAD() without an explicit ORDER BY"],
    },
    match_other_records: {
        intent: "match_other_records",
        approach: "Use a self-join, `EXISTS`, or `IN` against the same table to find records whose value matches another record.",
        explanation: "The question is about which records share a value, not about comparing neighbouring positions. `EXISTS`/`IN` express membership directly and a self-join exposes both matching rows; neither needs an ordering.",
        avoid: ["LAG()/LEAD()"],
    },
    adjacent_ordered_rows: {
        intent: "adjacent_ordered_rows",
        approach: "Use `LAG()`/`LEAD()` with an explicit `OVER (ORDER BY ...)` over the sequence.",
        explanation: "The question establishes an order and asks about the previous or next record, which is exactly what `LAG()`/`LEAD()` express without a join.",
        avoid: [],
    },
    ranking_or_aggregate: {
        intent: "ranking_or_aggregate",
        approach: "Use a window function (`RANK()`, `ROW_NUMBER()`, or a windowed aggregate) with an explicit `OVER (...)`.",
        explanation: "The question asks for a position or running aggregate across an ordered set, which is the case window functions exist for.",
        avoid: [],
    },
    unknown: {
        intent: "unknown",
        approach: "Ask which comparison is meant before choosing a technique.",
        explanation: "The wording admits more than one operation, and the technique changes completely between them. A focused clarification is more useful than a confident but possibly irrelevant tutorial.",
        avoid: ["LAG()/LEAD() before the intended comparison is established"],
    },
};
/** The technique that matches the classified operation. */
export function sqlApproachFor(intent) {
    return APPROACHES[intent];
}
/**
 * Prompt guidance for a data/comparison question, measured against the
 * question's own structure. It returns "" for ordinary chat and for wording
 * that carries no usable signal, so the model's normal behaviour is untouched.
 * This is guidance, not an answer: the model still writes the SQL.
 */
export function sqlIntentPrompt(question) {
    const result = classifySqlComparison(question);
    if (result.intent === "unknown") {
        return result.confidence >= 0.4 && result.clarification
            ? ` Data question: the wording fits more than one operation equally. Ask exactly one clarifying question before writing SQL: ${result.clarification}`
            : "";
    }
    if (result.confidence < 0.4)
        return "";
    const approach = sqlApproachFor(result.intent);
    const signals = result.signals.slice(0, 3).join(", ");
    const avoid = approach.avoid.length ? ` Do not lead with ${approach.avoid.join("; ")}.` : "";
    const windowNote = result.windowFunctionJustified
        ? ""
        : " A window function is not justified here: there is no explicit ordering.";
    return ` Data question shape: ${approach.intent.replace(/_/g, " ")}${signals ? ` (${signals})` : ""}. ${approach.approach}. ${approach.explanation}.${avoid}${windowNote}`;
}
/**
 * Guard for the response path: flags a recommendation that leads with a window
 * function when the question never established an ordered sequence.
 */
export function recommendationIsRelevant(question, recommendation) {
    const result = classifySqlComparison(question);
    const leadsWithWindow = /\b(?:lag|lead|row_number|rank|dense_rank|ntile)\s*\(/i.test(recommendation);
    if (leadsWithWindow && !result.windowFunctionJustified) {
        return {
            relevant: false,
            reason: `The question reads as ${result.intent}; an ordered window function is not justified without an explicit sequence.`,
        };
    }
    return { relevant: true };
}
