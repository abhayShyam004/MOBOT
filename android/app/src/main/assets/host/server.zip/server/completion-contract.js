/**
 * Task Completion, Verification & Delivery Contract
 *
 * Implements Phase 1 of the MOBOT Systematic Reliability Overhaul:
 * - Unambiguous task states: Queued, Running, Blocked, Partially Completed, Completed, Failed, Cancelled
 * - Strict separation of concerns:
 *     1. Execution (Did operations finish and what was produced?)
 *     2. Validation (Which requirements were checked and passed with empirical evidence?)
 *     3. Delivery (Do deliverables exist, match integrity hashes, and can users access them?)
 * - Preview accessibility tiering: Host Loopback vs Device vs LAN vs Public
 * - Truthful evidence-backed completion evaluation preventing premature completion claims
 */
import { createHash } from "node:crypto";
import { existsSync, statSync, readFileSync } from "node:fs";
import { basename, isAbsolute, resolve } from "node:path";
import { defaultArtifactManager } from "./computer-agent/artifact-manager.js";
import { getActionReceipts } from "./capabilities/action-truthfulness.js";
/**
 * Classify a preview URL to truthfully distinguish host-local loopback from
 * device-accessible, LAN-accessible, or public endpoints.
 */
export function classifyPreviewUrl(rawUrl, options) {
    if (!rawUrl || typeof rawUrl !== "string" || !rawUrl.trim()) {
        return {
            tier: "NONE",
            rawUrl: "",
            accessibleUrl: "",
            isMobileAccessible: false,
            accessInstructions: "No preview service configured.",
        };
    }
    const trimmed = rawUrl.trim();
    let parsed;
    try {
        parsed = new URL(trimmed);
    }
    catch {
        return {
            tier: "NONE",
            rawUrl: trimmed,
            accessibleUrl: "",
            isMobileAccessible: false,
            accessInstructions: "Invalid preview URL format.",
            warning: `Malformed preview URL: ${trimmed}`,
        };
    }
    const hostname = parsed.hostname.toLowerCase();
    const port = parsed.port || (parsed.protocol === "https:" ? "443" : "80");
    // 1. Host loopback (127.0.0.1, localhost, 0.0.0.0, ::1)
    const isLoopback = hostname === "127.0.0.1" ||
        hostname === "localhost" ||
        hostname.endsWith(".localhost") ||
        hostname === "0.0.0.0" ||
        hostname === "::1" ||
        hostname === "[::1]";
    if (isLoopback) {
        if (options?.adbDeviceForwarded) {
            const devPort = options.devicePort ? String(options.devicePort) : port;
            return {
                tier: "DEVICE_ACCESSIBLE",
                rawUrl: trimmed,
                accessibleUrl: `http://127.0.0.1:${devPort}`,
                isMobileAccessible: true,
                accessInstructions: `Preview is accessible on the phone via ADB reverse port forward on port ${devPort}.`,
            };
        }
        return {
            tier: "HOST_LOOPBACK",
            rawUrl: trimmed,
            accessibleUrl: trimmed,
            isMobileAccessible: false,
            accessInstructions: `Host-local loopback only. Running on workstation port ${port}. ` +
                `This URL cannot be opened directly from a separate mobile device or phone browser without ADB port reverse ('adb reverse tcp:${port} tcp:${port}') or LAN exposure.`,
            warning: "Host loopback only: not accessible from mobile companion app.",
        };
    }
    // 2. Private LAN IPs (10.x, 192.168.x, 172.16-31.x)
    const isLan = /^10\./.test(hostname) ||
        /^192\.168\./.test(hostname) ||
        /^172\.(?:1[6-9]|2\d|3[01])\./.test(hostname);
    if (isLan) {
        return {
            tier: "LAN_ACCESSIBLE",
            rawUrl: trimmed,
            accessibleUrl: trimmed,
            isMobileAccessible: true,
            accessInstructions: `Accessible from devices connected to the same Wi-Fi / Local Area Network at ${trimmed}.`,
        };
    }
    // 3. Internal hostnames (.local, .internal, .lan, .corp, etc.)
    const isInternalHostname = hostname.endsWith(".local") ||
        hostname.endsWith(".internal") ||
        hostname.endsWith(".lan") ||
        hostname.endsWith(".home") ||
        hostname.endsWith(".corp") ||
        hostname.endsWith(".test") ||
        hostname.endsWith(".example") ||
        hostname.endsWith(".invalid") ||
        !hostname.includes(".");
    if (isInternalHostname) {
        return {
            tier: "HOST_LOOPBACK",
            rawUrl: trimmed,
            accessibleUrl: trimmed,
            isMobileAccessible: false,
            accessInstructions: `Internal hostname (${hostname}) is not publicly resolvable. Inaccessible outside the host or local private network.`,
            warning: "Internal hostname: not accessible outside the local host or private domain.",
        };
    }
    // 4. Public domain / deployment topology
    return {
        tier: "PUBLIC_DEPLOYMENT",
        rawUrl: trimmed,
        accessibleUrl: trimmed,
        isMobileAccessible: true,
        accessInstructions: `Publicly deployed and accessible globally at ${trimmed}. (Topology classification; verify active service reachability independently).`,
    };
}
/**
 * Actively probe a preview URL to test actual network reachability vs URL topology.
 */
export async function probePreviewReachability(rawUrl, options = {}) {
    if (!rawUrl || typeof rawUrl !== "string") {
        return { reachable: false, reachability: "UNVERIFIED", error: "Missing URL" };
    }
    let parsed;
    try {
        parsed = new URL(rawUrl);
    }
    catch (e) {
        return { reachable: false, reachability: "UNVERIFIED", error: `Invalid URL: ${e.message}` };
    }
    const isLoopback = parsed.hostname === "127.0.0.1" || parsed.hostname === "localhost" || parsed.hostname === "0.0.0.0";
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), options.timeoutMs ?? 1000);
    try {
        const res = await fetch(rawUrl, {
            method: "HEAD",
            signal: controller.signal,
        });
        clearTimeout(timer);
        if (res.status === 401 || res.status === 403) {
            return { reachable: true, reachability: "REQUIRES_AUTH", httpStatus: res.status };
        }
        return { reachable: true, reachability: "REACHABLE", httpStatus: res.status };
    }
    catch (err) {
        clearTimeout(timer);
        if (isLoopback) {
            return {
                reachable: false,
                reachability: "REQUIRES_TUNNEL",
                error: `Loopback service unavailable or requires device reverse forwarding: ${err.message}`,
            };
        }
        return {
            reachable: false,
            reachability: "UNREACHABLE",
            error: `Server unreachable: ${err.message}`,
        };
    }
}
/**
 * Empirically verify an artifact candidate for existence, non-emptiness,
 * valid MIME type, and SHA-256 integrity.
 */
export function verifyArtifactForDelivery(sourcePathOrId, options = {}) {
    // Check if it's already a registered artifact ID
    const existing = defaultArtifactManager.getArtifact(sourcePathOrId);
    if (existing) {
        const exists = existsSync(existing.localPath);
        let size = 0;
        let sha = existing.sha256;
        let isNonEmpty = false;
        if (exists) {
            try {
                const stat = statSync(existing.localPath);
                size = stat.size;
                isNonEmpty = size > 0;
                if (isNonEmpty) {
                    const buf = readFileSync(existing.localPath);
                    sha = createHash("sha256").update(buf).digest("hex");
                }
            }
            catch {
                // failed reading
            }
        }
        const shaMatches = !exists || !isNonEmpty ? false : sha === existing.sha256;
        const ok = exists && isNonEmpty && shaMatches;
        return {
            id: existing.id,
            name: existing.name,
            kind: existing.kind,
            mime: existing.mime,
            sizeBytes: size,
            sha256: sha,
            urlPath: existing.urlPath,
            localPath: existing.localPath,
            existsOnDisk: exists,
            isNonEmpty,
            deliveryStatus: ok ? "DELIVERED" : "DELIVERY_FAILED",
            error: !exists
                ? `Artifact file missing from disk: ${existing.localPath}`
                : !isNonEmpty
                    ? `Artifact file is empty (0 bytes)`
                    : !shaMatches
                        ? `Integrity hash mismatch: expected ${existing.sha256}, calculated ${sha}`
                        : undefined,
        };
    }
    // Otherwise, treat as a workspace file path to register & verify
    const fullPath = isAbsolute(sourcePathOrId)
        ? sourcePathOrId
        : resolve(process.env.AC_WORKSPACE || process.cwd(), sourcePathOrId);
    if (!existsSync(fullPath)) {
        return {
            id: "",
            name: options.name || basename(fullPath),
            kind: options.expectedKind || "file",
            mime: "application/octet-stream",
            sizeBytes: 0,
            sha256: "",
            urlPath: "",
            localPath: fullPath,
            existsOnDisk: false,
            isNonEmpty: false,
            deliveryStatus: "DELIVERY_FAILED",
            error: `File does not exist: ${sourcePathOrId}`,
        };
    }
    let buf;
    try {
        buf = readFileSync(fullPath);
    }
    catch (err) {
        return {
            id: "",
            name: options.name || basename(fullPath),
            kind: options.expectedKind || "file",
            mime: "application/octet-stream",
            sizeBytes: 0,
            sha256: "",
            urlPath: "",
            localPath: fullPath,
            existsOnDisk: true,
            isNonEmpty: false,
            deliveryStatus: "DELIVERY_FAILED",
            error: `Could not read file: ${err.message}`,
        };
    }
    if (buf.byteLength === 0) {
        return {
            id: "",
            name: options.name || basename(fullPath),
            kind: options.expectedKind || "file",
            mime: "application/octet-stream",
            sizeBytes: 0,
            sha256: "",
            urlPath: "",
            localPath: fullPath,
            existsOnDisk: true,
            isNonEmpty: false,
            deliveryStatus: "DELIVERY_FAILED",
            error: `Artifact is empty (0 bytes)`,
        };
    }
    if (options.minBytes && buf.byteLength < options.minBytes) {
        return {
            id: "",
            name: options.name || basename(fullPath),
            kind: options.expectedKind || "file",
            mime: "application/octet-stream",
            sizeBytes: buf.byteLength,
            sha256: "",
            urlPath: "",
            localPath: fullPath,
            existsOnDisk: true,
            isNonEmpty: true,
            deliveryStatus: "DELIVERY_FAILED",
            error: `Artifact size (${buf.byteLength} bytes) is below minimum required (${options.minBytes} bytes)`,
        };
    }
    // Register through ArtifactManager
    try {
        const record = defaultArtifactManager.registerArtifact(fullPath, {
            name: options.name || basename(fullPath),
            visibility: "user_visible",
            metadata: {
                turnId: options.turnId,
                threadId: options.threadId,
            },
        });
        return {
            id: record.id,
            name: record.name,
            kind: record.kind,
            mime: record.mime,
            sizeBytes: record.sizeBytes,
            sha256: record.sha256,
            urlPath: record.urlPath,
            localPath: record.localPath,
            existsOnDisk: true,
            isNonEmpty: true,
            deliveryStatus: "DELIVERED",
        };
    }
    catch (regErr) {
        return {
            id: "",
            name: options.name || basename(fullPath),
            kind: options.expectedKind || "file",
            mime: "application/octet-stream",
            sizeBytes: buf.byteLength,
            sha256: createHash("sha256").update(buf).digest("hex"),
            urlPath: "",
            localPath: fullPath,
            existsOnDisk: true,
            isNonEmpty: true,
            deliveryStatus: "DELIVERY_FAILED",
            error: `Registration failed: ${regErr.message}`,
        };
    }
}
/**
 * Authoritative Evaluation:
 * Computes the truthful completion state by cross-evaluating execution,
 * validation, and delivery. Guarantees that:
 * 1. Execution success != Validation success != Delivery success.
 * 2. Missing/empty deliverables prevent COMPLETED classification.
 * 3. Inaccessible local preview cannot be represented as public deployment.
 * 4. Failed delivery is truthfully surfaced in overall status.
 */
export function evaluateTaskCompletion(params) {
    const operationsCompleted = params.execution.operationsCompleted || [];
    const operationsFailed = params.execution.operationsFailed || [];
    const reqs = params.requirements || [];
    // 1. Evaluate Requirements & Validation
    let checksPassed = 0;
    let checksFailed = 0;
    let checksUntested = 0;
    for (const r of reqs) {
        if (r.status === "SATISFIED")
            checksPassed++;
        else if (r.status === "VIOLATED")
            checksFailed++;
        else
            checksUntested++;
    }
    // Record test execution telemetry
    const suiteResults = params.testSuiteResults;
    const testExecutionFailed = Boolean(suiteResults &&
        (suiteResults.failed > 0 ||
            (suiteResults.exitCode !== undefined && suiteResults.exitCode !== 0)));
    const testExecutionPassed = Boolean(suiteResults &&
        !testExecutionFailed &&
        suiteResults.passed > 0);
    const executionVerified = testExecutionPassed;
    // Requirement verification: distinct from execution verification
    const requirementsVerified = reqs.length > 0 &&
        checksPassed === reqs.length &&
        checksFailed === 0 &&
        checksUntested === 0;
    let valStatus = reqs.length > 0 || suiteResults ? "UNVERIFIED" : "VERIFIED";
    if (reqs.length > 0) {
        if (checksFailed > 0 || testExecutionFailed) {
            valStatus = "FAILED";
        }
        else if (checksUntested > 0 || (suiteResults && suiteResults.skipped > 0)) {
            valStatus = checksPassed > 0 ? "PARTIALLY_VERIFIED" : "UNVERIFIED";
        }
        else if (checksPassed === reqs.length) {
            valStatus = "VERIFIED";
        }
    }
    else if (suiteResults) {
        if (testExecutionFailed) {
            valStatus = "FAILED";
        }
        else if (testExecutionPassed) {
            valStatus = suiteResults.skipped > 0 ? "PARTIALLY_VERIFIED" : "VERIFIED";
        }
    }
    // 2. Evaluate Delivery
    const verifiedArtifacts = [];
    let deliveryFailedCount = 0;
    let deliveredCount = 0;
    for (const item of params.artifacts || []) {
        const verified = typeof item === "string"
            ? verifyArtifactForDelivery(item, {
                turnId: params.turnId,
                threadId: params.threadId,
            })
            : item;
        verifiedArtifacts.push(verified);
        if (verified.deliveryStatus === "DELIVERED")
            deliveredCount++;
        else
            deliveryFailedCount++;
    }
    let deliveryStatus = "NOT_APPLICABLE";
    if (verifiedArtifacts.length > 0) {
        if (deliveryFailedCount === 0 && deliveredCount > 0) {
            deliveryStatus = "DELIVERED";
        }
        else if (deliveredCount > 0 && deliveryFailedCount > 0) {
            deliveryStatus = "PARTIALLY_DELIVERED";
        }
        else {
            deliveryStatus = "DELIVERY_FAILED";
        }
    }
    // 3. Evaluate Preview
    const preview = params.previewUrl
        ? classifyPreviewUrl(params.previewUrl, params.previewOptions)
        : undefined;
    // 4. Derive Truthful Overall Status
    const blockingErrors = [];
    const remainingWork = [];
    if (params.execution.error)
        blockingErrors.push(`Execution error: ${params.execution.error}`);
    if (operationsFailed.length > 0) {
        blockingErrors.push(`Operations failed: ${operationsFailed.join(", ")}`);
    }
    for (const r of reqs) {
        if (r.status === "VIOLATED") {
            blockingErrors.push(`Requirement violated: ${r.requirement}${r.failureReason ? ` (${r.failureReason})` : ""}`);
        }
        else if (r.status === "NOT_RUN") {
            remainingWork.push(`Requirement unverified: ${r.requirement}`);
        }
    }
    for (const a of verifiedArtifacts) {
        if (a.deliveryStatus !== "DELIVERED") {
            blockingErrors.push(`Artifact delivery failed for ${a.name}: ${a.error || "unavailable"}`);
        }
    }
    const requiresAccessiblePreview = Boolean(params.requiredAccessiblePreview ||
        params.previewOptions?.requiredAccessiblePreview ||
        reqs.some((r) => /accessible (?:preview|app|application)|working (?:preview|app)|mobile (?:preview|access)|public (?:deployment|preview)/i.test(r.requirement)) ||
        /accessible (?:preview|app|application)|working (?:preview|app)|mobile (?:preview|access)|public (?:deployment|preview)/i.test(params.objective));
    if (requiresAccessiblePreview) {
        if (!preview || !preview.isMobileAccessible) {
            blockingErrors.push(`Accessible working preview was explicitly required, but URL is ${preview ? `host loopback only (${preview.rawUrl})` : "missing"}. Inaccessible to mobile companion without port forwarding.`);
        }
    }
    let overallStatus = "RUNNING";
    if (params.execution.status === "FAILED") {
        overallStatus = "FAILED";
    }
    else if (params.execution.status === "RUNNING") {
        overallStatus = "RUNNING";
    }
    else if (params.execution.status === "NOT_STARTED") {
        overallStatus = "QUEUED";
    }
    else if (params.execution.status === "INTERRUPTED") {
        overallStatus = "CANCELLED";
    }
    else {
        // Execution SUCCEEDED: evaluate validation and delivery
        const hasDeliveryDefect = deliveryStatus === "DELIVERY_FAILED" || deliveryStatus === "PARTIALLY_DELIVERED";
        const hasValidationDefect = valStatus === "FAILED" || valStatus === "PARTIALLY_VERIFIED" || (reqs.length > 0 && valStatus === "UNVERIFIED");
        if (valStatus === "FAILED") {
            overallStatus = "FAILED";
        }
        else if (hasDeliveryDefect && deliveredCount === 0 && checksPassed === 0) {
            overallStatus = "FAILED";
        }
        else if (hasDeliveryDefect || hasValidationDefect || remainingWork.length > 0 || (requiresAccessiblePreview && (!preview || !preview.isMobileAccessible))) {
            overallStatus = "PARTIALLY_COMPLETED";
        }
        else {
            overallStatus = "COMPLETED";
        }
    }
    let evidenceSummary = "";
    if (suiteResults) {
        const exitStr = suiteResults.exitCode !== undefined ? `, exit ${suiteResults.exitCode}` : "";
        const testExecStr = `Execution verification: ${suiteResults.passed}/${suiteResults.total} tests passed (${suiteResults.failed} failed, ${suiteResults.skipped} skipped${exitStr})`;
        if (reqs.length > 0) {
            const reqStr = `Requirement verification: ${checksPassed}/${reqs.length} satisfied (${checksFailed} failed, ${checksUntested} untested)`;
            evidenceSummary = `${testExecStr}. ${reqStr}.`;
        }
        else {
            evidenceSummary = `${testExecStr}. No requirement checklist defined.`;
        }
    }
    else if (reqs.length > 0) {
        evidenceSummary = `Requirement verification: ${checksPassed}/${reqs.length} satisfied (${checksFailed} failed, ${checksUntested} untested)`;
    }
    else {
        evidenceSummary = "No automated verification checks executed";
    }
    const validationSummary = {
        status: valStatus,
        checksTotal: reqs.length,
        checksPassed,
        checksFailed,
        checksUntested,
        testSuiteResults: suiteResults,
        executionVerified,
        requirementsVerified,
        evidenceSummary,
    };
    const deliveryError = deliveryFailedCount > 0
        ? `${deliveryFailedCount} artifact(s) failed delivery`
        : undefined;
    const defaultSummary = formatTruthfulCompletionSummary({
        taskId: params.taskId,
        title: params.title,
        objective: params.objective,
        overallStatus,
        execution: {
            status: params.execution.status,
            operationsCompleted,
            operationsFailed,
            error: params.execution.error,
        },
        validation: validationSummary,
        requirements: reqs,
        delivery: {
            status: deliveryStatus,
            artifacts: verifiedArtifacts,
            preview,
            error: deliveryError,
        },
        summary: params.summary || "",
        remainingWork,
        blockingErrors,
        completedAt: overallStatus === "COMPLETED" || overallStatus === "PARTIALLY_COMPLETED" || overallStatus === "FAILED"
            ? new Date().toISOString()
            : undefined,
    });
    return {
        taskId: params.taskId,
        threadId: params.threadId,
        turnId: params.turnId,
        title: params.title,
        objective: params.objective,
        overallStatus,
        execution: {
            status: params.execution.status,
            operationsCompleted,
            operationsFailed,
            error: params.execution.error,
        },
        validation: validationSummary,
        requirements: reqs,
        delivery: {
            status: deliveryStatus,
            artifacts: verifiedArtifacts,
            preview,
            error: deliveryError,
        },
        summary: params.summary || defaultSummary,
        remainingWork,
        blockingErrors,
        completedAt: overallStatus === "COMPLETED" || overallStatus === "PARTIALLY_COMPLETED" || overallStatus === "FAILED"
            ? new Date().toISOString()
            : undefined,
    };
}
/**
 * Format a human-friendly, evidence-grounded completion summary without false claims.
 */
export function formatTruthfulCompletionSummary(contract) {
    const parts = [];
    // Status headline
    if (contract.overallStatus === "COMPLETED") {
        parts.push(`### Task Completed: ${contract.title}`);
    }
    else if (contract.overallStatus === "PARTIALLY_COMPLETED") {
        parts.push(`### Task Partially Completed: ${contract.title}`);
    }
    else if (contract.overallStatus === "FAILED") {
        parts.push(`### Task Execution Failed: ${contract.title}`);
    }
    else {
        parts.push(`### Task Status [${contract.overallStatus}]: ${contract.title}`);
    }
    // Objective
    if (contract.objective) {
        parts.push(`**Objective**: ${contract.objective}`);
    }
    // Execution Summary
    if (contract.execution.operationsCompleted.length > 0) {
        parts.push(`**Completed Operations**:\n${contract.execution.operationsCompleted.map((op) => `- ${op}`).join("\n")}`);
    }
    // Validation Results
    parts.push(`**Validation**: ${contract.validation.evidenceSummary}`);
    if (contract.requirements.length > 0) {
        const list = contract.requirements.map((r) => {
            const mark = r.status === "SATISFIED" ? "[PASS]" : r.status === "VIOLATED" ? "[FAIL]" : "[UNTESTED]";
            return `- ${mark} ${r.requirement}${r.evidence ? ` (Evidence: ${r.evidence})` : ""}${r.failureReason ? ` (Failure: ${r.failureReason})` : ""}`;
        });
        parts.push(`**Requirement Checklist**:\n${list.join("\n")}`);
    }
    // Deliverables
    if (contract.delivery.artifacts.length > 0) {
        const artLines = contract.delivery.artifacts.map((a) => {
            if (a.deliveryStatus === "DELIVERED") {
                return `- **${a.name}** (${a.kind}, ${a.sizeBytes} bytes, SHA-256: \`${a.sha256.slice(0, 10)}...\`): Verified on disk and delivered at \`${a.urlPath}\``;
            }
            return `- **${a.name}** [DELIVERY FAILED]: ${a.error || "File could not be found or delivered"}`;
        });
        parts.push(`**Deliverables**:\n${artLines.join("\n")}`);
    }
    // Preview & Deployment
    if (contract.delivery.preview && contract.delivery.preview.tier !== "NONE") {
        const prev = contract.delivery.preview;
        parts.push(`**Preview Tier**: ${prev.tier}`);
        parts.push(`**Preview URL**: ${prev.rawUrl}`);
        parts.push(`**Access Guidance**: ${prev.accessInstructions}`);
        if (prev.warning) {
            parts.push(`> [!WARNING]\n> ${prev.warning}`);
        }
    }
    // Remaining Work / Blocking Errors
    if (contract.blockingErrors.length > 0) {
        parts.push(`> [!CAUTION]\n> **Blocking Issues**:\n> ${contract.blockingErrors.join("\n> ")}`);
    }
    if (contract.remainingWork.length > 0) {
        parts.push(`**Remaining Work**:\n${contract.remainingWork.map((rw) => `- ${rw}`).join("\n")}`);
    }
    return parts.join("\n\n");
}
export function extractTestSuiteResultsFromTools(tools) {
    const testTools = tools.filter((t) => /test|jest|vitest|pytest|cargo test|npm test/i.test(t.name) ||
        (typeof t.output === "string" && /tests?\s+(?:passed|failed)/i.test(t.output)) ||
        (typeof t.input === "string" && /npm test|vitest|pytest|cargo test/i.test(t.input)));
    if (testTools.length === 0)
        return undefined;
    let totalPassed = 0;
    let totalFailed = 0;
    let totalSkipped = 0;
    let totalTests = 0;
    let command = undefined;
    let hasParsedCounts = false;
    let exitCode = 0;
    for (const t of testTools) {
        if (t.ok === false)
            exitCode = 1;
        if (typeof t.exitCode === "number" && t.exitCode !== 0) {
            exitCode = t.exitCode;
        }
        if (!command && (t.input || t.name))
            command = String(t.input || t.name);
        const out = typeof t.output === "string" ? t.output : "";
        if (!out)
            continue;
        const passMatch = out.match(/(\d+)\s+passed/i);
        const failMatch = out.match(/(\d+)\s+failed/i);
        const skipMatch = out.match(/(\d+)\s+(?:skipped|todo|pending|ignored)/i);
        const totalMatch = out.match(/(\d+)\s+total/i);
        if (passMatch || failMatch || skipMatch) {
            hasParsedCounts = true;
            const p = passMatch ? parseInt(passMatch[1], 10) : 0;
            const f = failMatch ? parseInt(failMatch[1], 10) : 0;
            const s = skipMatch ? parseInt(skipMatch[1], 10) : 0;
            const tot = totalMatch ? parseInt(totalMatch[1], 10) : (p + f + s);
            totalPassed += p;
            totalFailed += f;
            totalSkipped += s;
            totalTests += tot;
        }
    }
    if (!hasParsedCounts) {
        const anyFailed = testTools.some((t) => t.ok === false);
        return {
            total: testTools.length,
            passed: anyFailed ? 0 : testTools.length,
            failed: anyFailed ? testTools.filter((t) => t.ok === false).length : 0,
            skipped: 0,
            exitCode,
            command,
        };
    }
    return {
        total: Math.max(totalTests, totalPassed + totalFailed + totalSkipped),
        passed: totalPassed,
        failed: totalFailed,
        skipped: totalSkipped,
        exitCode,
        command,
    };
}
/**
 * Shared Authoritative Completion Evaluator for Direct Conversational Execution.
 *
 * Enforces the identical three-pillar completion contract (Execution, Validation, Delivery)
 * on direct conversational turns (POST /api/bots/:id/messages) that perform autonomous work,
 * ensuring no weakened reliability guarantees exist between execution paths while preserving
 * normal low-latency behavior for ordinary conversational Q&A.
 */
export function evaluateDirectTurnCompletion(options) {
    const userPrompt = (options.userPrompt || "").trim();
    const assistantText = options.assistantText || "";
    const tools = options.toolActivities || [];
    const actionReceipts = options.actionReceipts || (options.threadId ? getActionReceipts(options.threadId, options.turnId) : []);
    const workspacePath = options.workspacePath || process.cwd();
    // 1. Discover Deliverables & Candidate Files
    const candidateFiles = new Set();
    // Claimed file deliverables in assistant text
    const fileClaims = assistantText.matchAll(/(?:created|generated|saved|written|produced|exported|built|delivered|output)\s+(?:the\s+)?(?:file\s+)?["'`]?([a-zA-Z0-9_\-./\\]+\.[a-zA-Z0-9]+)["'`]?/gi);
    for (const m of fileClaims) {
        if (m[1])
            candidateFiles.add(m[1].trim());
    }
    // Explicit attachment links in assistant text
    const attachmentLinks = assistantText.matchAll(/(?:attachment:|\/api\/attachments\/)([a-zA-Z0-9_\-./\\]+\.[a-zA-Z0-9]+)/gi);
    for (const m of attachmentLinks) {
        if (m[1])
            candidateFiles.add(m[1].trim());
    }
    // File creation requested in user prompt
    const requestedFiles = userPrompt.matchAll(/\b(?:create|generate|write|build|make|export|produce)\b.*?["'`]?([a-zA-Z0-9_\-./\\]+\.(?:xlsx|xls|csv|pdf|docx|pptx|md|py|js|ts|json|txt|html|zip|tar\.gz))["'`]?/gi);
    for (const m of requestedFiles) {
        if (m[1])
            candidateFiles.add(m[1].trim());
    }
    // Files passed from registeredArtifacts option
    for (const a of options.registeredArtifacts || []) {
        if (a.name)
            candidateFiles.add(a.name);
    }
    // Filter out URLs, non-deliverable file extensions, and generic domains
    const validCandidates = [];
    for (const f of candidateFiles) {
        const base = basename(f);
        if (/^(?:https?|ftp):\/\//i.test(f))
            continue;
        if (/\.(?:com|org|net|io|gov|dev|app|edu|co|ai)$/i.test(base))
            continue;
        if (base.length > 2 && !validCandidates.includes(base)) {
            validCandidates.push(base);
        }
    }
    // Verify candidate artifacts on disk / via defaultArtifactManager
    const verifiedArtifacts = [];
    for (const candidate of validCandidates) {
        const reg = defaultArtifactManager.getArtifact(candidate) ||
            defaultArtifactManager.listArtifacts().find((a) => a.name === candidate || basename(a.urlPath) === candidate);
        const diskPath = isAbsolute(candidate) ? candidate : resolve(workspacePath, candidate);
        const exists = existsSync(diskPath);
        if (exists) {
            const stats = statSync(diskPath);
            const isNonEmpty = stats.size > 0;
            if (isNonEmpty) {
                let finalReg = reg;
                if (!finalReg) {
                    try {
                        finalReg = defaultArtifactManager.registerArtifact(diskPath, {
                            name: candidate,
                            visibility: "user_visible",
                        });
                    }
                    catch {
                        // keep unmanaged if registration failed
                    }
                }
                verifiedArtifacts.push(verifyArtifactForDelivery(diskPath, {
                    threadId: options.threadId,
                    turnId: options.turnId,
                }));
            }
            else {
                verifiedArtifacts.push({
                    id: `empty-${candidate}`,
                    name: candidate,
                    kind: "document",
                    mime: "application/octet-stream",
                    sizeBytes: 0,
                    sha256: "",
                    urlPath: "",
                    localPath: diskPath,
                    existsOnDisk: true,
                    isNonEmpty: false,
                    deliveryStatus: "DELIVERY_FAILED",
                    error: "file is empty (0 bytes)",
                });
            }
        }
        else if (reg && existsSync(reg.localPath)) {
            verifiedArtifacts.push(verifyArtifactForDelivery(reg.localPath, {
                threadId: options.threadId,
                turnId: options.turnId,
            }));
        }
        else {
            verifiedArtifacts.push({
                id: `missing-${candidate}`,
                name: candidate,
                kind: "document",
                mime: "application/octet-stream",
                sizeBytes: 0,
                sha256: "",
                urlPath: "",
                localPath: diskPath,
                existsOnDisk: false,
                isNonEmpty: false,
                deliveryStatus: "DELIVERY_FAILED",
                error: "file does not exist on disk",
            });
        }
    }
    // 2. Discover Validation & Test Verification
    const reqs = options.requirements ? [...options.requirements] : [];
    const claimsTestSuccess = /\b(?:(?:all\s+)?tests?\s+(?:pass(?:ed|ing)?|succeeded|verified)|implementation\s+verified|verified\s+with\s+tests?)\b/i.test(assistantText);
    const requiresTesting = /\b(?:test|tests|verify|run\s+tests?|check\s+that)\b/i.test(userPrompt);
    const testSuiteResults = options.testSuiteResults || extractTestSuiteResultsFromTools(tools);
    const testTools = tools.filter((t) => /test|jest|vitest|pytest|cargo test|npm test/i.test(t.name) ||
        (typeof t.output === "string" && /tests?\s+(?:passed|failed)/i.test(t.output)) ||
        (typeof t.input === "string" && /npm test|vitest|pytest|cargo test/i.test(t.input)));
    if (claimsTestSuccess) {
        if (!testSuiteResults && testTools.length === 0) {
            reqs.push({
                id: "req-test-exec",
                requirement: "Automated test execution",
                status: "NOT_RUN",
                failureReason: "No automated test execution was observed during this turn",
            });
        }
        else if (testSuiteResults && (testSuiteResults.failed > 0 || (testSuiteResults.exitCode !== undefined && testSuiteResults.exitCode !== 0))) {
            reqs.push({
                id: "req-test-exec",
                requirement: "Automated test execution",
                status: "VIOLATED",
                failureReason: `${testSuiteResults.failed} test(s) failed in ${testSuiteResults.command || "test runner"}`,
            });
        }
        else if (testTools.some((t) => t.ok === false)) {
            const err = testTools.find((t) => t.ok === false)?.error;
            reqs.push({
                id: "req-test-exec",
                requirement: "Automated test execution",
                status: "VIOLATED",
                failureReason: String(err || "Test execution returned failure"),
            });
        }
        else {
            const summaryStr = testSuiteResults
                ? `${testSuiteResults.passed}/${testSuiteResults.total} tests passed (exit ${testSuiteResults.exitCode ?? 0})`
                : "Automated test tool executed with passing status";
            reqs.push({
                id: "req-test-exec",
                requirement: "Automated test execution",
                status: "SATISFIED",
                evidence: summaryStr,
            });
        }
    }
    else if (requiresTesting && !testSuiteResults && testTools.length === 0 && reqs.length === 0) {
        reqs.push({
            id: "req-test-required",
            requirement: "Verify functionality with automated tests",
            status: "NOT_RUN",
            failureReason: "Testing was requested but no test commands were executed",
        });
    }
    // 3. Discover Preview & Deployment
    const urlMatch = assistantText.match(/(https?:\/\/(?:localhost|127\.0\.0\.1|[\w.-]+)(?::\d+)?(?:\/[^\s)\]]*)?)/i);
    const previewUrl = urlMatch ? urlMatch[1] : undefined;
    const requiredAccessiblePreview = Boolean(options.requiredAccessiblePreview ||
        /\b(?:accessible\s+(?:working\s+)?preview|mobile\s+preview|working\s+preview|public\s+preview)\b/i.test(userPrompt));
    // 4. Discover Operations Completed & Failed
    const operationsCompleted = tools.filter((t) => t.ok !== false).map((t) => t.name);
    const operationsFailed = tools.filter((t) => t.ok === false).map((t) => `${t.name}${t.error ? `: ${String(t.error)}` : ""}`);
    // 5. Determine Autonomous Work Classification
    const isAutonomous = tools.length > 0 ||
        validCandidates.length > 0 ||
        reqs.length > 0 ||
        Boolean(testSuiteResults) ||
        Boolean(previewUrl) ||
        Boolean(actionReceipts.length);
    // Ordinary conversational path: zero latency overhead, zero modification
    if (!isAutonomous) {
        return {
            isAutonomousWork: false,
            text: assistantText,
            corrected: false,
            overallStatus: "COMPLETED",
            blockingErrors: [],
        };
    }
    // 6. Evaluate via Authoritative Tripartite Contract
    const contract = evaluateTaskCompletion({
        taskId: options.turnId || `turn-${Date.now()}`,
        title: userPrompt ? userPrompt.slice(0, 80) : "Autonomous Direct Turn",
        objective: userPrompt || assistantText.slice(0, 120),
        threadId: options.threadId,
        turnId: options.turnId,
        execution: {
            status: operationsFailed.length > 0 && operationsCompleted.length === 0 ? "FAILED" : "SUCCEEDED",
            operationsCompleted,
            operationsFailed,
            error: operationsFailed.length > 0 ? operationsFailed.join("; ") : undefined,
        },
        requirements: reqs,
        testSuiteResults,
        artifacts: verifiedArtifacts,
        previewUrl,
        requiredAccessiblePreview,
    });
    // 7. Enforce Truthful Delivery and Validation in User-Facing Response
    let correctedText = assistantText;
    let corrected = false;
    if (contract.overallStatus !== "COMPLETED") {
        // Missing or 0-byte deliverables
        const failedDeliveries = contract.delivery.artifacts.filter((a) => a.deliveryStatus !== "DELIVERED");
        if (failedDeliveries.length > 0) {
            correctedText += `\n\n> [!CAUTION]\n> **Deliverable Incomplete**: ${failedDeliveries.map((a) => `Artifact "${a.name}" ${a.error || "missing or 0 bytes"}`).join(", ")}. Full completion cannot be claimed.`;
            corrected = true;
        }
        // Unverified claimed tests
        if (contract.requirements.some((r) => r.id === "req-test-exec" && r.status === "NOT_RUN")) {
            correctedText += `\n\n> [!WARNING]\n> **Validation Unverified**: Response claimed test success, but no automated test execution was observed during this turn.`;
            corrected = true;
        }
        // Violated requirements
        const violatedReqs = contract.requirements.filter((r) => r.status === "VIOLATED");
        if (violatedReqs.length > 0) {
            correctedText += `\n\n> [!CAUTION]\n> **Validation Failed**: Requirement checks failed: ${violatedReqs.map((r) => `${r.requirement}${r.failureReason ? ` (${r.failureReason})` : ""}`).join("; ")}.`;
            corrected = true;
        }
        // Untested requirements
        const untestedReqs = contract.requirements.filter((r) => r.id !== "req-test-exec" && r.status === "NOT_RUN");
        if (untestedReqs.length > 0) {
            correctedText += `\n\n> [!WARNING]\n> **Verification Incomplete**: Requirements unverified:\n${untestedReqs.map((r) => `> - ${r.requirement}`).join("\n")}`;
            corrected = true;
        }
        // Inaccessible preview (Case 7)
        if (requiredAccessiblePreview && contract.delivery.preview && !contract.delivery.preview.isMobileAccessible) {
            correctedText += `\n\n> [!CAUTION]\n> **Accessible Preview Incomplete**: Accessible working preview was explicitly required, but URL is host loopback only (${contract.delivery.preview.rawUrl}). Inaccessible to mobile companion without port forwarding.`;
            corrected = true;
        }
        // Failed tool operations (Requirement 9)
        if (operationsFailed.length > 0) {
            correctedText += `\n\n> [!CAUTION]\n> **Tool Execution Failure**: Tool operations failed during execution: ${operationsFailed.join(", ")}. Operation failure cannot be ignored.`;
            corrected = true;
        }
    }
    else {
        // Succeeded! If preview is host loopback and no public deployment was required, append note (Case 8)
        if (contract.delivery.preview && contract.delivery.preview.tier === "HOST_LOOPBACK" && !requiredAccessiblePreview) {
            correctedText += `\n\n> [!NOTE]\n> Preview is available at host loopback (${contract.delivery.preview.rawUrl}) for local access.`;
            corrected = true;
        }
    }
    return {
        isAutonomousWork: true,
        contract,
        text: correctedText,
        corrected,
        overallStatus: contract.overallStatus,
        blockingErrors: contract.blockingErrors,
    };
}
