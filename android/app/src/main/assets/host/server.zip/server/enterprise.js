var __rewriteRelativeImportExtension = (this && this.__rewriteRelativeImportExtension) || function (path, preserveJsx) {
    if (typeof path === "string" && /^\.\.?\//.test(path)) {
        return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function (m, tsx, d, ext, cm) {
            return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : (d + ext + "." + cm.toLowerCase() + "js");
        });
    }
    return path;
};
// Neutral hook point for the source-available enterprise layer.
//
// The layer lives in ../enterprise (its own LICENSE) and is loaded only if that
// folder is present: delete it and this file still compiles, the server still
// starts, and /api/edition reports the open-source edition. Core never imports
// the layer statically, so the bundle and the packaged app carry no trace of it.
// The layer's only obligation is `register()`, which turns OMB_LICENSE_KEY into
// entitlements; core keeps the resulting status and answers `entitled()`.
import { existsSync } from "node:fs";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import { z } from "zod";
import { SERVER_ROOT } from "./proxy-paths.js";
/** What the enterprise layer's register() must return; validated because it is external code. */
const layerSchema = z.object({
    customer: z.string().min(1),
    features: z.array(z.string().min(1)),
    expiresAt: z.string().nullable(),
});
const DEFAULT_DIR = join(SERVER_ROOT, "..", "enterprise");
let current = { edition: "oss", features: [] };
let workspaceAccessFactory;
export function hostedWorkspaceConfigured(env = process.env) {
    return env.OMB_ADMIN_URL !== undefined || env.OMB_ADMIN_WORKSPACE !== undefined || env.OMB_ADMIN_MEMBERSHIP !== undefined;
}
/** Validate the operator's complete hosted configuration before any session
 * can delegate membership authority. A partial setting is never standalone. */
export function hostedWorkspaceConfiguration(env = process.env) {
    try {
        const origin = (raw) => {
            if (!raw || raw !== raw.trim())
                throw new Error("missing origin");
            const url = new URL(raw);
            if (url.protocol !== "https:" || (raw !== url.origin && raw !== `${url.origin}/`))
                throw new Error("invalid origin");
            return url;
        };
        if (!/^[a-z][a-z0-9-]{1,30}$/.test(env.OMB_ADMIN_WORKSPACE ?? ""))
            return null;
        if (env.OMB_ADMIN_MEMBERSHIP !== undefined && !["local", "portal"].includes(env.OMB_ADMIN_MEMBERSHIP))
            return null;
        return { admin: origin(env.OMB_ADMIN_URL), tenant: origin(env.OMB_PUBLIC_URL), workspace: env.OMB_ADMIN_WORKSPACE, portalMembership: env.OMB_ADMIN_MEMBERSHIP === "portal" };
    }
    catch {
        return null;
    }
}
/** No enterprise import or portal dependency enters the core bundle. A
 * configured server without this hook must refuse hosted access, not fall
 * back to legacy email or QR credentials. */
export function createWorkspaceAccess(options) {
    if (!hostedWorkspaceConfigured(options.env))
        return null;
    return workspaceAccessFactory?.({ ...options, entitled: () => entitled("admin") }) ?? null;
}
function oss(notice) {
    current = notice ? { edition: "oss", features: [], notice } : { edition: "oss", features: [] };
    return current;
}
/** Resolve the edition once at startup. Never throws: a broken layer or key
 * degrades to the open-source edition with a notice that says what to fix. */
export async function loadEnterpriseLayer(options = {}) {
    workspaceAccessFactory = undefined;
    const dir = options.dir ?? process.env.OMB_ENTERPRISE_DIR ?? DEFAULT_DIR;
    const licenseKey = options.licenseKey ?? process.env.OMB_LICENSE_KEY;
    // Source in a checkout, a compiled bundle in an image: same convention as proxy-paths.ts.
    const entry = [join(dir, "server", "index.ts"), join(dir, "server", "index.js")].find((candidate) => existsSync(candidate));
    if (!entry) {
        return oss(licenseKey ? `OMB_LICENSE_KEY is set but no enterprise layer exists at ${dir}` : undefined);
    }
    try {
        const loaded = await import(__rewriteRelativeImportExtension(pathToFileURL(entry).href));
        const access = Reflect.get(Object(loaded), "createWorkspaceAccess");
        if (typeof access === "function")
            workspaceAccessFactory = access;
        const register = Reflect.get(Object(loaded), "register");
        if (typeof register !== "function")
            throw new Error(`${entry} does not export register()`);
        if (!licenseKey)
            return oss("enterprise layer present but OMB_LICENSE_KEY is not set");
        const registered = await register({ licenseKey });
        const layer = layerSchema.parse(registered);
        current = {
            edition: "enterprise",
            customer: layer.customer,
            features: [...new Set(layer.features)].sort(),
            expiresAt: layer.expiresAt,
        };
        return current;
    }
    catch (error) {
        return oss(`enterprise layer disabled: ${error instanceof Error ? error.message : String(error)}`);
    }
}
/** A license that expires while the server keeps running stops granting
 * features at that moment, not at the next restart. */
function expired(now) {
    if (current.edition !== "enterprise" || !current.expiresAt)
        return false;
    return now >= new Date(current.expiresAt).getTime();
}
export function editionStatus(now = Date.now()) {
    if (!expired(now))
        return current;
    return {
        edition: "oss",
        features: [],
        notice: `enterprise layer disabled: OMB_LICENSE_KEY expired on ${current.expiresAt}; renew it to keep enterprise features`,
    };
}
/** Feature gates in core ask this and nothing else. Unknown ids are simply not
 * granted, and the open-source edition always carries an empty feature list. */
export function entitled(feature, now = Date.now()) {
    return !expired(now) && current.features.includes(feature);
}
/** One line for the startup log. */
export function describeEdition(status) {
    if (status.edition === "enterprise") {
        const until = status.expiresAt ? ` until ${status.expiresAt}` : "";
        return `openmausbot enterprise edition for ${status.customer}${until}: ${status.features.join(", ") || "no features"}`;
    }
    return `openmausbot open-source edition${status.notice ? ` (${status.notice})` : ""}`;
}
