/**
 * One health verdict derived from the components that were actually checked.
 *
 * A system is never "healthy" just because the summary is convenient: an
 * unavailable component makes the whole thing unavailable, an unhealthy or
 * unchecked component can only lower the verdict, and every component keeps its
 * own status and timestamp so the reason survives the aggregation.
 */
const ORDER = ["healthy", "degraded", "unknown", "unavailable"];
function emptyCounts() {
    return { healthy: 0, degraded: 0, unknown: 0, unavailable: 0 };
}
/**
 * Aggregates component results:
 *   • nothing reported                  → unknown
 *   • any unavailable                   → unavailable
 *   • any degraded, or any unknown      → degraded
 *   • every component healthy           → healthy
 *
 * An `unknown` component means the check did not run, which is not evidence of
 * health: it degrades the verdict instead of being skipped.
 */
export function aggregateHealth(components) {
    const counts = emptyCounts();
    const byScope = {
        vm_infrastructure: [],
        external_service: [],
        platform: [],
    };
    for (const component of components) {
        counts[component.status] += 1;
        const scope = component.scope ?? "platform";
        byScope[scope].push(component);
    }
    if (components.length === 0) {
        return {
            status: "unknown",
            components: [],
            counts,
            byScope,
            summary: "No component has been checked yet.",
            problems: [],
        };
    }
    const status = counts.unknown === components.length
        ? "unknown"
        : counts.unavailable > 0
            ? "unavailable"
            : counts.degraded > 0 || counts.unknown > 0
                ? "degraded"
                : "healthy";
    const problems = components.filter((component) => component.status !== "healthy");
    return {
        status,
        components,
        counts,
        byScope,
        summary: summarise(status, components, counts),
        problems,
    };
}
function summarise(status, components, counts) {
    if (status === "healthy") {
        return `All ${components.length} ${components.length === 1 ? "component is" : "components are"} healthy.`;
    }
    const unavailable = components.filter((component) => component.status === "unavailable").map((component) => component.name);
    const degraded = components.filter((component) => component.status === "degraded").map((component) => component.name);
    const unknown = components.filter((component) => component.status === "unknown").map((component) => component.name);
    const parts = [];
    if (unavailable.length)
        parts.push(`unavailable: ${unavailable.join(", ")}`);
    if (degraded.length)
        parts.push(`degraded: ${degraded.join(", ")}`);
    if (unknown.length)
        parts.push(`not checked: ${unknown.join(", ")}`);
    const healthyCount = counts.healthy;
    const prefix = healthyCount > 0 ? `${healthyCount} healthy; ` : "";
    return `${prefix}${parts.join("; ")}.`;
}
/** True only when every reported component is healthy. */
export function isFullyHealthy(result) {
    return result.status === "healthy" && result.components.length > 0;
}
/**
 * The sentence a chat reply may use. It never upgrades a degraded or
 * unavailable system, and it keeps the failing component named.
 */
export function describeHealthForReply(result) {
    switch (result.status) {
        case "healthy":
            return `Everything checks out — all ${result.components.length} components are healthy.`;
        case "degraded":
            return `The system is degraded, not healthy. ${result.summary}`;
        case "unavailable":
            return `The system is unavailable. ${result.summary}`;
        default:
            return `I could not verify the system's health. ${result.summary}`;
    }
}
/** Severity ordering for display; higher is worse. */
export function healthSeverity(status) {
    return ORDER.indexOf(status);
}
