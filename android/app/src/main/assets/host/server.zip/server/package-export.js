import { parseBotPackage } from "./bot-package.js";
function portableKey(value, fallback, used) {
    const stem = value
        .normalize("NFKD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "")
        .slice(0, 48) || fallback;
    let key = stem;
    for (let suffix = 2; used.has(key); suffix++)
        key = `${stem}-${suffix}`;
    used.add(key);
    return key;
}
function samePlaybook(a, b) {
    return a.name === b.name && a.summary === b.summary && a.instructions === b.instructions &&
        a.triggers.join("\n") === b.triggers.join("\n");
}
/** Export a workspace definition, never its runtime state. Connected-app
 * labels are retained as setup intent, but grants, credentials, approvals,
 * transcripts, memory, paths, engines, and schedules' active state are not. */
export function createBotPackageExport(input) {
    const bots = input.bots.filter((bot) => !bot.hidden);
    if (!bots.length)
        throw new Error("Create a bot before exporting your package");
    const packageKeys = new Set();
    const idToKey = new Map();
    for (const [index, bot] of bots.entries()) {
        idToKey.set(bot.id, portableKey(bot.name, `bot-${index + 1}`, packageKeys));
    }
    const playbooks = [];
    const playbookKeys = new Set();
    const agentPlaybooks = new Map();
    const packageSkills = new Map();
    const agentSkills = new Map();
    for (const bot of bots) {
        const agentKey = idToKey.get(bot.id);
        const assigned = [];
        for (const playbook of bot.playbooks ?? []) {
            const existing = playbooks.find((candidate) => candidate.key === playbook.key);
            if (existing && samePlaybook(playbook, existing)) {
                assigned.push(existing.key);
                continue;
            }
            let key = playbook.key;
            if (existing)
                key = `${agentKey}-${playbook.key}`;
            key = portableKey(key, `${agentKey}-playbook`, playbookKeys);
            if (!playbooks.some((candidate) => candidate.key === key))
                playbooks.push({ ...playbook, key });
            assigned.push(key);
        }
        agentPlaybooks.set(bot.id, assigned);
        const assignedSkills = [];
        for (const skill of input.skillsByBot?.get(bot.id) ?? []) {
            const existing = packageSkills.get(skill.name);
            if (existing && (existing.instructions !== skill.instructions || existing.description !== skill.description ||
                existing.source !== skill.source || existing.license !== skill.license ||
                existing.compatibility !== skill.compatibility)) {
                throw new Error(`Skill "${skill.name}" has conflicting content across selected bots`);
            }
            if (!existing)
                packageSkills.set(skill.name, { ...skill });
            if (!assignedSkills.includes(skill.name))
                assignedSkills.push(skill.name);
        }
        agentSkills.set(bot.id, assignedSkills);
    }
    const requirements = new Map();
    for (const bot of bots) {
        for (const app of bot.installedPackage?.requiredApps ?? []) {
            if (!requirements.has(app.slug))
                requirements.set(app.slug, { ...app });
        }
    }
    const roomKeys = new Set();
    const rooms = [];
    for (const [index, group] of input.groups.filter((group) => !group.dm).entries()) {
        const members = group.memberIds.flatMap((id) => idToKey.has(id) ? [idToKey.get(id)] : []);
        if (!members.length)
            continue;
        const defaultResponder = group.defaultResponder.kind === "member" && idToKey.has(group.defaultResponder.botId)
            ? { kind: "agent", agent: idToKey.get(group.defaultResponder.botId) }
            : group.defaultResponder.kind === "everyone"
                ? { kind: "everyone" }
                : { kind: "mentions" };
        rooms.push({
            key: portableKey(group.name, `room-${index + 1}`, roomKeys),
            name: group.name,
            members,
            bulletin: group.bulletin,
            defaultResponder,
        });
    }
    const routineKeys = new Set();
    const routines = input.routines.flatMap((routine, index) => {
        // Package v1 only has a single-agent routine shape. Silently exporting a
        // room goal as a bot task would change what it does after import, so keep
        // it out until the portable format can name a package-local room.
        if (routine.target === "room-goal")
            return [];
        const agent = idToKey.get(routine.botId);
        if (!agent)
            return [];
        return [{
                key: portableKey(routine.name, `routine-${index + 1}`, routineKeys),
                name: routine.name,
                agent,
                prompt: routine.prompt,
                runOn: routine.runOn,
                schedule: routine.schedule.type === "once"
                    ? { type: "once", at: routine.schedule.at }
                    : routine.schedule.type === "cron"
                        ? { ...routine.schedule }
                        : routine.schedule.type === "interval"
                            ? {
                                type: "interval",
                                everyMinutes: routine.schedule.everyMinutes,
                                anchorAt: routine.schedule.anchorAt,
                                ...(routine.schedule.weekdays === undefined
                                    ? {}
                                    : { weekdays: [...routine.schedule.weekdays] }),
                                ...(routine.schedule.window === undefined
                                    ? {}
                                    : { window: { ...routine.schedule.window } }),
                                ...(routine.schedule.endsAt === undefined ? {} : { endsAt: routine.schedule.endsAt }),
                            }
                            : { type: "daily", time: routine.schedule.time, weekdays: [...routine.schedule.weekdays] },
                durationMinutes: routine.durationMinutes,
                ...(routine.timeoutMinutes === undefined ? {} : { timeoutMinutes: routine.timeoutMinutes }),
                enabledAfterInstall: false,
            }];
    });
    const id = portableKey(input.name, "openmaus-package", new Set());
    const agents = bots.map((bot) => {
        const appearance = { color: bot.color };
        if (bot.mascotExpression)
            appearance.mascotExpression = bot.mascotExpression;
        if (bot.mascotBody)
            appearance.mascotBody = bot.mascotBody;
        const agent = {
            key: idToKey.get(bot.id),
            name: bot.name,
            title: bot.title,
            description: bot.description,
            ...(bot.soul !== undefined ? { soul: bot.soul } : {}),
            appearance,
        };
        const assigned = agentPlaybooks.get(bot.id);
        if (assigned?.length)
            agent.playbooks = assigned;
        const assignedSkills = agentSkills.get(bot.id);
        if (assignedSkills?.length)
            agent.skills = assignedSkills;
        return agent;
    });
    const definition = {
        id,
        release: "1.0.0",
        name: input.name,
        tagline: `A portable OpenMausBot setup with ${bots.length} ${bots.length === 1 ? "bot" : "bots"}.`,
        summary: "Exported from OpenMausBot. Review the roles, rooms, playbooks, connector requirements, and paused routines before sharing or publishing.",
        category: "Community",
        author: { name: input.authorName?.trim() || "OpenMausBot user" },
        license: "Unspecified",
        outcomes: ["Recreate this bot setup without copying private runtime state."],
        setupMinutes: Math.min(240, Math.max(2, bots.length + requirements.size * 2)),
        requirements: { apps: [...requirements.values()], capabilities: [] },
        agents,
    };
    const chief = bots.find((bot) => bot.chiefOfStaff);
    if (chief)
        definition.chiefOfStaff = idToKey.get(chief.id);
    if (rooms.length)
        definition.rooms = rooms;
    if (routines.length)
        definition.routines = routines;
    if (playbooks.length)
        definition.playbooks = playbooks;
    if (packageSkills.size) {
        definition.skills = {
            version: 1,
            entries: [...packageSkills.values()].map((skill) => ({ ...skill })),
        };
    }
    return parseBotPackage({
        format: "openmaus.package",
        version: 1,
        package: definition,
    });
}
