/**
 * Types and interfaces for the Device Capability Registry (Phase P).
 *
 * Provides a clean, extensible abstraction layer over Android device actions
 * so the agent sees capabilities, schemas, and risk tiers rather than
 * implementation-specific Android internals.
 */
// ── Official Roadmap Phase 13: Capability State Awareness (mobot_54_phases_prompt.md:868-925) ──
export const ERR_CAPABILITY_PROBE_FAILED = 'ERR_CAPABILITY_PROBE_FAILED';
// ── Official Roadmap Phase 14: Risk-Aware Autonomy (mobot_54_phases_prompt.md:925-995) ──
export const ERR_CONFIRMATION_REQUIRED = 'ERR_CONFIRMATION_REQUIRED';
export const ERR_CONFIRMATION_REJECTED = 'ERR_CONFIRMATION_REJECTED';
export const ERR_CONFIRMATION_EXPIRED = 'ERR_CONFIRMATION_EXPIRED';
export const ERR_CONFIRMATION_INVALID = 'ERR_CONFIRMATION_INVALID';
// ── Official Roadmap Phase 11: Intelligent Capability Selection (mobot_54_phases_prompt.md:752-778) ──
export const ERR_NO_CAPABLE_TOOL = 'ERR_NO_CAPABLE_TOOL';
