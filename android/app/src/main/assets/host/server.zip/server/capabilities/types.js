/**
 * Types and interfaces for the Device Capability Registry (Phase P).
 *
 * Provides a clean, extensible abstraction layer over Android device actions
 * so the agent sees capabilities, schemas, and risk tiers rather than
 * implementation-specific Android internals.
 */
export {};
