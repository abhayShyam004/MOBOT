import { z } from "zod";
/**
 * `mascot` draws the animated mascot body, filled with the bot's colour
 * gradient. `circle`, `rounded`, and `square` crop the bot's own image
 * instead, shown as it is, with no mascot at all.
 */
export const BOT_AVATAR_CROPS = ["mascot", "circle", "rounded", "square"];
export const botAvatarCropSchema = z.enum(BOT_AVATAR_CROPS);
/**
 * Custom avatars are deliberately limited to this app's attachment server.
 * Besides making persisted profiles portable across desktop/browser clients,
 * this prevents a bot profile from becoming an external tracking pixel or a
 * script-capable SVG.
 */
export const botAvatarUrlSchema = z
    .string()
    .regex(/^\/api\/attachments\/[A-Za-z0-9-]+\.(?:png|jpg|gif|webp)$/, "must be a stored PNG, JPEG, GIF, or WebP attachment");
export function botAvatarUrlFromStoredPath(path) {
    const name = path.replaceAll("\\", "/").split("/").pop();
    if (!name)
        return null;
    const url = `/api/attachments/${name}`;
    return botAvatarUrlSchema.safeParse(url).success ? url : null;
}
export function botAvatarProfile(value) {
    const profile = {
        avatarCrop: botAvatarCropSchema.safeParse(value.avatarCrop).data ?? "mascot",
    };
    const url = botAvatarUrlSchema.safeParse(value.avatarUrl);
    if (url.success)
        profile.avatarUrl = url.data;
    return profile;
}
