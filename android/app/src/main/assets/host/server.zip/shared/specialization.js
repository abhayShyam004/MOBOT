/**
 * Authoritative Specialization Profile Data Contract (Phase 31).
 *
 * Defines the public specialization profile interface and role identifiers
 * shared across server, client, and wire transports.
 */
export {};
