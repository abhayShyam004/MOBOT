// server/android-browser.ts
import { createHash } from "node:crypto";
import { mkdirSync } from "node:fs";
var DRIVER_PORT = Number(process.env.AB_DRIVER_PORT ?? "0");
var DRIVER_TOKEN = process.env.AB_DRIVER_TOKEN ?? "";
if (!DRIVER_PORT || !DRIVER_TOKEN) {
  process.stderr.write("android-browser: AB_DRIVER_PORT/AB_DRIVER_TOKEN are not set \u2014 refusing to start\n");
  process.exit(2);
}
var SESSION_ROOT = process.env.AB_SESSIONS_ROOT ?? "";
if (!SESSION_ROOT) {
  process.stderr.write("android-browser: AB_SESSIONS_ROOT is not set\n");
  process.exit(2);
}
mkdirSync(SESSION_ROOT, { recursive: true });
var DRIVER_BASE = `http://127.0.0.1:${DRIVER_PORT}`;
var FRAME_BYTES = 2 * 1024 * 1024;
var MAX_FRAMES = 5e4;
var MAX_RESULT_BYTES = 24 * 1024;
var CALL_TIMEOUT_MS = 6e4;
function sessionName(botId) {
  if (typeof botId !== "string" || !/^[A-Za-z0-9_-]{1,96}$/.test(botId)) {
    throw new Error("botId is required (the bot's own id, from context)");
  }
  const digest = createHash("sha256").update(botId).digest("hex");
  return `omb-${digest.slice(0, 32)}`;
}
var buffer = "";
var frames = 0;
function writeFrame(frame) {
  const line = JSON.stringify(frame) + "\n";
  if (Buffer.byteLength(line) > FRAME_BYTES) throw new Error("frame too large");
  process.stdout.write(line);
}
function reply(id, result) {
  writeFrame({ jsonrpc: "2.0", id, result });
}
function replyError(id, message, code = -32603) {
  writeFrame({ jsonrpc: "2.0", id, error: { code, message } });
}
async function driver(action, session, body = {}, binary = false) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), CALL_TIMEOUT_MS);
  try {
    const response = await fetch(`${DRIVER_BASE}/session/${session}/${action}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${DRIVER_TOKEN}` },
      body: JSON.stringify(body),
      signal: controller.signal
    });
    if (!response.ok) throw new Error(`browser driver HTTP ${response.status}`);
    if (binary) return Buffer.from(await response.arrayBuffer());
    const payload = await response.json();
    if (payload.ok === false) throw new Error(payload.error ?? "browser action failed");
    return payload;
  } finally {
    clearTimeout(timer);
  }
}
function toolError(message) {
  return { ok: false, error: message };
}
function bounded(text, limit = MAX_RESULT_BYTES, marker = " [truncated]") {
  const bytes = Buffer.from(text, "utf8");
  if (bytes.length <= limit) return text;
  let end = limit;
  while (end > 0 && (bytes[end] & 192) === 128) end -= 1;
  return bytes.subarray(0, end).toString("utf8") + marker;
}
function textResult(payload, isError = false) {
  const full = JSON.stringify(payload, null, 1);
  if (Buffer.byteLength(full) <= MAX_RESULT_BYTES) {
    return { content: [{ type: "text", text: full }], ...isError ? { isError: true } : {} };
  }
  const shrunk = { ...payload, truncated: true };
  const strings = Object.entries(shrunk).filter(([, v]) => typeof v === "string");
  const totalStringBytes = strings.reduce((sum, [, v]) => sum + Buffer.byteLength(v), 0);
  const otherBytes = Buffer.byteLength(full) - totalStringBytes;
  if (totalStringBytes > 0 && otherBytes < MAX_RESULT_BYTES) {
    const budget = MAX_RESULT_BYTES - otherBytes - 256;
    for (const [name, value] of strings) {
      shrunk[name] = bounded(value, Math.max(1024, Math.floor(budget * (Buffer.byteLength(value) / totalStringBytes))));
    }
  }
  return { content: [{ type: "text", text: JSON.stringify(shrunk, null, 1) }], ...isError ? { isError: true } : {} };
}
function imageResult(jpeg) {
  return { content: [{ type: "image", data: jpeg.toString("base64"), mimeType: "image/jpeg" }] };
}
async function requireSession(args) {
  return sessionName(args.botId);
}
var TOOLS = {
  browser_open: {
    description: "Open a URL in this bot's browser and wait for the page to load. Only http/https; private and loopback addresses are refused. The browser session is this bot's own \u2014 cookies and storage are isolated per bot.",
    inputSchema: { type: "object", properties: { botId: { type: "string" }, url: { type: "string", description: "Absolute http(s) URL to open" } }, required: ["botId", "url"] },
    handler: async (args) => driver("open", await requireSession(args), { url: String(args.url ?? "") })
  },
  browser_navigate: {
    description: "Navigate the current tab to a new URL (same session, same isolation).",
    inputSchema: { type: "object", properties: { botId: { type: "string" }, url: { type: "string" } }, required: ["botId", "url"] },
    handler: async (args) => driver("navigate", await requireSession(args), { url: String(args.url ?? "") })
  },
  browser_status: {
    description: "Current page URL, title, load progress and back/forward availability.",
    inputSchema: { type: "object", properties: { botId: { type: "string" } }, required: ["botId"] },
    handler: async (args) => driver("status", await requireSession(args))
  },
  browser_back: {
    description: "Go back one page in this bot's browser history.",
    inputSchema: { type: "object", properties: { botId: { type: "string" } }, required: ["botId"] },
    handler: async (args) => driver("back", await requireSession(args))
  },
  browser_forward: {
    description: "Go forward one page in this bot's browser history.",
    inputSchema: { type: "object", properties: { botId: { type: "string" } }, required: ["botId"] },
    handler: async (args) => driver("forward", await requireSession(args))
  },
  browser_get_text: {
    description: "Read the page's visible text, bounded (default 20,000 characters). Prefer this over re-snapshotting a page.",
    inputSchema: { type: "object", properties: { botId: { type: "string" }, maxChars: { type: "integer", minimum: 200, maximum: 6e4 } }, required: ["botId"] },
    handler: async (args) => driver("text", await requireSession(args), { maxChars: Number(args.maxChars ?? 2e4) })
  },
  browser_dom: {
    description: "Inspect the page's interactive elements (links, buttons, inputs) with @eN refs for click/type. Bounded to the first N elements with visible size.",
    inputSchema: { type: "object", properties: { botId: { type: "string" }, maxElements: { type: "integer", minimum: 10, maximum: 400 } }, required: ["botId"] },
    handler: async (args) => driver("dom", await requireSession(args), { maxElements: Number(args.maxElements ?? 120) })
  },
  browser_click: {
    description: "Click an element by @eN ref from browser_dom (scrolls it into view first).",
    inputSchema: { type: "object", properties: { botId: { type: "string" }, ref: { type: "string", description: "@eN from browser_dom" } }, required: ["botId", "ref"] },
    handler: async (args) => driver("click", await requireSession(args), { ref: String(args.ref ?? "") })
  },
  browser_type: {
    description: "Type text into an input/textarea by @eN ref (clears the field first by default, fires input/change events).",
    inputSchema: { type: "object", properties: { botId: { type: "string" }, ref: { type: "string" }, text: { type: "string" }, clear: { type: "boolean" } }, required: ["botId", "ref", "text"] },
    handler: async (args) => driver("type", await requireSession(args), { ref: String(args.ref ?? ""), text: String(args.text ?? ""), clear: args.clear !== false })
  },
  browser_eval: {
    description: "Run JavaScript in the page's context and return the result as text. Page code can reach nothing of the app or other bots \u2014 this is read/write to the page only.",
    inputSchema: { type: "object", properties: { botId: { type: "string" }, expression: { type: "string" } }, required: ["botId", "expression"] },
    handler: async (args) => driver("eval", await requireSession(args), { expression: String(args.expression ?? "") })
  },
  browser_screenshot: {
    description: "Capture the current page as a JPEG image (bounded size).",
    inputSchema: { type: "object", properties: { botId: { type: "string" } }, required: ["botId"] },
    handler: async (args) => {
      const jpeg = await driver("screenshot", await requireSession(args), {}, true);
      return imageResult(jpeg);
    }
  },
  browser_cookies: {
    description: "List this session's cookies (per-bot isolated; other bots' cookies are invisible by construction).",
    inputSchema: { type: "object", properties: { botId: { type: "string" } }, required: ["botId"] },
    handler: async (args) => driver("cookies", await requireSession(args))
  },
  browser_clear: {
    description: "Clear this bot's browser state: cookies, storage, history. Other bots are unaffected.",
    inputSchema: { type: "object", properties: { botId: { type: "string" } }, required: ["botId"] },
    handler: async (args) => driver("clear", await requireSession(args))
  },
  browser_close: {
    description: "Close this bot's browser session and destroy its state on the phone.",
    inputSchema: { type: "object", properties: { botId: { type: "string" } }, required: ["botId"] },
    handler: async (args) => driver("close", await requireSession(args))
  },
  browser_persist: {
    description: "Flush this session's cookies to storage so logins survive an app restart (where the platform supports it).",
    inputSchema: { type: "object", properties: { botId: { type: "string" } }, required: ["botId"] },
    handler: async (args) => driver("persist", await requireSession(args))
  }
};
var TOOL_LIST = Object.entries(TOOLS).map(([name, spec]) => ({ name, description: spec.description, inputSchema: spec.inputSchema }));
var shuttingDown = false;
process.on("SIGTERM", () => {
  shuttingDown = true;
  process.exit(0);
});
process.on("SIGINT", () => process.exit(0));
function handle(message) {
  const id = message.id;
  if (typeof id !== "number" && typeof id !== "string") return;
  if (message.method === "initialize") {
    reply(id, {
      protocolVersion: "2024-11-05",
      capabilities: { tools: {} },
      serverInfo: { name: "android_browser", version: "1.0.0" }
    });
    return;
  }
  if (message.method === "tools/list") {
    reply(id, { tools: TOOL_LIST });
    return;
  }
  if (message.method === "tools/call") {
    const params = message.params ?? {};
    const name = typeof params.name === "string" ? params.name : "";
    const spec = TOOLS[name];
    if (!spec) {
      replyError(id, `unknown tool: ${name}`, -32602);
      return;
    }
    const args = params.arguments ?? {};
    Promise.resolve().then(() => spec.handler(args)).then(
      (result) => {
        if (shuttingDown) return;
        const failed = result.ok === false && !("data" in result);
        reply(id, textResult(result, failed));
      },
      (error) => {
        if (shuttingDown) return;
        const message2 = error instanceof Error ? error.message : String(error);
        reply(id, textResult(toolError(message2), true));
      }
    );
    return;
  }
  if (message.method === "ping") {
    reply(id, {});
    return;
  }
  if (message.method === "notifications/initialized") return;
  replyError(id, "method not supported", -32601);
}
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => {
  buffer += chunk;
  let newline;
  while ((newline = buffer.indexOf("\n")) !== -1) {
    const line = buffer.slice(0, newline);
    buffer = buffer.slice(newline + 1);
    if (!line.trim()) continue;
    if (++frames > MAX_FRAMES) {
      process.stderr.write("android-browser: frame limit exceeded\n");
      process.exit(2);
    }
    if (Buffer.byteLength(line) > FRAME_BYTES) {
      process.stderr.write("android-browser: frame too large\n");
      process.exit(2);
    }
    let message;
    try {
      message = JSON.parse(line);
    } catch {
      process.stderr.write("android-browser: invalid JSON frame\n");
      continue;
    }
    try {
      handle(message);
    } catch (error) {
      const id = message.id;
      if (typeof id === "number" || typeof id === "string") {
        replyError(id, error instanceof Error ? error.message : String(error));
      }
    }
  }
});
process.stdin.on("end", () => process.exit(0));
