// server/android-browser.ts
import { createHash } from "node:crypto";
import { mkdirSync } from "node:fs";

// server/permission-policy.ts
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
var ERR_CROSS_BOT_MEMORY_LEAK = "ERR_CROSS_BOT_MEMORY_LEAK";
var VALID_BOT_ID = /^[\w-]{1,128}$/;
function checkMemoryAccessPermission(req) {
  const { requestingBotId, targetBotId, operation, path } = req;
  if (!requestingBotId || !VALID_BOT_ID.test(requestingBotId)) {
    return {
      allowed: false,
      error: `${ERR_CROSS_BOT_MEMORY_LEAK}: Invalid or unknown requesting botId "${requestingBotId}".`,
      category: "permission_denied"
    };
  }
  if (path) {
    let clean;
    try {
      clean = decodeURIComponent(path).replace(/\\/g, "/");
    } catch {
      return {
        allowed: false,
        error: `${ERR_CROSS_BOT_MEMORY_LEAK}: Malformed encoded path "${path}".`,
        category: "permission_denied"
      };
    }
    const segments = clean.split("/");
    if (segments.some((s) => s === ".." || s === "." && clean !== ".")) {
      return {
        allowed: false,
        error: `${ERR_CROSS_BOT_MEMORY_LEAK}: Path traversal blocked in memory path "${path}".`,
        category: "permission_denied"
      };
    }
    const botMatch = clean.match(/^(?:bots\/|workspaces\/)([\w-]+)\//);
    if (botMatch && botMatch[1] !== requestingBotId && botMatch[1] !== "shared") {
      return {
        allowed: false,
        error: `${ERR_CROSS_BOT_MEMORY_LEAK}: Cross-bot path access blocked from "${requestingBotId}" to "${botMatch[1]}".`,
        category: "permission_denied"
      };
    }
  }
  if (targetBotId === "shared") {
    return { allowed: true };
  }
  if (targetBotId !== requestingBotId) {
    return {
      allowed: false,
      error: `${ERR_CROSS_BOT_MEMORY_LEAK}: Bot "${requestingBotId}" cannot ${operation} private memory partition of Bot "${targetBotId}".`,
      category: "permission_denied"
    };
  }
  return { allowed: true };
}
var PERMISSION_DOMAINS = {
  terminal: {
    id: "terminal",
    title: "Terminal & Shell Execution",
    description: "Allows MOBOT to run shell commands, scripts, and subprocesses."
  },
  filesystem: {
    id: "filesystem",
    title: "Filesystem Read & Write",
    description: "Allows MOBOT to read, create, edit, and delete workspace files."
  },
  browser: {
    id: "browser",
    title: "Browser & Network",
    description: "Allows MOBOT to search the web, fetch URLs, and use browser automation."
  },
  composio: {
    id: "composio",
    title: "Composio Integrations",
    description: "Allows MOBOT to invoke third-party actions on connected apps."
  }
};
var TERMINAL_TOOL_NAMES = /* @__PURE__ */ new Set([
  "Bash",
  "bash",
  "sh",
  "run_command",
  "run_shell",
  "open_interactive",
  "terminal_start",
  "terminal_write",
  "terminal_read",
  "terminal_resize",
  "terminal_close",
  "terminal_list",
  "pty",
  "shell_exec",
  "process_start",
  "process_stop",
  "process_list",
  "process_status",
  "process_signal",
  "project_run",
  "project_build",
  "port_forward_create",
  "port_forward_list",
  "port_forward_close"
]);
var PHONE_TOOL_NAMES = /* @__PURE__ */ new Set([
  "status",
  "read_screen",
  "screenshot",
  "list_apps",
  "open_app",
  "tap_text",
  "tap",
  "swipe",
  "type_text",
  "clear_text",
  "press"
]);
var FILESYSTEM_TOOL_NAMES = /* @__PURE__ */ new Set([
  "ReadFile",
  "WriteFile",
  "EditFile",
  "GlobTool",
  "GrepTool",
  "workspace_list",
  "workspace_read",
  "workspace_write",
  "workspace_append",
  "workspace_mkdir",
  "workspace_move",
  "workspace_copy",
  "workspace_delete",
  "workspace_stat",
  "workspace_exists",
  "file_read",
  "file_write",
  "file_delete",
  "device.files",
  "artifact_create",
  "artifact_read",
  "artifact_write",
  "artifact_delete",
  "artifact_list",
  "project_create",
  "resource_extract_pdf_text",
  "resource_extract_pdf",
  "resource_artifact_info",
  "resource_list"
]);
var BROWSER_TOOL_NAMES = /* @__PURE__ */ new Set([
  "http_fetch",
  "web_search",
  "Fetch",
  "WebSearch",
  "resource_inspect",
  "resource_fetch",
  "resource_download",
  "resource_extract_links",
  "resource_extract_html",
  "resource_artifacts",
  "browser_open",
  "browser_navigate",
  "browser_status",
  "browser_back",
  "browser_forward",
  "browser_get_text",
  "browser_dom",
  "browser_click",
  "browser_type",
  "browser_eval",
  "browser_screenshot",
  "browser_cookies",
  "browser_clear",
  "browser_close",
  "browser_persist",
  "browser_scroll",
  "browser_fill",
  "browser_tabs",
  "browser_press",
  "browser_hover",
  "browser_evaluate"
]);
var KNOWN_BROWSER_ACTIONS = /* @__PURE__ */ new Set([
  "open",
  "navigate",
  "status",
  "back",
  "forward",
  "get_text",
  "dom",
  "click",
  "type",
  "eval",
  "screenshot",
  "cookies",
  "clear",
  "close",
  "persist",
  "scroll",
  "fill",
  "tabs",
  "press",
  "hover",
  "evaluate"
]);
var SYSTEM_TOOL_NAMES = /* @__PURE__ */ new Set([
  "ask_user",
  "AskUserQuestion",
  "coordinate_bots",
  "delegate_bot",
  "approve",
  "environment_discover",
  "environment_list",
  "environment_set",
  "environment_remove",
  "package_status",
  "device_capability_list",
  "device_capability_describe"
]);
function stripMcpPrefix(name) {
  const mcpMatch = /^mcp__[a-zA-Z0-9_-]+__(.+)$/i.exec(name);
  if (mcpMatch) return mcpMatch[1];
  const abMatch = /^android_browser_(.+)$/i.exec(name);
  if (abMatch) return abMatch[1];
  const acMatch = /^android_computer_(.+)$/i.exec(name);
  if (acMatch) return acMatch[1];
  return name;
}
function classifyTool(toolName, args) {
  const normalized = toolName.trim();
  const stripped = stripMcpPrefix(normalized);
  if (SYSTEM_TOOL_NAMES.has(normalized) || SYSTEM_TOOL_NAMES.has(stripped) || /^(plan_|task_)/i.test(normalized) || /^(plan_|task_)/i.test(stripped)) {
    return { domain: "system", label: "System Collaboration" };
  }
  if (normalized === "device_capability_invoke" || stripped === "device_capability_invoke") {
    if (args) {
      const capId = String(args.capabilityId || "");
      if (capId === "device.files") return { domain: "filesystem", label: PERMISSION_DOMAINS.filesystem.title };
      if (capId === "device.browser" || capId === "device.network") return { domain: "browser", label: PERMISSION_DOMAINS.browser.title };
      if (capId.startsWith("device.")) return { domain: "system", label: "Device Native Capability" };
    }
    return { domain: "system", label: "Device Native Capability" };
  }
  const isAuthenticBrowser = BROWSER_TOOL_NAMES.has(normalized) || BROWSER_TOOL_NAMES.has(stripped) || stripped.startsWith("browser_") && KNOWN_BROWSER_ACTIONS.has(stripped.slice("browser_".length)) || KNOWN_BROWSER_ACTIONS.has(stripped) || /^(preview_|deployment_|verify_service)/i.test(normalized) || /^(preview_|deployment_|verify_service)/i.test(stripped);
  if (normalized.startsWith("android_browser_") || normalized.startsWith("mcp__android_browser__")) {
    if (isAuthenticBrowser) {
      return { domain: "browser", label: PERMISSION_DOMAINS.browser.title };
    }
    return { domain: "unknown", label: "Unclassified Tool" };
  }
  if (normalized.startsWith("android_computer_") || normalized.startsWith("mcp__android_computer__")) {
    if (isAuthenticBrowser) {
      return { domain: "browser", label: PERMISSION_DOMAINS.browser.title };
    }
    if (TERMINAL_TOOL_NAMES.has(stripped) || PHONE_TOOL_NAMES.has(stripped) || /^(bash|sh|terminal_|shell_|exec_|process_|build_|test_|project_git_|repair_|phone_)/i.test(stripped)) {
      return { domain: "terminal", label: PERMISSION_DOMAINS.terminal.title };
    }
    if (FILESYSTEM_TOOL_NAMES.has(stripped) || /^(fs_|file_|workspace_|artifact_|project_(create|open|read|write|patch|delete|rename|list)|verify_file|verify_artifact|verify_image)/i.test(stripped)) {
      return { domain: "filesystem", label: PERMISSION_DOMAINS.filesystem.title };
    }
    return { domain: "unknown", label: "Unclassified Tool" };
  }
  if (isAuthenticBrowser) {
    return { domain: "browser", label: PERMISSION_DOMAINS.browser.title };
  }
  if (TERMINAL_TOOL_NAMES.has(normalized) || TERMINAL_TOOL_NAMES.has(stripped) || PHONE_TOOL_NAMES.has(normalized) || PHONE_TOOL_NAMES.has(stripped) || /^(bash|sh|terminal_|shell_|exec_|process_|build_|test_|project_git_|repair_|mcp__openmausbot-phone__|phone_)/i.test(normalized) || /^(bash|sh|terminal_|shell_|exec_|process_|build_|test_|project_git_|repair_|phone_)/i.test(stripped)) {
    return { domain: "terminal", label: PERMISSION_DOMAINS.terminal.title };
  }
  if (FILESYSTEM_TOOL_NAMES.has(normalized) || FILESYSTEM_TOOL_NAMES.has(stripped) || /^(fs_|file_|workspace_|artifact_|project_(create|open|read|write|patch|delete|rename|list)|verify_file|verify_artifact|verify_image)/i.test(normalized) || /^(fs_|file_|workspace_|artifact_|project_(create|open|read|write|patch|delete|rename|list)|verify_file|verify_artifact|verify_image)/i.test(stripped)) {
    return { domain: "filesystem", label: PERMISSION_DOMAINS.filesystem.title };
  }
  if (normalized.startsWith("mcp__composio") || normalized.startsWith("composio_") || stripped.startsWith("composio_") || /^composio/i.test(normalized) || /^composio/i.test(stripped)) {
    return { domain: "composio", label: PERMISSION_DOMAINS.composio.title };
  }
  return { domain: "unknown", label: "Unclassified Tool" };
}
function checkToolPermission(toolName, permissions, args, extra) {
  const classification = classifyTool(toolName, args);
  if (classification.domain === "system") {
    return { allowed: true, reason: "" };
  }
  if (classification.domain === "unknown") {
    return {
      allowed: false,
      reason: `Unclassified tool "${toolName}" is blocked by security policy.`,
      domain: void 0
    };
  }
  const domain = classification.domain;
  const state = permissions?.[domain] ?? "granted";
  if (domain === "terminal") {
    if (state === "denied") {
      return {
        allowed: false,
        reason: "Terminal & Shell Execution is disabled in Settings -> Agent Permissions.",
        domain: "terminal",
        state: "denied"
      };
    }
    if (state === "restricted") {
      return {
        allowed: false,
        reason: "Terminal execution is restricted by the current environment.",
        domain: "terminal",
        state: "restricted"
      };
    }
    return { allowed: true, reason: "", domain: "terminal", state };
  }
  if (domain === "filesystem") {
    if (state === "denied") {
      return {
        allowed: false,
        reason: "Filesystem Read & Write is disabled in Settings -> Agent Permissions.",
        domain: "filesystem",
        state: "denied"
      };
    }
    if (state === "restricted") {
      return {
        allowed: false,
        reason: "Filesystem operations are restricted by the current environment.",
        domain: "filesystem",
        state: "restricted"
      };
    }
    const requestingBot = extra?.requestingBotId ?? extra?.botId ?? (typeof args?.requestingBotId === "string" ? args.requestingBotId : void 0);
    const pathArg = typeof args?.path === "string" ? args.path : typeof args?.filePath === "string" ? args.filePath : void 0;
    if (requestingBot && pathArg) {
      const memCheck = checkMemoryAccessPermission({
        requestingBotId: String(requestingBot),
        targetBotId: String(requestingBot),
        operation: "read",
        path: pathArg
      });
      if (!memCheck.allowed) {
        return {
          allowed: false,
          reason: memCheck.error ?? `${ERR_CROSS_BOT_MEMORY_LEAK}: Cross-bot memory access blocked.`,
          domain: "filesystem",
          state: "denied"
        };
      }
    }
    return { allowed: true, reason: "", domain: "filesystem", state };
  }
  if (domain === "browser") {
    if (state === "denied") {
      return {
        allowed: false,
        reason: "Browser & Network is disabled in Settings -> Agent Permissions.",
        domain: "browser",
        state: "denied"
      };
    }
    if (state === "restricted") {
      return {
        allowed: false,
        reason: "Browser automation is restricted by the current environment.",
        domain: "browser",
        state: "restricted"
      };
    }
    return { allowed: true, reason: "", domain: "browser", state };
  }
  if (domain === "composio") {
    if (state === "denied") {
      return {
        allowed: false,
        reason: "Composio Integrations is disabled in Settings -> Agent Permissions.",
        domain: "composio",
        state: "denied"
      };
    }
    if (extra?.composioConfigured === false || state === "requires_configuration") {
      return {
        allowed: false,
        reason: "Composio capability requires configuration in Settings -> Connected Services.",
        domain: "composio",
        state: "requires_configuration"
      };
    }
    return { allowed: true, reason: "", domain: "composio", state };
  }
  return { allowed: true, reason: "" };
}
function loadDiskPermissions() {
  try {
    const dataDir = process.env.OMB_DATA_DIR || (process.env.HOME ? join(process.env.HOME, ".openmausbot") : "");
    if (!dataDir) return {};
    const configPath = join(dataDir, "config.json");
    if (!existsSync(configPath)) return {};
    const raw = JSON.parse(readFileSync(configPath, "utf-8"));
    return raw.agentPermissions ?? {};
  } catch {
    return {};
  }
}

// server/android-browser.ts
var DRIVER_PORT = Number(process.env.AB_DRIVER_PORT ?? "0");
var DRIVER_TOKEN = process.env.AB_DRIVER_TOKEN ?? "";
if (!DRIVER_PORT || !DRIVER_TOKEN) {
  process.stderr.write("android-browser: AB_DRIVER_PORT/AB_DRIVER_TOKEN are not set \u2014 refusing to start\n");
  process.exit(2);
}
var SESSION_ROOT = process.env.AB_SESSIONS_ROOT ?? "";
if (!SESSION_ROOT) {
  process.stderr.write("android-browser: AB_SESSIONS_ROOT is not set\n");
  process.exit(2);
}
mkdirSync(SESSION_ROOT, { recursive: true });
var DRIVER_BASE = `http://127.0.0.1:${DRIVER_PORT}`;
var FRAME_BYTES = 2 * 1024 * 1024;
var MAX_FRAMES = 5e4;
var MAX_RESULT_BYTES = 24 * 1024;
var CALL_TIMEOUT_MS = 6e4;
function sessionName(botId) {
  if (botId !== void 0 && botId !== null && botId !== "") {
    if (typeof botId !== "string" || !/^[A-Za-z0-9_-]{1,96}$/.test(botId)) {
      throw new Error("botId is required (the bot's own id, from context)");
    }
    const digest = createHash("sha256").update(botId).digest("hex");
    return `omb-${digest.slice(0, 32)}`;
  }
  const fallback = process.env.OMB_BOT_ID;
  if (typeof fallback === "string" && /^[A-Za-z0-9_-]{1,96}$/.test(fallback)) {
    const digest = createHash("sha256").update(fallback).digest("hex");
    return `omb-${digest.slice(0, 32)}`;
  }
  throw new Error("botId is required (the bot's own id, from context)");
}
var buffer = "";
var frames = 0;
function writeFrame(frame) {
  const line = JSON.stringify(frame) + "\n";
  if (Buffer.byteLength(line) > FRAME_BYTES) throw new Error("frame too large");
  process.stdout.write(line);
}
function reply(id, result) {
  writeFrame({ jsonrpc: "2.0", id, result });
}
function replyError(id, message, code = -32603) {
  writeFrame({ jsonrpc: "2.0", id, error: { code, message } });
}
async function driver(action, session, body = {}, binary = false) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), CALL_TIMEOUT_MS);
  try {
    const response = await fetch(`${DRIVER_BASE}/session/${session}/${action}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${DRIVER_TOKEN}` },
      body: JSON.stringify(body),
      signal: controller.signal
    });
    if (!response.ok) throw new Error(`browser driver HTTP ${response.status}`);
    if (binary) return Buffer.from(await response.arrayBuffer());
    const payload = await response.json();
    if (payload.ok === false) throw new Error(payload.error ?? "browser action failed");
    return payload;
  } finally {
    clearTimeout(timer);
  }
}
function toolError(message) {
  return { ok: false, error: message };
}
function bounded(text, limit = MAX_RESULT_BYTES, marker = " [truncated]") {
  const bytes = Buffer.from(text, "utf8");
  if (bytes.length <= limit) return text;
  let end = limit;
  while (end > 0 && (bytes[end] & 192) === 128) end -= 1;
  return bytes.subarray(0, end).toString("utf8") + marker;
}
function textResult(payload, isError = false) {
  const full = JSON.stringify(payload, null, 1);
  if (Buffer.byteLength(full) <= MAX_RESULT_BYTES) {
    return { content: [{ type: "text", text: full }], ...isError ? { isError: true } : {} };
  }
  const shrunk = { ...payload, truncated: true };
  const strings = Object.entries(shrunk).filter(([, v]) => typeof v === "string");
  const totalStringBytes = strings.reduce((sum, [, v]) => sum + Buffer.byteLength(v), 0);
  const otherBytes = Buffer.byteLength(full) - totalStringBytes;
  if (totalStringBytes > 0 && otherBytes < MAX_RESULT_BYTES) {
    const budget = MAX_RESULT_BYTES - otherBytes - 256;
    for (const [name, value] of strings) {
      shrunk[name] = bounded(value, Math.max(1024, Math.floor(budget * (Buffer.byteLength(value) / totalStringBytes))));
    }
  }
  return { content: [{ type: "text", text: JSON.stringify(shrunk, null, 1) }], ...isError ? { isError: true } : {} };
}
function imageResult(jpeg) {
  return { content: [{ type: "image", data: jpeg.toString("base64"), mimeType: "image/jpeg" }] };
}
async function requireSession(args) {
  return sessionName(args.botId);
}
var TOOLS = {
  browser_open: {
    description: "Open a URL in this bot's browser and wait for the page to load. Only http/https; private and loopback addresses are refused. The browser session is this bot's own \u2014 cookies and storage are isolated per bot.",
    inputSchema: { type: "object", properties: { botId: { type: "string" }, url: { type: "string", description: "Absolute http(s) URL to open" } }, required: ["url"] },
    handler: async (args) => driver("open", await requireSession(args), { url: String(args.url ?? "") })
  },
  browser_navigate: {
    description: "Navigate the current tab to a new URL (same session, same isolation).",
    inputSchema: { type: "object", properties: { botId: { type: "string" }, url: { type: "string" } }, required: ["url"] },
    handler: async (args) => driver("navigate", await requireSession(args), { url: String(args.url ?? "") })
  },
  browser_status: {
    description: "Current page URL, title, load progress and back/forward availability.",
    inputSchema: { type: "object", properties: { botId: { type: "string" } }, required: [] },
    handler: async (args) => driver("status", await requireSession(args))
  },
  browser_back: {
    description: "Go back one page in this bot's browser history.",
    inputSchema: { type: "object", properties: { botId: { type: "string" } }, required: [] },
    handler: async (args) => driver("back", await requireSession(args))
  },
  browser_forward: {
    description: "Go forward one page in this bot's browser history.",
    inputSchema: { type: "object", properties: { botId: { type: "string" } }, required: [] },
    handler: async (args) => driver("forward", await requireSession(args))
  },
  browser_get_text: {
    description: "Read the page's visible text, bounded (default 20,000 characters). Prefer this over re-snapshotting a page.",
    inputSchema: { type: "object", properties: { botId: { type: "string" }, maxChars: { type: "integer", minimum: 200, maximum: 6e4 } }, required: [] },
    handler: async (args) => driver("text", await requireSession(args), { maxChars: Number(args.maxChars ?? 2e4) })
  },
  browser_dom: {
    description: "Inspect the page's interactive elements (links, buttons, inputs) with @eN refs for click/type. Bounded to the first N elements with visible size.",
    inputSchema: { type: "object", properties: { botId: { type: "string" }, maxElements: { type: "integer", minimum: 10, maximum: 400 } }, required: [] },
    handler: async (args) => driver("dom", await requireSession(args), { maxElements: Number(args.maxElements ?? 120) })
  },
  browser_click: {
    description: "Click an element by @eN ref from browser_dom (scrolls it into view first).",
    inputSchema: { type: "object", properties: { botId: { type: "string" }, ref: { type: "string", description: "@eN from browser_dom" } }, required: ["ref"] },
    handler: async (args) => driver("click", await requireSession(args), { ref: String(args.ref ?? "") })
  },
  browser_type: {
    description: "Type text into an input/textarea by @eN ref (clears the field first by default, fires input/change events).",
    inputSchema: { type: "object", properties: { botId: { type: "string" }, ref: { type: "string" }, text: { type: "string" }, clear: { type: "boolean" } }, required: ["ref", "text"] },
    handler: async (args) => driver("type", await requireSession(args), { ref: String(args.ref ?? ""), text: String(args.text ?? ""), clear: args.clear !== false })
  },
  browser_eval: {
    description: "Run JavaScript in the page's context and return the result as text. Page code can reach nothing of the app or other bots \u2014 this is read/write to the page only.",
    inputSchema: { type: "object", properties: { botId: { type: "string" }, expression: { type: "string" } }, required: ["expression"] },
    handler: async (args) => driver("eval", await requireSession(args), { expression: String(args.expression ?? "") })
  },
  browser_screenshot: {
    description: "Capture the current page as a JPEG image (bounded size).",
    inputSchema: { type: "object", properties: { botId: { type: "string" } }, required: [] },
    handler: async (args) => {
      const jpeg = await driver("screenshot", await requireSession(args), {}, true);
      return imageResult(jpeg);
    }
  },
  browser_cookies: {
    description: "List this session's cookies (per-bot isolated; other bots' cookies are invisible by construction).",
    inputSchema: { type: "object", properties: { botId: { type: "string" } }, required: [] },
    handler: async (args) => driver("cookies", await requireSession(args))
  },
  browser_clear: {
    description: "Clear this bot's browser state: cookies, storage, history. Other bots are unaffected.",
    inputSchema: { type: "object", properties: { botId: { type: "string" } }, required: [] },
    handler: async (args) => driver("clear", await requireSession(args))
  },
  browser_close: {
    description: "Close this bot's browser session and destroy its state on the phone.",
    inputSchema: { type: "object", properties: { botId: { type: "string" } }, required: [] },
    handler: async (args) => driver("close", await requireSession(args))
  },
  browser_persist: {
    description: "Flush this session's cookies to storage so logins survive an app restart (where the platform supports it).",
    inputSchema: { type: "object", properties: { botId: { type: "string" } }, required: [] },
    handler: async (args) => driver("persist", await requireSession(args))
  }
};
var TOOL_LIST = Object.entries(TOOLS).map(([name, spec]) => ({ name, description: spec.description, inputSchema: spec.inputSchema }));
var shuttingDown = false;
process.on("SIGTERM", () => {
  shuttingDown = true;
  process.exit(0);
});
process.on("SIGINT", () => process.exit(0));
function handle(message) {
  const id = message.id;
  if (typeof id !== "number" && typeof id !== "string") return;
  if (message.method === "initialize") {
    reply(id, {
      protocolVersion: "2024-11-05",
      capabilities: { tools: {} },
      serverInfo: { name: "android_browser", version: "1.0.0" }
    });
    return;
  }
  if (message.method === "tools/list") {
    reply(id, { tools: TOOL_LIST });
    return;
  }
  if (message.method === "tools/call") {
    const params = message.params ?? {};
    const name = typeof params.name === "string" ? params.name : "";
    const spec = TOOLS[name];
    if (!spec) {
      replyError(id, `unknown tool: ${name}`, -32602);
      return;
    }
    const args = params.arguments ?? {};
    const perm = checkToolPermission(name, loadDiskPermissions(), args);
    if (!perm.allowed) {
      reply(id, textResult(toolError(perm.reason || "Browser access is disabled in Settings -> Agent Permissions"), true));
      return;
    }
    Promise.resolve().then(() => spec.handler(args)).then(
      (result) => {
        if (shuttingDown) return;
        const failed = result.ok === false && !("data" in result);
        reply(id, textResult(result, failed));
      },
      (error) => {
        if (shuttingDown) return;
        const message2 = error instanceof Error ? error.message : String(error);
        reply(id, textResult(toolError(message2), true));
      }
    );
    return;
  }
  if (message.method === "ping") {
    reply(id, {});
    return;
  }
  if (message.method === "notifications/initialized") return;
  replyError(id, "method not supported", -32601);
}
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => {
  buffer += chunk;
  let newline;
  while ((newline = buffer.indexOf("\n")) !== -1) {
    const line = buffer.slice(0, newline);
    buffer = buffer.slice(newline + 1);
    if (!line.trim()) continue;
    if (++frames > MAX_FRAMES) {
      process.stderr.write("android-browser: frame limit exceeded\n");
      process.exit(2);
    }
    if (Buffer.byteLength(line) > FRAME_BYTES) {
      process.stderr.write("android-browser: frame too large\n");
      process.exit(2);
    }
    let message;
    try {
      message = JSON.parse(line);
    } catch {
      process.stderr.write("android-browser: invalid JSON frame\n");
      continue;
    }
    try {
      handle(message);
    } catch (error) {
      const id = message.id;
      if (typeof id === "number" || typeof id === "string") {
        replyError(id, error instanceof Error ? error.message : String(error));
      }
    }
  }
});
process.stdin.on("end", () => process.exit(0));
