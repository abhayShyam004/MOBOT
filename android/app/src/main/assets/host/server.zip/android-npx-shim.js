// server/android-npx-shim.ts
import { existsSync as existsSync2, mkdirSync as mkdirSync2, readFileSync as readFileSync2 } from "node:fs";
import { dirname as dirname2, join as join2, resolve } from "node:path";
import { spawnSync } from "node:child_process";

// server/android-native-addons.ts
import { chmodSync, closeSync, copyFileSync, existsSync, mkdirSync, openSync, readFileSync, readSync, renameSync, rmSync, statSync } from "node:fs";
import { createHash } from "node:crypto";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var ANDROID_ADDONS = [
  { package: "node-datachannel", file: "node_datachannel.node", target: "build/Release/node_datachannel.node" },
  { package: "utp-native", file: "utp_native.node", target: "build/Release/utp_native.node" }
];
function androidAbiForArch(arch) {
  switch (arch) {
    case "arm64":
      return "arm64-v8a";
    case "arm":
      return "armeabi-v7a";
    case "x64":
      return "x86_64";
    case "ia32":
      return "x86";
    default:
      return null;
  }
}
var ELF_MACHINES = { arm64: 183, arm: 40, x64: 62, ia32: 3 };
function bundledAddonDir(arch = process.arch) {
  const abi = androidAbiForArch(arch);
  if (!abi) return null;
  return join(dirname(fileURLToPath(import.meta.url)), "native", abi);
}
function elfMachine(file) {
  let fd = null;
  try {
    fd = openSync(file, "r");
    const header = Buffer.alloc(20);
    const read = readSync(fd, header, 0, 20, 0);
    if (read < 20) return null;
    if (header[0] !== 127 || header[1] !== 69 || header[2] !== 76 || header[3] !== 70) return null;
    return header.readUInt16LE(18);
  } catch {
    return null;
  } finally {
    if (fd !== null) {
      try {
        closeSync(fd);
      } catch {
      }
    }
  }
}
function sha256(file) {
  return createHash("sha256").update(readFileSync(file)).digest("hex");
}
function placeAddonsIn(nodeModulesDir, options = {}) {
  const arch = options.arch ?? process.arch;
  const sourceDir = options.sourceDir ?? bundledAddonDir(arch);
  const result = { placed: [], current: [], refused: [], missing: [] };
  if (!sourceDir || !existsSync(sourceDir)) return result;
  const expectedMachine = ELF_MACHINES[arch];
  for (const addon of ANDROID_ADDONS) {
    const packageDir = join(nodeModulesDir, ...addon.package.split("/"));
    if (!existsSync(join(packageDir, "package.json"))) {
      result.missing.push(addon.package);
      continue;
    }
    const source = join(sourceDir, addon.file);
    const target = join(packageDir, addon.target);
    if (!existsSync(source)) {
      result.refused.push(`${addon.package}: ${addon.file} is not in the shipped bundle`);
      continue;
    }
    const machine = elfMachine(source);
    if (machine !== expectedMachine) {
      result.refused.push(`${addon.package}: shipped ${addon.file} is not ${arch} (e_machine ${machine ?? "not an ELF"})`);
      continue;
    }
    if (existsSync(target) && statSync(target).size === statSync(source).size && sha256(target) === sha256(source)) {
      result.current.push(addon.package);
      continue;
    }
    try {
      mkdirSync(dirname(target), { recursive: true });
      const staging = `${target}.omb-${process.pid}`;
      rmSync(staging, { force: true });
      copyFileSync(source, staging);
      chmodSync(staging, 493);
      renameSync(staging, target);
      result.placed.push(addon.package);
      options.onPlace?.(`${addon.package} \u2192 ${addon.target}`);
    } catch (error) {
      result.refused.push(`${addon.package}: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  return result;
}
function placeAddonsForPrefix(prefixDir, options = {}) {
  return placeAddonsIn(join(prefixDir, "node_modules"), options);
}

// server/android-npx-shim.ts
var FLAGS_WITH_VALUE = /* @__PURE__ */ new Set(["-p", "--package"]);
function parseNpxArgs(argv) {
  const packages = [];
  const rest = [];
  let noInstall = false;
  let parsingNpxFlags = true;
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (parsingNpxFlags && token === "--") {
      parsingNpxFlags = false;
      continue;
    }
    if (parsingNpxFlags && token.startsWith("-") && token !== "-") {
      if (token === "-y" || token === "--yes" || token === "-q" || token === "--quiet") continue;
      if (token === "--no-install") {
        noInstall = true;
        continue;
      }
      if (FLAGS_WITH_VALUE.has(token)) {
        const value = argv[index + 1];
        if (!value) throw new Error(`${token} needs a package spec`);
        packages.push(value);
        index += 1;
        continue;
      }
      if (token.startsWith("--package=")) {
        packages.push(token.slice("--package=".length));
        continue;
      }
      throw new Error(`unsupported npx flag: ${token}`);
    }
    parsingNpxFlags = false;
    rest.push(token);
  }
  const command = rest.shift();
  if (!command) throw new Error("npx needs a command, e.g. npx --yes torlnk");
  const binName = packages.length ? command : defaultBinName(command);
  return { packages: packages.length ? packages : [command], command: binName, args: rest, noInstall };
}
function packageNameOf(spec) {
  const at = spec.lastIndexOf("@");
  return at > 0 ? spec.slice(0, at) : spec;
}
function defaultBinName(spec) {
  const last = spec.slice(spec.lastIndexOf("/") + 1);
  const at = last.lastIndexOf("@");
  return at > 0 ? last.slice(0, at) : last;
}
function resolvePackageBin(prefixDir, packageName, command) {
  const packageDir = join2(prefixDir, "node_modules", ...packageName.split("/"));
  const manifestPath = join2(packageDir, "package.json");
  if (!existsSync2(manifestPath)) return null;
  let manifest;
  try {
    manifest = JSON.parse(readFileSync2(manifestPath, "utf8"));
  } catch {
    return null;
  }
  const bin = manifest.bin;
  let relative;
  if (typeof bin === "string") {
    if (command === packageName.split("/").pop()) relative = bin;
  } else if (bin && typeof bin === "object") {
    relative = bin[command] ?? (Object.keys(bin).length === 1 ? Object.values(bin)[0] : void 0);
  }
  if (!relative) return null;
  return resolve(packageDir, relative);
}
function looksLikeScript(path) {
  return /\.(c|m)?js$/.test(path);
}
function cacheDirFor(spec) {
  const home = process.env.HOME || process.cwd();
  const safe = spec.replace(/[^A-Za-z0-9._@-]/g, "_");
  return join2(home, ".npm", "_npx-shim", safe);
}
function ensureNativeAddons(prefixDir) {
  try {
    const outcome = placeAddonsForPrefix(prefixDir, {
      onPlace: (what) => console.error(`npx: native addon ${what}`)
    });
    for (const refusal of outcome.refused) console.error(`npx: native addon not placed \u2014 ${refusal}`);
  } catch (error) {
    console.error(`npx: native addon placement failed: ${error instanceof Error ? error.message : String(error)}`);
  }
}
function runNode(scriptPath, args) {
  const child = spawnSync(process.execPath, [scriptPath, ...args], { stdio: "inherit", env: runEnv() });
  if (child.error) {
    console.error(`npx: could not run ${scriptPath}: ${child.error.message}`);
    return 1;
  }
  return child.status ?? 1;
}
function runEnv() {
  const env = { ...process.env };
  const nativeDir = dirname2(process.execPath);
  env.LD_LIBRARY_PATH = env.LD_LIBRARY_PATH ? `${env.LD_LIBRARY_PATH}:${nativeDir}` : nativeDir;
  const botBin = join2(process.env.HOME || process.cwd(), ".omb-bin");
  if (existsSync2(join2(botBin, "node"))) {
    env.PATH = env.PATH ? `${botBin}:${env.PATH}` : botBin;
  }
  return env;
}
function main() {
  const invocation = parseNpxArgs(process.argv.slice(2));
  const npmCli = process.env.OMB_NPM_CLI;
  const prefixDir = cacheDirFor(invocation.packages.join("+"));
  const packageName = packageNameOf(invocation.command);
  let binPath = resolvePackageBin(prefixDir, packageName, invocation.command);
  if (!binPath) {
    if (invocation.noInstall) {
      console.error(`npx: ${packageName} is not installed here and --no-install was given`);
      return 1;
    }
    if (!npmCli || !existsSync2(npmCli)) {
      console.error("npx: no npm installation found to fetch packages with");
      return 1;
    }
    mkdirSync2(dirname2(prefixDir), { recursive: true });
    const install = spawnSync(process.execPath, [
      npmCli,
      "install",
      "--prefix",
      prefixDir,
      "--no-audit",
      "--no-fund",
      "--ignore-scripts",
      "--loglevel",
      "error",
      ...invocation.packages
    ], { stdio: "inherit", env: runEnv() });
    if (install.error || install.status !== 0) {
      console.error(`npx: installing ${invocation.packages.join(", ")} failed`);
      return install.status ?? 1;
    }
    binPath = resolvePackageBin(prefixDir, packageName, invocation.command);
  }
  if (!binPath || !existsSync2(binPath)) {
    console.error(`npx: ${packageName} has no bin named "${invocation.command}"`);
    return 1;
  }
  if (!looksLikeScript(binPath)) {
    console.error(`npx: ${packageName}'s "${invocation.command}" is not a JavaScript CLI (Android cannot run downloaded binaries)`);
    return 1;
  }
  ensureNativeAddons(prefixDir);
  return runNode(binPath, invocation.args);
}
var invokedDirectly = (() => {
  const entry = process.argv[1];
  if (!entry) return false;
  try {
    return import.meta.url === new URL(`file://${resolve(entry)}`).href;
  } catch {
    return false;
  }
})();
if (invokedDirectly) {
  try {
    process.exitCode = main();
  } catch (error) {
    console.error(`npx: ${error instanceof Error ? error.message : String(error)}`);
    process.exitCode = 1;
  }
}
export {
  defaultBinName,
  looksLikeScript,
  packageNameOf,
  parseNpxArgs,
  resolvePackageBin
};
