// server/permission-proxy.ts
import { connect } from "node:net";
import { randomUUID } from "node:crypto";

// shared/ask-question.ts
var ASK_QUESTION_TYPES = ["single_choice", "multiple_choice", "confirmation", "free_text"];
var OTHER_ID = "other";
var CONFIRMED_ID = "confirmed";
var DECLINED_ID = "declined";
var MAX_SELECTIONS = 12;
var MAX_OPTION_ID = 40;
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function parseOptionId(raw) {
  if (typeof raw !== "string") return "";
  const slug = raw.toLowerCase().replace(/[^a-z0-9_-]+/g, "_").replace(/^_+|_+$/g, "").slice(0, MAX_OPTION_ID);
  return slug === OTHER_ID ? "other_option" : slug;
}
var MAX_QUESTIONS = 6;
var MAX_OPTIONS = 12;
var MAX_QUESTION_TEXT = 400;
var MAX_LABEL = 120;
var MAX_DESCRIPTION = 400;
function text(value, limit) {
  if (typeof value !== "string") return void 0;
  const trimmed = value.trim();
  return trimmed ? trimmed.slice(0, limit) : void 0;
}
function parseOption(value) {
  if (typeof value === "string") {
    const label2 = text(value, MAX_LABEL);
    return label2 ? { label: label2 } : null;
  }
  if (!isRecord(value)) return null;
  const label = text(value.label, MAX_LABEL);
  if (!label) return null;
  const description = text(value.description, MAX_DESCRIPTION);
  const id = parseOptionId(value.id);
  return description ? { label, description, ...id ? { id } : {} } : id ? { label, id } : { label };
}
function parseQuestion(value) {
  if (!isRecord(value)) return null;
  const question = text(value.question, MAX_QUESTION_TEXT);
  if (!question) return null;
  const options = [];
  const seen = /* @__PURE__ */ new Set();
  for (const raw of Array.isArray(value.options) ? value.options : []) {
    const option = parseOption(raw);
    if (!option || seen.has(option.label) || option.id && seen.has(`#:${option.id}`)) continue;
    seen.add(option.label);
    if (option.id) seen.add(`#:${option.id}`);
    options.push(option);
    if (options.length === MAX_OPTIONS) break;
  }
  const header = text(value.header, MAX_LABEL);
  const declared = typeof value.type === "string" && ASK_QUESTION_TYPES.includes(value.type) ? value.type : void 0;
  const type = declared ?? (options.length ? value.multiSelect === true ? "multiple_choice" : "single_choice" : "free_text");
  const isFree = type === "free_text";
  const isMulti = type === "multiple_choice";
  const declaredMin = isMulti && typeof value.minSelections === "number" && Number.isInteger(value.minSelections) ? Math.min(Math.max(value.minSelections, 0), MAX_SELECTIONS) : void 0;
  const declaredMax = isMulti && typeof value.maxSelections === "number" && Number.isInteger(value.maxSelections) ? Math.min(Math.max(value.maxSelections, 1), MAX_SELECTIONS) : void 0;
  const effectiveMin = declaredMin !== void 0 && declaredMax !== void 0 ? Math.min(declaredMin, declaredMax) : declaredMin;
  const finalOptions = type === "confirmation" ? [{ label: "Confirm", id: CONFIRMED_ID }, { label: "Cancel", id: DECLINED_ID }] : options;
  return {
    question,
    ...header ? { header } : {},
    ...isMulti ? { multiSelect: true } : {},
    ...isFree ? { options: [] } : { options: finalOptions },
    ...declared ? { type } : {},
    ...effectiveMin !== void 0 ? { minSelections: effectiveMin } : {},
    ...declaredMax !== void 0 ? { maxSelections: declaredMax } : {},
    ...value.required === false ? { required: false } : {},
    ...!isFree && type !== "confirmation" && value.allowOther === false ? { allowOther: false } : {}
  };
}
function parseAskQuestions(input) {
  if (!isRecord(input) || !Array.isArray(input.questions)) return null;
  const questions = [];
  for (const raw of input.questions) {
    const question = parseQuestion(raw);
    if (!question) continue;
    questions.push(question);
    if (questions.length === MAX_QUESTIONS) break;
  }
  return questions.length ? questions : null;
}
function inferDiscoveryChoices(questionText) {
  const q = questionText.toLowerCase();
  if (/(?:kind|type|category).*(?:website|app|application|project|store)|(?:website|app|application).*(?:kind|type|category)/i.test(q)) {
    return {
      type: "single_choice",
      options: [
        { label: "Portfolio", description: "Showcase personal projects, creative work, or case studies", id: "portfolio" },
        { label: "Business Website", description: "Company brand presence, services overview, and lead capture", id: "business" },
        { label: "Agency / Services", description: "Client showcase, detailed service packages, and consultation booking", id: "agency" },
        { label: "E-Commerce / Online Store", description: "Product catalog, shopping cart, and online checkout", id: "ecommerce" },
        { label: "Blog / Publication", description: "Articles, newsletters, editorial stories, and RSS feeds", id: "blog" },
        { label: "Community / Forum", description: "User discussions, member directory, and profile pages", id: "community" },
        { label: "SaaS / Web Application", description: "Interactive product workflows, dashboards, and tooling", id: "saas" },
        { label: "Internal Tool / Operations", description: "Admin panel, inventory tracker, or team dashboard", id: "internal_tool" }
      ]
    };
  }
  if (/(?:main|primary|core)?\s*(?:goal|purpose|objective)|what\s*should\s*(?:the|this|it)\s*(?:full[\s-]?stack\s*)?(?:website|app)?\s*(?:do|accomplish)/i.test(q)) {
    return {
      type: "single_choice",
      options: [
        { label: "Generate Leads", description: "Collect client inquiries, quote requests, and contact submissions", id: "get_leads" },
        { label: "Sell Products", description: "Process online purchases, manage catalog items, and track orders", id: "sell_products" },
        { label: "Showcase Work", description: "Demonstrate skills, portfolio pieces, and case study results", id: "showcase_work" },
        { label: "Book Appointments", description: "Allow visitors to schedule consultations, calls, or reservations", id: "book_appointments" },
        { label: "Publish Content", description: "Share insights, tutorials, guides, and regular news updates", id: "publish_content" },
        { label: "Interactive Service", description: "Deliver self-service calculators, tools, or utilities", id: "interactive_service" },
        { label: "Manage Operations", description: "Coordinate team records, internal status, and company workflows", id: "internal_operations" }
      ]
    };
  }
  if (/(?:target\s*audience|who\s*will\s*use|who\s*is\s*(?:this|it)\s*for)/i.test(q)) {
    return {
      type: "single_choice",
      options: [
        { label: "General Public / Consumers", description: "Everyday shoppers, casual visitors, and retail customers", id: "consumers" },
        { label: "B2B / Business Clients", description: "Corporate decision-makers, small business owners, and managers", id: "b2b_clients" },
        { label: "Developers & Technical Users", description: "Software engineers, DevOps, and technical teams", id: "developers" },
        { label: "Creative Professionals", description: "Designers, photographers, artists, and media agencies", id: "creatives" },
        { label: "Internal Team & Staff", description: "Company employees, operations staff, and administrators", id: "internal_team" }
      ]
    };
  }
  if (/(?:visual\s*style|aesthetic|theme|look\s*and\s*feel|vibe)/i.test(q)) {
    return {
      type: "single_choice",
      options: [
        { label: "Minimal & Clean", description: "Generous whitespace, crisp typography, and restrained neutral accents", id: "minimal_clean" },
        { label: "Modern Tech", description: "Dark mode, sleek card elevations, and vibrant indigo/cyan accents", id: "modern_tech" },
        { label: "Professional Corporate", description: "Structured layouts, navy/slate palette, and formal clarity", id: "professional_corp" },
        { label: "Warm Editorial", description: "Serif typography, earthy tones, and magazine-style layout", id: "warm_editorial" },
        { label: "Playful & Vibrant", description: "Bold colorful accents, rounded surfaces, and lively energy", id: "playful_vibrant" },
        { label: "Luxury & Premium", description: "Monochrome tones, champagne/gold details, and refined minimalism", id: "luxury_premium" }
      ]
    };
  }
  if (/(?:what\s*(?:features|capabilities)|what\s*should\s*users\s*be\s*able\s*to\s*do|what\s*(?:actions|workflows|screens)\s*(?:must|should)\s*it\s*support)/i.test(q)) {
    return {
      type: "multiple_choice",
      multiSelect: true,
      minSelections: 1,
      maxSelections: 8,
      options: [
        { label: "Browse Content", description: "Explore product lists, article grids, or showcase galleries", id: "browse_content" },
        { label: "Search & Filter", description: "Find items quickly with real-time keyword search and category tags", id: "search_filter" },
        { label: "User Accounts", description: "Sign up, log in, and manage personal profile settings", id: "user_accounts" },
        { label: "Submit Forms", description: "Send inquiries, quote requests, feedback, or applications", id: "submit_forms" },
        { label: "Upload Files", description: "Attach documents, images, or project assets securely", id: "upload_files" },
        { label: "Make Payments", description: "Complete online checkout with debit/credit card or digital pay", id: "make_payments" },
        { label: "Save Favorites", description: "Bookmark items into a wishlist or pinned collection", id: "save_favorites" },
        { label: "Contact Business", description: "Reach out via integrated contact form, email, or chat link", id: "contact_business" }
      ]
    };
  }
  if (/(?:type\s*of\s*authentication|authentication|login|sign[\s-]*in|user\s*accounts)/i.test(q)) {
    return {
      type: "single_choice",
      options: [
        { label: "Email & Password", description: "Standard email signup with secure password hashing", id: "email_password" },
        { label: "Google One-Tap / OAuth", description: "Fast social login via Google accounts", id: "google_oauth" },
        { label: "GitHub OAuth", description: "Developer-focused OAuth authentication via GitHub", id: "github_oauth" },
        { label: "Magic Link / Passwordless", description: "Email verification link without password management", id: "magic_link" },
        { label: "Multiple Providers", description: "Offer email alongside Google and GitHub social logins", id: "multiple_providers" },
        { label: "Private Single-User", description: "Zero login friction, runs locally as a private app on this phone", id: "none_local" }
      ]
    };
  }
  if (/(?:database|storage|persist|store\s*data|data\s*layer|records)/i.test(q)) {
    return {
      type: "single_choice",
      options: [
        { label: "Embedded SQLite Database", description: "Fast, relational, zero-latency local database on this phone", id: "sqlite" },
        { label: "Local JSON Storage", description: "Simple file-based key-value and record persistence", id: "json_store" },
        { label: "Hosted PostgreSQL / Cloud DB", description: "Remote cloud database with automated migrations", id: "cloud_postgres" },
        { label: "In-Memory Session Only", description: "Temporary session state without disk persistence", id: "in_memory" }
      ]
    };
  }
  if (/(?:backend\s*(?:architecture|endpoints|api)|server\s*logic)/i.test(q)) {
    return {
      type: "single_choice",
      options: [
        { label: "Node.js / Express REST API", description: "Clean JSON REST endpoints with validation middleware", id: "express_rest" },
        { label: "Full-Stack Integrated Endpoints", description: "Unified frontend and server routes in one framework", id: "fullstack_routes" },
        { label: "REST API + Background Workers", description: "API endpoints plus asynchronous background task execution", id: "api_with_workers" },
        { label: "Static Frontend Only", description: "Client-side state without dedicated server endpoints", id: "static_only" }
      ]
    };
  }
  if (/(?:where\s*(?:would\s*you\s*like|to\s*deploy)|deployment\s*preference|hosting)/i.test(q)) {
    return {
      type: "single_choice",
      options: [
        { label: "Local Preview on Phone", description: "Run directly on this phone at localhost with instant hot-reload", id: "local_preview" },
        { label: "Vercel Cloud", description: "Global edge CDN deployment ideal for frontend and full-stack", id: "vercel" },
        { label: "Render Web Service", description: "Deploy full-stack web service and background workers on Render", id: "render" },
        { label: "GitHub Pages / Static", description: "Free static web hosting with custom domain support", id: "github_pages" }
      ]
    };
  }
  if (/(?:responsive|navigation\s*style|layout\s*and\s*navigation|mobile\s*layout)/i.test(q)) {
    return {
      type: "single_choice",
      options: [
        { label: "Mobile-First with Drawer / Bottom Nav", description: "Optimized for phone screens with slide-out navigation", id: "mobile_drawer" },
        { label: "Desktop-First with Top-Bar Tabs", description: "Clean horizontal top navigation for wide screens", id: "desktop_header" },
        { label: "Collapsible Sidebar Dashboard", description: "Sidebar layout with nested sections for data-dense tools", id: "sidebar_dashboard" },
        { label: "Single-Page Continuous Flow", description: "Smooth scrolling sections on one continuous canvas", id: "single_page" }
      ]
    };
  }
  if (/(?:full[\s-]?stack\s*capabilities|capabilities\s*does\s*the)/i.test(q)) {
    return {
      type: "multiple_choice",
      multiSelect: true,
      minSelections: 1,
      maxSelections: 8,
      options: [
        { label: "User accounts & auth", description: "Registration, login sessions, and user profiles", id: "user_accounts" },
        { label: "Database persistence", description: "Local SQLite database for durable records", id: "database" },
        { label: "Admin dashboard", description: "Back-office management view to inspect and edit records", id: "admin_dashboard" },
        { label: "Search & filtering", description: "Full-text query search and multi-criteria filters", id: "search" },
        { label: "File & image uploads", description: "Storage for document attachments and avatar photos", id: "file_uploads" },
        { label: "Notifications", description: "In-app alerts and confirmation banners", id: "notifications" },
        { label: "Payments & checkout", description: "Order transactions and payment records", id: "payments" },
        { label: "External APIs", description: "Integration with third-party web services", id: "external_apis" }
      ]
    };
  }
  return null;
}
function normalizeAskUserInput(input) {
  const structured = parseAskQuestions(input);
  if (structured) return structured;
  if (!isRecord(input)) return null;
  const flatQuestion = text(input.question, MAX_QUESTION_TEXT);
  if (!flatQuestion) return null;
  const options = [];
  const seen = /* @__PURE__ */ new Set();
  for (const raw of Array.isArray(input.choices) ? input.choices : []) {
    const row = isRecord(raw) ? { label: text(raw.label, MAX_LABEL), description: text(raw.description, MAX_DESCRIPTION), id: parseOptionId(raw.id) } : { label: text(raw, MAX_LABEL), description: void 0, id: "" };
    if (!row.label || seen.has(row.label)) continue;
    seen.add(row.label);
    const description = row.description ? { description: row.description } : {};
    options.push({ label: row.label, ...description, ...row.id ? { id: row.id } : {} });
    if (options.length === MAX_OPTIONS) break;
  }
  let effectiveType = typeof input.type === "string" && ASK_QUESTION_TYPES.includes(input.type) ? input.type : void 0;
  let effectiveMulti = input.type === "multiple_choice" || input.multiSelect === true;
  let minSelections = input.minSelections;
  let maxSelections = input.maxSelections;
  if (!options.length && input.type !== "free_text" && input.type !== "confirmation") {
    const inferred = inferDiscoveryChoices(flatQuestion);
    if (inferred) {
      options.push(...inferred.options);
      if (!effectiveType && inferred.type) effectiveType = inferred.type;
      if (inferred.multiSelect) effectiveMulti = true;
      if (inferred.minSelections !== void 0 && minSelections === void 0) minSelections = inferred.minSelections;
      if (inferred.maxSelections !== void 0 && maxSelections === void 0) maxSelections = inferred.maxSelections;
    }
  }
  return parseAskQuestions({ questions: [{
    question: flatQuestion,
    options,
    ...effectiveMulti ? { multiSelect: true } : {},
    ...effectiveType ? { type: effectiveType } : {},
    ...minSelections === void 0 ? {} : { minSelections },
    ...maxSelections === void 0 ? {} : { maxSelections },
    ...input.required === void 0 ? {} : { required: input.required },
    ...input.allowOther === void 0 ? {} : { allowOther: input.allowOther }
  }] });
}
function questionAnswersByQuestion(message, questions) {
  const answers = {};
  const known = new Map(questions.map((entry) => [entry.question, entry.question]));
  for (const block of message.split("\n\n")) {
    const match = /^Q: ([\s\S]+?)\nA: ([\s\S]+)$/.exec(block.trim());
    if (!match) continue;
    const question = known.get(match[1].trim());
    if (question) answers[question] = match[2].trim();
  }
  if (Object.keys(answers).length) return answers;
  const only = questions.length === 1 ? questions[0] : void 0;
  const flat = message.trim();
  return only && flat ? { [only.question]: flat } : {};
}

// server/permission-policy.ts
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
var ERR_CROSS_BOT_MEMORY_LEAK = "ERR_CROSS_BOT_MEMORY_LEAK";
var VALID_BOT_ID = /^[\w-]{1,128}$/;
function checkMemoryAccessPermission(req) {
  const { requestingBotId, targetBotId, operation, path } = req;
  if (!requestingBotId || !VALID_BOT_ID.test(requestingBotId)) {
    return {
      allowed: false,
      error: `${ERR_CROSS_BOT_MEMORY_LEAK}: Invalid or unknown requesting botId "${requestingBotId}".`,
      category: "permission_denied"
    };
  }
  if (path) {
    let clean;
    try {
      clean = decodeURIComponent(path).replace(/\\/g, "/");
    } catch {
      return {
        allowed: false,
        error: `${ERR_CROSS_BOT_MEMORY_LEAK}: Malformed encoded path "${path}".`,
        category: "permission_denied"
      };
    }
    const segments = clean.split("/");
    if (segments.some((s) => s === ".." || s === "." && clean !== ".")) {
      return {
        allowed: false,
        error: `${ERR_CROSS_BOT_MEMORY_LEAK}: Path traversal blocked in memory path "${path}".`,
        category: "permission_denied"
      };
    }
    const botMatch = clean.match(/^(?:bots\/|workspaces\/)([\w-]+)\//);
    if (botMatch && botMatch[1] !== requestingBotId && botMatch[1] !== "shared") {
      return {
        allowed: false,
        error: `${ERR_CROSS_BOT_MEMORY_LEAK}: Cross-bot path access blocked from "${requestingBotId}" to "${botMatch[1]}".`,
        category: "permission_denied"
      };
    }
  }
  if (targetBotId === "shared") {
    return { allowed: true };
  }
  if (targetBotId !== requestingBotId) {
    return {
      allowed: false,
      error: `${ERR_CROSS_BOT_MEMORY_LEAK}: Bot "${requestingBotId}" cannot ${operation} private memory partition of Bot "${targetBotId}".`,
      category: "permission_denied"
    };
  }
  return { allowed: true };
}
var PERMISSION_DOMAINS = {
  terminal: {
    id: "terminal",
    title: "Terminal & Shell Execution",
    description: "Allows MOBOT to run shell commands, scripts, and subprocesses."
  },
  filesystem: {
    id: "filesystem",
    title: "Filesystem Read & Write",
    description: "Allows MOBOT to read, create, edit, and delete workspace files."
  },
  browser: {
    id: "browser",
    title: "Browser & Network",
    description: "Allows MOBOT to search the web, fetch URLs, and use browser automation."
  },
  composio: {
    id: "composio",
    title: "Composio Integrations",
    description: "Allows MOBOT to invoke third-party actions on connected apps."
  }
};
var TERMINAL_TOOL_NAMES = /* @__PURE__ */ new Set([
  "Bash",
  "bash",
  "sh",
  "run_command",
  "run_shell",
  "open_interactive",
  "terminal_start",
  "terminal_write",
  "terminal_read",
  "terminal_resize",
  "terminal_close",
  "terminal_list",
  "pty",
  "shell_exec",
  "process_start",
  "process_stop",
  "process_list",
  "process_status",
  "process_signal",
  "project_run",
  "project_build",
  "port_forward_create",
  "port_forward_list",
  "port_forward_close"
]);
var PHONE_TOOL_NAMES = /* @__PURE__ */ new Set([
  "status",
  "read_screen",
  "screenshot",
  "list_apps",
  "open_app",
  "tap_text",
  "tap",
  "swipe",
  "type_text",
  "clear_text",
  "press"
]);
var FILESYSTEM_TOOL_NAMES = /* @__PURE__ */ new Set([
  "ReadFile",
  "WriteFile",
  "EditFile",
  "GlobTool",
  "GrepTool",
  "workspace_list",
  "workspace_read",
  "workspace_write",
  "workspace_append",
  "workspace_mkdir",
  "workspace_move",
  "workspace_copy",
  "workspace_delete",
  "workspace_stat",
  "workspace_exists",
  "file_read",
  "file_write",
  "file_delete",
  "device.files",
  "artifact_create",
  "artifact_read",
  "artifact_write",
  "artifact_delete",
  "artifact_list",
  "project_create",
  "resource_extract_pdf_text",
  "resource_extract_pdf",
  "resource_artifact_info",
  "resource_list"
]);
var BROWSER_TOOL_NAMES = /* @__PURE__ */ new Set([
  "http_fetch",
  "web_search",
  "Fetch",
  "WebSearch",
  "resource_inspect",
  "resource_fetch",
  "resource_download",
  "resource_extract_links",
  "resource_extract_html",
  "resource_artifacts",
  "browser_open",
  "browser_navigate",
  "browser_status",
  "browser_back",
  "browser_forward",
  "browser_get_text",
  "browser_dom",
  "browser_click",
  "browser_type",
  "browser_eval",
  "browser_screenshot",
  "browser_cookies",
  "browser_clear",
  "browser_close",
  "browser_persist",
  "browser_scroll",
  "browser_fill",
  "browser_tabs",
  "browser_press",
  "browser_hover",
  "browser_evaluate"
]);
var KNOWN_BROWSER_ACTIONS = /* @__PURE__ */ new Set([
  "open",
  "navigate",
  "status",
  "back",
  "forward",
  "get_text",
  "dom",
  "click",
  "type",
  "eval",
  "screenshot",
  "cookies",
  "clear",
  "close",
  "persist",
  "scroll",
  "fill",
  "tabs",
  "press",
  "hover",
  "evaluate"
]);
var SYSTEM_TOOL_NAMES = /* @__PURE__ */ new Set([
  "ask_user",
  "AskUserQuestion",
  "coordinate_bots",
  "delegate_bot",
  "approve",
  "environment_discover",
  "environment_list",
  "environment_set",
  "environment_remove",
  "package_status",
  "device_capability_list",
  "device_capability_describe"
]);
function stripMcpPrefix(name) {
  const mcpMatch = /^mcp__[a-zA-Z0-9_-]+__(.+)$/i.exec(name);
  if (mcpMatch) return mcpMatch[1];
  const abMatch = /^android_browser_(.+)$/i.exec(name);
  if (abMatch) return abMatch[1];
  const acMatch = /^android_computer_(.+)$/i.exec(name);
  if (acMatch) return acMatch[1];
  return name;
}
function classifyTool(toolName, args) {
  const normalized = toolName.trim();
  const stripped = stripMcpPrefix(normalized);
  if (SYSTEM_TOOL_NAMES.has(normalized) || SYSTEM_TOOL_NAMES.has(stripped) || /^(plan_|task_)/i.test(normalized) || /^(plan_|task_)/i.test(stripped)) {
    return { domain: "system", label: "System Collaboration" };
  }
  if (normalized === "device_capability_invoke" || stripped === "device_capability_invoke") {
    if (args) {
      const capId = String(args.capabilityId || "");
      if (capId === "device.files") return { domain: "filesystem", label: PERMISSION_DOMAINS.filesystem.title };
      if (capId === "device.browser" || capId === "device.network") return { domain: "browser", label: PERMISSION_DOMAINS.browser.title };
      if (capId.startsWith("device.")) return { domain: "system", label: "Device Native Capability" };
    }
    return { domain: "system", label: "Device Native Capability" };
  }
  const isAuthenticBrowser = BROWSER_TOOL_NAMES.has(normalized) || BROWSER_TOOL_NAMES.has(stripped) || stripped.startsWith("browser_") && KNOWN_BROWSER_ACTIONS.has(stripped.slice("browser_".length)) || KNOWN_BROWSER_ACTIONS.has(stripped) || /^(preview_|deployment_|verify_service)/i.test(normalized) || /^(preview_|deployment_|verify_service)/i.test(stripped);
  if (normalized.startsWith("android_browser_") || normalized.startsWith("mcp__android_browser__")) {
    if (isAuthenticBrowser) {
      return { domain: "browser", label: PERMISSION_DOMAINS.browser.title };
    }
    return { domain: "unknown", label: "Unclassified Tool" };
  }
  if (normalized.startsWith("android_computer_") || normalized.startsWith("mcp__android_computer__")) {
    if (isAuthenticBrowser) {
      return { domain: "browser", label: PERMISSION_DOMAINS.browser.title };
    }
    if (TERMINAL_TOOL_NAMES.has(stripped) || PHONE_TOOL_NAMES.has(stripped) || /^(bash|sh|terminal_|shell_|exec_|process_|build_|test_|project_git_|repair_|phone_)/i.test(stripped)) {
      return { domain: "terminal", label: PERMISSION_DOMAINS.terminal.title };
    }
    if (FILESYSTEM_TOOL_NAMES.has(stripped) || /^(fs_|file_|workspace_|artifact_|project_(create|open|read|write|patch|delete|rename|list)|verify_file|verify_artifact|verify_image)/i.test(stripped)) {
      return { domain: "filesystem", label: PERMISSION_DOMAINS.filesystem.title };
    }
    return { domain: "unknown", label: "Unclassified Tool" };
  }
  if (isAuthenticBrowser) {
    return { domain: "browser", label: PERMISSION_DOMAINS.browser.title };
  }
  if (TERMINAL_TOOL_NAMES.has(normalized) || TERMINAL_TOOL_NAMES.has(stripped) || PHONE_TOOL_NAMES.has(normalized) || PHONE_TOOL_NAMES.has(stripped) || /^(bash|sh|terminal_|shell_|exec_|process_|build_|test_|project_git_|repair_|mcp__openmausbot-phone__|phone_)/i.test(normalized) || /^(bash|sh|terminal_|shell_|exec_|process_|build_|test_|project_git_|repair_|phone_)/i.test(stripped)) {
    return { domain: "terminal", label: PERMISSION_DOMAINS.terminal.title };
  }
  if (FILESYSTEM_TOOL_NAMES.has(normalized) || FILESYSTEM_TOOL_NAMES.has(stripped) || /^(fs_|file_|workspace_|artifact_|project_(create|open|read|write|patch|delete|rename|list)|verify_file|verify_artifact|verify_image)/i.test(normalized) || /^(fs_|file_|workspace_|artifact_|project_(create|open|read|write|patch|delete|rename|list)|verify_file|verify_artifact|verify_image)/i.test(stripped)) {
    return { domain: "filesystem", label: PERMISSION_DOMAINS.filesystem.title };
  }
  if (normalized.startsWith("mcp__composio") || normalized.startsWith("composio_") || stripped.startsWith("composio_") || /^composio/i.test(normalized) || /^composio/i.test(stripped)) {
    return { domain: "composio", label: PERMISSION_DOMAINS.composio.title };
  }
  return { domain: "unknown", label: "Unclassified Tool" };
}
function checkToolPermission(toolName, permissions, args, extra) {
  const classification = classifyTool(toolName, args);
  if (classification.domain === "system") {
    return { allowed: true, reason: "" };
  }
  if (classification.domain === "unknown") {
    return {
      allowed: false,
      reason: `Unclassified tool "${toolName}" is blocked by security policy.`,
      domain: void 0
    };
  }
  const domain = classification.domain;
  const state = permissions?.[domain] ?? "granted";
  if (domain === "terminal") {
    if (state === "denied") {
      return {
        allowed: false,
        reason: "Terminal & Shell Execution is disabled in Settings -> Agent Permissions.",
        domain: "terminal",
        state: "denied"
      };
    }
    if (state === "restricted") {
      return {
        allowed: false,
        reason: "Terminal execution is restricted by the current environment.",
        domain: "terminal",
        state: "restricted"
      };
    }
    return { allowed: true, reason: "", domain: "terminal", state };
  }
  if (domain === "filesystem") {
    if (state === "denied") {
      return {
        allowed: false,
        reason: "Filesystem Read & Write is disabled in Settings -> Agent Permissions.",
        domain: "filesystem",
        state: "denied"
      };
    }
    if (state === "restricted") {
      return {
        allowed: false,
        reason: "Filesystem operations are restricted by the current environment.",
        domain: "filesystem",
        state: "restricted"
      };
    }
    const requestingBot = extra?.requestingBotId ?? extra?.botId ?? (typeof args?.requestingBotId === "string" ? args.requestingBotId : void 0);
    const pathArg = typeof args?.path === "string" ? args.path : typeof args?.filePath === "string" ? args.filePath : void 0;
    if (requestingBot && pathArg) {
      const memCheck = checkMemoryAccessPermission({
        requestingBotId: String(requestingBot),
        targetBotId: String(requestingBot),
        operation: "read",
        path: pathArg
      });
      if (!memCheck.allowed) {
        return {
          allowed: false,
          reason: memCheck.error ?? `${ERR_CROSS_BOT_MEMORY_LEAK}: Cross-bot memory access blocked.`,
          domain: "filesystem",
          state: "denied"
        };
      }
    }
    return { allowed: true, reason: "", domain: "filesystem", state };
  }
  if (domain === "browser") {
    if (state === "denied") {
      return {
        allowed: false,
        reason: "Browser & Network is disabled in Settings -> Agent Permissions.",
        domain: "browser",
        state: "denied"
      };
    }
    if (state === "restricted") {
      return {
        allowed: false,
        reason: "Browser automation is restricted by the current environment.",
        domain: "browser",
        state: "restricted"
      };
    }
    return { allowed: true, reason: "", domain: "browser", state };
  }
  if (domain === "composio") {
    if (state === "denied") {
      return {
        allowed: false,
        reason: "Composio Integrations is disabled in Settings -> Agent Permissions.",
        domain: "composio",
        state: "denied"
      };
    }
    if (extra?.composioConfigured === false || state === "requires_configuration") {
      return {
        allowed: false,
        reason: "Composio capability requires configuration in Settings -> Connected Services.",
        domain: "composio",
        state: "requires_configuration"
      };
    }
    return { allowed: true, reason: "", domain: "composio", state };
  }
  return { allowed: true, reason: "" };
}
function loadDiskPermissions() {
  try {
    const dataDir = process.env.OMB_DATA_DIR || (process.env.HOME ? join(process.env.HOME, ".openmausbot") : "");
    if (!dataDir) return {};
    const configPath = join(dataDir, "config.json");
    if (!existsSync(configPath)) return {};
    const raw = JSON.parse(readFileSync(configPath, "utf-8"));
    return raw.agentPermissions ?? {};
  } catch {
    return {};
  }
}

// server/permission-proxy.ts
function checkPermissionForTool(toolName, args) {
  const permissions = loadDiskPermissions();
  const res = checkToolPermission(toolName, permissions, args);
  return { allowed: res.allowed, reason: res.reason };
}
var socketPath = process.argv[2] ?? "";
var waiting = /* @__PURE__ */ new Map();
var conn = connect(socketPath);
var dead = () => {
  for (const resolve of waiting.values()) {
    resolve({ behavior: "deny", message: "OpenMausBot: permission broker unavailable \u2014 skip this action" });
  }
  waiting.clear();
};
conn.on("error", dead);
conn.on("close", dead);
var connBuf = "";
conn.on("data", (chunk) => {
  connBuf += chunk;
  let nl;
  while ((nl = connBuf.indexOf("\n")) !== -1) {
    const line = connBuf.slice(0, nl);
    connBuf = connBuf.slice(nl + 1);
    let msg;
    try {
      msg = JSON.parse(line);
    } catch {
      continue;
    }
    if (msg.t === "answer") {
      waiting.get(msg.id)?.(msg);
      waiting.delete(msg.id);
    }
  }
});
var send = (obj) => process.stdout.write(JSON.stringify(obj) + "\n");
function askBroker(ask) {
  return new Promise((resolve) => {
    waiting.set(String(ask.id), resolve);
    if (conn.destroyed) return dead();
    try {
      conn.write(JSON.stringify(ask) + "\n");
    } catch {
      dead();
    }
  });
}
var ASK_USER_QUESTION = "AskUserQuestion";
var asRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value) ? value : null;
async function answerNativeQuestions(input) {
  const questions = normalizeAskUserInput(input);
  if (!questions?.length) {
    return JSON.stringify({
      behavior: "deny",
      message: "OpenMausBot: this AskUserQuestion call had no answerable question (each one needs question text), so nobody was shown it. Ask again with a well-formed call, or continue without it."
    });
  }
  const answer = await askBroker({
    t: "ask",
    id: randomUUID(),
    kind: "question",
    tool: ASK_USER_QUESTION,
    input: { questions }
  });
  if (answer.behavior === "deny") {
    return JSON.stringify({ behavior: "deny", message: answer.message || "Denied from OpenMausBot" });
  }
  const answers = answer.source === "user" && typeof answer.message === "string" ? questionAnswersByQuestion(answer.message, questions) : {};
  return JSON.stringify({ behavior: "allow", updatedInput: { ...asRecord(input), answers } });
}
var TOOLS = [
  {
    name: "approve",
    description: "Ask the OpenMausBot user whether a tool use is allowed",
    inputSchema: {
      type: "object",
      properties: {
        tool_name: { type: "string" },
        input: { type: "object" },
        tool_use_id: { type: "string" }
      },
      required: ["tool_name", "input"]
    }
  },
  {
    name: "ask_user",
    description: "Interactively ask the user a structured multiple-choice question, preference choice, or clarification \u2014 then continue the SAME task with their answer. Call this tool autonomously whenever the user's request is broad, ambiguous, or requires clarification or preference selection (such as recommendations, choosing products/services, selecting categories, scoping goals, deciding features, or picking preferences). NEVER write option menus, bulleted choices, or lettered lists as plain chat text. The phone UI renders this tool call as interactive, tappable choice cards. ONE question. type \u2014 single_choice (one pick), multiple_choice (several, with min/maxSelections), confirmation (yes/no), free_text (they type; omit choices). Give each option a stable snake_case id; the answer cites it. 4-8 options, each with a one-line description of when to choose it. Use multi-select for non-mutually exclusive choices. Returns their answer as text.",
    inputSchema: {
      type: "object",
      properties: {
        question: { type: "string", description: "The question, with enough context to answer at a glance" },
        type: {
          type: "string",
          enum: ["single_choice", "multiple_choice", "confirmation", "free_text"],
          description: "single_choice unless the question is really one of the others."
        },
        choices: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "string", maxLength: 40, description: "Stable snake_case id the answer will cite." },
              label: { type: "string", maxLength: 120 },
              description: { type: "string", maxLength: 400, description: "When to choose this, or what it implies." }
            },
            required: ["label"]
          },
          description: "The options, most likely first. Omit for free_text."
        },
        minSelections: { type: "integer", minimum: 0, maximum: 12, description: "multiple_choice: at least this many picks." },
        maxSelections: { type: "integer", minimum: 1, maximum: 12, description: "multiple_choice: at most this many picks." },
        required: { type: "boolean", default: true, description: "false lets the task continue without an answer." },
        allowOther: { type: "boolean", default: true, description: "false removes the free-text row from a choice question." }
      },
      required: ["question"]
    }
  }
];
async function handle(msg) {
  if (msg.method === "initialize") {
    return send({
      jsonrpc: "2.0",
      id: msg.id,
      result: {
        protocolVersion: msg.params?.protocolVersion ?? "2024-11-05",
        capabilities: { tools: {} },
        serverInfo: { name: "openmausbot-permissions", version: "1" }
      }
    });
  }
  if (msg.method === "tools/list") return send({ jsonrpc: "2.0", id: msg.id, result: { tools: TOOLS } });
  if (msg.method === "tools/call") {
    const name = msg.params?.name;
    const args = msg.params?.arguments ?? {};
    const reply = (text3) => send({ jsonrpc: "2.0", id: msg.id, result: { content: [{ type: "text", text: text3 }] } });
    if (name === "approve") {
      if (args.tool_name === ASK_USER_QUESTION) {
        return reply(await answerNativeQuestions(args.input));
      }
      const permCheck = checkPermissionForTool(String(args.tool_name ?? ""), args.input);
      if (!permCheck.allowed) {
        return reply(JSON.stringify({ behavior: "deny", message: permCheck.reason || "Permission Denied" }));
      }
    }
    const askId = randomUUID();
    const isQuestion = name === "ask_user";
    const suggestions = Array.isArray(args.permission_suggestions) ? args.permission_suggestions : Array.isArray(args.suggestions) ? args.suggestions : null;
    const normalized = isQuestion ? normalizeAskUserInput(args) : null;
    const answer = await askBroker(
      isQuestion ? {
        t: "ask",
        id: askId,
        kind: "question",
        tool: "ask_user",
        input: { question: args.question, choices: args.choices, ...normalized ? { questions: normalized } : {} }
      } : { t: "ask", id: askId, tool: args.tool_name, input: args.input }
    );
    let text2 = answer.message || "No answer was given \u2014 use your best judgment.";
    if (!isQuestion) {
      if (answer.behavior === "allow") {
        const result = { behavior: "allow", updatedInput: args.input ?? {} };
        if (answer.always && suggestions) result.updatedPermissions = suggestions;
        text2 = JSON.stringify(result);
      } else {
        text2 = JSON.stringify({ behavior: "deny", message: answer.message || "Denied from OpenMausBot" });
      }
    }
    return reply(text2);
  }
  if (String(msg.method ?? "").startsWith("notifications/")) return;
  if (msg.id != null) {
    send({ jsonrpc: "2.0", id: msg.id, error: { code: -32601, message: `method not found: ${msg.method}` } });
  }
}
var inBuf = "";
process.stdin.on("data", (chunk) => {
  inBuf += chunk;
  let nl;
  while ((nl = inBuf.indexOf("\n")) !== -1) {
    const line = inBuf.slice(0, nl);
    inBuf = inBuf.slice(nl + 1);
    if (!line.trim()) continue;
    try {
      void handle(JSON.parse(line));
    } catch {
    }
  }
});
process.stdin.on("end", () => process.exit(0));
