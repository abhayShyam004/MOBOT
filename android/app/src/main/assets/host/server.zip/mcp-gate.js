// server/mcp-gate.ts
import { spawn as spawn2 } from "node:child_process";
import { mkdirSync, readdirSync as readdirSync2, rmSync, statSync as statSync2, writeFileSync } from "node:fs";
import { join as join3 } from "node:path";
import { createInterface } from "node:readline";

// server/env-path.ts
import { execFile } from "node:child_process";
import { closeSync, existsSync, openSync, readFileSync, readSync, statSync, readdirSync } from "node:fs";
import { homedir } from "node:os";
import { basename, delimiter, dirname, extname, join } from "node:path";
function nvmBinDirs() {
  try {
    const base = join(homedir(), ".nvm", "versions", "node");
    return readdirSync(base).filter((v) => v.startsWith("v")).sort((a, b) => b.localeCompare(a, void 0, { numeric: true })).map((v) => join(base, v, "bin"));
  } catch {
    return [];
  }
}
function knownDirs() {
  const home = homedir();
  return [
    join(home, ".local", "bin"),
    // claude installer default
    join(home, ".npm-global", "bin"),
    // npm prefix ~/.npm-global (claude, opencode)
    join(home, ".kimi-code", "bin"),
    // kimi-code installer
    join(home, ".grok", "bin"),
    // x.ai installer
    join(home, ".opencode", "bin"),
    // opencode installer
    join(home, ".claude", "local"),
    // claude "local install"
    "/opt/homebrew/bin",
    // brew, Apple silicon
    "/usr/local/bin",
    // brew Intel / classic installs
    join(home, ".volta", "bin"),
    join(home, ".bun", "bin"),
    join(home, ".asdf", "shims"),
    join(home, ".deno", "bin"),
    join(home, "bin"),
    ...nvmBinDirs()
  ];
}
function windowsKnownDirs() {
  const home = homedir();
  const appData = process.env.APPDATA ?? join(home, "AppData", "Roaming");
  const localAppData = process.env.LOCALAPPDATA ?? join(home, "AppData", "Local");
  return [
    join(appData, "npm"),
    // npm -g shims: claude, codex
    join(home, ".grok", "bin"),
    // x.ai installer
    join(localAppData, "agy", "bin"),
    // Antigravity installer
    join(home, ".local", "bin"),
    // claude native installer
    join(home, ".claude", "local"),
    join(home, "bin"),
    // Factory droid installer (%USERPROFILE%\bin)
    join(home, ".bun", "bin"),
    join(home, ".deno", "bin"),
    join(home, "go", "bin")
  ];
}
var cached = null;
var probed = false;
var loginShellPath = null;
var registeredDirs = [];
function augmentedPath() {
  if (cached === null) {
    cached = mergePaths([
      ...registeredDirs.filter((d) => existsSync(d)),
      ...process.env.OMB_EXTRA_PATH ? process.env.OMB_EXTRA_PATH.split(delimiter) : [],
      ...process.env.PATH ? process.env.PATH.split(delimiter) : [],
      // Keep the last successful login-shell result while a rescan starts a
      // fresh asynchronous probe. Otherwise resetPathCache() would make
      // rc-only CLIs disappear again for the response that triggered it.
      ...loginShellPath ? loginShellPath.split(delimiter) : [],
      // Both platforms scan their standard install locations; only the
      // login-shell probe below stays unix-only, since Windows has no
      // equivalent rc file to source.
      ...(process.platform === "win32" ? windowsKnownDirs() : knownDirs()).filter((d) => existsSync(d))
    ]);
  }
  if (!probed && !process.env.VITEST && process.platform !== "win32") {
    probed = true;
    probeLoginShellPath();
  }
  return cached;
}
function mergePaths(parts) {
  return [...new Set(parts.filter(Boolean))].join(delimiter);
}
function probeLoginShellPath() {
  const shell = process.env.SHELL || "/bin/zsh";
  execFile(
    shell,
    ["-l", "-i", "-c", 'printf "__OMB_PATH__%s" "$PATH"'],
    { timeout: 5e3 },
    (err, stdout) => {
      if (err || !stdout) return;
      const m = /__OMB_PATH__([^\n]*)/.exec(stdout);
      if (!m || !m[1]) return;
      loginShellPath = m[1];
      cached = mergePaths([...(cached ?? "").split(delimiter), ...m[1].split(delimiter)]);
    }
  );
}
function splitCliString(cli) {
  const out = [];
  let cur = "";
  let quote = null;
  for (const ch of cli.trim()) {
    if (quote) {
      if (ch === quote) quote = null;
      else cur += ch;
    } else if (ch === '"' || ch === "'") {
      quote = ch;
    } else if (/\s/.test(ch)) {
      if (cur) out.push(cur);
      cur = "";
    } else {
      cur += ch;
    }
  }
  if (cur) out.push(cur);
  return out;
}
function isFile(p) {
  try {
    return statSync(p, { throwIfNoEntry: false })?.isFile() ?? false;
  } catch {
    return false;
  }
}
function whichWin(cli, env) {
  const exts = ((env ?? process.env).PATHEXT ?? ".COM;.EXE;.BAT;.CMD").split(";").filter(Boolean);
  const probe = (base) => {
    const order = extname(base) ? [base, ...exts.map((e) => base + e)] : [...exts.map((e) => base + e), base];
    return order.find(isFile) ?? null;
  };
  if (/[\\/]/.test(cli) || /^[a-zA-Z]:/.test(cli)) return probe(cli);
  const path = env ? env.PATH ?? env.Path ?? "" : augmentedPath();
  for (const dir of path.split(delimiter)) {
    if (!dir) continue;
    const hit = probe(join(dir, cli));
    if (hit) return hit;
  }
  return null;
}
function nodeExe(near, env) {
  const local = join(near, "node.exe");
  if (isFile(local)) return local;
  const onPath = whichWin("node.exe", env);
  if (onPath && extname(onPath).toLowerCase() === ".exe") return onPath;
  return process.versions.electron ? null : process.execPath;
}
function parseCmdShim(shim, env) {
  let text;
  try {
    text = readFileSync(shim, "utf8");
  } catch {
    return null;
  }
  const dir = dirname(shim);
  const npmEntry = /^SET "NP[MX]_CLI_JS=%~dp0\\([^"]+)"/im.exec(text);
  const targets = [...npmEntry ? [npmEntry] : [], ...text.matchAll(/"%~?dp0%?\\?([^"]+)"/g)].map((m) => join(dir, m[1])).filter((p) => isFile(p) && basename(p).toLowerCase() !== "node.exe");
  const script = targets.find((p) => /\.[cm]?js$/i.test(p));
  if (script) {
    const node = nodeExe(dir, env);
    if (node) return { command: node, args: [script] };
  }
  const exe = targets.find((p) => extname(p).toLowerCase() === ".exe");
  return exe ? { command: exe, args: [] } : null;
}
function parseNodeShebang(file, env) {
  let head = "";
  let fd = null;
  try {
    fd = openSync(file, "r");
    const buf = Buffer.alloc(128);
    const n = readSync(fd, buf, 0, buf.length, 0);
    head = buf.subarray(0, n).toString("utf8").split("\n", 1)[0];
  } catch {
    return null;
  } finally {
    if (fd !== null) {
      try {
        closeSync(fd);
      } catch {
      }
    }
  }
  if (!/^#!.*\bnode(\.exe)?\b/.test(head)) return null;
  const node = nodeExe(dirname(file), env);
  return node ? { command: node, args: [file] } : null;
}
function resolveWord(cli, args, env) {
  if (process.platform !== "win32") return { command: cli, args };
  const file = whichWin(cli, env);
  if (!file) return { command: cli, args };
  const ext = extname(file).toLowerCase();
  if (ext === ".cmd" || ext === ".bat") {
    const direct = parseCmdShim(file, env);
    return direct ? { command: direct.command, args: [...direct.args, ...args] } : { command: file, args };
  }
  if (ext === ".exe" || ext === ".com") return { command: file, args };
  const viaNode = parseNodeShebang(file, env);
  return viaNode ? { command: viaNode.command, args: [...viaNode.args, ...args] } : { command: file, args };
}
function resolveCliSpawn(cli, args, env) {
  const trimmed = cli.trim();
  if (trimmed.includes(" ") && existsSync(trimmed)) return resolveWord(trimmed, args, env);
  const split = splitCliString(cli);
  if (split.length > 1 || split[0] !== trimmed) {
    const [head, ...fixed] = split;
    if (!head) return { command: cli, args };
    return resolveWord(head, [...fixed, ...args], env);
  }
  return resolveWord(cli, args, env);
}

// server/mcp-trim.ts
var DEFAULT_RESULT_BUDGET = 8e3;
var MIN_BUDGET = 512;
var fmt = (n) => n.toLocaleString("en-US");
function serialize(value) {
  try {
    const json = JSON.stringify(value);
    return typeof json === "string" ? json : null;
  } catch {
    return null;
  }
}
function fitArray(items, budget) {
  const kept = [];
  let used = 2;
  for (const item of items) {
    const json = serialize(item);
    if (json === null) break;
    const cost = json.length + (kept.length ? 1 : 0);
    if (kept.length && used + cost > budget) break;
    kept.push(item);
    used += cost;
  }
  return kept;
}
function arrayFields(value) {
  if (Array.isArray(value)) return [{ key: "", items: value }];
  if (!value || typeof value !== "object") return [];
  return Object.entries(value).filter((entry) => Array.isArray(entry[1])).map(([key, items]) => ({ key, items }));
}
function cutAt(text, chars) {
  const cut = text.slice(0, Math.max(0, chars));
  const last = cut.charCodeAt(cut.length - 1);
  return last >= 55296 && last <= 56319 ? cut.slice(0, -1) : cut;
}
function marker(input) {
  const counts = input.dropped.filter((d) => d.kept < d.total).map((d) => `${d.key || "items"} ${fmt(d.kept)} of ${fmt(d.total)}`).join(", ");
  const what = input.structural ? counts ? ` Kept ${counts}.` : "" : " Cut mid-text, so what is above may be incomplete JSON.";
  const where = input.spillHint && input.spillPath ? ` The whole result is at ${JSON.stringify(input.spillPath)}; reading it costs as much as not trimming, so narrow the call first.` : " If you need more, call the tool again with a narrower query, a filter, or the next page.";
  return `

[OpenMausBot trimmed this tool result to fit the conversation: ${fmt(input.originalChars)} \u2192 ${fmt(input.keptChars)} characters.${what}${where}]`;
}
function trimStructured(parsed, budget) {
  const room = Math.max(MIN_BUDGET, budget);
  const current = serialize(parsed);
  if (current !== null && current.length <= room) return null;
  const fields = arrayFields(parsed);
  if (!fields.length) return null;
  const skeleton = Array.isArray(parsed) ? 2 : serialize({ ...parsed, ...Object.fromEntries(fields.map((f) => [f.key, []])) })?.length ?? Infinity;
  const share = Math.floor((room - skeleton) / fields.length);
  if (!Number.isFinite(skeleton) || share <= 0) return null;
  const dropped = [];
  let value;
  if (Array.isArray(parsed)) {
    const kept = fitArray(parsed, share);
    dropped.push({ key: "", kept: kept.length, total: parsed.length });
    value = kept;
  } else {
    const next = { ...parsed };
    for (const field of fields) {
      const kept = fitArray(field.items, share);
      dropped.push({ key: field.key, kept: kept.length, total: field.items.length });
      next[field.key] = kept;
    }
    value = next;
  }
  if (!dropped.some((d) => d.kept < d.total)) return null;
  const json = serialize(value);
  return json !== null && json.length <= room ? { value, dropped } : null;
}
function trimResultText(input) {
  const { text } = input;
  const budget = Math.max(MIN_BUDGET, input.budget ?? DEFAULT_RESULT_BUDGET);
  if (text.length <= budget) return { text, trimmed: false, originalChars: text.length };
  const room = Math.max(MIN_BUDGET, budget - 400);
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    parsed = void 0;
  }
  const fields = parsed === void 0 ? [] : arrayFields(parsed);
  if (fields.length) {
    const skeleton = Array.isArray(parsed) ? 2 : serialize({ ...parsed, ...Object.fromEntries(fields.map((f) => [f.key, []])) })?.length ?? Infinity;
    const share = Math.floor((room - skeleton) / fields.length);
    if (Number.isFinite(skeleton) && share > 0) {
      const dropped = [];
      let value;
      if (Array.isArray(parsed)) {
        const kept = fitArray(parsed, share);
        dropped.push({ key: "", kept: kept.length, total: parsed.length });
        value = kept;
      } else {
        const next = { ...parsed };
        for (const field of fields) {
          const kept = fitArray(field.items, share);
          dropped.push({ key: field.key, kept: kept.length, total: field.items.length });
          next[field.key] = kept;
        }
        value = next;
      }
      const json = serialize(value);
      if (json !== null && json.length <= room) {
        return {
          text: json + marker({ originalChars: text.length, keptChars: json.length, dropped, spillPath: input.spillPath, spillHint: input.spillHint, structural: true }),
          trimmed: true,
          originalChars: text.length
        };
      }
    }
  }
  const cut = cutAt(text, room);
  return {
    text: cut + marker({ originalChars: text.length, keptChars: cut.length, dropped: [], spillPath: input.spillPath, spillHint: input.spillHint, structural: false }),
    trimmed: true,
    originalChars: text.length
  };
}

// server/permission-policy.ts
import { existsSync as existsSync2, readFileSync as readFileSync2 } from "node:fs";
import { join as join2 } from "node:path";
var ERR_CROSS_BOT_MEMORY_LEAK = "ERR_CROSS_BOT_MEMORY_LEAK";
var VALID_BOT_ID = /^[\w-]{1,128}$/;
function checkMemoryAccessPermission(req) {
  const { requestingBotId, targetBotId, operation, path } = req;
  if (!requestingBotId || !VALID_BOT_ID.test(requestingBotId)) {
    return {
      allowed: false,
      error: `${ERR_CROSS_BOT_MEMORY_LEAK}: Invalid or unknown requesting botId "${requestingBotId}".`,
      category: "permission_denied"
    };
  }
  if (path) {
    let clean;
    try {
      clean = decodeURIComponent(path).replace(/\\/g, "/");
    } catch {
      return {
        allowed: false,
        error: `${ERR_CROSS_BOT_MEMORY_LEAK}: Malformed encoded path "${path}".`,
        category: "permission_denied"
      };
    }
    const segments = clean.split("/");
    if (segments.some((s) => s === ".." || s === "." && clean !== ".")) {
      return {
        allowed: false,
        error: `${ERR_CROSS_BOT_MEMORY_LEAK}: Path traversal blocked in memory path "${path}".`,
        category: "permission_denied"
      };
    }
    const botMatch = clean.match(/^(?:bots\/|workspaces\/)([\w-]+)\//);
    if (botMatch && botMatch[1] !== requestingBotId && botMatch[1] !== "shared") {
      return {
        allowed: false,
        error: `${ERR_CROSS_BOT_MEMORY_LEAK}: Cross-bot path access blocked from "${requestingBotId}" to "${botMatch[1]}".`,
        category: "permission_denied"
      };
    }
  }
  if (targetBotId === "shared") {
    return { allowed: true };
  }
  if (targetBotId !== requestingBotId) {
    return {
      allowed: false,
      error: `${ERR_CROSS_BOT_MEMORY_LEAK}: Bot "${requestingBotId}" cannot ${operation} private memory partition of Bot "${targetBotId}".`,
      category: "permission_denied"
    };
  }
  return { allowed: true };
}
var PERMISSION_DOMAINS = {
  terminal: {
    id: "terminal",
    title: "Terminal & Shell Execution",
    description: "Allows MOBOT to run shell commands, scripts, and subprocesses."
  },
  filesystem: {
    id: "filesystem",
    title: "Filesystem Read & Write",
    description: "Allows MOBOT to read, create, edit, and delete workspace files."
  },
  browser: {
    id: "browser",
    title: "Browser & Network",
    description: "Allows MOBOT to search the web, fetch URLs, and use browser automation."
  },
  composio: {
    id: "composio",
    title: "Composio Integrations",
    description: "Allows MOBOT to invoke third-party actions on connected apps."
  }
};
var TERMINAL_TOOL_NAMES = /* @__PURE__ */ new Set([
  "Bash",
  "bash",
  "sh",
  "run_command",
  "run_shell",
  "open_interactive",
  "terminal_start",
  "terminal_write",
  "terminal_read",
  "terminal_resize",
  "terminal_close",
  "terminal_list",
  "pty",
  "shell_exec",
  "process_start",
  "process_stop",
  "process_list",
  "process_status",
  "process_signal",
  "project_run",
  "project_build",
  "port_forward_create",
  "port_forward_list",
  "port_forward_close"
]);
var PHONE_TOOL_NAMES = /* @__PURE__ */ new Set([
  "status",
  "read_screen",
  "screenshot",
  "list_apps",
  "open_app",
  "tap_text",
  "tap",
  "swipe",
  "type_text",
  "clear_text",
  "press"
]);
var FILESYSTEM_TOOL_NAMES = /* @__PURE__ */ new Set([
  "ReadFile",
  "WriteFile",
  "EditFile",
  "GlobTool",
  "GrepTool",
  "workspace_list",
  "workspace_read",
  "workspace_write",
  "workspace_append",
  "workspace_mkdir",
  "workspace_move",
  "workspace_copy",
  "workspace_delete",
  "workspace_stat",
  "workspace_exists",
  "file_read",
  "file_write",
  "file_delete",
  "device.files",
  "artifact_create",
  "artifact_read",
  "artifact_write",
  "artifact_delete",
  "artifact_list",
  "project_create",
  "resource_extract_pdf_text",
  "resource_extract_pdf",
  "resource_artifact_info",
  "resource_list"
]);
var BROWSER_TOOL_NAMES = /* @__PURE__ */ new Set([
  "http_fetch",
  "web_search",
  "Fetch",
  "WebSearch",
  "resource_inspect",
  "resource_fetch",
  "resource_download",
  "resource_extract_links",
  "resource_extract_html",
  "resource_artifacts",
  "browser_open",
  "browser_navigate",
  "browser_status",
  "browser_back",
  "browser_forward",
  "browser_get_text",
  "browser_dom",
  "browser_click",
  "browser_type",
  "browser_eval",
  "browser_screenshot",
  "browser_cookies",
  "browser_clear",
  "browser_close",
  "browser_persist",
  "browser_scroll",
  "browser_fill",
  "browser_tabs",
  "browser_press",
  "browser_hover",
  "browser_evaluate"
]);
var KNOWN_BROWSER_ACTIONS = /* @__PURE__ */ new Set([
  "open",
  "navigate",
  "status",
  "back",
  "forward",
  "get_text",
  "dom",
  "click",
  "type",
  "eval",
  "screenshot",
  "cookies",
  "clear",
  "close",
  "persist",
  "scroll",
  "fill",
  "tabs",
  "press",
  "hover",
  "evaluate"
]);
var SYSTEM_TOOL_NAMES = /* @__PURE__ */ new Set([
  "ask_user",
  "AskUserQuestion",
  "coordinate_bots",
  "delegate_bot",
  "approve",
  "environment_discover",
  "environment_list",
  "environment_set",
  "environment_remove",
  "package_status",
  "device_capability_list",
  "device_capability_describe"
]);
function stripMcpPrefix(name) {
  const mcpMatch = /^mcp__[a-zA-Z0-9_-]+__(.+)$/i.exec(name);
  if (mcpMatch) return mcpMatch[1];
  const abMatch = /^android_browser_(.+)$/i.exec(name);
  if (abMatch) return abMatch[1];
  const acMatch = /^android_computer_(.+)$/i.exec(name);
  if (acMatch) return acMatch[1];
  return name;
}
function classifyTool(toolName, args) {
  const normalized = toolName.trim();
  const stripped = stripMcpPrefix(normalized);
  if (SYSTEM_TOOL_NAMES.has(normalized) || SYSTEM_TOOL_NAMES.has(stripped) || /^(plan_|task_)/i.test(normalized) || /^(plan_|task_)/i.test(stripped)) {
    return { domain: "system", label: "System Collaboration" };
  }
  if (normalized === "device_capability_invoke" || stripped === "device_capability_invoke") {
    if (args) {
      const capId = String(args.capabilityId || "");
      if (capId === "device.files") return { domain: "filesystem", label: PERMISSION_DOMAINS.filesystem.title };
      if (capId === "device.browser" || capId === "device.network") return { domain: "browser", label: PERMISSION_DOMAINS.browser.title };
      if (capId.startsWith("device.")) return { domain: "system", label: "Device Native Capability" };
    }
    return { domain: "system", label: "Device Native Capability" };
  }
  const isAuthenticBrowser = BROWSER_TOOL_NAMES.has(normalized) || BROWSER_TOOL_NAMES.has(stripped) || stripped.startsWith("browser_") && KNOWN_BROWSER_ACTIONS.has(stripped.slice("browser_".length)) || KNOWN_BROWSER_ACTIONS.has(stripped) || /^(preview_|deployment_|verify_service)/i.test(normalized) || /^(preview_|deployment_|verify_service)/i.test(stripped);
  if (normalized.startsWith("android_browser_") || normalized.startsWith("mcp__android_browser__")) {
    if (isAuthenticBrowser) {
      return { domain: "browser", label: PERMISSION_DOMAINS.browser.title };
    }
    return { domain: "unknown", label: "Unclassified Tool" };
  }
  if (normalized.startsWith("android_computer_") || normalized.startsWith("mcp__android_computer__")) {
    if (isAuthenticBrowser) {
      return { domain: "browser", label: PERMISSION_DOMAINS.browser.title };
    }
    if (TERMINAL_TOOL_NAMES.has(stripped) || PHONE_TOOL_NAMES.has(stripped) || /^(bash|sh|terminal_|shell_|exec_|process_|build_|test_|project_git_|repair_|phone_)/i.test(stripped)) {
      return { domain: "terminal", label: PERMISSION_DOMAINS.terminal.title };
    }
    if (FILESYSTEM_TOOL_NAMES.has(stripped) || /^(fs_|file_|workspace_|artifact_|project_(create|open|read|write|patch|delete|rename|list)|verify_file|verify_artifact|verify_image)/i.test(stripped)) {
      return { domain: "filesystem", label: PERMISSION_DOMAINS.filesystem.title };
    }
    return { domain: "unknown", label: "Unclassified Tool" };
  }
  if (isAuthenticBrowser) {
    return { domain: "browser", label: PERMISSION_DOMAINS.browser.title };
  }
  if (TERMINAL_TOOL_NAMES.has(normalized) || TERMINAL_TOOL_NAMES.has(stripped) || PHONE_TOOL_NAMES.has(normalized) || PHONE_TOOL_NAMES.has(stripped) || /^(bash|sh|terminal_|shell_|exec_|process_|build_|test_|project_git_|repair_|mcp__openmausbot-phone__|phone_)/i.test(normalized) || /^(bash|sh|terminal_|shell_|exec_|process_|build_|test_|project_git_|repair_|phone_)/i.test(stripped)) {
    return { domain: "terminal", label: PERMISSION_DOMAINS.terminal.title };
  }
  if (FILESYSTEM_TOOL_NAMES.has(normalized) || FILESYSTEM_TOOL_NAMES.has(stripped) || /^(fs_|file_|workspace_|artifact_|project_(create|open|read|write|patch|delete|rename|list)|verify_file|verify_artifact|verify_image)/i.test(normalized) || /^(fs_|file_|workspace_|artifact_|project_(create|open|read|write|patch|delete|rename|list)|verify_file|verify_artifact|verify_image)/i.test(stripped)) {
    return { domain: "filesystem", label: PERMISSION_DOMAINS.filesystem.title };
  }
  if (normalized.startsWith("mcp__composio") || normalized.startsWith("composio_") || stripped.startsWith("composio_") || /^composio/i.test(normalized) || /^composio/i.test(stripped)) {
    return { domain: "composio", label: PERMISSION_DOMAINS.composio.title };
  }
  return { domain: "unknown", label: "Unclassified Tool" };
}
function checkToolPermission(toolName, permissions, args, extra) {
  const classification = classifyTool(toolName, args);
  if (classification.domain === "system") {
    return { allowed: true, reason: "" };
  }
  if (classification.domain === "unknown") {
    return {
      allowed: false,
      reason: `Unclassified tool "${toolName}" is blocked by security policy.`,
      domain: void 0
    };
  }
  const domain = classification.domain;
  const state = permissions?.[domain] ?? "granted";
  if (domain === "terminal") {
    if (state === "denied") {
      return {
        allowed: false,
        reason: "Terminal & Shell Execution is disabled in Settings -> Agent Permissions.",
        domain: "terminal",
        state: "denied"
      };
    }
    if (state === "restricted") {
      return {
        allowed: false,
        reason: "Terminal execution is restricted by the current environment.",
        domain: "terminal",
        state: "restricted"
      };
    }
    return { allowed: true, reason: "", domain: "terminal", state };
  }
  if (domain === "filesystem") {
    if (state === "denied") {
      return {
        allowed: false,
        reason: "Filesystem Read & Write is disabled in Settings -> Agent Permissions.",
        domain: "filesystem",
        state: "denied"
      };
    }
    if (state === "restricted") {
      return {
        allowed: false,
        reason: "Filesystem operations are restricted by the current environment.",
        domain: "filesystem",
        state: "restricted"
      };
    }
    const requestingBot = extra?.requestingBotId ?? extra?.botId ?? (typeof args?.requestingBotId === "string" ? args.requestingBotId : void 0);
    const pathArg = typeof args?.path === "string" ? args.path : typeof args?.filePath === "string" ? args.filePath : void 0;
    if (requestingBot && pathArg) {
      const memCheck = checkMemoryAccessPermission({
        requestingBotId: String(requestingBot),
        targetBotId: String(requestingBot),
        operation: "read",
        path: pathArg
      });
      if (!memCheck.allowed) {
        return {
          allowed: false,
          reason: memCheck.error ?? `${ERR_CROSS_BOT_MEMORY_LEAK}: Cross-bot memory access blocked.`,
          domain: "filesystem",
          state: "denied"
        };
      }
    }
    return { allowed: true, reason: "", domain: "filesystem", state };
  }
  if (domain === "browser") {
    if (state === "denied") {
      return {
        allowed: false,
        reason: "Browser & Network is disabled in Settings -> Agent Permissions.",
        domain: "browser",
        state: "denied"
      };
    }
    if (state === "restricted") {
      return {
        allowed: false,
        reason: "Browser automation is restricted by the current environment.",
        domain: "browser",
        state: "restricted"
      };
    }
    return { allowed: true, reason: "", domain: "browser", state };
  }
  if (domain === "composio") {
    if (state === "denied") {
      return {
        allowed: false,
        reason: "Composio Integrations is disabled in Settings -> Agent Permissions.",
        domain: "composio",
        state: "denied"
      };
    }
    if (extra?.composioConfigured === false || state === "requires_configuration") {
      return {
        allowed: false,
        reason: "Composio capability requires configuration in Settings -> Connected Services.",
        domain: "composio",
        state: "requires_configuration"
      };
    }
    return { allowed: true, reason: "", domain: "composio", state };
  }
  return { allowed: true, reason: "" };
}
function loadDiskPermissions() {
  try {
    const dataDir = process.env.OMB_DATA_DIR || (process.env.HOME ? join2(process.env.HOME, ".openmausbot") : "");
    if (!dataDir) return {};
    const configPath = join2(dataDir, "config.json");
    if (!existsSync2(configPath)) return {};
    const raw = JSON.parse(readFileSync2(configPath, "utf-8"));
    return raw.agentPermissions ?? {};
  } catch {
    return {};
  }
}

// server/procs.ts
import {
  spawn,
  execFile as execFile2
} from "node:child_process";
var cliGroups = /* @__PURE__ */ new WeakSet();
var stopping = /* @__PURE__ */ new WeakMap();
function killCliTree(child2, timeoutMs = 5e3) {
  const existing = stopping.get(child2);
  if (existing) return existing;
  const pid = child2.pid;
  if (!pid) return Promise.resolve(true);
  if (!Number.isInteger(pid) || pid <= 1 || pid === process.pid) return Promise.resolve(false);
  const run = stopCliTree(child2, pid, Number.isFinite(timeoutMs) ? Math.max(0, timeoutMs) : 5e3);
  stopping.set(child2, run);
  void run.then((stopped) => {
    if (!stopped) stopping.delete(child2);
  });
  return run;
}
async function stopCliTree(child2, pid, timeoutMs) {
  const exited = () => child2.exitCode !== null || child2.signalCode !== null;
  if (process.platform !== "win32") {
    const group = cliGroups.has(child2);
    const settled = () => {
      if (!exited()) return false;
      if (!group) return true;
      try {
        process.kill(-pid, 0);
        return false;
      } catch (error) {
        return error.code === "ESRCH";
      }
    };
    const signal = (value) => {
      try {
        if (group) process.kill(-pid, value);
        else child2.kill(value);
      } catch {
        try {
          child2.kill(value);
        } catch {
        }
      }
    };
    const wait = async (ms) => {
      const deadline = Date.now() + ms;
      while (!settled()) {
        const remaining = deadline - Date.now();
        if (remaining <= 0) return false;
        await new Promise((resolve) => setTimeout(resolve, Math.min(25, remaining)));
      }
      return true;
    };
    if (settled()) return true;
    signal("SIGTERM");
    if (await wait(timeoutMs)) return true;
    signal("SIGKILL");
    return wait(1e3);
  }
  if (exited()) return true;
  return new Promise((resolve) => {
    let timer;
    let finished = false;
    const done = (stopped) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      child2.off("close", closed);
      child2.off("exit", closed);
      resolve(stopped);
    };
    const closed = () => done(true);
    child2.once("close", closed);
    timer = setTimeout(() => done(false), timeoutMs);
    timer.unref?.();
    execFile2("taskkill", ["/PID", String(pid), "/T", "/F"], { windowsHide: true }, (err) => {
      if (finished) return;
      if (!err) {
        if (exited()) done(true);
        else child2.once("exit", closed);
        return;
      }
      try {
        child2.kill();
      } catch {
      }
    });
  });
}

// server/mcp-gate.ts
var NAME = process.env.OMB_GATE_NAME || "mcp";
var SPILL_DIR = process.env.OMB_GATE_SPILL_DIR || "";
var BUDGET = Number(process.env.OMB_GATE_BUDGET) > 0 ? Number(process.env.OMB_GATE_BUDGET) : DEFAULT_RESULT_BUDGET;
var SPILL_MAX_AGE_MS = 24 * 60 * 6e4;
var SPILL_HINT = process.env.OMB_GATE_SPILL_HINT === "1";
var GATE_ENV_KEYS = ["OMB_GATE_NAME", "OMB_GATE_SPILL_DIR", "OMB_GATE_BUDGET", "OMB_GATE_UPSTREAM", "OMB_GATE_SPILL_HINT"];
function fail(message) {
  process.stderr.write(`mcp-gate(${NAME}): ${message}
`);
  process.exit(1);
}
function upstreamSpec() {
  let parsed;
  try {
    parsed = JSON.parse(process.env.OMB_GATE_UPSTREAM ?? "");
  } catch {
    fail("OMB_GATE_UPSTREAM is not valid JSON");
  }
  const spec2 = parsed;
  if (!spec2 || typeof spec2 !== "object" || typeof spec2.command !== "string" || !spec2.command) {
    fail("OMB_GATE_UPSTREAM needs a command");
  }
  return spec2;
}
function sweepSpill(dir) {
  let entries;
  try {
    entries = readdirSync2(dir);
  } catch {
    return;
  }
  const cutoff = Date.now() - SPILL_MAX_AGE_MS;
  for (const entry of entries) {
    try {
      const path = join3(dir, entry);
      if (statSync2(path).mtimeMs < cutoff) rmSync(path, { force: true });
    } catch {
    }
  }
}
var spilled = 0;
function spill(tool, text) {
  if (!SPILL_DIR) return void 0;
  const safeTool = tool.replace(/[^A-Za-z0-9_.-]/g, "-").slice(0, 60) || "tool";
  const path = join3(SPILL_DIR, `${Date.now()}-${process.pid}-${spilled++}-${safeTool}.json`);
  try {
    mkdirSync(SPILL_DIR, { recursive: true, mode: 448 });
    writeFileSync(path, text, { mode: 384 });
    return path;
  } catch (error) {
    process.stderr.write(`mcp-gate(${NAME}): could not save the full result: ${String(error)}
`);
    return void 0;
  }
}
function trimCallResult(result, tool) {
  const content = result.content;
  if (!Array.isArray(content)) return false;
  const textBlocks = content.filter(
    (block) => Boolean(block) && typeof block === "object" && block.type === "text" && typeof block.text === "string"
  );
  const total = textBlocks.reduce((sum, block) => sum + block.text.length, 0);
  if (!textBlocks.length || total <= BUDGET) return false;
  const share = Math.floor(BUDGET / textBlocks.length);
  const path = spill(tool, textBlocks.map((block) => block.text).join("\n"));
  let trimmed = false;
  for (const block of textBlocks) {
    const outcome = trimResultText({ text: block.text, budget: share, spillPath: path, spillHint: SPILL_HINT, toolName: tool });
    if (!outcome.trimmed) continue;
    block.text = outcome.text;
    trimmed = true;
  }
  if (trimmed && result.structuredContent && typeof result.structuredContent === "object") {
    const structured = trimStructured(result.structuredContent, BUDGET);
    if (structured) result.structuredContent = structured.value;
  }
  return trimmed;
}
var spec = upstreamSpec();
if (SPILL_DIR) sweepSpill(SPILL_DIR);
var childEnv = { ...process.env, ...spec.env };
for (const key of GATE_ENV_KEYS) delete childEnv[key];
var resolved = resolveCliSpawn(spec.command, spec.args ?? []);
var child = spawn2(resolved.command, resolved.args, {
  stdio: ["pipe", "pipe", "pipe"],
  env: childEnv,
  shell: false,
  // a console app spawned from the desktop shell flashes a window otherwise
  ...process.platform === "win32" ? { windowsHide: true } : {}
});
var reaping = false;
var reapChild = () => {
  if (reaping) return;
  reaping = true;
  void killCliTree(child);
};
process.on("SIGTERM", () => {
  reapChild();
  process.exit(0);
});
process.on("SIGINT", () => {
  reapChild();
  process.exit(0);
});
process.on("exit", reapChild);
child.on("error", (error) => {
  process.stderr.write(`mcp-gate(${NAME}): could not start ${resolved.command}: ${String(error)}
`);
  process.exit(1);
});
child.stderr.pipe(process.stderr);
var pending = /* @__PURE__ */ new Map();
createInterface({ input: process.stdin }).on("line", (line) => {
  if (line.trim()) {
    try {
      const message = JSON.parse(line);
      if (message.method === "tools/call" && message.id !== void 0 && message.id !== null) {
        const params = message.params;
        const toolName = typeof params?.name === "string" ? params.name : "tool";
        const args = params?.arguments ?? {};
        const perm = checkToolPermission(toolName, loadDiskPermissions(), args);
        if (!perm.allowed) {
          process.stdout.write(
            JSON.stringify({
              jsonrpc: "2.0",
              id: message.id,
              result: {
                content: [{ type: "text", text: perm.reason || "Permission Denied" }],
                isError: true
              }
            }) + "\n"
          );
          return;
        }
        pending.set(String(message.id), toolName);
      }
    } catch {
    }
  }
  child.stdin.write(`${line}
`);
});
process.stdin.on("end", () => child.stdin.end());
createInterface({ input: child.stdout }).on("line", (line) => {
  if (!line.trim()) return;
  let message;
  try {
    message = JSON.parse(line);
  } catch {
    process.stdout.write(`${line}
`);
    return;
  }
  const id = message.id === void 0 || message.id === null ? void 0 : String(message.id);
  const tool = id === void 0 ? void 0 : pending.get(id);
  if (id !== void 0) pending.delete(id);
  const result = message.result;
  if (tool && result && typeof result === "object" && !Array.isArray(result)) {
    try {
      if (trimCallResult(result, tool)) {
        process.stderr.write(`mcp-gate(${NAME}): trimmed ${tool} to ${BUDGET} chars
`);
      }
    } catch (error) {
      process.stderr.write(`mcp-gate(${NAME}): could not trim ${tool}: ${String(error)}
`);
      process.stdout.write(`${line}
`);
      return;
    }
  }
  process.stdout.write(`${JSON.stringify(message)}
`);
});
child.on("exit", (code, signal) => process.exit(code ?? (signal ? 1 : 0)));
